// Bean 1.1.7 - the order queue glue (popup AND hidden runner run this file; lib/orders.js holds the logic, ARCHITECTURE.md section 17).
//   p9bn.orders   the queue + history ........ the EXECUTOR (the page that holds the lease: the runner while its heartbeat is fresh, else the popup)
//   p9bn.ordin    popup requests (submit/cancel/move/retry/clear-history) ........ the popup
//   p9bn.ordack   what the executor did with each request ........ the executor
//   p9bn.ordlease who is the executor ........ the executor
//   p9bn.ui       which Orders panels are collapsed ........ the popup
//   p9bn.pbeat    the popup is open (so the runner may adopt a run the popup can no longer drive) ........ the popup
(() => {
  'use strict';
let probeAt = 0, freezeUntil = 0;      // 1.1.7: see stale()
  const O = self.P9BEAN_ORD, E = self.P9BEAN_ERR, B = self.B11;
  if (!O || !E || !B || typeof B.executor !== 'function') return;
  const ROLE = B.ROLE, me = ROLE + '-' + Math.random().toString(36).slice(2, 8), now = () => Date.now();
  const S17 = { disp: null, pre: new Map(), lastRep: {}, firstRep: {}, pumping: false, held: false, err: '', timer: 0, claims: {} };
  const fnv = (str, seed) => { let h = seed >>> 0; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h; };
  const hash64 = (str) => fnv(str, 0x811c9dc5).toString(36) + fnv(str, 0x9747b28c).toString(36);
  const markerExists = async (vid, lc, ckey) => { const k = 'p9bn.clk.' + hash64(vid + '|' + lc + '|' + ckey); return (await sget(k)) != null; };
  const io = { get: sget, set: (k, v) => chrome.storage.local.set({ [k]: v }) };          // the lease / inbox / ack / orders are their own keys: they never touch lastWriteAt of the run record

  const batchOf = async (o) => { const b = await sget(K.batch); return b && (b.order === o.id || (o.batchId && b.id === o.batchId)) ? b : null; };
  const waitIdle = async (o, ms) => {
    for (let t0 = now(); now() - t0 < ms; await sleep(1000)) { const cb = await sget(K.batch), dc = await sget('p9bn.disc'); if (!(running(cb) && cb.order !== o.id) && !(dc && dc.state === 'running' && now() - (dc.created || 0) < 180000)) return true; }
    return false;
  };
  const ports = {
    ledgerUsed: (vid, lc, ckey) => B.used(vid, lc, ckey),
    markerExists,
    batchOf,
    stale: (rec) => { const t = now(); if (probeAt && t - probeAt > 30000) freezeUntil = t + 120000; probeAt = t;          // 1.1.7: THIS page was frozen (a computer asleep, a throttled / starved window): the silence it sees is its own - the tabs get 2 minutes to be heard before a run is ended as lost
      return rec.state === 'running' && t >= freezeUntil && t >= Math.max(L.staleAt(rec), runHeardAt(rec) + L.STALE_MS) + 60000; },          // advance() ends a lost run itself after RESUME_MS; this is the backstop
    endStale: async (o, rec) => { if (self.P9BEAN_HEARD && rec && await self.P9BEAN_HEARD(rec)) return rec;          // 1.1.7.2: a tab still answers the direct ping: not lost (backstop judged from an old copy)
      const ev = self.P9BEAN_EVID ? await self.P9BEAN_EVID.clickEvidence(rec).catch(() => ({})) : {};
      const b = await mutate((bb) => { if (bb.order !== o.id) return false; if (self.P9BEAN_EVID) self.P9BEAN_EVID.applyEvidence(bb, ev, now()); const open0 = bb.items.some((x) => x.status === 'queued' || x.status === 'running'); O.endItems(bb.items, now()); (bb.events = bb.events || []).push([now(), 'order ended: nothing was heard from this run for ' + Math.round((now() - runHeardAt(bb)) / 1000) + ' s (record updated ' + Math.round((now() - (bb.updated || 0)) / 1000) + ' s ago)']); bb.events = bb.events.slice(-20); (bb.groups || []).forEach((g) => { if (g.status !== 'done') { g.status = 'done'; g.doneAt = now(); } }); bb.state = open0 ? 'stopped' : 'done'; bb.updated = now(); }); try { await closeRunTabs(b || rec, 'all'); await sweepTabs(null); } catch (_) { /* best effort */ } return b || rec; },
    abortBatch: async (o, why) => { const b = await sget(K.batch); if (b && b.order === o.id && b.state === 'running') await stop(); },
    pauseBatch: async (o, on) => { const b = await sget(K.batch); if (!b || b.order !== o.id || b.state !== 'running') return; if (on) await pauseRun('the ExpressVPN check failed twice: ' + (((S17.disp && S17.disp.d && S17.disp.d.hk && S17.disp.d.hk.vpn && S17.disp.d.hk.vpn.msg) || 'not connected')).slice(0, 120)); else await resumeRun(); },          // 1.1.7.2: an automatic pause says why in the run log
    vpnCheck: async () => { const b = await sget(K.batch); if (!b || !b.vpn || !b.vpn.on || !B.checkNow) return null; return B.checkNow(b.id); },
    housekeeping: async () => {
      const st = { all: () => chrome.storage.local.get(null), set: (o) => chrome.storage.local.set(o), remove: (ks) => chrome.storage.local.remove(ks) };
      const hk = await O.housekeeping(st, now()); if (B.S && B.S.client && B.cfgSoon) { try { B.cfgSoon(true); } catch (_) { /* capacity push is best effort */ } } return { sizes: hk };
    },
    preflight: async (o) => {
      try {
        await loadContainers(); await loadChannelCache();
        if (!ctrs) return { ok: false, code: 'no_bridge', msg: E.message('no_bridge') };
        const asked = await askYtf(1500), v = verdict(asked);
        if (v === 'off') return { ok: false, code: 'focus_off' };
        if (v === 'missing') return { ok: false, code: 'focus_missing' };
        if (!(await waitIdle(o, 90000))) return { ok: false, code: 'busy', msg: 'Bean was busy with another run for more than 90 seconds.' };
        for (let i = 0; i < 40 && !(B.S && B.S.ledReady); i++) await sleep(100);
        const pre = await B.prepare(o.targets); if (!pre.ok) return { ok: false, code: 'vpn_unavailable', msg: pre.msg };
        S17.pre.set(o.id, pre); return { ok: true };
      } catch (e) { return { ok: false, code: 'internal', msg: String((e && e.message) || e).slice(0, 100) }; }
    },
    startBatch: async (o, st) => {
      const pre = S17.pre.get(o.id) || await B.prepare(o.targets); if (!pre.ok) return { ok: false, code: 'vpn_unavailable', msg: pre.msg };
      const links = o.links.map((l) => ({ n: l.n, vid: l.vid, lc: l.lc, url: L.watchUrl(l.vid, l.lc) }));
      const plan = L.planChosen(links, o.targets, st.chosen);
      if (!plan.items.length) return { ok: false, code: 'no_capacity', msg: E.message('no_capacity') };
      o.seqn = o.seqn || {}; for (const it of plan.items) { const k = it.vid + '|' + it.lc; it.seq = o.seqn[k] = (o.seqn[k] || 0) + 1; it.seq -= 1; }          // unique per link across retry rounds (the API result key is n + seq)
      const id = Math.random().toString(36).slice(2, 10) + now().toString(36), pace = L.pickPace(await sget(K.pace), o.pace);          // 1.1.6.3: ONE saved pace for every order (popup, API, queued): the order's own pace is only a fallback
      const b = { id, state: 'running', pace, created: now(), updated: now(), nextAt: 0, idx: 0, groups: plan.groups, items: plan.items, owner: ROLE, restoreBack: !!o.restoreBack, order: o.id, needed: (o.needed != null && o.needed >= 1) ? o.needed : null };          // 1.1.7.6
      if (o.src === 'api') b.job = o.jobId;
      B.decorate(b, pre, o.targets); { const om = L.openModeLabel(L.bgTabsOn(await sget(L.BGTABS_KEY).catch(() => null))); b.openMode = om; (b.events = b.events || []).push([now(), 'open mode — ' + om]); }      // 1.1.6.5: one line per run (popup, API and queued orders alike)
      b.order = o.id; if (o.src === 'api') b.job = o.jobId; b.restoreBack = !!o.restoreBack;
      (b.events = b.events || []).push([now(), 'timing — the order waited ' + Math.round((now() - (o.created || now())) / 1000) + ' s in the queue (accepted → run started)' + (o.tries ? '; it had to wait ' + o.tries + ' time(s) first (' + (o.waitWhy || 'retry') + ')' : '')]);          // 1.1.7.1: the run log now shows where the minutes before the first like went
      batch = b; own.id = id; own.last = b; own.stopped = false; own.cleared = false;
      await sset(K.batch, b); renderResults(); advance().catch(() => {});
      return { ok: true, batchId: id };
    },
    onFinal: async (o) => { S17.pre.delete(o.id); try { if (B.S && B.S.client && B.cfgSoon) B.cfgSoon(true); } catch (_) { /* best effort */ } if (self.B11 && B.S) B.S.lastOrderEnd = now(); },
    onBatch: async (o, rec) => { if (o.src === 'api') harvest(o, rec); },
    onChange: () => { try { if (typeof self.renderOrders === 'function') self.renderOrders(); } catch (_) { /* ui only */ } }
  };
  function disp() {
    if (!S17.disp) { S17.disp = new O.Dispatcher({ store: { get: sget, set: (k, v) => chrome.storage.local.set({ [k]: v }) }, ports }); S17.disp.held = false; }
    return S17.disp;
  }

  // ---------------------------------------------------------------- the executor pump (once a second, in the page that is the executor)
  async function pump17() {
    if (S17.pumping && now() - S17.pumpAt < 60000) return;          // 1.1.7.1: a pump that has not returned for a minute (an IPC call that never answered after a Panel 9 restart) no longer blocks the next one
    S17.pumping = true; S17.pumpAt = now();
    try {
      if (!B.executor()) { S17.held = false; return; }
      const d = disp(), r = await O.pump(d, io, me); S17.held = r.held;
      if (!r.held) return;
      const cb = await sget(K.batch);
      if (cb && cb.state === 'running' && cb.order) { if ((cb.owner || 'popup') === ROLE) advance().catch(() => {}); }
    } catch (e) { S17.err = String((e && e.message) || e).slice(0, 120); S17.pumpErrs = (S17.pumpErrs || 0) + 1; }
    finally { S17.pumping = false; }
  }
  // 1.1.7.1: reporting to the API server runs on its OWN timer, no longer behind the dispatcher's tick (real job_pw7W: after a Panel 9 restart the local run went on while nothing reached the server - one failing or stuck step in front of apiTick
  // was enough). It needs the executor role and the lease (or nobody holding it); one pass at a time, bounded to 40 s; every order is handled on its own so one bad order cannot stop the others.
  // 1.1.7.1: a claimed job that is not queued locally is retried every 3 s; after 30 s it is handed back (finished, nothing clicked) so it can never sit claimed-idle on the server
  const CLAIM_GIVE_UP_MS = 90000;          // 1.1.7.2: 30 s handed back real jobs (job_IpAePu05dKstEVYT, job_y0Q44wtVF1P-kXRY): only a job that NEVER became a local order is handed back, after 90 s of retries
  async function retryClaims() {
    const S = B.S; if (!S || !S.client) return; const t = now();
    for (const id of Object.keys(S17.claims)) {
      const c = S17.claims[id]; if (!c || S17.accepting === id) continue;
      if (S17.disp && S17.disp.d.queue.concat(S17.disp.d.hist).some((o) => o.jobId === id)) { delete S17.claims[id]; continue; }
      if (t - c.at > CLAIM_GIVE_UP_MS) {
        if (!B.executor()) { c.at = t; continue; }          // 1.1.7.2: only the page that runs the queue may ever hand a job back
        { let known = false; try { const dd = await sget(O.KEY); known = !!(dd && (dd.queue || []).concat(dd.hist || []).some((o) => o.jobId === id)); } catch (_) { known = true; }          // 1.1.7.2: judged from the stored queue too (this page's copy can be behind), and an unreadable store is never a reason to hand back
          if (!known) { try { const bb = await sget('p9bn.batch'); const dd2 = S17.disp && S17.disp.d; if (bb && bb.order && dd2 && dd2.queue.concat(dd2.hist).some((o) => o.id === bb.order && o.jobId === id)) known = true; } catch (_) { known = true; } }
          if (known) { delete S17.claims[id]; continue; } }
        try { await S.client.report(id, { state: 'finished', results: [], warnings: [], error: { code: 'not_started', message: 'Bean received this job but could not start it within 30 seconds, so it is handed back. Nothing was clicked.' } }); } catch (e) { if (e.code !== 'job_not_found') { S.err = String((e && e.message) || e).slice(0, 120); continue; } }
        delete S17.claims[id]; S.jobs.unshift({ id, status: 'failed', code: 'not_started', at: now() }); S.jobs.length = Math.min(S.jobs.length, 5); if (B.writeStat) B.writeStat(true); continue;
      }
      if (t >= c.next) { c.next = t + 3000; accept(c.job).catch(() => {}); }
    }
  }
  // 1.1.7.2 LEASE KEEPER (Oluchi's live complaint: one hanging container must never make the server give a job up as agent_lost). The server renews a running job's lease from a poll or a report. The polls come from their own loop;
  // this is a second, tiny, independent heartbeat: every 15 s a bare 'running' report (no results) for each open API order, read from the executor's own memory only - no storage read, no tab, no run record, no other await in front of it.
  // (apiTick reads the run record first; one lost storage reply there used to be enough to silence every report of the job.)
  async function leaseKeep() {
    const S = B.S; if (!apiOn() || !S || !S.client || !B.executor() || !S17.disp) return; const t = now();
    if (S17.keepBusy && t - S17.keepBusy < 25000) return;
    const o = S17.disp.d.queue.find((x) => x.src === 'api' && x.jobId && !x.apiDone && O.isOpen(x) && t - Math.max(S17.lastRep[x.id] || 0, (S17.keepRep || {})[x.id] || 0) > 15000); if (!o) return;
    S17.keepBusy = t; S17.keepRep = S17.keepRep || {};
    try { await S.client.report(o.jobId, { state: 'running', results: [] }); S17.keepRep[o.id] = now(); S17.keepAt = now(); } catch (_) { /* the next second tries again; apiTick handles job_not_found */ }
    finally { S17.keepBusy = 0; }
  }
  async function apiGuard() {
    retryClaims().catch(() => {});
    if (S17.apiBusy && now() - S17.apiBusy < 40000) return;
    if (!S17.disp || !B.executor() || !apiOn() || !B.S.client) return;
    S17.apiBusy = now();
    try {
      const l = await sget(O.LEASE); if (l && l.id !== me && now() - (l.at || 0) < O.C.LEASE_MS) return;
      await Promise.race([apiTick(), new Promise((r) => setTimeout(r, 40000))]);
    } catch (e) { S17.err = String((e && e.message) || e).slice(0, 120); }
    finally { S17.apiBusy = 0; }
  }

  // ---------------------------------------------------------------- the popup's side: requests and acks
  const newId = () => 'r' + Math.random().toString(36).slice(2, 9) + now().toString(36);
  async function request(req, waitMs) {
    req = Object.assign({ id: newId(), at: now() }, req);
    const cur = ((await sget(O.INBOX)) || []).filter((r) => r && now() - (r.at || 0) < 600000).slice(-40);
    cur.push(req); await sset(O.INBOX, cur);
    pump17().catch(() => {});
    const t0 = now(), lim = waitMs == null ? 15000 : waitMs;
    for (;;) {
      const ack = await sget(O.ACK); if (ack && ack.res && ack.res[req.id]) return ack.res[req.id];
      if (now() - t0 > lim) return { ok: false, timeout: true, message: 'The order was written to the queue, but nothing picked it up yet (Bean’s queue runner is not answering). It will start as soon as it is.' };
      await sleep(250);
    }
  }
  async function pruneInbox() { const ack = await sget(O.ACK), cur = await sget(O.INBOX); if (!Array.isArray(cur) || !cur.length) return; const done = new Set((ack && ack.ids) || []), keep = cur.filter((r) => r && !done.has(r.id) && now() - (r.at || 0) < 600000); if (keep.length !== cur.length) await sset(O.INBOX, keep); }

  // ---------------------------------------------------------------- API orders: accepted into the same queue, reported to the server from here
  const apiOn = () => !!(B.S && B.S.api && B.S.api.enabled && B.S.api.token && !B.S.api.revoked);
  const errCode = (c) => ({ 'ytf-off': 'focus_off', 'no-ytf': 'focus_missing', 'vpn-unavailable': 'vpn_unavailable', 'comment-gone': 'comment_not_found' }[c] || c);
  async function accept(job) {
    const S = B.S; if (!S || !S.client) return; S17.accepting = job.job_id;
    // 1.1.7.1 (real job_V4Drrn4Psg2ovX5T): the server hands a claimed job out ONCE. A hand-over that returned silently (not the executor for a moment, the queue's lease held elsewhere, a run still tearing down) left the job 'running' on the server for ever.
    // Every claimed job is therefore kept here (S17.claims) until it is queued locally or reported; retryClaims() tries again every 3 s and, after 30 s without a local order, hands the job back with a finish report.
    if (!S17.claims[job.job_id] && B.executor()) S17.claims[job.job_id] = { job, at: ((S17.first = S17.first || {})[job.job_id] = (S17.first[job.job_id] || now())), next: now() + 3000 };          /* 1.1.7.2: a re-adopted job keeps its FIRST claim time, so the 90 s give-up is never reset */          // 1.1.7.2: a page that is not the executor keeps no claim (it could never start it, and must never hand it back)
    const rep = (body) => S.client.report(job.job_id, body);
    const finishErr = async (code, message) => { delete S17.claims[job.job_id]; await rep({ state: 'finished', error: { code, message }, results: [], warnings: [] }).catch(() => {}); S.jobs.unshift({ id: job.job_id, status: 'failed', code, at: now() }); S.jobs.length = Math.min(S.jobs.length, 5); B.writeStat && B.writeStat(true); };
    try {
      if (!B.executor()) return;
      const d = disp(); await O.pump(d, io, me);
      const tb = self.B17 && self.B17.testBlock; if (tb && tb.id === job.job_id && tb.n > 0) { tb.n--; return; }          // test hook only: this hand-over attempt fails like a teardown race
      if (d.find && d.d.queue.concat(d.d.hist).some((o) => o.jobId === job.job_id)) { delete S17.claims[job.job_id]; return; }          // 1.1.7.2: checked BEFORE the lease test: a job handed out again while another page holds the lease is already ours, never a new claim; already accepted (the server hands the same job out until it hears back)
      if (!d.held) return;
      await loadContainers(); await loadChannelCache(); restoreSel();
      if (!ctrs) return finishErr('no_bridge', E.message('no_bridge'));
      const tg = healthyTargets().length ? healthyTargets() : targets();
      if (!sel.size) return finishErr('no_channels_saved', 'No containers or channels are saved in Bean. Tick them in Bean, then try again.');
      for (let i = 0; i < 40 && !(B.S && B.S.ledReady); i++) await sleep(100);
      const links = (job.links || []).map((l) => ({ n: l.n, vid: l.vid, lc: l.lc, quantity: l.quantity == null ? null : l.quantity, url: L.watchUrl(l.vid, l.lc) }));
      const r = await d.submit({ src: 'api', jobId: job.job_id, links, targets: tg, pace: settings.pace && L.PACES[settings.pace] ? settings.pace : 'normal', restoreBack: !!settings.restoreBack });
      if (!r.ok) return finishErr(r.code === 'no_capacity' ? 'no_capacity' : (r.code || 'internal'), r.message || E.message(r.code || 'internal'));
      delete S17.claims[job.job_id];          // the order exists locally: from here the queue owns the job
      S.job = { id: job.job_id, state: 'queued', done: 0, total: links.reduce((n, l) => n + (l.quantity || 0), 0) };
      if (B.writeStat) B.writeStat(true);
      await rep({ state: 'running', results: [], warnings: [] }).catch(() => {});
    } catch (e) { await finishErr('internal', 'Bean could not queue the job: ' + String((e && e.message) || e).slice(0, 120)); }
    finally { if (S17.accepting === job.job_id) S17.accepting = ''; }
  }
  async function cancelJob(id) {
    if (!S17.disp) return; const o = S17.disp.d.queue.find((x) => x.jobId === id); if (o) await S17.disp.cancel(o.id, 'cancelled by the API');
  }
  // the finished items of a (running or just ended) batch become API results, once each (o.hv remembers which items of which batch)
  function harvest(o, rec) {
    if (!rec || !Array.isArray(rec.items)) return; o.hv = o.hv || {}; o.apiRes = o.apiRes || [];
    const seen = new Set(o.hv[rec.id] || []);
    rec.items.forEach((it, i) => { if (!B.isFinalIt(it) || seen.has(i)) return; seen.add(i); if (it.code === 'not-started') return; o.apiRes.push(B.toResult(rec, it)); });
    o.hv[rec.id] = [...seen]; const ids = Object.keys(o.hv); if (ids.length > 3) for (const k of ids.slice(0, ids.length - 3)) delete o.hv[k];
    if (o.apiRes.length > 1500) { const drop = o.apiRes.length - 1500; o.apiRes.splice(0, drop); o.apiSent = Math.max(0, (o.apiSent || 0) - drop); }
  }
  const shortResults = (o) => { const out = []; for (const sf of o.shortfall || []) { const l = o.links.find((x) => x.n === sf.n); const miss = sf.want - sf.got; for (let k = 0; k < miss; k++) out.push({ n: sf.n, seq: 1000 + k, status: 'skipped', code: 'no_capacity', message: 'No unused channel left for this comment', container: '', channel: '', handle: '', at: now() }); } return out; };
  async function apiTick() {
    if (!apiOn() || !B.S.client) return; const S = B.S, d = S17.disp.d;
    for (const o of d.queue.concat(d.hist)) {
     try {
      if (o.src !== 'api' || o.apiDone) continue;
      const open = O.isOpen(o), rep = (body) => S.client.report(o.jobId, body), t = now();
      if (open) {
        if (o.state === 'running') harvest(o, await batchOf(o));
        const fresh = (o.apiRes || []).slice(o.apiSent || 0), first = !S17.firstRep[o.id], last = S17.lastRep[o.id] || 0;
        S.job = { id: o.jobId, state: o.state === 'running' ? 'running' : 'queued', done: o.carry.liked + o.carry.already, total: o.links.reduce((n, l) => n + (l.quantity || 0), 0) };
        if (!(first || (fresh.length && t - last > 2500) || t - last > 20000)) continue;
        const pre = S17.pre.get(o.id), warn = first && pre && pre.warn ? pre.warn : undefined;
        try {
          const resp = await rep({ state: 'running', results: fresh, warnings: warn }); S17.firstRep[o.id] = 1; S17.lastRep[o.id] = t; o.apiSent = (o.apiSent || 0) + fresh.length; S17.disp.touch();
          if (resp && resp.cancel && !o.cancelReq) await S17.disp.cancel(o.id, 'cancelled by the API');
          if (resp && resp.ignored && resp.status !== 'running' && !o.cancelReq) await S17.disp.cancel(o.id, 'the server no longer waits for this job');
        } catch (e) { if (e.code === 'job_not_found') { o.apiDone = true; if (!o.cancelReq) await S17.disp.cancel(o.id, 'the server no longer knows this job'); } else S.err = String((e && e.message) || e).slice(0, 120); }          // 1.1.7.2: the local run ends (results kept, tabs closed) and the next job is claimed
      } else {
        const fresh = (o.apiRes || []).slice(o.apiSent || 0).concat(shortResults(o));
        const error = o.state === 'done' || o.state === 'cancelled' ? undefined : o.state === 'stopped' ? { code: 'stopped', message: 'The run was stopped in Bean.' } : o.err ? { code: errCode(o.err.code), message: o.err.message } : undefined;
        try { await rep({ state: 'finished', results: fresh, warnings: [], error }); o.apiDone = true; o.apiRes = []; o.apiSent = 0; S.jobs.unshift({ id: o.jobId, status: 'finished', at: now() }); S.jobs.length = Math.min(S.jobs.length, 5); if (S.job && S.job.id === o.jobId) S.job = null; S17.disp.touch(); }
        catch (e) { if (e.code === 'job_not_found') { o.apiDone = true; S17.disp.touch(); } else S.err = String((e && e.message) || e).slice(0, 120); }
      }
     } catch (e) { S.err = String((e && e.message) || e).slice(0, 120); }
    }
    if (B.writeStat) B.writeStat(false);
    reconcile().catch(() => {});
  }
  // 1.1.7.1 RECONCILIATION (real job_pw7W: Bean's run went on after a Panel 9 restart while the server kept the job "running" for an hour and blocked 25 others). Every 30 s, with the server's own list of this install's jobs:
  //   - a job the server calls running whose order here is over (or was marked done): its finish is sent again (everything not acked goes with it)
  //   - a job the server calls running although Bean has no live order for it (and none is being accepted): after 3 minutes and two sightings Bean reports it finished ("interrupted", nothing was clicked again); the results it already holds stay
  const dev = (m) => { try { S17.disp.ev(m); } catch (_) { /* log only */ } };          // 1.1.7.2: ev() needs its `this`: the detached call threw a TypeError (the 'server closed the job' and 're-adopt' branches never finished)
  async function reconcile() {
    const S = B.S; if (!apiOn() || !S.client || !S17.disp || !B.executor()) return; const t = now(); if (t - (S17.recAt || 0) < 15000) return; S17.recAt = t;          // 1.1.7.2 (live jobs bgPW, XEGZ closed 'interrupted'): only the page that runs the queue judges orphans; a just-opened popup with an empty view never does
    let jl; try { jl = await S.client.jobs(); } catch (_) { return; }
    const d = S17.disp.d, all = d.queue.concat(d.hist); S17.orph = S17.orph || {}; const live = new Set();
    { const listed = new Set(((jl && jl.jobs) || []).map((j) => j.job_id)); S17.gone = S17.gone || {};          // 1.1.7.2 (real job_2BgDpLrIIAAE1PZj, 09:14): the server closed the job (agent_lost / partial) while Bean still ran it
      for (const o of all) { if (o.src !== 'api' || o.state !== 'running' || !o.jobId || o.cancelReq) continue; if (listed.has(o.jobId)) { delete S17.gone[o.jobId]; continue; }
        if (t - (o.created || 0) < 20000) continue; S17.gone[o.jobId] = (S17.gone[o.jobId] || 0) + 1;
        if (S17.gone[o.jobId] >= 2) { delete S17.gone[o.jobId]; o.apiDone = true; dev('api reconcile: the server closed job ' + o.jobId + ': local run ended'); await S17.disp.cancel(o.id, 'the server closed this job').catch(() => {}); } } }
    for (const j of (jl && jl.jobs) || []) {
      if (j.status !== 'running') continue; live.add(j.job_id);
      const o = all.find((x) => x.src === 'api' && x.jobId === j.job_id);
      if (o) {
        if (O.isOpen(o)) continue;
        if (o.apiDone) { o.apiDone = false; S17.disp.touch(); dev('api reconcile: server says running, the order is over: finish sent again ' + o.id); }
        continue;
      }
      if ((S.job && S.job.id === j.job_id) || S17.accepting === j.job_id || S17.claims[j.job_id]) continue;
      const first = S17.orph[j.job_id] || (S17.orph[j.job_id] = t), startedAt = Date.parse(j.started_at || '') || t;
      if (t - first < 14000 || t - startedAt < 30000) continue;
      // 1.1.7.2: a running job with no local run AND nothing reported yet (the claim answer was lost, or Bean restarted before the first result) is RE-ADOPTED: its links come from the server's own list and a run is queued for it
      // (the ledger / click markers keep any like already sent from being sent again). A job that already has results is never re-run (its quantity is partly done): it is reported 'interrupted' below, results kept. After 3 failed adoptions it is reported too.
      { S17.adopt = S17.adopt || {}; const done0 = j.progress && Number(j.progress.done); let stored = false; try { const dd = await sget(O.KEY); stored = !!(dd && (dd.queue || []).concat(dd.hist || []).some((x) => x.jobId === j.job_id)); } catch (_) { stored = true; }
        if (stored) continue;          // the order exists in the shared queue (this page's copy was behind): never adopted twice, never judged an orphan
        if (done0 === 0 && Array.isArray(j.links) && j.links.length && (S17.adopt[j.job_id] || 0) < 3) { S17.adopt[j.job_id] = (S17.adopt[j.job_id] || 0) + 1; dev('api reconcile: job ' + j.job_id + ' had no local run and no results: re-adopted (' + S17.adopt[j.job_id] + ' of 3)');
          await accept({ job_id: j.job_id, links: j.links.map((l) => ({ n: l.n, vid: l.vid, lc: l.comment_id, quantity: l.accepted })) }).catch(() => {}); S17.orph[j.job_id] = t; continue; } }
      try { await S.client.report(j.job_id, { state: 'finished', results: [], warnings: [], error: { code: 'interrupted', message: 'Bean has no run for this job any more (Bean was restarted or its run was cleared). Nothing was clicked again; the results already sent stay.' } }); delete S17.orph[j.job_id]; S.jobs.unshift({ id: j.job_id, status: 'finished', at: now() }); S.jobs.length = Math.min(S.jobs.length, 5); } catch (_) { /* tried again in 30 s */ }
    }
    for (const k of Object.keys(S17.orph)) if (!live.has(k)) delete S17.orph[k];
  }

  function init17() {
    if (S17.timer) return;
    S17.timer = setInterval(() => { pump17().catch(() => {}); }, 1000);
    S17.apiTimer = setInterval(() => { apiGuard().catch(() => {}); leaseKeep().catch(() => {}); }, 1000);
    if (ROLE === 'popup') { setInterval(() => { sset('p9bn.pbeat', { at: now() }).catch(() => {}); pruneInbox().catch(() => {}); }, 3000); sset('p9bn.pbeat', { at: now() }).catch(() => {}); }
    pump17().catch(() => {});
  }
  self.B17 = { init: init17, request, accept, cancelJob, pump: pump17, state: () => (S17.disp ? S17.disp.d : null), held: () => S17.held, me, disp, ports };
})();
