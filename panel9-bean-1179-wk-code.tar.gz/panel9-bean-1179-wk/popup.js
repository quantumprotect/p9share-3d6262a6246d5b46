// Bean popup. Talks to the content script on youtube.com only through chrome.storage.local (mirrored by Panel 9 to every session = container):
//   p9bn.ping      popup -> content scripts: "tell me what YouTube Focus looks like right now"
//   p9bn.ytf       content script -> popup: { installed, commentsOnly, seen }
//   p9bn.batch     the run: { id, state, pace, created, updated, nextAt, groups:[{cid,name,status}], items:[{vid, lc, cid, cname, status, code, msg, hb}] }
//                  (popup creates / stops / clears and opens the container tabs, the YouTube tabs update the items)
//   p9bn.settings  { pace, sel: { <profileId>: [containerId…] } }  (remembered choices)
// Containers: Panel 9 (>= 2.3.9; Bean requires 2.3.10+) gives this popup — and only this extension's popup — window.panel9ext.containers() and .openTabInContainer({url, containerId}).
// Without that bridge (older Panel 9, other browsers) the picker is hidden and the first link opens with window.open in the container of the current tab, as a single-container liker.
const L = self.P9BEAN;
const ROLE = /[?&]runner=1\b/.test(location.search) ? 'runner' : 'popup';   // 1.1.0: the same page also runs hidden as Bean's background runner (see ext11.js)
const K = { ytf: 'p9bn.ytf', batch: 'p9bn.batch', ping: 'p9bn.ping', settings: 'p9bn.settings', disc: 'p9bn.disc', pause: 'p9bn.pause', pace: 'p9bn.pace', alive: 'p9bn.alive', ver: 'p9bn.ver' };
const $ = (id) => document.getElementById(id);
const els = { links: $('links'), count: $('count'), go: $('go'), stop: $('stop'), pause: $('pause'), resume: $('resume'), clear: $('clear'), pace: $('pace'), msg: $('msg'), results: $('results'), gate: $('gate'), pill: $('pill'),
  cbox: $('cbox'), clist: $('clist'), csel: $('csel'), cnote: $('cnote'), refresh: $('crefresh'), possible: $('possible'), cfilter: $('cfilter'), call: $('call'), cnone: $('cnone'), plan: $('plan'), nobridge: $('nobridge'), qrow: $('qrow'), qall: $('qall'), qmax: $('qmax') };
const sget = (k) => chrome.storage.local.get({ [k]: null }).then((v) => v[k]);
let lastWriteAt = 0;               // 1.1.1: Panel 9 can leave a setting stale in a container session that is seeded for the first time within ~1 s of the write -> no first tab before 2 s have passed
const sset = (k, v) => { lastWriteAt = Date.now(); return chrome.storage.local.set({ [k]: v }); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const bridge = () => (window.panel9ext && typeof window.panel9ext.containers === 'function' && typeof window.panel9ext.openTabInContainer === 'function' ? window.panel9ext : null);
const STALE_MS = L.STALE_MS, NAV_GRACE_MS = L.NAV_GRACE_MS;            // a running run whose record was not touched for this long has lost its tab
const OPEN_GRACE_MS = 45000;          // 1.1.7.2: 75 s -> 45 s                 // a freshly opened tab that never loads (dead proxy, error page) is given up after this long; in-tab navigations announce the longer NAV_GRACE_MS
const RESUME_MS = 5 * 60000;       // a run interrupted (popup closed) is resumed on reopen only within this window
let ytf = null, batch = null, gateV = 'unknown';
let parsed = { items: [], errors: [], total: 0 };
let ctrs = null;                   // { profile, active, containers:[{id,name,color,builtin,signedIn,checked,people}] } or null (no bridge)
let sel = new Set();               // chosen container ids
let settings = {};
const own = { id: '', last: null, stopped: false, cleared: false };   // the run this popup drives: lets it repair a write that Panel 9's cross-session storage mirror lost

// ================================================================ YouTube Focus status (unchanged from 1.0.0)
// verdict: 'on' | 'off' | 'missing' | 'unknown' (no YouTube tab answered)
function verdict(askedAt) {
  if (!ytf || (askedAt && ytf.seen < askedAt)) return 'unknown';
  if (ytf.installed === false) return 'missing';
  if (ytf.installed === true) return ytf.commentsOnly ? 'on' : 'off';
  return 'unknown';
}
function renderGate(v) {
  gateV = v;
  const pill = els.pill, g = els.gate;
  pill.className = 'pill';
  if (v === 'on') { pill.textContent = 'Comment-only view: on'; pill.classList.add('on'); g.hidden = true; }
  else if (v === 'off') {
    pill.textContent = 'Comment-only view: off'; pill.classList.add('off');
    g.hidden = false; g.innerHTML = '<b>Turn on YouTube Focus comment-only view.</b><br>Open YouTube Focus (🧩 toolbar) and switch on <b>Comments only</b>, then come back here.';
  } else if (v === 'missing') {
    pill.textContent = 'YouTube Focus missing'; pill.classList.add('bad');
    g.hidden = false; g.innerHTML = '<b>YouTube Focus is not installed or not enabled.</b><br>Install it from the Panel 9 Store (Extensions), then switch on <b>Comments only</b>.';
  } else { pill.textContent = 'not checked yet'; g.hidden = true; }
  refreshButtons();
}
async function askYtf(wait) {
  const t = Date.now();
  await sset(K.ping, t).catch(() => {});
  const t0 = Date.now();
  while (Date.now() - t0 < (wait || 900)) {
    const v = await sget(K.ytf); if (v && v.seen >= t) { ytf = v; return t; }
    await sleep(120);
  }
  return t;
}

// ================================================================ containers and their channels
// A container holds one Google account; that account can own several YouTube channels (brand accounts). The content script reads the list of channels from YouTube's own
// account switcher in a tab of that container ("Refresh channels") and stores it under  p9bn.ch.<profile>.<container>  (names, handles, avatars — no cookies, tokens or e-mail).
async function loadContainers() {
  const b = bridge();
  if (!b) { ctrs = null; return; }
  try { ctrs = await b.containers(); } catch (_) { ctrs = null; }
  if (ctrs && !Array.isArray(ctrs.containers)) ctrs = null;
}
const pid = () => (ctrs && ctrs.profile && String(ctrs.profile.id)) || '0';
let chCache = {};                  // containerId -> { at, ok, channels:[{id,name,handle,avatar}], active, err }
let chSel = {};                    // containerId -> Set(channel ids to like from)
const expanded = new Set(), expSeen = new Set();
let chStale = {};
let actRec = {};                   // 1.1.7.1: containerId -> { id, at, src } the last channel Bean saw ACTIVE there (written by the tabs); planning prefers it over channels that need a switch
const activeOf = (cid) => L.activeChannel(chCache[cid], actRec[cid]);
let discovering = null;            // { i, n, name, cid, ids[], done:Set, single } while a channel refresh runs (all ticked containers, or ONE container: the row's ↻)
const rowNote = {};                // cid -> { t, kind } last result of a refresh, shown on that container's row ('ok' | 'warn')
async function loadChannelCache() {
  const all = await chrome.storage.local.get(null), pre = L.chKey(pid(), '');
  chCache = {};
  for (const k of Object.keys(all)) if (k.indexOf(pre) === 0 && all[k] && typeof all[k] === 'object') chCache[k.slice(pre.length)] = all[k];
  actRec = {};
  for (const k of Object.keys(all)) if (k.indexOf(L.ACT_KEY) === 0 && all[k] && typeof all[k] === 'object' && all[k].id) actRec[k.slice(L.ACT_KEY.length)] = all[k];
  chStale = {};      // 1.1.6: channels a run could not find in the account menu (renamed / deleted / re-sign-in): shown with a warning until the channels are refreshed
  for (const k of Object.keys(all)) if (k.indexOf('p9bn.chstale.') === 0 && all[k] && Array.isArray(all[k].ids)) chStale[k.slice(13)] = all[k];
}
const known = (cid) => { const c = chCache[cid]; return c && c.ok && Array.isArray(c.channels) && c.channels.length ? c.channels : null; };
function restoreSel() {
  const saved = (settings.sel && settings.sel[pid()]) || [];
  const have = new Set(ctrs ? ctrs.containers.map((c) => c.id) : []);
  sel = new Set(saved.filter((id) => have.has(id)));          // containers deleted since are dropped silently
  const sc = (settings.chs && settings.chs[pid()]) || {};
  chSel = {};
  for (const cid of Object.keys(sc)) if (have.has(cid) && Array.isArray(sc[cid])) chSel[cid] = new Set(sc[cid]);
  normalizeSel();
}
// keep the ticks of containers and of their channels in step; channels that no longer exist are dropped
function normalizeSel() {
  for (const c of ctrs ? ctrs.containers : []) {
    const list = known(c.id); if (!list) continue;
    const have = new Set(list.map((x) => x.id));
    const s = chSel[c.id] = new Set([...(chSel[c.id] || [])].filter((id) => have.has(id)));
    // 1.1.1: NEVER add a channel the user did not tick (1.1.0 ticked the active / first channel of a ticked container that had none ticked). No channel ticked -> the container is
    // unticked and its row says so. The one exception: a container with exactly ONE channel has nothing to choose, so ticking the container ticks that channel.
    if (sel.has(c.id) && !s.size) { if (list.length === 1) s.add(list[0].id); else rowNote[c.id] = { t: 'Choose which of its channels to like from — Bean no longer picks one for you.', kind: 'warn', choose: true }; }
    if (s.size) sel.add(c.id); else sel.delete(c.id);
  }
}
function saveSel() {
  settings.sel = Object.assign({}, settings.sel || {}, { [pid()]: [...sel] });
  const chs = {}; for (const cid of Object.keys(chSel)) if (known(cid)) chs[cid] = [...chSel[cid]];
  settings.chs = Object.assign({}, settings.chs || {}, { [pid()]: chs });
  sset(K.settings, settings).catch(() => {});
  verifySettings(0);
  if (self.B11) B11.cfgSoon();
}
// Panel 9's cross-session storage mirror can bring back an older snapshot within ~100 ms of another session's write: check that the choice stuck, write it again if not
function verifySettings(n) {
  setTimeout(async () => {
    try { const cur = await sget(K.settings); if (cur && JSON.stringify(cur.sel) === JSON.stringify(settings.sel) && JSON.stringify(cur.chs) === JSON.stringify(settings.chs) && cur.pace === settings.pace) return; } catch (_) { /* retry */ }
    if (n < 3) { sset(K.settings, settings).catch(() => {}); verifySettings(n + 1); }
  }, 600);
}
function initials(n) { return (String(n || '?').trim().match(/[\p{L}\p{N}]/u) || ['?'])[0].toUpperCase(); }
function avatar(ch) {
  const w = document.createElement('span'); w.className = 'av'; w.textContent = initials(ch.name);
  if (ch.avatar) { const im = document.createElement('img'); im.alt = ''; im.referrerPolicy = 'no-referrer'; im.src = ch.avatar; im.addEventListener('load', () => { w.textContent = ''; w.append(im); }); }
  return w;
}
function renderContainers() {
  if (!ctrs) { els.cbox.hidden = true; els.nobridge.hidden = false; renderPlan(); return; }
  els.nobridge.hidden = true; els.cbox.hidden = false;
  const q = (els.cfilter.value || '').trim().toLowerCase();
  els.cfilter.hidden = ctrs.containers.length <= 8;
  els.clist.textContent = '';
  for (const c of ctrs.containers) {
    if (q && c.name.toLowerCase().indexOf(q) < 0 && !(c.people || []).some((p) => p.toLowerCase().indexOf(q) >= 0)) continue;
    const list = known(c.id), s = chSel[c.id] || new Set();
    if (list && list.length > 1 && !expSeen.has(c.id)) { expSeen.add(c.id); expanded.add(c.id); }
    const wrap = document.createElement('div'); wrap.className = 'cwrap';
    const row = document.createElement('label'); row.className = 'crow' + (c.id === ctrs.active ? ' cur' : ''); row.dataset.cid = c.id;
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.dataset.cid = c.id;
    cb.checked = list ? s.size > 0 : sel.has(c.id); cb.indeterminate = !!list && s.size > 0 && s.size < list.length;
    cb.addEventListener('change', () => {
      if (list) { chSel[c.id] = cb.checked ? new Set(list.map((x) => x.id)) : new Set(); if (cb.checked) sel.add(c.id); else sel.delete(c.id); }
      else { if (cb.checked) sel.add(c.id); else sel.delete(c.id); saveSel(); renderPlan(); updSel(); return; }       // no channel list: nothing else changes, keep the DOM as it is
      saveSel(); renderContainers();
    });
    const dot = document.createElement('span'); dot.className = 'cd'; if (c.color) dot.style.background = c.color;
    const nm = document.createElement('span'); nm.className = 'cn'; nm.textContent = c.name; nm.title = c.name;
    const tg = document.createElement('span'); tg.className = 'ct';
    const who = (c.people || [])[0], ce = chCache[c.id];
    if (list && list.length > 1) tg.textContent = `${s.size}/${list.length} channels`;
    else if (list) tg.textContent = list[0].name;
    else if (ce && ce.err) { tg.textContent = 'no channel list'; tg.classList.add('warn'); tg.title = ce.err; }
    else if (c.checked && !c.signedIn) { tg.textContent = 'signed out'; tg.classList.add('warn'); }
    else if (who && who !== c.name) tg.textContent = who;
    // per-row status while a reading runs, and the per-container ↻ (reads ONLY this container, ticked or not)
    if (discovering && discovering.cid === c.id) { tg.textContent = 'reading…'; tg.className = 'ct busy'; tg.title = ''; }
    else if (discovering && discovering.ids.includes(c.id) && !discovering.done.has(c.id)) { tg.textContent = 'waiting…'; tg.className = 'ct busy'; tg.title = ''; }
    row.append(cb, dot, nm, tg);
    const rf = document.createElement('button'); rf.type = 'button'; rf.className = 'rf' + (discovering && discovering.cid === c.id ? ' spin' : ''); rf.dataset.cid = c.id; rf.textContent = '↻';
    const rfOff = !!discovering || running(batch); rf.disabled = rfOff;
    rf.title = rfOff ? (discovering ? 'Channels are being read — wait until that has finished.' : 'A run is in progress — wait until it has finished.') : `Read the channels of '${c.name}' only (opens one short-lived tab in this container)`;
    rf.setAttribute('aria-label', `Refresh channels of ${c.name}`);
    rf.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); refreshOne(c.id).catch((er) => { discovering = null; setMsg('Could not read the channels: ' + String((er && er.message) || er).slice(0, 100), 'warn'); renderContainers(); }); });
    row.append(rf);
    if (list && list.length > 1) {
      const car = document.createElement('button'); car.type = 'button'; car.className = 'car'; car.textContent = expanded.has(c.id) ? '▾' : '▸'; car.title = 'Show / hide the channels';
      car.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); if (expanded.has(c.id)) expanded.delete(c.id); else expanded.add(c.id); renderContainers(); });
      row.append(car);
    }
    wrap.append(row);
    const rnv = rowNote[c.id] || (ce && ce.err ? { t: 'Could not refresh: ' + ce.err + (list ? ' — still showing the previous list.' : ''), kind: 'warn' } : null);
    if (rnv && !(discovering && discovering.ids.includes(c.id) && !discovering.done.has(c.id))) { const rn = document.createElement('div'); rn.className = 'rnote ' + rnv.kind; rn.dataset.cid = c.id; rn.textContent = rnv.t; wrap.append(rn); }
    if (list && list.length > 1 && expanded.has(c.id)) {
      const sub = document.createElement('div'); sub.className = 'chlist';
      const hd = document.createElement('div'); hd.className = 'chhd';
      const mkb = (t, fn) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'lnk'; b.textContent = t; b.addEventListener('click', fn); return b; };
      hd.append(mkb('All', () => { chSel[c.id] = new Set(list.map((x) => x.id)); sel.add(c.id); saveSel(); renderContainers(); }), mkb('None', () => { chSel[c.id] = new Set(); sel.delete(c.id); saveSel(); renderContainers(); }));
      sub.append(hd);
      for (const ch of list) {
        const r2 = document.createElement('label'); r2.className = 'chrow'; r2.dataset.chid = ch.id;
        const cb2 = document.createElement('input'); cb2.type = 'checkbox'; cb2.dataset.cid = c.id; cb2.dataset.chid = ch.id; cb2.checked = s.has(ch.id);
        cb2.addEventListener('change', () => {
          const cur = chSel[c.id] || (chSel[c.id] = new Set());
          if (cb2.checked) cur.add(ch.id); else cur.delete(ch.id);
          if (cur.size) sel.add(c.id); else sel.delete(c.id);
          saveSel(); renderContainers();
        });
        const n2 = document.createElement('span'); n2.className = 'cn'; n2.textContent = ch.name; n2.title = ch.name;
        const h2 = document.createElement('span'); h2.className = 'ct'; h2.textContent = ch.handle || (ch.id === activeOf(c.id) ? 'active now' : '');
        if (chStale[c.id] && chStale[c.id].ids.indexOf(ch.id) >= 0) { h2.textContent = '⚠ not found in the last run: refresh'; h2.title = 'The last run could not find this channel in the account menu (renamed, deleted, or it needs signing in again). Press ↻ to read the channels again.'; }
        r2.append(cb2, avatar(ch), n2, h2); sub.append(r2);
      }
      wrap.append(sub);
    }
    els.clist.append(wrap);
  }
  renderPlan();
}
function setAll(on) {
  const q = (els.cfilter.value || '').trim().toLowerCase();
  for (const c of ctrs ? ctrs.containers : []) {
    if (q && c.name.toLowerCase().indexOf(q) < 0) continue;
    const list = known(c.id);
    if (list) { chSel[c.id] = on ? new Set(list.map((x) => x.id)) : new Set(); }
    if (on) sel.add(c.id); else sel.delete(c.id);
  }
  saveSel(); renderContainers();
}
// who will like: the ticked containers (with their ticked channels), else the current tab's container as it is (current channel)
function targets() {
  if (!ctrs) return [{ id: '', name: '' }];
  const out = [];
  for (const c of ctrs.containers) {
    if (!sel.has(c.id)) continue;
    const list = known(c.id), s = chSel[c.id];
    // the channel that is active right now goes first: no switch is needed for it, and fewer switches means fewer page loads
    const act = activeOf(c.id);          // 1.1.7.1: the last channel Bean confirmed active here (or the channel list's own active one, whichever is newer)
    const chans = list && s && s.size ? list.filter((x) => s.has(x.id)).sort((a, b) => (b.id === act) - (a.id === act)).map((x) => ({ id: x.id, name: x.name, handle: x.handle })) : undefined;
    out.push({ id: c.id, name: c.name, channels: chans, active: act || undefined });
  }
  if (out.length) return out;
  const a = ctrs.containers.find((c) => c.id === ctrs.active) || ctrs.containers[0];
  return [a ? { id: a.id, name: a.name } : { id: '', name: '' }];
}
// 1.1.6: the same list without the channels the last run flagged (not found / could not be switched to): what Bean can really like from, the same number the API's /capacity reports
const healthyTargets = () => targets().map((x) => x.channels ? Object.assign({}, x, { channels: x.channels.filter((ch) => !(self.B11 && B11.bad && B11.bad(x.id, ch.id))) }) : x).filter((x) => !(x.channels && !x.channels.length));
const channelCount = (t) => t.reduce((n, x) => n + Math.max(1, (x.channels || []).length), 0);
// ---- 1.1.7.6 "Likes needed": a TOTAL for the whole popup run (1–200). Empty = all possible. Distributed across links (greedy). Optional per-link overrides in the Possible likes panel still win for that link. API / YT Panel jobs ignore this field (server items stay the source of truth).
let ordData = null;                                  // the queue as the executor wrote it (p9bn.orders), read-only here
const qty = { all: '', per: {} };                    // all = likes needed (total); per = optional per-link overrides ('vid|lc')
const lkOf = (it) => it.vid + '|' + it.lc;
function capacityNow() {
  const rc = {}, res = (vid, lc, ck) => { const k = vid + '|' + lc; return (rc[k] || (rc[k] = P9BEAN_ORD.reservedKeys(ordData, vid, lc))).has(ck); };
  return L.possibleLikes(healthyTargets(), parsed.items, (vid, lc, ck) => (self.B11 ? B11.used(vid, lc, ck) : false), null, res);
}
function effQty(P) {
  P = P || capacityNow();
  const need = L.clampNeeded(qty.all);
  const base = need.q != null ? L.distributeNeeded(need.q, P.perLink) : P.perLink.map((x) => ({ n: x.n, vid: x.vid, lc: x.lc, key: x.vid + '|' + x.lc, max: x.max, q: null, clamped: false }));
  return base.map((x) => {
    const key = x.key || (x.vid + '|' + x.lc), mine = qty.per[key] != null && String(qty.per[key]).trim() !== '';
    if (!mine) return Object.assign({}, x, { key, own: false, needed: need.q, needClamped: !!need.clamped });
    const c = L.clampQty(qty.per[key], x.max); return { n: x.n, vid: x.vid, lc: x.lc, key, max: x.max, q: c.q, clamped: c.clamped, own: true, needed: need.q, needClamped: !!need.clamped };
  });
}
const qtyActive = () => parsed.items.length > 0 && (String(qty.all).trim() !== '' || parsed.items.some((it) => String(qty.per[lkOf(it)] == null ? '' : qty.per[lkOf(it)]).trim() !== ''));
const actionCount = () => { if (ctrs && qtyActive()) return effQty().reduce((n, x) => n + (x.q != null ? x.q : x.max), 0); return parsed.items.length * channelCount(targets()); };
const overCap = () => actionCount() > L.MAX_ACTIONS;
function saveLikesNeeded() { settings.likesNeeded = String(qty.all == null ? '' : qty.all); sset(K.settings, settings).catch(() => {}); }
// 1.1.7.9: Likes needed stays visible in the popup (runopts), never gated on containers/links. Max hint updates when capacity is known.
function updLikesNeededHint(P) {
  if (!els.qrow || !els.qall) return;
  els.qrow.hidden = false;
  if (P && parsed.items.length) {
    const E = effQty(P), sm = E.reduce((n, x) => n + x.max, 0);
    if (els.qmax) els.qmax.textContent = `max ${Math.min(L.MAX_ACTIONS, sm)} possible`;
    els.qall.max = String(Math.min(L.MAX_ACTIONS, Math.max(1, sm)));
  } else if (els.qmax) els.qmax.textContent = '1–200';
  if (document.activeElement !== els.qall) els.qall.value = qty.all;
}
// 1.1.7.9: Parallel (cap=4) / Single (cap=1). Persisted as p9bn.parallel so parallelCap() / pickOpen use it for popup + API jobs.
const PAR_KEY = 'p9bn.parallel';
async function parallelModeNow() { let v = null; try { v = await sget(PAR_KEY); } catch (_) { v = null; } const n = Number(v && typeof v === 'object' ? v.n : v); return n === 1 ? 'single' : 'parallel'; }
async function saveParallelMode(mode) {
  const single = mode === 'single';
  settings.parallelMode = single ? 'single' : 'parallel';
  sset(K.settings, settings).catch(() => {});
  if (single) await sset(PAR_KEY, 1); else await sset(PAR_KEY, ST.PARALLEL_CONTAINERS);
}
function updSel() { els.csel.textContent = ctrs ? (sel.size ? `· ${sel.size} selected` : '· none selected') : ''; }
function renderPlan() {
  const t = targets(), links = parsed.items.length, nch = channelCount(t), actions = links * nch;
  els.csel.textContent = ctrs ? (sel.size ? `· ${sel.size} selected` : '· none selected') : '';
  if (ctrs) {
    const unknown = t.filter((x) => !x.channels && ctrs.containers.some((c) => c.id === x.id) && !known(x.id) && sel.has(x.id)).length;
    els.cnote.textContent = discovering ? (discovering.single ? `Reading the channels of '${discovering.name}'…` : `Reading the channels of '${discovering.name}' (${discovering.i}/${discovering.n})…`)
      : !sel.size ? `None ticked: it will use the container of your current tab${t[0] && t[0].name ? ' (' + t[0].name + ')' : ''}, whichever channel is active there.`
      : unknown ? `${unknown} ticked container${unknown === 1 ? '' : 's'} without a channel list: Bean likes from the channel that is active there. Press “Refresh channels” to list the channels of the ticked containers.` : '';
    els.refresh.disabled = !!discovering || running(batch);
    els.refresh.title = els.refresh.disabled ? (discovering ? 'Channels are being read — wait until that has finished.' : 'A run is in progress — wait until it has finished.') : 'Read the YouTube channels of the ticked containers (opens a short-lived tab in each)';
  }
  els.plan.className = 'plan'; els.plan.textContent = '';
  if (links) {
    const dur = L.fmtDuration(L.estimateSeconds(actions, t.length, els.pace.value, L.countSwitches(t)));
    const what = `${links} link${links === 1 ? '' : 's'} × ${t.length} container${t.length === 1 ? '' : 's'}${nch > t.length ? ' (' + nch + ' channels)' : ''}`;
    els.plan.textContent = nch > 1 || links > 1 ? `${what} = ${actions} like${actions === 1 ? '' : 's'} · about ${dur}` : '';
    if (ctrs && qtyActive()) { const E = effQty(), sq = E.reduce((n, x) => n + (x.q != null ? x.q : x.max), 0), sm = E.reduce((n, x) => n + x.max, 0), nd = E[0] && E[0].needed; els.plan.textContent = (nd != null ? `Likes needed: ${nd}` : `${links} link${links === 1 ? '' : 's'}`) + ` · ${sq} like${sq === 1 ? '' : 's'} of ${sm} possible · about ${L.fmtDuration(L.estimateSeconds(sq, t.length, els.pace.value, L.countSwitches(t)))}` + (E.some((x) => x.clamped || x.needClamped) ? ' · lowered to the maximum' : ''); }
    if (actionCount() > L.MAX_ACTIONS) { els.plan.className = 'plan bad'; els.plan.textContent = `${what} = ${actions} likes — over the limit of ${L.MAX_ACTIONS} per run. Remove some links, containers or channels.`; }
    else if (actionCount() > L.WARN_ACTIONS) { els.plan.className = 'plan warn'; els.plan.textContent += ' — that is a lot at once; YouTube may rate-limit or flag many likes in a short time. Consider the Slow pace or fewer channels.'; }
  }
  refreshButtons();
}
// "Refresh channels" (all ticked containers, or the current one) and the per-row ↻ (ONE container, ticked or not): one short-lived tab per container reads that container's
// account switcher; the result lands in chCache (only for the containers that were read). Same rules for both: never during a run or another reading, one Bean tab at a time,
// the tab is closed (awaited) before the next one opens, its id is kept in p9bn.disc, a failed read keeps the previous list and puts the error on that container's row.
let rbusy = false;                 // synchronous guard: two quick clicks can never start two readings
async function refreshChannels() {
  if (!bridge() || discovering || rbusy) return; rbusy = true;
  try { await refreshChannels0(); } finally { rbusy = false; }
}
async function refreshChannels0() {
  await loadContainers();
  let cs = ctrs.containers.filter((c) => sel.has(c.id));
  if (!cs.length) cs = ctrs.containers.filter((c) => c.id === ctrs.active);
  if (!cs.length) { setMsg('Nothing to refresh.', 'warn'); return; }
  return refreshContainers(cs, false);
}
async function refreshOne(cid) {
  if (!bridge()) return;
  if (discovering || rbusy) { setMsg('Channels are already being read — wait until that has finished.', 'warn'); return; }
  rbusy = true;
  try {
    await loadContainers();
    const c = ctrs.containers.find((x) => x.id === cid);
    if (!c) { setMsg('That container no longer exists.', 'warn'); return; }
    return await refreshContainers([c], true);
  } finally { rbusy = false; }
}
async function refreshContainers(cs, single) {
  const b = bridge();
  if (!b || discovering) return;
  const live = await sget(K.batch);
  if (running(batch) || running(live)) { setMsg('A run is in progress — wait until it has finished (Bean keeps only one tab open at a time).', 'warn'); holdMsgUntil = Date.now() + 6000; renderContainers(); return; }
  const dc = await sget(K.disc);
  if (dc && dc.state === 'running' && Date.now() - (dc.created || 0) < 180000) { setMsg('Another channel reading is still running — wait until it has finished.', 'warn'); renderContainers(); return; }
  const id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  discovering = { i: 0, n: cs.length, name: cs[0].name, cid: cs[0].id, ids: cs.map((c) => c.id), done: new Set(), single: !!single };     // set before the first await below: controls are disabled at once
  for (const c of cs) delete rowNote[c.id];
  await sset(K.disc, { id, state: 'running', created: Date.now() });
  setMsg(single ? `Reading the channels of '${cs[0].name}'… keep this window open.` : 'Reading the channels of ' + cs.length + ' container' + (cs.length === 1 ? '' : 's') + '… keep this window open.', '');
  renderContainers();
  const failed = [];
  try {
    for (let i = 0; i < cs.length; i++) {
      Object.assign(discovering, { i: i + 1, name: cs[i].name, cid: cs[i].id }); renderContainers();
      const t0 = Date.now(); let tab = null; const key = L.chKey(pid(), cs[i].id);
      const fail = async (why) => { const old = await sget(key); await sset(key, old && old.ok ? Object.assign({}, old, { at: Date.now(), err: why }) : { at: Date.now(), ok: false, channels: [], active: '', err: why }).catch(() => {}); };
      try { tab = await b.openTabInContainer({ containerId: cs[i].id, url: L.discoverUrl(id, cs[i].id, pid()), ...((await bgTabsNow()) ? { background: true } : {}) }); if (tab && tab.tabId != null) { myTabs.add(tab.tabId); await regTab(tab.tabId, 'disc', cs[i].id).catch(() => {}); await sset(K.disc, { id, state: 'running', created: Date.now(), tab: tab.tabId }); } } catch (e) { tab = null; await fail('Could not open a tab for this container'); }
      if (tab) {
        try {
          let got = false;
          for (let w = 0; w < 90; w++) { const r = await sget(key); if (r && r.at >= t0) { got = true; break; } await sleep(500); }
          if (!got) await fail('No answer from the page (timed out)');
        } finally { if (await closeTabId(tab.tabId)) await unregTab(tab.tabId); await sset(K.disc, { id, state: 'running', created: Date.now() }).catch(() => {}); }      // this container's tab is closed BEFORE the next one opens
      }
      await loadChannelCache(); normalizeSel(); saveSel();
      const ce = chCache[cs[i].id] || {};
      if (ce.err) { failed.push(cs[i].id); rowNote[cs[i].id] = { t: 'Could not refresh: ' + ce.err + (known(cs[i].id) ? ' — still showing the previous list.' : ''), kind: 'warn' }; }
      else if (known(cs[i].id) && !(rowNote[cs[i].id] && rowNote[cs[i].id].choose)) { const n = known(cs[i].id).length; rowNote[cs[i].id] = { t: `Updated · ${n} channel${n === 1 ? '' : 's'}`, kind: 'ok' }; }
      discovering.done.add(cs[i].id); renderContainers();
      if (i < cs.length - 1) await sleep(1500 + Math.random() * 1500);
    }
  } finally { await sset(K.disc, { id, state: 'done', created: Date.now() }).catch(() => {}); discovering = null; renderContainers(); }
  const withCh = cs.filter((c) => known(c.id) && !failed.includes(c.id));
  if (single) setMsg(withCh.length ? `Channels of '${cs[0].name}' updated.` : `Could not read the channels of '${cs[0].name}' (signed out, or YouTube changed its account switcher).${known(cs[0].id) ? ' The previous list was kept.' : ''}`, withCh.length ? 'ok' : 'warn');
  else setMsg(withCh.length ? 'Channels updated.' : 'Could not read a channel list (signed out, or YouTube changed its account switcher).', withCh.length ? 'ok' : 'warn');
}

// ================================================================ run state
const running = (b) => !!b && b.state === 'running' && Date.now() < L.staleAt(b);        // 1.1.2: a page that announced a navigation (graceUntil) is not lost for 2 min
const finalIt = (it) => !(it.status === 'queued' || it.status === 'running');
// 1.1.2: what becomes of the items of a group whose tab is really gone. An item whose like was SENT (or was being verified) is "liked-unverified": counted, kept in the
// ledger (so it is never clicked again), never "interrupted". Items that never started are "not-started" — not "interrupted".
function endItems(its, now) {
  its.forEach((it) => {
    if (finalIt(it)) return;
    if ((it.status === 'running' && (it.sent || it.verify)) || it.mkSeen) { it.status = 'liked'; it.code = 'liked-unverified'; it.msg = 'The like was sent, but the fresh page that should confirm it did not report back.'; it.at = now; it.hb = 0; (it.lg = it.lg || []).push([now, 'result', 'liked-unverified — the page after the click never loaded']); }
    else if (it.status === 'running') { it.status = 'failed'; it.code = 'interrupted'; it.hb = 0; (it.lg = it.lg || []).push([now, 'result', 'interrupted — the tab went quiet before any like was sent']); }
    else { it.status = 'skipped'; it.code = 'not-started'; it.msg = self.P9BEAN_ORD ? P9BEAN_ORD.MSG_QUIET : "Its container's tab went quiet after it started."; }
  });
}
// 1.1.2: progress counter + bar, computed ONLY from the run record (so it is right after a reload, in a second window, and for runs driven by the hidden runner)
const fmtDur = (ms) => { const s = Math.max(0, Math.round(ms / 1000)); return s >= 3600 ? Math.floor(s / 3600) + 'h ' + String(Math.floor(s % 3600 / 60)).padStart(2, '0') + 'm' : s >= 60 ? Math.floor(s / 60) + 'm ' + String(s % 60).padStart(2, '0') + 's' : s + 's'; };
function progressInfo(b, now) {
  const items = b.items || [], total = items.length;
  let liked = 0, already = 0, failed = 0, left = 0, unconf = 0, cur = null;
  for (const it of items) {
    const code = effective(it, b), k = L.kind(code);
    if (code === 'liked' || code === 'liked-unverified') { liked++; if (code === 'liked-unverified') unconf++; } else if (code === 'already') already++;
    else if (code === 'running') { left++; if (!cur) cur = it; } else if (code === 'queued') left++;
    else if (k !== 'busy') failed++;
  }
  const done = total - left, live = running(b), end = live ? now : (b.updated || now), elapsed = Math.max(0, end - (b.created || end));
  const eta = live && done > 0 && left > 0 ? Math.round(elapsed / done * left) : null;
  return { total, done, liked, already, failed, left, unconf, cur, elapsed, eta, live };
}
function renderProgress(b) {
  const el = document.getElementById('progress'); if (!el) return;
  const p = progressInfo(b, Date.now());
  if (!p.total) { el.hidden = true; return; }
  el.hidden = false;
  // 1.1.7.1: the count only goes UP while the run is live: Panel 9's storage mirror can bring back an OLDER copy of the run record for a moment (5 / 12 after 6 / 12), which made the number flicker between two values
  { const hi = (renderProgress.hi = renderProgress.hi && renderProgress.hi.id === b.id ? renderProgress.hi : { id: b.id, n: 0 }); if (p.live && p.done < hi.n) p.done = hi.n; else hi.n = Math.max(hi.n, p.done); }
  const pct = Math.round(p.done / p.total * 100);
  document.getElementById('pcount').textContent = `${p.done} / ${p.total} done`;
  document.getElementById('ptime').textContent = p.live ? `elapsed ${fmtDur(p.elapsed)}${p.eta != null ? ' · about ' + fmtDur(p.eta) + ' left' : ''}` : `${b.state === 'done' ? 'finished' : b.state} in ${fmtDur(p.elapsed)}`;
  const bar = document.getElementById('pbar'); document.getElementById('pfill').style.width = pct + '%'; bar.setAttribute('aria-valuenow', String(pct)); bar.className = 'pbar' + (!p.live && p.done === p.total ? (p.failed ? ' bad' : ' done') : '');
  document.getElementById('pc-liked').textContent = `${p.liked} liked${p.unconf ? ' (' + p.unconf + ' unconfirmed)' : ''}`;
  document.getElementById('pc-already').textContent = `${p.already} already liked`;
  document.getElementById('pc-failed').textContent = `${p.failed} failed`;
  document.getElementById('pc-left').textContent = `${p.left} remaining`;
  const c = p.cur;
  const ps = pauseUi(b);
  el.classList.toggle('paused', !!ps);
  if (ps) { document.getElementById('ptime').textContent = ps === 'paused' ? `PAUSED since ${L.fmtT((b.pause && b.pause.since) || (uiPause && uiPause.since) || Date.now())} · elapsed ${fmtDur(p.elapsed)}` : 'pausing… the like in progress finishes first'; document.getElementById('pnow').textContent = ps === 'paused' ? (b.pause.where && /^Bean was/.test(b.pause.where) ? `Paused: ${b.pause.where}, press Resume` : 'Paused — press Resume to carry on with the next item') : 'Pausing…'; return; }
  document.getElementById('pnow').textContent = p.live ? (c ? `Now: ${c.cname || 'container'}${c.chname ? ' / ' + c.chname : ''}` : 'Waiting for the next container…') : '';
}
function effective(it, b) {            // what to show for an item
  const stale = b.state === 'running' && !running(b);
  if (it.status === 'running') return stale ? 'interrupted' : 'running';
  if (it.status === 'queued') return b.state === 'running' ? (stale ? 'not-started' : 'queued') : 'skipped';
  if (it.status === 'failed') return it.code || 'click-failed';
  if (it.status === 'liked' || it.status === 'already') return it.status === 'liked' && it.code === 'liked-unverified' ? 'liked-unverified' : it.status;
  if (it.status === 'skipped') return it.code && it.code !== 'queued' ? it.code : 'skipped';
  if (it.status === 'stopped') return 'stopped';
  return it.status;
}
let holdMsgUntil = 0, lastBusy = null, finMsgKey = '', goBusy = false;
function renderResults() {
  { const busy = running(batch) || !!discovering; if (busy !== lastBusy) { const first = lastBusy === null; lastBusy = busy; if (!first && ctrs) setTimeout(() => renderContainers(), 0); } }     // the ↻ buttons follow the run state at once
  els.results.textContent = '';
  const b = batch;
  { const cs = document.getElementById('curstate'); if (cs) { const it = b && b.state === 'running' ? (b.items || []).find((x) => x.status === 'running') : null; const t = Date.now(); cs.textContent = it ? 'Item ' + it.n + ': ' + (it.sent && !finalIt(it) ? 'liked, confirming' : (it.step || 'working')) + ' for ' + Math.max(0, Math.round((t - (it.prog || it.at || t)) / 1000)) + ' s' + (b.pauseReq ? ' (pause requested)' : '') : b && b.state === 'running' ? (b.pauseReq ? 'Paused' : 'Between containers') : 'Idle'; cs.dataset.state = it ? String(it.step || 'working') : b && b.state === 'running' ? 'between' : 'idle'; cs.dataset.secs = it ? String(Math.round((t - (it.prog || it.at || t)) / 1000)) : '0'; } }          // 1.1.7.2: the current item's state as plain accessible text (read by the Panel 9 helper watcher)
  const live = !!b && b.state === 'running';          // 1.1.7.2 (real 09:16): a run that is not over ALWAYS has its Stop / Pause controls, even while its record is quiet (stale)
  els.clear.hidden = !b || live;
  els.stop.hidden = !live;
  els.go.hidden = running(b);                // 1.1.5: while a run is going the action row is Pause/Resume + Stop only
  { const ps = pauseUi(b); els.pause.hidden = !live || !!ps; els.resume.hidden = !live || !ps; els.resume.textContent = ps === 'pausing' ? 'Cancel pause' : 'Resume'; }
  if (!b) { refreshButtons(); return; }
  const multi = new Set(b.items.map((it) => it.cid || '')).size > 1;
  let liked = 0, already = 0, failed = 0, ledgerSkips = 0, unconf = 0; const byCode = {};
  b.items.forEach((it, i) => {
    const code = effective(it, b);
    const kind = L.kind(code);
    if (code === 'liked' || code === 'liked-unverified') { liked++; if (code === 'liked-unverified') unconf++; } else if (code === 'already') already++; else if (code === 'ledger-used') ledgerSkips++; else if (kind !== 'busy') { failed++; byCode[code] = (byCode[code] || 0) + 1; }
    const row = document.createElement('div'); row.className = 'res ' + kind;
    const dot = document.createElement('span'); dot.className = 'dot';
    const meta = document.createElement('div'); meta.className = 'meta';
    const t = document.createElement('div'); t.className = 't';
    const extra = it.msg && code !== 'liked' && code !== 'already' && code !== 'skipped' ? ' — ' + it.msg : '';
    const who = it.cname ? `Container '${it.cname}'${it.chname ? `, channel '${it.chname}'` : ''}: ` : (i + 1) + '. ';
    const via = it.vpn && it.vpn.location && (code === 'liked' || code === 'already') ? ' · via ' + it.vpn.location : '';
    t.textContent = who + (code === 'switch-failed' ? L.label(code) + (it.chname ? ' ' + it.chname : '') : L.label(code)) + extra + via; t.title = t.textContent;
    const s = document.createElement('div'); s.className = 's';
    s.textContent = it.vid + (it.lc.indexOf('.') > 0 ? ' · reply ' : ' · ') + '…' + it.lc.replace(/\..*$/, '').slice(-8) + (it.lc.indexOf('.') > 0 ? '.' + it.lc.split('.')[1].slice(-6) : '');
    meta.append(t, s);
    if (kind === 'bad' || kind === 'warn') { const w = document.createElement('div'); w.className = 'why'; w.textContent = L.hint(code) + ' [' + code + ']'; meta.append(w); }
    row.append(dot, meta);
    els.results.append(row);
  });
  for (const g of b.groups || []) {
    if (!g.restore || g.restore.indexOf('failed') !== 0) continue;
    const row = document.createElement('div'); row.className = 'res bad';
    const dot = document.createElement('span'); dot.className = 'dot'; const meta = document.createElement('div'); meta.className = 'meta';
    const t = document.createElement('div'); t.className = 't'; t.textContent = `Container '${g.name}': could not switch back to channel '${g.origName}'${g.restoreMsg ? ' — ' + g.restoreMsg : ''}`; t.title = t.textContent;
    const s2 = document.createElement('div'); s2.className = 's'; s2.textContent = 'Check which channel is active in that container before you use it.';
    meta.append(t, s2); row.append(dot, meta); els.results.append(row);
  }
  renderProgress(b, liked, already, failed, unconf);
  const finKey = b.id + ':' + b.state, quiet = !running(b) && finMsgKey === finKey;      // a finished run's summary is shown once; a later message (e.g. why a new run was refused) is not overwritten by a re-render
  if (!running(b)) finMsgKey = finKey;
  if (quiet) { /* keep what is on screen */ }
  else if (running(b) && pauseUi(b) === 'paused' && b.pause && b.pause.where && /^Bean was/.test(b.pause.where)) setMsg(`Paused: ${b.pause.where}, press Resume.`, 'warn');
  else if (running(b) && pauseUi(b)) setMsg(pauseUi(b) === 'paused' ? 'Paused — press Resume to carry on.' : 'Pausing… the like in progress finishes first, then Bean waits.', 'warn');          // 1.1.7.1: one steady text while pausing, one when paused
  else if (running(b)) { if (Date.now() >= holdMsgUntil) setMsg(multi ? 'Working… keep this window and the YouTube tab open.' : 'Working… keep the YouTube tab open.', ''); }
  else if (b.state === 'done') setMsg(`Done — ${liked} liked${unconf ? ' (' + unconf + ' not confirmed)' : ''}, ${already} already liked${ledgerSkips ? ', ' + ledgerSkips + ' skipped (channel already used on the comment)' : ''}${failed ? ', ' + failed + ' failed (' + Object.keys(byCode).map((k) => byCode[k] + '× ' + k).join(', ') + ')' : ''}.${b.vpn && b.vpn.warn && b.vpn.warn.length ? ' ' + b.vpn.warn.join(' ') : ''}`, failed ? 'warn' : 'ok');
  else if (b.state === 'stopped') {
    const blocker = b.items.find((it) => it.code === 'ytf-off' || it.code === 'no-ytf' || it.code === 'vpn-unavailable');
    if (blocker) setMsg(L.label(blocker.code) + (blocker.msg && blocker.code === 'vpn-unavailable' ? ' — ' + blocker.msg : '') + '.', 'warn');
    else setMsg(`Stopped — ${liked} liked, ${already} already liked${ledgerSkips ? ', ' + ledgerSkips + ' skipped (channel already used)' : ''}.`, 'warn');
  } else if (b.state === 'running') setMsg('The run was interrupted (popup or tab closed).', 'warn');
  refreshButtons();
  archiveRun(b); logSoon();
}
function setMsg(t, kind) { els.msg.textContent = t || ''; els.msg.className = 'msg' + (kind ? ' ' + kind : ''); }

// ================================================================ input
function renderCount() {
  parsed = L.parseMany(els.links.value);
  els.count.textContent = '';
  const mk = (cls, text) => { const s = document.createElement('span'); s.className = cls; s.textContent = text; return s; };
  if (parsed.items.length) els.count.append(mk('good', `${parsed.items.length} comment link${parsed.items.length === 1 ? '' : 's'} ready`));
  if (parsed.errors.length) { if (parsed.items.length) els.count.append(' · '); els.count.append(mk('bad', `${parsed.errors.length} problem${parsed.errors.length === 1 ? '' : 's'}`)); }
  els.count.title = parsed.errors.map((e) => `line ${e.line}: ${e.msg}`).join('\n');
  if (parsed.errors.length) { const e = parsed.errors[0]; els.count.append(document.createElement('br'), mk('bad', `Line ${e.line}: ${e.msg}`)); }
  renderPlan();
}
// 1.1.1 "Possible likes": how many channels can like each comment, counted like the Bean API's /capacity (ticked channels minus the ones the permanent ledger lists for that comment)
function renderPossible() {
  const el = els.possible; if (!el) return;
  if (!ctrs || !sel.size) { el.hidden = true; el.textContent = ''; updLikesNeededHint(); return; }
  const byId = {}; for (const c of ctrs.containers) byId[c.id] = c;
  let unknownRoute = false;
  const skipOf = (t) => { const i = self.B11 && B11.skipInfo ? B11.skipInfo(byId[t.id] || { id: t.id }) : null; if (i && i.unknown) unknownRoute = true; return i && i.reason ? i.reason : ''; };
  const ready = !!(self.B11 && B11.S && B11.S.ledReady);
  const fa = document.activeElement, keep = fa && fa.classList && fa.classList.contains('lqin') ? { key: fa.dataset.key, a: fa.selectionStart, b: fa.selectionEnd } : null;
  const P = (() => { const rc = {}, res = (vid, lc, ck) => { const k = vid + '|' + lc; return (rc[k] || (rc[k] = P9BEAN_ORD.reservedKeys(ordData, vid, lc))).has(ck); }; return L.possibleLikes(healthyTargets(), parsed.items, (vid, lc, ckey) => (self.B11 ? B11.used(vid, lc, ckey) : false), skipOf, res); })();
  el.hidden = false; el.textContent = '';
  const add = (cls, text, parent) => { const d = document.createElement('div'); d.className = cls; d.textContent = text; (parent || el).append(d); return d; };
  const head = add('pl', `Possible likes: ${P.per} per comment`); head.id = 'possibleHead';
  head.title = 'Ticked channels (a ticked container without a channel list counts as one). The Bean API counts the same way.';
  if (P.skipped.length) add('pe', `Likely skipped (estimate): ${P.skipped.slice(0, 4).map((x) => (x.chname ? x.cname + ' / ' + x.chname : x.cname) + ' — ' + x.reason).join('; ')}${P.skipped.length > 4 ? '; …' : ''} → about ${P.per - P.skipped.length} per comment`);
  if (unknownRoute) add('pe', 'Estimate: containers that bypass the VPN will be skipped ("Skip containers that bypass the VPN" is on); open VPN locations to check which ones.');
  const est = P.skipped.length > 0 || unknownRoute;
  if (P.perLink.length) {
    const box = document.createElement('div'); box.id = 'possibleLinks';
    for (const x of P.perLink.slice(0, 8)) {
      const r = document.createElement('div'); r.className = 'lr'; r.dataset.n = x.n;
      const a = document.createElement('span'); a.textContent = `Link ${x.n}`; a.title = x.vid + ' · ' + x.lc;
      const v = document.createElement('span'); v.className = 'lv'; v.textContent = `${x.avail} of ${x.total} possible${x.used ? ` (${x.used} already used)` : ''}${est ? ` · about ${x.expected} expected` : ''}`;
      r.append(a, v);
      if (parsed.items.length > 1) { const w = document.createElement('span'); w.className = 'lq'; const inp = document.createElement('input'); inp.type = 'number'; inp.min = '1'; inp.step = '1'; inp.className = 'lqin'; inp.dataset.key = x.vid + '|' + x.lc; inp.placeholder = 'all'; inp.setAttribute('aria-label', `Likes for link ${x.n}`); inp.value = qty.per[inp.dataset.key] == null ? '' : qty.per[inp.dataset.key];
        inp.addEventListener('input', () => { qty.per[inp.dataset.key] = inp.value; updQty(); }); const mx = document.createElement('span'); mx.className = 'lmax hint'; mx.dataset.key = inp.dataset.key; mx.textContent = `max ${x.max}`; mx.title = x.reserved ? `${x.reserved} channel${x.reserved === 1 ? ' is' : 's are'} reserved by orders in the queue` : 'ticked channels minus the ones that already liked it'; w.append(inp, mx); r.append(w); }
      box.append(r);
    }
    if (P.perLink.length > 8) add('pk', `… and ${P.perLink.length - 8} more link${P.perLink.length - 8 === 1 ? '' : 's'}`, box);
    el.append(box);
    const t = add('lr tot', ''); t.id = 'possibleTotal'; const ta = document.createElement('span'); ta.textContent = 'Total'; const tv = document.createElement('span'); tv.className = 'lv';
    tv.textContent = `${P.totals.avail} of ${P.totals.all} possible${P.totals.used ? ` (${P.totals.used} already used)` : ''}${est ? ` · about ${P.totals.expected} expected` : ''}`; t.append(ta, tv);
  }
  add('pk', 'Counted like the Bean API’s capacity: the ledger is applied and channels reserved by orders in the queue are left out (they are the “max”).' + (ready ? '' : ' (Ledger still loading.)'));
  updLikesNeededHint(P);
  if (keep) { const e2 = [...el.querySelectorAll('.lqin')].find((i) => i.dataset.key === keep.key); if (e2) { e2.focus(); try { e2.setSelectionRange(keep.a, keep.b); } catch (_) { /* number inputs have no selection */ } } }
}
function refreshButtons() {
  renderPossible();
  els.go.disabled = !parsed.items.length || !!discovering || gateV === 'off' || gateV === 'missing' || overCap();          // 1.1.7: a run in progress no longer blocks it: the new order joins the queue
  setGoLabel();
  els.go.classList.toggle('loading', !!goBusy);
}
function setGoLabel() {
  if (ctrs && qtyActive()) { const E = effQty(), sq = E.reduce((n, x) => n + (x.q != null ? x.q : x.max), 0), sm = E.reduce((n, x) => n + x.max, 0), nd = E[0] && E[0].needed; els.go.textContent = nd != null ? `Like ${sq} needed` : `Like ${sq} of ${sm} possible`; return; }
  const n = ctrs ? actionCount() : parsed.items.length;
  els.go.textContent = n > 1 ? `Like ${n} comments` : 'Like comment';
}
// typing in a quantity field: only the numbers around it are updated (the fields themselves are never rebuilt while typing)
function updQty() {
  if (!ctrs || !sel.size || !parsed.items.length) return;
  const E = effQty(), mn = E.length ? Math.min(...E.map((x) => x.max)) : 0;
  if (els.qmax) els.qmax.textContent = E.length > 1 && E.some((x) => x.max !== mn) ? `max ${mn} (links differ: see each link)` : `max ${mn}`;
  for (const x of E) { const el = document.querySelector(`.lmax[data-key="${CSS.escape(x.key)}"]`); if (el) el.textContent = `max ${x.max}${x.clamped ? ' · lowered to it' : ''}`; }
  renderPlan(); setGoLabel();
}
// ================================================================ run control
// read-modify-write on the run record (the YouTube tabs write it too, so always read right before writing)
async function mutate(fn) {
  const b = await sget(K.batch); if (!b) return null;
  const before = self.P9BEAN_ORD ? JSON.parse(JSON.stringify(b)) : null;
  const r = fn(b); if (r === false) return b;
  b.rev = (b.rev || 0) + 1;                                  // 1.1.7: every write of this page bumps the revision: a stale copy that comes back from Panel 9's storage mirror carries an older one
  await sset(K.batch, b); batch = b;
  if (before) verifyWrite(before, b).catch(() => {});
  return b;
}
// 1.1.7 run-record race: this page's write can be replaced by an OLDER copy (Panel 9 mirrors whole storage snapshots between sessions). A moment later the record is read again; when it is an older copy
// (lower rev), exactly the fields this write changed are put back (per-field merge onto the current record, max 2 times). A record with our rev or higher is never touched.
const raceStat = { repaired: 0, checked: 0 };
async function verifyWrite(before, after) {
  const want = P9BEAN_ORD.diffWant(before, after);
  if (!Object.keys(want.batch).length && !Object.keys(want.items).length && !Object.keys(want.groups).length) return;
  for (let n = 0; n < 2; n++) {
    await sleep(300); raceStat.checked++;
    const back = await sget(K.batch), plan = P9BEAN_ORD.repairPlan(back, after, want);
    if (plan.act !== 'repair') return;
    if (back.state !== 'running' && after.state === 'running' && !want.batch.state) return;          // never bring a finished run back
    P9BEAN_ORD.applyWant(back, want); back.rev = Math.max(back.rev || 0, after.rev || 0); raceStat.repaired++;
    await sset(K.batch, back); batch = back; try { chrome.storage.local.set({ 'p9bn.race': { at: Date.now(), repaired: raceStat.repaired, checked: raceStat.checked, last: plan.miss.slice(0, 6) } }); } catch (_) { /* diagnostics only */ }
  }
}
// 1.1.6.5: background tabs are OFF by default (setting p9bn.bgTabs === true turns them on; read fresh before every open, from the settings toggle). 1.1.6.4 always sent background:true; Panel 9 2.3.23 honours it by HIDING the view,
// and on real YouTube the comments never load in a hidden view. So the flag is only sent when asked for (Panel 9 2.3.24+ is meant to keep such a tab loading). One setting for every run: popup, API, queued orders.
const bgTabsNow = async () => { try { return L.bgTabsOn(await sget(L.BGTABS_KEY)); } catch (_) { return false; } };
let lastOpenBg = false;
async function openInContainer(cid, url) {
  const b = bridge();
  if (cid && b) { const args = { url, containerId: cid }; lastOpenBg = await bgTabsNow(); if (lastOpenBg) args.background = true; return b.openTabInContainer(args); }       // unset/false: NO background key at all (1.1.6.5)
       // a new tab IN that container: its session, its Google account / channel
  window.open(url, '_blank');                                               // no bridge: Panel 9 opens it in the container of the active tab
  return { legacy: true };
}
// 1.1.0 TAB RULE: Bean keeps AT MOST ONE tab of its own open at any time (runs, API jobs, channel discovery). A container's tab is closed as soon as that container's
// work is done, BEFORE the next container's tab is opened; also on Stop, on errors, on completion and when a run is cleared. Tab ids are kept in the run record
// (group.tab), so any Bean page (popup or background runner) can close them. A tab that is already gone is simply ignored. If this Panel 9 has no closeTab bridge,
// nothing can be closed from here (the tab is then left open, as in 1.0.0) — Panel 9 2.3.9 and newer always have it; Bean requires 2.3.10+.
const closedTabs = new Set(), myTabs = new Set(), tabOf = new Map(), closeTries = {};       // tabOf: run id:container id -> tab id (this page's own memory of what it opened)
const canClose = () => { const b = bridge(); return !!(b && typeof b.closeTab === 'function'); };
// 1.1.6.3 VERIFIED CLOSE (the real 1.1.6.2 run left the old tab open after "closing this tab and continuing in a NEW tab"): a tab counts as closed ONLY after the bridge confirmed it
// (or said it is not one of ours any more). A failed call is retried in place (3 tries), a second caller waits for the call in flight instead of being told "closed", and the tab stays in the registry
// until it really is closed.
const closing = new Map();
async function closeTabId(id) {
  if (id == null) return false;
  if (!canClose()) { myTabs.delete(id); return false; }
  const key = String(id); if (closedTabs.has(key)) { myTabs.delete(id); return true; }
  if (closing.has(key)) return closing.get(key);
  const p = (async () => {
    for (let n = 0; n < 3; n++) {
      try {
        if (self.__beanCloseFail > 0) { self.__beanCloseFail--; throw new Error('test: closeTab failed'); }      // test hook (mock runs only): the next N close calls fail
        await bridge().closeTab({ tabId: id });
      } catch (e) {
        if (/not a tab opened/i.test(String((e && e.message) || e))) { closedTabs.add(key); myTabs.delete(id); return true; }       // already closed / not ours: nothing more can be done
        closeTries[key] = (closeTries[key] || 0) + 1; await sleep(250 * (n + 1)); continue;
      }
      closedTabs.add(key); if (closedTabs.size > 400) closedTabs.delete(closedTabs.values().next().value); myTabs.delete(id); return true;
    }
    return false;
  })().finally(() => closing.delete(key));
  closing.set(key, p); return p;
}
// close the tabs of a run's containers. mode 'done': only finished containers; 'all': every container of that record; 'sweep': 'all' + every tab this page opened itself
// (only for this page's OWN run: a stale copy of an older record, which the storage mirror can hand us, must never close the live tab of the current run)
async function closeRunTabs(rec, mode) {
  if (rec) for (const g of rec.groups || []) if (g.tab != null && (mode !== 'done' || g.status === 'done')) await closeTabId(g.tab);
  if (mode === 'sweep') for (const id of [...myTabs]) await closeTabId(id);
}
// 1.1.2 TAB REGISTRY: every tab Bean opens for a run is written to ONE key of its own (p9bn.tabidx) by the page that opened it, right when it opens — the run record is
// rewritten by the YouTube tab and by the popup, and a write can lose group.tab (the real 1.1.1 log left 3 tabs open). The registry is only ever added to by the opener and
// pruned by whoever closes. sweepTabs(keep) closes every registered tab except those keep(entry) says belong to the group that is working right now.
// 1.1.7 (job_7JCK left Bean tabs open in containers 25, 26, 27, 30, 31): the registry is no longer ONE list key that two pages rewrite whole (a stale mirror copy took entries away); every tab has a SLOT KEY of its own,
// p9bn.tab.<0..39> = { id, run, cid, at }, written by the opener and removed by whoever closes it. (Legacy p9bn.tabidx is only pruned.)
const TABIDX = 'p9bn.tabidx', TABKEY = 'p9bn.tab.', TABSLOTS = 40;
const tabKeys = () => Array.from({ length: TABSLOTS }, (_, k) => TABKEY + k);
async function regList() {
  const keys = tabKeys(); let v = {}; try { v = await chrome.storage.local.get(keys); } catch (_) { return []; }
  const now = Date.now(); return keys.map((k, s) => ({ slot: s, key: k, e: v[k] })).filter((x) => x.e && x.e.id != null && now - (x.e.at || 0) < 6 * 3600000).map((x) => Object.assign({ slot: x.slot, key: x.key }, x.e));
}
async function regTab(id, run, cid) {
  if (id == null) return;
  const put = async () => { const l = await regList(); let s = (l.find((x) => x.id === id) || {}).slot; if (s == null) { const used = new Set(l.map((x) => x.slot)); for (let k = 0; k < TABSLOTS; k++) if (!used.has(k)) { s = k; break; } if (s == null) s = l.sort((a, b) => (a.at || 0) - (b.at || 0))[0].slot; } await sset(TABKEY + s, { id, run: run || '', cid: cid || '', at: Date.now() }); };
  await put();
  // 1.1.6.3: Panel 9 copies the whole storage snapshot between sessions, so a registry write can be lost; the entry is read back and written again until it is there (a tab that is not in the registry cannot be swept)
  for (let n = 0; n < 3 && !closedTabs.has(String(id)); n++) { await sleep(350); if ((await regList()).some((x) => x.id === id)) return; await put(); }
}
async function unregTab(id) { try { const rm = (await regList()).filter((x) => x.id === id).map((x) => x.key); if (rm.length) await chrome.storage.local.remove(rm); } catch (_) { /* best effort */ } }
function activeKeep(b) {
  if (!b || b.state !== 'running') return null;
  const live = openGroups(b).filter((g) => Date.now() <= memStale(b, g));          // 1.1.7: alive by the runner's own memory (open time / last heartbeat seen / grace)
  if (!live.length) return null;
  return (e) => e.run === b.id && live.some((g) => (g.cid || '') === (e.cid || ''));
}
async function sweepTabs(keep) {
  try {
    if (!keep) await chrome.storage.local.remove('p9bn.bind').catch(() => {});       // 1.1.3: no run is waiting for a page: the one-shot hand-over of a tab is void
    const l = await regList(); if (!l.length) return;
    const gone = [];
    for (const e of l) { if (keep && keep(e)) continue; if (await closeTabId(e.id)) gone.push(e.key); }
    if (gone.length) await chrome.storage.local.remove(gone);
  } catch (_) { /* best effort */ }
}
// 1.1.6.3: close everything the registry (and this page's memory) knows except what keep() protects, and CHECK: the registry is read again and every entry that is not protected must be closed. Returns
// { ok, left }. A tab that will not close is retried (4 passes) — the caller must not open another tab while 'left' is not empty (the one-tab rule).
async function sweepVerified(keep, passes) {
  let left = [];
  for (let n = 0; n < (passes || 4); n++) {
    await sweepTabs(keep);
    if (!keep) for (const id of [...myTabs]) await closeTabId(id);
    left = (await regList()).filter((e) => !(keep && keep(e)) && !closedTabs.has(String(e.id))).map((e) => e.id);
    if (!keep) for (const id of myTabs) if (!left.includes(id)) left.push(id);
    if (!left.length) return { ok: true, left };
    await sleep(500);
  }
  return { ok: false, left };
}
// Panel 9 mirrors chrome.storage between sessions by whole-snapshot copy, so two sessions writing within ~100 ms can lose one write (an older record comes back,
// or a Stop is reverted). The popup is the one component that knows the intended state of its run, so it repairs those two cases.
const fin = {};                    // run id -> { item index -> the final state this popup has seen }: a stale mirror copy must never turn a finished item back into a running one
function noteFinal(b) {
  if (!b || !own.id || b.id !== own.id || !Array.isArray(b.items)) return;
  const m = fin[b.id] || (fin[b.id] = {});
  b.items.forEach((it, i) => { if (finalIt(it) && !m[i]) m[i] = JSON.parse(JSON.stringify(it)); });
}
const finalState = {};             // run id -> 'done' | 'stopped' once this page has seen the run over
async function heal() {
  if (!own.id || !own.last || own.cleared) return;
  const cur = await sget(K.batch);
  noteFinal(cur);
  // 1.1.1: a run that is over STAYS over. A late write from a YouTube tab / a stale mirror copy that shows it "running" again is repaired and every tab is closed again.
  if (cur && cur.id === own.id && cur.state !== 'running') finalState[cur.id] = { state: cur.state, items: JSON.parse(JSON.stringify(cur.items || [])) };
  else if (cur && cur.id === own.id && cur.state === 'running' && finalState[cur.id] && !own.cleared) {
    const f = finalState[cur.id]; cur.state = f.state; cur.updated = Date.now();
    cur.items = cur.items.map((it, i) => (f.items[i] && finalIt(f.items[i]) ? f.items[i] : (finalIt(it) ? it : Object.assign(it, { status: 'skipped', code: it.code || 'stopped' }))));
    await sset(K.batch, cur); batch = cur; renderResults(); await closeRunTabs(cur, 'sweep'); return;
  }
  if (cur && cur.id === own.id && fin[own.id] && Array.isArray(cur.items) && !(own.stopped && cur.state === 'running')) {
    const m = fin[own.id]; let n = 0;
    cur.items.forEach((it, i) => { if (m[i] && !finalIt(it)) { cur.items[i] = JSON.parse(JSON.stringify(m[i])); n++; } });
    if (n) { cur.updated = Date.now(); await sset(K.batch, cur); }
  }
  if (!cur || (cur.id !== own.id && (cur.created || 0) < (own.last.created || 0))) { if (own.last.state === 'running') await sset(K.batch, own.last); return; }
  if (cur.id === own.id && own.stopped && cur.state === 'running') {
    cur.state = 'stopped'; cur.updated = Date.now();
    cur.items.forEach((it) => { if (it.status === 'queued') { it.status = 'skipped'; it.code = 'stopped'; } });
    await sset(K.batch, cur);
  }
}
// 1.1.6.4 A RUN SURVIVES AN UPDATE OR RELOAD OF BEAN. After an update / reload the YouTube tab of a run is an orphan: its script is dead (it cannot write or answer), so before this the run was
// ended as "interrupted" and Resume did nothing until the Bean window was closed and opened again. Now, when this page starts (or a paused run goes silent), the popup asks the tab "are you alive?"
// (p9bn.ping -> p9bn.alive). No answer = orphan: the run is KEPT and PAUSED ("Paused: Bean was updated, press Resume"), the dead tab is closed, the group goes back to the queue and the items that were
// open go back to 'queued' (a like that was already sent is only ever verified: its marker p9bn.clk.* and the ledger survive, so nothing is repeated). Resume then works at once: a fresh tab continues.
let lastGoneCheck = 0;
// is the tab that works on this run alive? (it answers p9bn.ping with p9bn.alive within a few seconds)
// 1.1.7.2 CLICK EVIDENCE BEFORE ANY "NOTHING WAS CLICKED": a stale copy of the run record (Panel 9's mirror) can lose an item's "sent" flag. Before a run or a container is
// ended as silent, every open item is checked against its own like marker (p9bn.clk.*) and the ledger; a click found there is marked mkSeen, so it ends "Like sent - not confirmed"
// (counted, never clicked again) instead of "not started / nothing was clicked". Returns { key: true } for the items with evidence.
async function clickEvidence(b) {
  const out = {}; if (!b || !b.items) return out;
  for (const it of b.items) {
    if (it.status !== 'queued' && it.status !== 'running') continue;
    let hit = false;
    try { if (self.B11 && B11.used && it.vid && it.ck && B11.used(it.vid, it.lc, it.ck)) hit = true; } catch (_) { /* ledger not ready */ }
    if (!hit) { try { const mx = self.B17 && B17.ports && B17.ports.markerExists; if (mx && it.vid && it.ck) hit = !!(await Promise.race([mx(it.vid, it.lc, it.ck), new Promise((r) => setTimeout(() => r(false), 3000))])); } catch (_) { /* unreadable: no evidence */ } }
    if (hit) out[it.vid + '|' + (it.lc || '') + '|' + it.ck] = true;
  }
  return out;
}
function applyEvidence(b, ev, now) { let n = 0; for (const it of b.items || []) { if ((it.status === 'queued' || it.status === 'running') && ev[it.vid + '|' + (it.lc || '') + '|' + it.ck] && !it.mkSeen) { it.mkSeen = now; it.sent = it.sent || now; n++; } } return n; }
self.P9BEAN_EVID = { clickEvidence, applyEvidence };
// 1.1.7.2 SILENCE IS JUDGED FROM WHAT THIS PAGE HEARS, not from the stored record (which may be an old copy, with old heartbeats): before a run is ended as lost the tabs are asked directly
async function heardDirect(cur) { try { if (await tabAnswers(cur)) { const t = Date.now(); for (const g of cur.groups || []) if (g.status === 'opening' || g.status === 'running') memOf(cur.id, g.cid, g).lastSeenAt = t; return true; } } catch (_) { /* no answer */ } return false; }
self.P9BEAN_HEARD = heardDirect;
// 1.1.7.2 BOUNDED AFTER THE CLICK (Oluchi's run i7de3vi7mw1sir2y #5, 08:46): the like was made on YouTube, but the tab's last report never reached this page and the item showed "liking" for 10 minutes.
// A running item whose like is PROVEN sent (the record's sent flag, its click marker or the ledger) gets 35 s from the moment this page first saw that proof: then it ends "Like sent - not confirmed"
// (counted, kept in the ledger, never clicked again) and the run moves on. A report that does arrive later still upgrades it to "liked".
const POST_CLICK_MS = 20000, POST_CLICK_HARD_MS = 45000, sentSeen = {};          // 35 s without progress, 90 s at most even while the tab still says it is busy
async function postClickBound(cur) {
  const t = Date.now(), run = (cur.items || []).filter((it) => it.status === 'running'); if (!run.length) return {};
  const ev = await clickEvidence({ items: run }).catch(() => ({})), out = {};
  for (const it of run) { const k = cur.id + '|' + it.vid + '|' + (it.lc || '') + '|' + it.ck; if (!(it.sent || ev[it.vid + '|' + (it.lc || '') + '|' + it.ck])) { delete sentSeen[k]; continue; } sentSeen[k] = sentSeen[k] || t; if (t - sentSeen[k] > POST_CLICK_MS && (t - (it.prog || 0) > POST_CLICK_MS || t - sentSeen[k] > POST_CLICK_HARD_MS)) out[it.vid + '|' + (it.lc || '') + '|' + it.ck] = true; }
  return out;
}
async function tabAnswers(cur, cid) {          // 1.1.7.5: with a container id, only THAT container's tab counts (up to 4 tabs answer at once: one live tab must not hide a dead one)
  const t = Date.now(); await sset(K.ping, t).catch(() => {});
  for (let t0 = Date.now(); Date.now() - t0 < 4500;) {
    if (cid == null) { const a = await sget(K.alive).catch(() => null); if (a && a.bid === cur.id && a.for >= t) { self.__lastAlive = a; return true; } }
    else { const v = await chrome.storage.local.get([K.alive, K.alive + '.' + (cid || '')]).catch(() => ({})); for (const a of [v[K.alive + '.' + (cid || '')], v[K.alive]]) if (a && a.bid === cur.id && a.for >= t && (a.cid || '') === (cid || '')) { self.__lastAlive = a; return true; } }
    await sleep(250);
  }
  return false;
}
let lastSilentCheck = 0;
// 1.1.7.1 PAUSE UI: ONE steady state per press. The record the popup reads can come back older (Panel 9 mirrors storage between sessions) and flip the buttons between "running", "pausing" and "paused" for a few seconds. The popup therefore latches
// what it has shown: pressing Pause = "pausing" at once; "paused" once seen sticks (an older record never takes it back); Resume = running for 6 s whatever an older record says. The latch is dropped when the run ends or the record has said nothing for 8 s.
let uiPause = null, uiResume = null;
function pauseUi(b) {
  const now = Date.now();
  if (!b || b.state !== 'running') { uiPause = null; uiResume = null; return ''; }
  if (uiResume && uiResume.bid === b.id && now - uiResume.at < 6000) return '';
  const real = L.pauseState(b);
  if (real) { if (!uiPause || uiPause.bid !== b.id) uiPause = { bid: b.id, st: real, at: now, seen: now }; uiPause.seen = now; if (real === 'paused') { uiPause.st = 'paused'; uiPause.since = b.pause.since; } return uiPause.st; }
  if (uiPause && uiPause.bid === b.id && now - Math.max(uiPause.at, uiPause.seen) < 8000) return uiPause.st;
  uiPause = null; return '';
}
// 1.1.7: what to write down when a tab misses its heartbeat (Oluchi's logs showed only "nothing" - no VPN state, no way to tell a dead script from an error page)
async function missDiag(b, g, sn) {
  const parts = [], m = memOf(b.id, g.cid, g), now = Date.now();
  try { const v = self.B11 && B11.vpnPeek ? await B11.vpnPeek() : null; parts.push(b.vpn && b.vpn.on ? (v ? `VPN ${v.state}${v.location ? ' at ' + v.location : ''}${v.err ? ' (' + v.err + ')' : ''}` : 'VPN state not readable') : 'VPN not used'); } catch (_) { parts.push('VPN state not readable'); }
  parts.push(`Bean ${ROLE} page runtime id ${(chrome.runtime && chrome.runtime.id) ? 'ok' : 'MISSING (extension reloaded?)'}`);
  parts.push(`opened ${Math.round((now - (m.openedAt || now)) / 1000)} s ago${m.vpnDoneAt ? ', VPN ready ' + Math.round((m.openedAt - m.vpnDoneAt) / 1000) + ' s before' : ''}, last heartbeat seen ${Math.round((now - (m.lastSeenAt || now)) / 1000)} s ago`);
  parts.push(sn && sn.at >= (m.cut || m.openedAt || 0) ? `a Bean page had started (${String(sn.url || '?').split('?')[0]})` : 'no Bean page ever started in the tab (Panel 9 error page / the page never loaded?)');
  const al = self.__lastAlive; if (al && al.bid === b.id && now - (al.at || 0) < 60000) parts.push(`last ping answer ${Math.round((now - al.at) / 1000)} s ago from ${al.host || '?'} (script runtime id ${al.rt === false ? 'MISSING' : 'ok'})`);
  parts.push('tab address: not available from Panel 9');
  return parts.join('; ');
}

// 1.1.7.1: Pause waits for the like in progress, never for a STUCK step: when Pause was asked 4+ s ago and every open item has shown no progress for 10 s (its tab beats but waits on a step that never settles, or its heartbeat stopped), and (a like that was already sent is kept: only verified later)
// the item goes back to the queue (nothing clicked again), its tab is closed (verified) and the run is paused at once. Resume opens a fresh tab and carries on.
let lastStuckPause = 0;
async function pauseStuckStep(cur) {
  if (!cur || cur.state !== 'running' || !cur.pauseReq || (cur.pause && cur.pause.since) || (cur.owner || 'popup') !== ROLE) return false;
  if (pausedBy[cur.id] && pausedBy[cur.id].since) return false;          // a tab that reports "I hold for the Pause" is not stuck (it is doing exactly what Pause asks)
  const now = Date.now(); if (now - cur.pauseReq < 1000 || now - lastStuckPause < 1500) return false;          // 1.1.7.2: Paused within ~2-3 s ALWAYS: the step in progress is not waited for (a click marker / sent flag makes the resumed item verify-only)
  const open = (cur.items || []).filter((it) => it.status === 'running'); if (!open.length && !(cur.groups || []).some((g) => g.status === 'opening' || g.status === 'running')) return false;          // 1.1.7.2 (R82): a container still OPENING (its page never started) is cut the same way          // every open item silent for 10+ s; a like already SENT is kept (sent / mk stay): after Resume a fresh tab only VERIFIES it, never clicks again
  lastStuckPause = now; const msg = 'the step in progress was stopped for the Pause (a like already sent is only verified after Resume, never clicked again)';
  const b = await mutate((b) => {
    if (b.id !== cur.id || b.state !== 'running' || !b.pauseReq || (b.pause && b.pause.since)) return false;
    for (const g of b.groups || []) if (g.status === 'opening' || g.status === 'running') { g.status = 'queued'; g.recycle = (g.recycle || 0) + 1; delete g.tab; g.lostAt = now; }
    for (const it of b.items || []) if (it.status === 'running') { it.status = 'queued'; it.hb = 0; it.prog = 0; it.pauseCut = (it.pauseCut || 0) + 1; if (it.sent) it.verify = it.verify || now; (it.lg = it.lg || []).push([now, 'pause', 'Pause was requested while this step was stuck (' + (it.step || 'no progress') + '): it was cancelled, nothing was clicked; it goes back to the queue']); }
    b.pause = { since: now, where: msg }; b.nextAt = 0; b.graceUntil = 0; b.updated = now;
    (b.events = b.events || []).push([now, 'paused — ' + msg + '; the old tab is closed, press Resume to carry on']); b.events = b.events.slice(-20);
    return true;
  });
  if (!b) return false;
  await sset(K.pause, { bid: cur.id, at: b.pauseReq || now }).catch(() => {}); await sweepVerified(null, 3).catch(() => {}); return true;
}

async function recoverAfterReload(why) {
  const cur = await sget(K.batch);
  if (!cur || cur.state !== 'running' || (cur.owner || 'popup') !== ROLE) return false;
  const out = (cur.groups || []).some((g) => g.status === 'opening' || g.status === 'running') || (cur.items || []).some((it) => it.status === 'running');
  if (!out || Date.now() < (cur.graceUntil || 0)) return false;          // nothing is out there / a page that announced a navigation (or is still opening) brings its own fresh script
  // 1.1.7.1: this check used to pause the run by itself ("paused - Bean was reloaded", real run zo8n4jxzmw0n9e3l 13:28:50) when the ping answer took longer than 4.5 s through Panel 9's slow storage mirror (2-8 s each way): a live tab looked orphaned.
  // The ping now waits 12 s, and a tab whose heartbeat is younger than 8 s at the end of the wait is alive whatever the ping said (a tab orphaned by a reload cannot answer and has stopped beating).
  const t = Date.now(); await sset(K.ping, t).catch(() => {});
  for (let t0 = Date.now(); Date.now() - t0 < 12000;) { const a = await sget(K.alive).catch(() => null); if (a && a.bid === cur.id && a.for >= t) return false; await sleep(250); }
  { const c2 = await sget(K.batch).catch(() => null), nw = Date.now(); if (c2 && c2.id === cur.id && (c2.items || []).some((it) => it.status === 'running' && it.hb && nw - it.hb < 8000)) return false; }
  const now = Date.now(), msg = why || 'Bean was reloaded';
  const b = await mutate((b) => {
    if (b.id !== cur.id || b.state !== 'running') return false;
    for (const g of b.groups || []) if (g.status === 'opening' || g.status === 'running') { g.status = 'queued'; g.recycle = (g.recycle || 0) + 1; delete g.tab; g.lostAt = now; }
    for (const it of b.items || []) if (it.status === 'running') { it.status = 'queued'; it.hb = 0; it.reloaded = (it.reloaded || 0) + 1; (it.lg = it.lg || []).push([now, 'reload', msg + ' while this item was open: it goes back to the queue (a like that was already sent is only checked again, never repeated)']); }
    b.pauseReq = b.pauseReq || now; b.pause = { since: (b.pause && b.pause.since) || now, where: msg }; b.nextAt = 0; b.graceUntil = 0; b.updated = now;
    (b.events = b.events || []).push([now, 'paused — ' + msg + '; the old tab is closed, press Resume to carry on']); b.events = b.events.slice(-20);
    return true;
  });
  await sset(K.pause, { bid: cur.id, at: (b && b.pauseReq) || now }).catch(() => {});
  await sweepVerified(null, 3);
  if (b) { batch = b; renderResults(); }
  return true;
}
// 1.1.7: tab-seen / google-check markers belong to one run: removed when it is over; anything older than 6 h is pruned at start
const cleaned = new Set();
async function cleanMarkers(bid) {
  try {
    if (bid && cleaned.has(bid)) return; if (bid) cleaned.add(bid);
    const all = await chrome.storage.local.get(null), rm = [], old = Date.now() - 6 * 3600000;
    for (const k of Object.keys(all)) { const own = bid && (k.indexOf('p9bn.hb.' + bid + '.') === 0 || k.indexOf('p9bn.rep.' + bid + '.') === 0); if (own) { rm.push(k); continue; } if (k.indexOf('p9bn.stop.') === 0) { if (!all[k] || (all[k].at || 0) < old) rm.push(k); continue; } if (k.indexOf(L.TABSEEN) !== 0 && k.indexOf(L.GCHECK) !== 0) continue; const v = all[k]; if ((bid && k.indexOf('.' + bid + '.') > 0) || !v || (v.at || 0) < old) rm.push(k); }
    if (rm.length) await chrome.storage.local.remove(rm);
  } catch (_) { /* best effort */ }
}
// ================================================================ 1.1.7 SPLIT WRITERS (runner side; lib/reports.js)
// The tabs never write the run record. They write their own report + heartbeat keys; THIS page (the owner of the run) merges them, and judges "is this tab alive?" from what IT saw and when (its own clock and
// memory: open time, VPN-done time, tab id, last heartbeat seen), never from the age of the shared record, which a stale mirror copy can reset.
const mem = {};      // run id : container id -> { openedAt, vpnDoneAt, tab, lastSeenAt, graceUntil, cut, applied: {slot: {gen, seq, rseq}}, prevRep: {slot: report} }
const memOf = (bid, cid, g) => { const k = bid + ':' + (cid || ''); if (!mem[k]) { const t = Date.now(); mem[k] = { openedAt: (g && g.openedAt) || t, vpnDoneAt: 0, tab: g && g.tab != null ? g.tab : null, lastSeenAt: t, graceUntil: 0, cut: 0, applied: {}, prevRep: {} }; } return mem[k]; };
// when does the silence of this group's tab count as lost? last heartbeat SEEN + 45 s, or the open / navigation grace, or a pause
const memStale = (b, g) => { const m = memOf(b.id, g.cid, g); return Math.max(m.short && m.graceUntil ? 0 : m.lastSeenAt + STALE_MS, m.graceUntil || 0, b.pauseReq && b.pause && b.pause.since ? b.pause.since + L.PAUSE_MAX_MS : 0); };
// 1.1.7: when did THIS page last hear from the run? (the record's own age counts, but a stale copy cannot make a live run look old: the runner's memory of the last heartbeat seen counts too)
const runHeardAt = (b) => { let t = b.updated || b.created || 0; for (const g of b.groups || []) { const m = mem[b.id + ':' + (g.cid || '')]; if (m && m.lastSeenAt > t) t = m.lastSeenAt; } return t; };
const openGroups = (b) => (b.groups || []).filter((g) => g.status === 'opening' || g.status === 'running');
// 1.1.7.8 PARALLEL CONTAINERS (lib/steps.js): up to 4 containers are open at once. Closing tabs is therefore PER CONTAINER: closing / checking before an open, a VPN-drop reopen or a lost tab
// touches only that container's tab; the tabs of the other open containers are kept (keepOthers).
const ST = self.P9BEAN_STEPS, waveMem = {}, lastOpenAt = {};
const waveOf = (b) => { const r = b.wave, m = waveMem[b.id]; if (r && m) return (r.n || 0) > (m.n || 0) || ((r.n || 0) === (m.n || 0) && (r.cids || []).length >= (m.cids || []).length) ? r : m; return r || m || null; };          // a stale mirror copy can lose b.wave: this page remembers it
function keepOthers(b, cid) {
  // 1.1.7.9 (live c4l4j9rvmw57odgc): a stale mirror copy can lose other groups' opening/running status right when we open the next wave member.
  // If keepOthers then returns null, sweepVerified(null) closes EVERY Bean tab and kills siblings mid-step (shown as interrupted). Always keep containers this page still knows are live.
  const live = new Set(), skip = cid || '';
  for (const g of openGroups(b)) if ((g.cid || '') !== skip) live.add(g.cid || '');
  if (b) {
    for (const g of b.groups || []) {
      const c = g.cid || ''; if (c === skip) continue;
      const m = mem[b.id + ':' + c];
      if (m && (m.tab != null || m.heard) && Date.now() - (m.lastSeenAt || 0) < 180000) live.add(c);
      if (tabOf.has(b.id + ':' + c)) live.add(c);
    }
    const w = waveOf(b); if (w) for (const c of w.cids || []) if (c && c !== skip) live.add(c);
  }
  if (!live.size) return null;
  return (e) => e && e.run === b.id && live.has(e.cid || '');
}
async function keptTabIds(b, keep) { const ids = new Set(); if (!keep) return ids; for (const g of b.groups || []) { if (!keep({ run: b.id, cid: g.cid || '' })) continue; if (g.tab != null) ids.add(g.tab); const t = tabOf.get(b.id + ':' + (g.cid || '')); if (t != null) ids.add(t); const m = mem[b.id + ':' + (g.cid || '')]; if (m && m.tab != null) ids.add(m.tab); } for (const e of await regList()) if (keep(e)) ids.add(e.id); return ids; }
// close every tab of this run EXCEPT those of the other open containers (no other container open = the old one-tab sweep)
async function closeExcept(b, cid) {
  // 1.1.7.9: one-tab-per-container only for THIS cid. Never close another parallel container's tab (a stale openGroups used to make keepOthers null → sweep killed #1–#3 while opening #4).
  const kill = new Set(), mine = cid || '', bid = (b && b.id) || '';
  for (const g of (b && b.groups) || []) if ((g.cid || '') === mine && g.tab != null) kill.add(g.tab);
  const t = tabOf.get(bid + ':' + mine); if (t != null) kill.add(t);
  const m = mem[bid + ':' + mine]; if (m && m.tab != null) kill.add(m.tab);
  try { for (const e of await regList()) if (e && e.run === bid && (e.cid || '') === mine) kill.add(e.id); } catch (_) { /* best effort */ }
  for (const id of kill) await closeTabId(id);
}
// only this container's tab goes (a reopen after a VPN drop / a lost tab), checked closed; the other open containers keep working
async function closeOneGroup(b, cid, passes) {
  // 1.1.7.9: never closeRunTabs('all') / sweepVerified(null) while parallel siblings may be live
  const keep = keepOthers(b, cid) || ((e) => e && b && e.run === b.id && (e.cid || '') !== (cid || ''));
  await closeExcept(b, cid); await sweepVerified(keep, passes);
}
const pausedBy = {};      // run id : the {since, where} the tab last reported while it holds for a Pause (the record's copy can be wiped by a stale mirror write; the Pause key only holds the request)
async function pullReports(cur) {
  const R = self.P9BEAN_REP; if (!R || !cur || cur.state !== 'running' || (cur.owner || 'popup') !== ROLE) return null;
  const now = Date.now(), gs = (cur.groups || []).filter((g) => g.status === 'opening' || g.status === 'running' || (g.doneAt && now - g.doneAt < 30000));
  if (!gs.length) return null;
  const keys = []; for (const g of gs) for (let k = 0; k < R.SLOTS; k++) keys.push(R.keyHb(cur.id, g.cid || '', k));
  let hbRaw = {}; try { hbRaw = await chrome.storage.local.get(keys); } catch (_) { return null; }
  const want = [];                                  // [cid, slot, hb]
  let seenAny = false, gUntil = null;      // gUntil: the grace the tab's newest heartbeat announced (0 = none), mirrored into the record so a RELOADED page (no memory) judges the run from the truth, not from the open grace written at open time
  for (const g of gs) {
    const cid = g.cid || '', m = memOf(cur.id, cid, g), hbs = {};
    for (let k = 0; k < R.SLOTS; k++) { const h = hbRaw[R.keyHb(cur.id, cid, k)]; if (h) hbs[k] = h; }
    const cut = Math.max((cur.repCut || {})[cid] || 0, m.cut || 0), pl = R.plan(hbs, m.applied, cut);
    if (pl.seen) {
      seenAny = true; m.lastSeenAt = now; m.heard = true;
      let newest = null; for (const s of Object.keys(hbs)) { const h = hbs[s]; if (cut && h.gen < cut) continue; if (!newest || h.gen > newest.gen || (h.gen === newest.gen && h.seq > newest.seq)) newest = h; }
      m.graceUntil = newest && newest.graceMs > 0 ? now + newest.graceMs : 0; m.short = !!(newest && newest.graceMs > 0 && newest.graceMs <= L.SWITCH_WATCH_MAX);      // 1.1.7.1: a SHORT announced grace (a channel-switch navigation) is the whole allowance: the 45 s floor does not apply      gUntil = m.graceUntil;      // the first heartbeat ends the open grace: from then on only an announced navigation grants one
      for (const s of Object.keys(hbs)) { const h = hbs[s], a = m.applied[s]; if (!(cut && h.gen < cut) && (!a || a.gen !== h.gen || h.seq > a.seq)) m.applied[s] = Object.assign({ rseq: -1 }, a && a.gen === h.gen ? a : {}, { gen: h.gen, seq: h.seq }); }
    }
    for (const s of pl.needRep) want.push([cid, s, hbs[s]]);
    if (pl.stale.length) { const rm = []; for (const s of pl.stale) { rm.push(R.keyHb(cur.id, cid, s), R.keyRep(cur.id, cid, s)); delete m.applied[s]; delete m.prevRep[s]; } chrome.storage.local.remove(rm).catch(() => {}); }      // the slot of a tab that was replaced
  }
  let reps = [];
  if (want.length) {
    let raw = {}; try { raw = await chrome.storage.local.get(want.map((w) => R.keyRep(cur.id, w[0], w[1]))); } catch (_) { raw = {}; }
    for (const [cid, s, h] of want) { const rep = raw[R.keyRep(cur.id, cid, s)], m = memOf(cur.id, cid); if (!rep || rep.gen !== h.gen || rep.seq < h.rseq) continue; if (rep.top && 'pause' in rep.top) pausedBy[cur.id] = rep.top.pause || null; reps.push({ cid, s, rep, part: R.diffRep(m.prevRep[s] && m.prevRep[s].gen === rep.gen ? m.prevRep[s] : null, rep) }); }
  }
  if (!reps.length && !(seenAny && now - (cur.updated || 0) > 4000)) return null;
  const b = await mutate((bb) => {
    if (bb.id !== cur.id || bb.state !== 'running') return false; let n = 0;
    for (const r of reps) n += R.apply(bb, r.part);
    if (reps.length || seenAny) { bb.updated = now; n++; }
    if (gUntil !== null && (bb.graceUntil || 0) !== gUntil) { bb.graceUntil = gUntil; n++; }
    return n > 0 ? undefined : false;
  });
  for (const r of reps) { const m = memOf(cur.id, r.cid); m.prevRep[r.s] = r.rep; m.applied[r.s] = Object.assign(m.applied[r.s] || {}, { gen: r.rep.gen, rseq: r.rep.seq }); }
  return b || null;
}
let advancing = false;
async function parallelCap() { if (!(await bgTabsNow())) return 1;          /* 1.1.7.5: parallel only with Background tabs ON. 1.1.7.9: popup Parallel/Single toggle writes p9bn.parallel (4 or 1); Single = wave of 1. */ let v = null; try { v = await ST.step('record-quiet', sget(PAR_KEY), 3000); } catch (_) { v = null; } const n = Number(v && typeof v === 'object' ? v.n : v); return n >= 1 && n <= ST.PARALLEL_CONTAINERS ? Math.floor(n) : ST.PARALLEL_CONTAINERS; }
const opened = new Set();          // run id : container id — tabs this popup has opened
// The state machine of a multi-container run: opens one tab per container, one container after the other, with a human-like gap in between.
// The tab itself walks through all links of its container (content.js). Runs from the popup once a second while it is open, and again when it is reopened.
let advancingAt = 0, advGen = 0;
async function advance() {
  if (advancing && Date.now() - advancingAt < 150000) return;          // 1.1.7.2: a pass that has not returned for 150 s (an await that never answered) no longer blocks every later pass
  advancing = true; advancingAt = Date.now(); const myGen = ++advGen;
  try {
    await heal();
    let cur = await sget(K.batch);
    // 1.1.7: a record of ANOTHER run (a stale mirror copy of the previous run, 'done') while this page is driving a live run says nothing about it: no sweep, no closing; heal() puts the live record back
    if (cur && own.id && cur.id !== own.id && own.last && own.last.state === 'running' && !own.cleared && !own.stopped) return;
    if (!cur || cur.state !== 'running') { if (cur && (cur.owner || 'popup') === ROLE) { await closeRunTabs(cur, cur.id === own.id ? 'sweep' : 'all'); await sweepTabs(null); cleanMarkers(cur.id); } if (cur && batch !== cur) { batch = cur; renderResults(); } return; }
    if ((cur.owner || 'popup') !== ROLE) {                        // 1.1.0: a run is driven by the page that created it (popup, or the runner for API jobs)
      // 1.1.7: …unless that page is gone (popup closed while the hidden runner is alive, or the runner stopped while the popup is open): the other one adopts the run, so a queue goes on
      const owner = cur.owner || 'popup'; let gone = false;
      if (cur.order) {
        if (owner === 'popup' && ROLE === 'runner') { const pb = await sget('p9bn.pbeat').catch(() => null); gone = !pb || Date.now() - (pb.at || 0) > 15000; }
        else if (owner === 'runner' && ROLE === 'popup') gone = !(self.B11 && B11.runnerAlive && B11.runnerAlive());
      }
      if (!gone) return;
      const ad = await mutate((b) => { if (b.id !== cur.id || b.state !== 'running' || (b.owner || 'popup') !== owner) return false; b.owner = ROLE; (b.events = b.events || []).push([Date.now(), `the ${owner} page is gone: this ${ROLE} page continues the run`]); b.events = b.events.slice(-20); b.updated = Date.now(); });
      if (!ad) return; own.id = cur.id; own.last = ad; own.stopped = false; own.cleared = false; cur.owner = ROLE;
      if (await recoverAfterReload('Bean was reloaded').catch(() => false)) return;      // 1.1.6.4: the page that was driving the run is gone (an update / reload?): an orphaned tab is closed and the run is kept paused
    }
    { const pr = await pullReports(cur).catch(() => null); if (pr) cur = pr; }          // 1.1.7: merge what the tabs reported (they never write the run record themselves)
    if (await pauseStuckStep(cur).catch(() => false)) return;          // 1.1.7.1: Pause never waits for a step that is stuck
    if (cur.pauseReq && cur.pause && cur.pause.since && (cur.groups || []).some((g) => g.status === 'running') && Date.now() - (cur.updated || 0) > 25000 && Date.now() - lastSilentCheck > 30000) { lastSilentCheck = Date.now(); if (await recoverAfterReload('Bean was reloaded')) return; }      // 1.1.6.4: a paused tab refreshes the record every ~3 s: silence = an orphan
    // 1.1.7 A TAB THAT DISAPPEARED MID-STEP (closed by hand, crashed, expired by Panel 9: a background tab lives 20 min there): a working tab touches the run record at least every ~15 s and answers the
    // "alive?" ping (p9bn.ping/alive) at any time. A record quiet for 35 s whose tab does not answer = the tab is gone (or dead): it is closed for sure (a no-op when already gone), and the run goes on in a
    // fresh tab as after a closed tab: items that were open are tried again, a like that was already sent is NEVER repeated (reported 'Like sent - not confirmed'). No pause, no interruption.
    // 1.1.7: ExpressVPN dropped while a freshly opened tab had not answered yet (its page cannot load, or loads into an error page): as soon as the VPN is connected again (+ settle) the tab is closed and the container is
    // opened again in a fresh one - no waiting for the open grace (75-120 s) and the quiet period. It does not count as one of the 2 reopens (a VPN outage is not the tab's fault), but is bounded (6).
    { const g1 = openGroups(cur).filter((g) => cur.items.some((it) => (it.cid || '') === (g.cid || '') && !finalIt(it)) && !cur.items.some((it) => (it.cid || '') === (g.cid || '') && it.vpnSkip) && !memOf(cur.id, g.cid, g).heard)[0], m1 = g1 ? memOf(cur.id, g1.cid, g1) : null;          // 1.1.7.5: the (one) open container that uses the VPN and has not answered yet
      if (m1 && !m1.heard && cur.vpn && cur.vpn.on && !cur.pauseReq && (g1.vpnReopens || 0) < 6 && Date.now() - (m1.openedAt || 0) > 2500 && Date.now() - (m1.vpnChk || 0) > 2000 && !cur.items.some((it) => (it.cid || '') === (g1.cid || '') && it.vpnSkip)) {
        m1.vpnChk = Date.now(); const pk = await B11.vpnPeek().catch(() => ({ state: 'unreadable' }));
        if (pk.state !== 'connected') { m1.vpnDownAt = m1.vpnDownAt || Date.now(); m1.vpnUpSince = 0; }
        else if (m1.vpnDownAt) {
          m1.vpnUpSince = m1.vpnUpSince || Date.now();
          if (Date.now() - m1.vpnUpSince >= 3000) {
            const nowT = Date.now(), re = await mutate((b) => {
              if (b.id !== cur.id || b.state !== 'running' || b.pauseReq) return false; const g = (b.groups || []).find((x) => (x.cid || '') === (g1.cid || '')); if (!g || (g.status !== 'opening' && g.status !== 'running')) return false;
              for (const it of b.items) if ((it.cid || '') === (g.cid || '') && it.status === 'running' && !it.sent && !it.verify) { it.status = 'queued'; it.hb = 0; it.runner = ''; it.at = 0; (it.lg = it.lg || []).push([nowT, 'reopen', 'ExpressVPN dropped while the tab was loading: it is tried again in a fresh tab now that the VPN is back']); }
              g.status = 'queued'; g.recycle = (g.recycle || 0) + 1; g.vpnReopens = (g.vpnReopens || 0) + 1; delete g.tab; b.nextAt = nowT + 2000; b.graceUntil = 0; b.updated = nowT;
              (b.events = b.events || []).push([nowT, 'ExpressVPN dropped while a container\'s tab was loading: the tab is closed and the container opened again in a fresh one now that the VPN is back']); b.events = b.events.slice(-30); return true;
            });
            m1.vpnDownAt = 0; m1.vpnUpSince = 0;
            if (re) { m1.lastSeenAt = Date.now(); m1.graceUntil = 0; delete m1.tab; { const gg = (re.groups || []).find((x) => (x.cid || '') === (g1.cid || '')); m1.rc = Math.max((m1.rc || 0) + 1, (gg && gg.recycle) || 0); } await ST.step('close-previous', closeOneGroup(re, g1.cid, 3)).catch(() => {}); batch = re; renderResults(); return; }
          }
        }
      } }
    { const og = openGroups(cur).filter((g) => cur.items.some((it) => (it.cid || '') === (g.cid || '') && !finalIt(it))).sort((x, y) => memOf(cur.id, x.cid, x).lastSeenAt - memOf(cur.id, y.cid, y).lastSeenAt), g0 = og[0], gm0 = g0 ? memOf(cur.id, g0.cid, g0) : null;          // 1.1.7.5: the most silent of the open containers
      if (self.P9BEAN_ORD && !cur.pauseReq && gm0 && Date.now() > (gm0.graceUntil || 0) && Date.now() - gm0.lastSeenAt > 35000 && Date.now() - lastGoneCheck > 20000) {         // 1.1.7: judged from what THIS page saw (last heartbeat seen), not from the age of the shared record
        lastGoneCheck = Date.now();
        let neverStarted = false;          // 1.1.7.1: this call does NOT end here for a tab that never started (a page whose timers are throttled calls advance() only every ~30-60 s: ending every call here meant the reopen below was never reached)
        if (await tabAnswers(cur, g0.cid || '')) return;          // (a ping answer is not progress: nothing is refreshed)
        { const sn0 = await sget(L.TABSEEN + cur.id + '.' + (g0.cid || '')).catch(() => null); if (!(sn0 && sn0.at >= (gm0.cut || gm0.openedAt || 0))) { gm0.lastSeenAt = Math.min(gm0.lastSeenAt, Date.now() - STALE_MS - 1); neverStarted = true; } }       // 1.1.7: no Bean page ever started in this tab: that is the 'never answered' case below (reopen max 2, plain message), not a tab that disappeared mid-step
        if (!neverStarted) {
        const dg = await missDiag(cur, g0, await sget(L.TABSEEN + cur.id + '.' + (g0.cid || '')).catch(() => null));
        const gone = await mutate((b) => { if (b.id !== cur.id || b.state !== 'running' || b.pauseReq || Date.now() - gm0.lastSeenAt <= 35000) return false; const r = P9BEAN_ORD.tabGone(b, Date.now(), { cid: g0.cid || '' }); if (r.changed) { (b.events = b.events || []).push([Date.now(), 'heartbeat missed (35 s): ' + dg]); b.events = b.events.slice(-30); } return r.changed ? true : false; });
        if (gone) { gm0.lastSeenAt = Date.now(); gm0.graceUntil = 0; delete gm0.tab; { const gg = (gone.groups || []).find((x) => (x.cid || '') === (g0.cid || '')); gm0.rc = Math.max((gm0.rc || 0) + 1, (gg && gg.recycle) || 0); } await ST.step('close-previous', closeOneGroup(gone, g0.cid, 3)).catch(() => {}); batch = gone; renderResults(); }
        return; }
      } }
    // While a tab is working, only act on a record that has been quiet for ~1 s: the storage mirror can hand this popup a copy that is a moment behind the tab's last
    // write, and acting on it (e.g. closing a container whose last item is still shown as running) would overwrite that write.
    if ((cur.groups || []).some((g) => g.status === 'opening' || g.status === 'running')) {
      const key = cur.id + ':' + cur.updated + ':' + cur.items.map((it) => it.status).join();
      if (!advance.busyAt) advance.busyAt = Date.now();
      const capOk = Date.now() - advance.busyAt > ST.QUIET_GATE_MAX_MS;          // 1.1.7.5: with 3 tabs reporting, the record may never be quiet for 1 s: after 4 s this page acts on the newest record anyway (step 'record-quiet')
      if (advance.key !== key && !capOk) { advance.key = key; advance.at = Date.now(); return; }
      if (Date.now() - advance.at < 900 && !capOk) return;
      advance.key = key; advance.busyAt = 0;
    } else advance.busyAt = 0;
    const now = Date.now();
    let toOpen = null;
    // 1.1.2: a record whose group is lost (nothing heard for 45 s and no navigation announced) loses its tabs too: found through the registry, not through group.tab
    await sweepTabs(activeKeep(cur));          // 1.1.7: null (no group of this run is alive by the runner's own memory) sweeps every registered tab
    const seenM = {}, gch = {};       // 1.1.7: tab-seen markers (a Bean page started in the tab) and Google-check reports of the containers that are open now
    for (const g of cur.groups || []) if (g.status === 'opening' || g.status === 'running') { const c = g.cid || ''; seenM[c] = await sget(L.TABSEEN + cur.id + '.' + c).catch(() => null); gch[c] = await sget(L.GCHECK + cur.id + '.' + c).catch(() => null); }
    const expired = {};             // 1.1.7: containers whose tab is silent by the runner's own memory: { cid: diagnosis }
    for (const g of openGroups(cur)) {
      const c = g.cid || '', m = memOf(cur.id, c, g); if (gch[c] || now <= memStale(cur, g) || cur.items.filter((it) => (it.cid || '') === c).every(finalIt)) continue;
      const sn = seenM[c], seen = !!(sn && sn.at >= (m.cut || m.openedAt || 0));
      const noSave = cur.items.some((it) => (it.cid || '') === c && it.status === 'running' && (it.swat || (it.prog && Date.now() - it.prog > 45000)));          // 1.1.7.1: answering a ping is not progress: a tab waiting for a switch page that never came, or with no progress for 45 s, is not given another grace period
      if (!noSave && seen && (m.pingSaves || 0) < 1 && await tabAnswers(cur, c)) { m.pingSaves = (m.pingSaves || 0) + 1; m.lastSeenAt = Date.now(); continue; }      // the page still answers the "alive?" ping: one more grace period
      expired[c] = { seen, diag: await missDiag(cur, g, sn) };
    }
    const pcb = cur.pauseReq ? {} : await postClickBound(cur).catch(() => ({}));          // 1.1.7.2 bounded post-click
    let evid = {};          // 1.1.7.2: click evidence for every container about to be ended / reopened, and for a run about to be ended as lost
    if (!(cur.pause && cur.pauseReq) && Date.now() - runHeardAt(cur) > RESUME_MS - 3000) await heardDirect(cur);          // 1.1.7.2: a tab that still answers refreshes what this page heard: the run is not lost (the record is an old copy)
    if (Object.keys(expired).length || Date.now() - runHeardAt(cur) > RESUME_MS - 3000) evid = await clickEvidence(cur).catch(() => ({}));
    const pcs = await sget(K.pace).catch(() => null);        // 1.1.6.3: the ONE saved pace: the gap before the next container uses it
    const parCap = await parallelCap();          // 1.1.7.8: 4 (p9bn.parallel = 1..3 lowers it: a fallback without a new build)
    const pk = await sget(K.pause).catch(() => null);        // 1.1.6: the Pause key is the truth; the run record's pauseReq is healed from it (a stale write by the tab can wipe the mirror)
    const b = await mutate((b) => {
      let ch = L.applyPauseKey(b, pk);
      if (applyEvidence(b, evid, now)) ch = true;
      { const gc = {}, found = new Set(); for (const it of b.items || []) { const k = it.vid + '|' + it.lc; if (it.code === 'comment-gone' && !it.goneSkip) (gc[k] = gc[k] || new Set()).add(it.cid || ''); if (it.status === 'liked' || it.status === 'already' || it.sent || it.mkSeen) found.add(k); }          // 1.1.7.2: SURE only after 2 DIFFERENT containers fully loaded the comments without it, and never when any copy was found
        const gone = new Set(Object.keys(gc).filter((k) => gc[k].size >= 2 && !found.has(k))); if (gone.size) for (const it of b.items) if (it.status === 'queued' && !it.sent && !it.mkSeen && gone.has(it.vid + '|' + it.lc)) { it.status = 'failed'; it.code = 'comment-gone'; it.goneSkip = 1; it.msg = 'Not tried: two containers\' pages showed this comment is gone (deleted or removed).'; it.at = now; (it.lg = it.lg || []).push([now, 'result', 'comment-gone - not tried, the comment was found gone on an earlier page']); ch = true; } }          // 1.1.7.2: a gone comment is not tried on the other channels
      for (const it of b.items || []) if (it.status === 'running' && pcb[it.vid + '|' + (it.lc || '') + '|' + it.ck]) { it.mkSeen = it.mkSeen || now; it.sent = it.sent || now; endItems([it], now); (it.lg = it.lg || []).push([now, 'result', 'Like sent - not confirmed: no report from the tab for ' + Math.round(POST_CLICK_MS / 1000) + ' s after the click (1.1.7.2 bound); never clicked again']); (b.events = b.events || []).push([now, 'item ' + it.n + ': like sent, no confirmation within ' + Math.round(POST_CLICK_MS / 1000) + ' s - counted as "Like sent - not confirmed", moving on']); b.events = b.events.slice(-30); b.updated = now; ch = true; }
      if (b.pauseReq && !(b.pause && b.pause.since) && pausedBy[b.id] && pausedBy[b.id].since) { b.pause = pausedBy[b.id]; ch = true; }      // 1.1.7: the tab holds for the Pause (its own report says so): the record says so again after a stale write wiped it
      const gap = () => { if (!b.nextAt) { b.nextAt = now + L.pauseMs(L.pickPace(pcs, b.pace)); } };
      const gitems = (g) => b.items.filter((it) => (it.cid || '') === (g.cid || ''));
      if (b.pauseReq && b.pause && b.pause.since && now - b.pause.since > L.PAUSE_MAX_MS) { b.state = 'stopped'; b.items.forEach((it) => { if (it.status === 'queued') { it.status = 'skipped'; it.code = 'stopped'; it.msg = 'Paused for more than 6 hours: the run was stopped.'; } }); (b.events = b.events || []).push([now, 'auto-stopped: paused for more than 6 hours']); b.updated = now; return true; }
      if (!(b.pause && b.pauseReq) && now - runHeardAt(b) > RESUME_MS && (b.longQuiet || 0) < 2 && b.items.some((it) => it.status === 'queued' || it.status === 'running')) {          // 1.1.7.2 (live: 0/11, every untried item failed "interrupted"): this page is alive, so the run is NOT given up: its containers are handed back and it carries on (twice at most)
        b.longQuiet = (b.longQuiet || 0) + 1; for (const g of b.groups || []) if (g.status === 'opening' || g.status === 'running') { g.status = 'queued'; g.recycle = (g.recycle || 0) + 1; delete g.tab; const mq = memOf(b.id, g.cid, g); mq.rc = Math.max((mq.rc || 0) + 1, g.recycle); delete mq.tab; mq.lastSeenAt = now; mq.graceUntil = 0; }
        for (const it of b.items) if (it.status === 'running') { it.status = 'queued'; it.hb = 0; it.prog = 0; if (it.sent || it.mkSeen) it.verify = it.verify || now; }
        for (const k of [...opened]) if (k.indexOf(b.id + ':') === 0) opened.delete(k);
        b.nextAt = 0; b.graceUntil = 0; b.updated = now; (b.events = b.events || []).push([now, 'nothing was heard from this run for ' + Math.round(RESUME_MS / 60000) + ' min: its open container was handed back and the run carries on (' + b.longQuiet + ' of 2); nothing failed']); b.events = b.events.slice(-30); return true;
      }
      if (!(b.pause && b.pauseReq) && now - runHeardAt(b) > RESUME_MS) { b.state = b.items.every(finalIt) ? 'done' : 'stopped'; b.items.forEach((it) => { if (it.status === 'queued') { it.status = 'skipped'; it.code = 'not-started'; } else if (it.status === 'running') { it.status = 'failed'; it.code = 'interrupted'; } }); return true; }
      { const rc0 = {}; for (const g of b.groups || []) rc0[g.cid || ''] = g.recycle || 0; const wd = self.P9BEAN_ORD ? P9BEAN_ORD.watchdog(b, now, {}) : null; if (wd && wd.changed) { ch = true; for (const g of b.groups || []) if ((g.recycle || 0) > rc0[g.cid || '']) { const mw = memOf(b.id, g.cid, g); mw.rc = Math.max((mw.rc || 0) + 1, g.recycle || 0); delete mw.tab; } } }          // 1.1.7: an item stuck for minutes (heartbeat fresh, page spinning) is retried in a fresh tab, never after a like was sent
      for (const g of b.groups || []) {
        if (g.status !== 'opening' && g.status !== 'running') continue;
        // 1.1.7.9: group stuck in 'opening' with no tab (VPN stamped, open never finished) must not wedge the wave forever
        if (g.status === 'opening' && g.openedAt && now - g.openedAt > 90000) {
          const mm = memOf(b.id, g.cid, g); if (!(mm && mm.tab != null) && g.tab == null) {
            g.openHangs = (g.openHangs || 0) + 1; delete g.tab;
            if (g.openHangs > 3) { g.status = 'done'; g.doneAt = now; for (const it of gitems(g)) if (!finalIt(it)) { it.status = 'failed'; it.code = 'open-failed'; it.msg = 'Opening this container never got a tab (stuck opening).'; it.at = now; } }
            else { g.status = 'queued'; g.recycle = (g.recycle || 0) + 1; for (const it of gitems(g)) if (it.status === 'running' && !it.sent && !it.verify) { it.status = 'queued'; it.hb = 0; it.runner = ''; it.at = 0; } }
            opened.delete(b.id + ':' + (g.cid || '') + ':' + (mm.rc || g.recycle || 0));
            mm.rc = Math.max((mm.rc || 0) + 1, g.recycle || 0); delete mm.tab; mm.lastSeenAt = now; mm.graceUntil = 0;
            b.nextAt = now + 2500; b.updated = now; (b.events = b.events || []).push([now, 'container stuck opening >90 s with no tab: ' + (g.status === 'done' ? 'given up' : 'handed back')]); b.events = b.events.slice(-30); ch = true; continue;
          }
        }
        const its = gitems(g);
        if (its.every(finalIt)) { const mf = memOf(b.id, g.cid, g); mf.allFinalAt = mf.allFinalAt || now; }          // 1.1.7.2 (real job__7oLkcMhLbq6It4O: 12/12 final, the run never ended, Pause waited for ever): the channel restore after the last item gets 20 s, measured from when THIS page saw every item final (b.updated is refreshed by many writes)
        if (its.every(finalIt) && !(g.restore === 'pending' && now - (memOf(b.id, g.cid, g).allFinalAt || now) <= 20000)) { if (g.restore === 'pending') g.restore = 'failed'; g.status = 'done'; g.doneAt = g.doneAt || now; gap(); ch = true; }
        else if (gch[g.cid || ''] && gch[g.cid || ''].at >= ((mem[b.id + ':' + (g.cid || '')] && mem[b.id + ':' + (g.cid || '')].cut) || g.openedAt || 0)) {
          // 1.1.7: the tab landed on a Google sign-in / consent page: the container needs a human. Skipped right away with a plain message; nothing is solved, nothing is clicked there
          if (g.restore === 'pending') g.restore = 'failed';
          for (const it of its) { if (finalIt(it)) continue; if (it.status === 'running' && (it.sent || it.verify)) { endItems([it], now); continue; } it.status = 'skipped'; it.code = 'google-check'; it.msg = L.gcheckMsg(it.cname || g.name || ''); it.at = now; it.hb = 0; it.runner = ''; (it.lg = it.lg || []).push([now, 'result', 'google-check - ' + gch[g.cid || ''].host + ' showed a ' + gch[g.cid || ''].kind + ' page instead of YouTube; skipped, nothing was clicked']); }
          g.status = 'done'; g.doneAt = now; b.nextAt = now + L.pauseMs(L.pickPace(pcs, b.pace)); b.graceUntil = 0; b.updated = now; (b.events = b.events || []).push([now, L.gcheckMsg(g.name || (its[0] && its[0].cname) || '')]); b.events = b.events.slice(-20); ch = true;
        }
        else if (expired[g.cid || '']) {
          // 1.1.7: the tab went silent (never started, or went quiet): NOT the end of the container. It is closed and opened again in a fresh tab (max 2 reopens, the VPN location of an item is kept, a like that was
          // sent is never repeated); only after that do its items end, with a message that says which silence it was
          if (g.restore === 'pending') g.restore = 'failed';
          const ex = expired[g.cid || '']; if (self.P9BEAN_ORD) { P9BEAN_ORD.reopenGroup(b, g, now, { seen: ex.seen }); (b.events = b.events || []).push([now, 'heartbeat missed: ' + ex.diag]); b.events = b.events.slice(-30); const mm = memOf(b.id, g.cid, g); mm.lastSeenAt = now; mm.graceUntil = 0; delete mm.tab; mm.rc = Math.max((mm.rc || 0) + 1, g.recycle || 0); g.recycle = mm.rc; } else { endItems(its, now); g.status = 'done'; g.doneAt = now; }
          if (g.status === 'done') b.nextAt = now + L.pauseMs(L.pickPace(pcs, b.pace)); ch = true;
        }
      }
      // 1.1.7.6 Likes needed: once enough successful likes are done, skip the rest (never open more) so the run does not overshoot. Running items finish; nothing already liked is re-clicked.
      if (b.needed != null && b.needed >= 1) {
        let got = 0; for (const it of b.items || []) if (it.status === 'liked' || it.status === 'already') got++;
        if (got >= b.needed) {
          for (const it of b.items || []) if (it.status === 'queued') { it.status = 'skipped'; it.code = 'skipped'; it.msg = 'Likes needed (' + b.needed + ') already reached.'; it.at = now; ch = true; }
          const busy = (b.groups || []).some((g) => g.status === 'opening' || g.status === 'running') || (b.items || []).some((it) => it.status === 'running');
          if (!busy) { b.state = 'done'; (b.events = b.events || []).push([now, 'likes needed (' + b.needed + ') reached: run done']); b.events = b.events.slice(-30); b.updated = now; return true; }
          if (ch) { b.updated = now; }
        }
      }
      // 1.1.7.9 PARALLEL / SINGLE + WAVE-SHARED VPN: parCap from Parallel (4) or Single (1) toggle via p9bn.parallel; waves via lib/steps.js pickOpen (Single = wave of 1, one rotate per container).
      // One VPN rotate per wave (wave.loc); every VPN member of the wave runs on that same location. Members open STAGGER_MS apart; the pace gap applies between waves only.
      const openNow = (b.groups || []).filter((g) => g.status === 'opening' || g.status === 'running');
      if (!(b.groups || []).some((g) => g.status === 'queued')) {
        if (openNow.length) return ch ? true : false;     // the open containers finish their channels
        if (!b.items.some((it) => !finalIt(it))) { b.state = 'done'; return true; } endItems(b.items.filter((it) => !finalIt(it)), now); b.state = 'done'; return true;      // 1.1.2: no group is left to work on them: they can never finish -> end them (never 'running' forever)
      }
      if (b.pauseReq) { if (openNow.length) return ch ? true : false; if (!b.pause) { b.pause = { since: now, where: 'opening the next container' }; (b.events = b.events || []).push([now, 'paused — nothing is open; the next container is not opened until Resume']); b.events = b.events.slice(-20); b.updated = now; return true; } return ch; }     // 1.1.4 paused: no new tab, no VPN switch, no navigation
      if (!openNow.length && b.nextAt && now < b.nextAt) { if (now - (b.updated || 0) > 4000) { b.updated = now; return true; } return ch; }     // inside the pause between waves
      const pl = ST.pickOpen(b, { now, cap: parCap, wave: waveOf(b), lastOpenAt: lastOpenAt[b.id] || 0 });
      if (pl.wave) { b.wave = pl.wave; waveMem[b.id] = pl.wave; if (pl.wave.cids.length === 1) { (b.events = b.events || []).push([now, 'wave ' + pl.wave.n + ' starts (up to ' + parCap + ' containers at once' + (b.vpn && b.vpn.on ? '; one shared VPN switch for the wave' : '') + ')']); b.events = b.events.slice(-30); } ch = true; }
      if (!pl.cid && pl.cid !== '') return ch ? true : false;     // every slot is busy / wave full / staggering: wait
      const next = (b.groups || []).find((g) => (g.cid || '') === pl.cid && g.status === 'queued'); if (!next) return ch ? true : false;
      // a container's tab is opened at most once per run, even when a stale copy of the record (storage mirror) shows that container as still queued
      // 1.1.7: the key counts the runner's OWN memory of how often this container was handed back (mem.rc): a stale copy of the record that lost `recycle`+1 (the "reopen handoff lost" of Oluchi's job: the group
      // looked already opened, no fresh tab was ever opened) cannot make a requeued container look opened. And "opened" is only believed while the runner still knows a tab of it (mem.tab).
      const mN = memOf(b.id, next.cid, next); mN.rc = Math.max(mN.rc || 0, next.recycle || 0);
      const okey = b.id + ':' + (next.cid || '') + ':' + mN.rc;
      if (opened.has(okey)) { if (mN.tab != null && !closedTabs.has(String(mN.tab))) { next.status = 'running'; b.updated = now; b.nextAt = 0; return true; } opened.delete(okey); }
      opened.add(okey);
      const first = b.items.find((it) => (it.cid || '') === (next.cid || '') && it.status === 'queued');
      next.status = 'opening'; next.openedAt = now; b.updated = now; b.graceUntil = now + OPEN_GRACE_MS; b.nextAt = 0; lastOpenAt[b.id] = now;
      toOpen = { okey, cid: next.cid, url: first ? L.watchUrl(first.vid, first.lc, b.id, next.cid, first.chid) : '', bid: b.id };
      return true;
    });
    if (toOpen && toOpen.url) { const m0 = memOf(toOpen.bid, toOpen.cid); const t0 = Date.now(); m0.lastSeenAt = t0; m0.graceUntil = t0 + 120000; m0.openedAt = t0; m0.cut = t0; m0.pingSaves = 0; m0.heard = false; m0.vpnDownAt = 0; m0.vpnUpSince = 0; delete m0.tab; }       // 1.1.7: the group is 'opening' (VPN, gate, tab open): alive by memory while this page works on it
    if (b) {
      renderResults();
      if (b.state === 'running') {
        await bound(closeRunTabs(b, 'done'), 20000, 'closing a finished container\'s tab').catch(() => {});          // 1.1.7.2: never holds the run
        const lost = (b.groups || []).filter((g) => g.status !== 'queued' && ((g.tab == null && tabOf.has(b.id + ':' + (g.cid || ''))) || (g.status !== 'done' && !g.openedAt && mem[b.id + ':' + (g.cid || '')])));       // a write of the tab can lose the tab id: put it back
        if (lost.length) await mutate((bb) => { if (bb.id !== b.id) return false; let ch = false; for (const g of bb.groups || []) { const t = tabOf.get(bb.id + ':' + (g.cid || '')), mm = mem[bb.id + ':' + (g.cid || '')]; if (g.tab == null && t != null && g.status !== 'queued') { g.tab = t; ch = true; } if (mm && g.status !== 'queued' && g.status !== 'done' && !g.openedAt && mm.openedAt) { g.openedAt = mm.openedAt; ch = true; } } return ch ? undefined : false; });
      } else { await bound(closeRunTabs(b, b.id === own.id ? 'sweep' : 'all'), 20000, 'closing the run\'s tabs').catch(() => {}); if ((b.owner || 'popup') === ROLE) await bound(sweepVerified(null, 2), 20000, 'checking the run\'s tabs closed').catch(() => {}); }
    }       // a finished container's tab goes away now; the whole run is over -> every tab
    if (toOpen && toOpen.url) {
      try {
        await ST.step('close-previous', closeExcept(b, toOpen.cid));                  // 1.1.7.9: close ONLY this container's previous tab (siblings kept)
        const keepSiblings = keepOthers(b, toOpen.cid) || ((e) => e && b && e.run === b.id && (e.cid || '') !== (toOpen.cid || '') && (tabOf.has(b.id + ':' + (e.cid || '')) || (mem[b.id + ':' + (e.cid || '')] && mem[b.id + ':' + (e.cid || '')].tab != null)));
        const sv = await ST.step('verify-closed', sweepVerified(keepSiblings));            // 1.1.7.9: NEVER sweepVerified(null) while other containers may still have tabs
        if (!sv.ok) {
          const nTry = await mutate((bb) => {
            if (bb.id !== toOpen.bid) return false; const g = (bb.groups || []).find((x) => (x.cid || '') === (toOpen.cid || '')); if (!g) return false;
            bb.tabCloseFails = (bb.tabCloseFails || 0) + 1; bb.updated = Date.now(); bb.nextAt = Date.now() + 2500;
            (bb.events = bb.events || []).push([Date.now(), `the previous Bean tab (${sv.left.join(', ')}) would not close: the next tab is NOT opened yet (one-tab rule), trying again (${bb.tabCloseFails} of 8)`]); bb.events = bb.events.slice(-20);
            if (bb.tabCloseFails >= 8) { g.status = 'done'; bb.items.forEach((it) => { if ((it.cid || '') === (toOpen.cid || '') && !finalIt(it)) { it.status = 'failed'; it.code = 'open-failed'; it.msg = 'The previous Bean tab would not close, so no second tab was opened (one-tab rule). Nothing was clicked.'; it.at = Date.now(); } }); bb.tabCloseFails = 0; } else g.status = 'queued';
          });
          opened.delete(toOpen.okey); renderResults(); return;
        }
        if (b && b.tabCloseFails) await mutate((bb) => { if (bb.id !== toOpen.bid || !bb.tabCloseFails) return false; bb.tabCloseFails = 0; });
        if (b && b.vpn && b.vpn.on && self.B11 && B11.rotateNow) { const prevOpen = toOpen; toOpen = await ST.step('vpn-rotate', vpnBeforeOpen(toOpen)); if (!toOpen || !toOpen.url) { await handBack(prevOpen, 'VPN prepare returned no URL'); return; } }
        // 1.1.7: NEVER open a tab while the VPN is down (or has only just come back): real logs showed tabs opened 2 s before an ExpressVPN outage, ending on Panel 9's error page with the script never running.
        // Waits until ExpressVPN reports `connected` + a ~3 s settle (a state read only). Bypassed containers (vpnSkip) do not use the VPN: no wait.
        if (b && b.vpn && b.vpn.on && self.B11 && B11.vpnUp) { const okUp = await ST.step('vpn-up', vpnUpBeforeOpen(toOpen)); if (!okUp) return; }
        { const pr = await sget(K.batch); if (pr && pr.id === toOpen.bid && pr.pauseReq) { await mutate((bb) => { if (bb.id !== toOpen.bid) return false; const g = (bb.groups || []).find((x) => (x.cid || '') === (toOpen.cid || '')); if (g && g.status === 'opening') g.status = 'queued'; bb.updated = Date.now(); }); opened.delete(toOpen.okey); return; } }      // a Pause arrived during the VPN switch: no tab is opened       // 1.1.2: the VPN location of the container's FIRST item is set now, while NO Bean tab exists (nothing is loading)
        { const gap = 2000 - (Date.now() - lastWriteAt); if (gap > 0) await sleep(gap); }       // let the storage mirror / a never-used container session settle before its first tab loads (the tab also re-reads the run record)
        const tOpen0 = Date.now();
        const t = await bound((self.P9T && P9T.hangOpen > 0 && P9T.hangOpen--) ? new Promise(() => {}) : openInContainer(toOpen.cid, toOpen.url), ST.stepMs('open-tab'), 'step "open-tab": opening the tab');          // P9T.hangOpen: test hook (R91: the open call never answers)
        { const om = L.openModeLabel(lastOpenBg); if (b && b.openMode && b.openMode !== om) await mutate((bb) => { if (bb.id !== toOpen.bid || bb.openMode === om) return false; bb.openMode = om; (bb.events = bb.events || []).push([Date.now(), 'open mode changed — ' + om]); bb.events = bb.events.slice(-20); }).catch(() => {}); }
        if (t && t.tabId != null) { await regTab(t.tabId, toOpen.bid, toOpen.cid); myTabs.add(t.tabId); tabOf.set(toOpen.bid + ':' + (toOpen.cid || ''), t.tabId); await mutate((bb) => { if (bb.id !== toOpen.bid) return false; const g = (bb.groups || []).find((x) => (x.cid || '') === (toOpen.cid || '')); if (!g) return false; g.tab = t.tabId; g.openedAt = tOpen0; g.recycle = Math.max(g.recycle || 0, (mem[toOpen.bid + ':' + (toOpen.cid || '')] || {}).rc || 0); const nw = Date.now(); bb.graceUntil = nw + (self.P9BEAN_ORD ? P9BEAN_ORD.openGraceMs(lastRotateAt, nw) : OPEN_GRACE_MS); bb.updated = nw; (bb.repCut = bb.repCut || {})[toOpen.cid || ''] = tOpen0; }); { const m = memOf(toOpen.bid, toOpen.cid), nw = Date.now(); m.cut = tOpen0; m.openedAt = nw; m.lastSeenAt = nw; m.graceUntil = nw + (self.P9BEAN_ORD ? P9BEAN_ORD.openGraceMs(lastRotateAt, nw) : OPEN_GRACE_MS); m.vpnDoneAt = lastRotateAt; m.tab = t.tabId; m.pingSaves = 0; } }       // 1.1.7: the open grace starts when the tab OPENS (not before the VPN rotation), 120 s after a rotation in the last 30 s
        else { await handBackHung(toOpen, 'open returned no tab id'); renderResults(); return; }          // 1.1.7.9: never leave group status=opening with no tab (wedged wave 1 in c4l4j9rvmw57odgc #4)
      }
      catch (e) {
        const why = String((e && e.message) || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '').slice(0, 100);
        if (e && e.bound) { await handBackHung(toOpen, why).catch(() => {}); renderResults(); return; }          // 1.1.7.2: a step that never answered: the container is handed back and opened again (max 3), nothing failed
        await mutate((bb) => { if (bb.id !== toOpen.bid) return false; const g = (bb.groups || []).find((x) => (x.cid || '') === (toOpen.cid || '')); if (g) g.status = 'done'; bb.items.forEach((it) => { if ((it.cid || '') === (toOpen.cid || '') && !finalIt(it)) { it.status = 'failed'; it.code = 'open-failed'; it.msg = why; } }); bb.nextAt = Date.now() + L.pauseMs(L.pickPace(pcs, bb.pace)); bb.updated = Date.now(); });
        renderResults();
      }
    }
  } finally { if (advGen === myGen) advancing = false; }
}

// 1.1.2: switch the VPN for the first queued item of this container BEFORE its tab opens (no page is loading, nothing to break). A failed switch ends only that item and the next
// one is tried; the tab then opens on the new exit. Items that are bypassed (skip-bypass) need no switch.
// 1.1.7: wait for the VPN before a tab is opened; true = go ahead (also when the VPN is not used for this container), false = the group was handed back / the item failed / the run is over
async function vpnUpBeforeOpen(toOpen) {
  const cur = await sget(K.batch); if (!cur || cur.id !== toOpen.bid) { await handBack(toOpen, 'the run record could not be read (a stale copy came back)'); return false; } if (cur.state !== 'running') return false;
  const gi = cur.items.findIndex((it) => (it.cid || '') === (toOpen.cid || '') && it.status === 'queued'); if (gi < 0) return true;
  if (cur.items[gi].vpnSkip) return true;
  const hbv = setInterval(() => { { const m = memOf(cur.id, toOpen.cid); m.lastSeenAt = Date.now(); m.graceUntil = Date.now() + 120000; } mutate((bb) => { if (bb.id !== cur.id || bb.state !== 'running') return false; bb.updated = Date.now(); bb.graceUntil = 0; }).catch(() => {}); }, 8000); setTimeout(() => clearInterval(hbv), 330000);          // 1.1.7.2: never outlives a step that hung
  let r; try { r = await B11.vpnUp(cur.id, { maxMs: 300000 }); } finally { clearInterval(hbv); }
  if (r && r.ok) {
    if (r.waited > 1500) await mutate((bb) => { if (bb.id !== cur.id || !bb.items[gi]) return false; const t = Date.now(); (bb.items[gi].lg = bb.items[gi].lg || []).push([t, 'vpn', `ExpressVPN was not ready: waited ${Math.round(r.waited / 1000)} s (connected + settle) before the tab was opened`]); (bb.events = bb.events || []).push([t, `waited ${Math.round(r.waited / 1000)} s for ExpressVPN to be connected before opening a container's tab`]); bb.events = bb.events.slice(-20); }).catch(() => {});
    return true;
  }
  if (r && r.code === 'stopped') { if (!(await B11.runIsOver(cur.id))) await handBack(toOpen, 'the wait for the VPN was interrupted by an unclear stop signal'); return false; }
  await mutate((bb) => {
    if (bb.id !== cur.id || !bb.items[gi]) return false; const t = Date.now(), x = bb.items[gi];
    x.status = 'failed'; x.code = 'vpn-failed'; x.msg = (r && r.msg) || 'ExpressVPN was not connected'; x.at = t; (x.lg = x.lg || []).push([t, 'vpn', 'failed (vpn-failed) before the tab opened — ExpressVPN stayed down; nothing was opened, loaded or clicked']);
    const g = (bb.groups || []).find((y) => (y.cid || '') === (toOpen.cid || '')); if (g && g.status === 'opening') g.status = 'queued'; bb.nextAt = t + 2000; bb.updated = t;
  }).catch(() => {});
  opened.delete(toOpen.okey); return false;
}
// 1.1.7: give a container's group back to the queue (nothing failed, nothing skipped); the next pass opens it again
// 1.1.7.2 EVERY AWAITED STEP IS BOUNDED (Oluchi's run 0b8p7pfomw1tx4af, 09:03:02: the VPN was connected for #1, then the tab was never opened and nothing fired: an awaited Panel 9 call that never answered
// held advance() for ever). A step that does not answer in time rejects with { bound: true }; the open path hands the container back (fresh attempt, max 3) instead of waiting for ever.
const bound = (p, ms, what) => { let tm; return Promise.race([Promise.resolve(p).finally(() => clearTimeout(tm)), new Promise((_, rej) => { tm = setTimeout(() => rej(Object.assign(new Error(what + ' did not answer within ' + Math.round(ms / 1000) + ' s'), { bound: true })), ms); })]); };
async function handBackHung(toOpen, why) {
  await mutate((bb) => { if (bb.id !== toOpen.bid) return false; const g = (bb.groups || []).find((x) => (x.cid || '') === (toOpen.cid || '')); if (!g || (g.status !== 'opening' && g.status !== 'running')) return false; const t = Date.now();
    g.openHangs = (g.openHangs || 0) + 1; delete g.tab;
    if (g.openHangs > 3) { g.status = 'done'; g.doneAt = t; bb.items.forEach((it) => { if ((it.cid || '') === (toOpen.cid || '') && !finalIt(it)) { if (it.sent || it.mkSeen) { it.status = 'liked'; it.code = 'liked-unverified'; } else { it.status = 'failed'; it.code = 'open-failed'; it.msg = 'Opening this container\'s tab did not answer 3 times (' + why + ').'; } it.at = t; } }); }
    else { g.status = 'queued'; g.recycle = (g.recycle || 0) + 1; }
    bb.nextAt = t + 2500; bb.updated = t; (bb.events = bb.events || []).push([t, why + ': ' + (g.status === 'done' ? 'the container is given up (3 tries)' : 'handed back, it is opened again in a fresh tab (' + g.openHangs + ' of 3)')]); bb.events = bb.events.slice(-30); });
  opened.delete(toOpen.okey); { const m = mem[toOpen.bid + ':' + (toOpen.cid || '')]; if (m) { delete m.tab; m.rc = (m.rc || 0) + 1; m.lastSeenAt = Date.now(); m.graceUntil = 0; } }
}
async function handBack(toOpen, why) {
  await mutate((bb) => { if (bb.id !== toOpen.bid) return false; const g = (bb.groups || []).find((x) => (x.cid || '') === (toOpen.cid || '')); if (!g || g.status !== 'opening') return false; g.status = 'queued'; bb.nextAt = Date.now() + 2500; bb.updated = Date.now(); (bb.events = bb.events || []).push([Date.now(), `a container's open was put back in the queue (${why}); nothing was skipped`]); bb.events = bb.events.slice(-30); }).catch(() => {});
  opened.delete(toOpen.okey);
}
let lastRotateAt = 0;       // 1.1.7: when this page last finished a VPN rotation (the open grace is longer right after one)
async function vpnBeforeOpen(toOpen) {
  for (let n = 0; n < 60; n++) {
    // 1.1.7: a record that is missing or belongs to ANOTHER run (a stale mirror copy: the previous run's, already 'done') says nothing about THIS run: read again a few times over ~2 s; only a definitive
    // stop (this run's own record not running, or its stop key) ends the open. Anything ambiguous hands the container back to the queue: nothing is skipped, nothing is lost.
    let cur = null; for (let r = 0; r < 4; r++) { cur = await sget(K.batch); if (cur && cur.id === toOpen.bid) break; if (r < 3) await sleep(650); }
    if (!cur || cur.id !== toOpen.bid) { await handBack(toOpen, 'the run record could not be read (a stale copy came back)'); return null; }
    if (cur.state !== 'running') return null;
    const gi = cur.items.findIndex((it) => (it.cid || '') === (toOpen.cid || '') && it.status === 'queued');
    if (gi < 0) return null;                                              // nothing left to do in this container: no tab, the group ends on the next pass
    const it = cur.items[gi], url = L.watchUrl(it.vid, it.lc, cur.id, toOpen.cid, it.chid);
    if (it.vpnSkip) return Object.assign({}, toOpen, { url });
    // 1.1.7: ONE rotation per like attempt. An item that already has its location (the tab of the previous container pre-switched it, or this is a REOPEN in a fresh tab after a channel switch, or a stalled item that
    // was handed back) keeps it: the new tab opens on the current exit, nothing rotates again.
    if (it.vpn && it.vpn.location !== undefined) {
      await mutate((bb) => { if (bb.id !== cur.id || !bb.items[gi]) return false; (bb.items[gi].lg = bb.items[gi].lg || []).push([Date.now(), 'vpn', `kept the location '${(it.vpn.location || '?')}': this like already has its location (a fresh tab for the same item does not rotate again)`]); bb.items[gi].lg = bb.items[gi].lg.slice(-60); bb.updated = Date.now(); });
      return Object.assign({}, toOpen, { url });
    }
    // 1.1.7.7 WAVE-SHARED VPN: if this wave already rotated, stamp this container's unfinished items with wave.loc — no second rotate (all members of the wave share one location).
    const w0 = waveOf(cur);
    if (w0 && w0.loc && w0.loc.location !== undefined) {
      const loc = { location: w0.loc.location || '', ipChanged: w0.loc.ipChanged == null ? null : !!w0.loc.ipChanged };
      await mutate((bb) => {
        if (bb.id !== cur.id) return false; const t = Date.now(); let n = 0;
        for (const x of bb.items || []) if ((x.cid || '') === (toOpen.cid || '') && (x.status === 'queued' || x.status === 'running') && !x.vpnSkip && !(x.vpn && x.vpn.location !== undefined)) { x.vpn = { location: loc.location, ipChanged: loc.ipChanged }; n++; }
        if (bb.items[gi]) (bb.items[gi].lg = bb.items[gi].lg || []).push([t, 'vpn', `shared wave location '${loc.location || '?'}' (wave ${w0.n}: one VPN switch for the whole set of parallel containers)`]);
        if (bb.items[gi]) bb.items[gi].lg = bb.items[gi].lg.slice(-60);
        bb.updated = t; return n || true;
      });
      return Object.assign({}, toOpen, { url });
    }
    const hbv = setInterval(() => { { const m = memOf(cur.id, toOpen.cid); m.lastSeenAt = Date.now(); m.graceUntil = Date.now() + 120000; } mutate((bb) => { if (bb.id !== cur.id || bb.state !== 'running') return false; bb.updated = Date.now(); bb.graceUntil = 0; }).catch(() => {}); }, 8000); setTimeout(() => clearInterval(hbv), 330000);          // 1.1.7.2: never outlives a step that hung       // the run is alive while the VPN connects
    let out; try { out = await B11.rotateNow(cur.id); } finally { clearInterval(hbv); }
    if (out.ok) {
      lastRotateAt = Date.now();
      const loc = { location: out.location || '', ipChanged: out.ipChanged == null ? null : !!out.ipChanged };
      await mutate((bb) => {
        if (bb.id !== cur.id || !bb.items[gi]) return false;
        const w = waveOf(bb) || { n: 1, cids: [toOpen.cid || ''] };
        const cids = new Set((w.cids || []).concat([toOpen.cid || '']));
        w.loc = loc; bb.wave = w; waveMem[bb.id] = w;
        for (const x of bb.items || []) if (cids.has(x.cid || '') && (x.status === 'queued' || x.status === 'running') && !x.vpnSkip && !(x.vpn && x.vpn.location !== undefined)) x.vpn = { location: loc.location, ipChanged: loc.ipChanged };
        (bb.items[gi].lg = bb.items[gi].lg || []).push([Date.now(), 'vpn', `wave ${w.n} shared VPN: connected to '${loc.location || '?'}' before the tabs opened; exit address changed: ${loc.ipChanged === false ? 'NO' : loc.ipChanged ? 'yes' : 'unknown'} (every container in this wave uses this location)`]);
        bb.updated = Date.now(); bb.graceUntil = Date.now() + NAV_GRACE_MS;
        (bb.events = bb.events || []).push([Date.now(), `wave ${w.n}: one shared VPN switch → '${loc.location || '?'}'`]); bb.events = bb.events.slice(-30);
      });
      return Object.assign({}, toOpen, { url });
    }
    if (out.code === 'stopped') {          // 1.1.7: "the run is over" is only believed when it is definitive; otherwise the item stays queued (never skipped for a stale read)
      if (await B11.runIsOver(cur.id)) return null;
      if (n >= 2) { await handBack(toOpen, 'the VPN switch was interrupted by an unclear stop signal'); return null; }
      continue;
    }
    const everywhere = out.code === 'vpn-unavailable';
    await mutate((bb) => {
      if (bb.id !== cur.id) return false; const t = Date.now();
      const f = (x) => { x.status = 'failed'; x.code = out.code || 'vpn-failed'; x.msg = out.msg || ''; x.at = t; (x.lg = x.lg || []).push([t, 'vpn', `failed (${out.code || 'vpn-failed'}) before the tab opened — not loaded, not clicked`]); };
      if (everywhere) { bb.items.forEach((x) => { if (x.status === 'queued') { x.status = 'skipped'; x.code = out.code; x.msg = 'Skipped: ' + L.label(out.code); } }); bb.state = 'stopped'; } else f(bb.items[gi]);
      bb.updated = t;
    });
    if (everywhere) return null;
  }
  return null;
}
async function go() { if (els.go.disabled) return; goBusy = true; refreshButtons(); try { await goInner(); } finally { goBusy = false; refreshButtons(); } }
async function goDirect() {   // 1.1.6 path (no order queue loaded): one run at a time
  if (els.go.disabled) return;
  renderCount();
  if (!parsed.items.length) return;
  if (running(batch)) { setMsg('A run is already in progress — stop it first.', 'warn'); return; }
  if (discovering) { setMsg('Wait until the channels have been read.', 'warn'); return; }
  await sweepTabs(null);                       // 1.1.2: any Bean tab left over from an earlier run is closed before this one starts
  els.go.disabled = true; setMsg('Checking YouTube Focus…', '');
  await loadContainers();                                   // fresh names + which container is current
  if (ctrs) { await loadChannelCache(); const have = new Set(ctrs.containers.map((c) => c.id)); for (const id of [...sel]) if (!have.has(id)) sel.delete(id); normalizeSel(); renderContainers(); }
  const tg = targets();
  if (actionCount() > L.MAX_ACTIONS) { setMsg(`Over the limit of ${L.MAX_ACTIONS} likes per run.`, 'warn'); renderPlan(); return; }
  const asked = await askYtf(1000);
  const v = verdict(asked);
  renderGate(v);
  if (v === 'off') { setMsg('Turn on YouTube Focus comment-only view first.', 'warn'); return; }
  if (v === 'missing') { setMsg('YouTube Focus is not installed or not enabled.', 'warn'); return; }
  const id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
  const pace = els.pace.value;
  { const ps = await sget(K.pace).catch(() => null); if (!ps || ps.pace !== pace) await sset(K.pace, { pace, at: Date.now() }).catch(() => {}); }          // 1.1.6.3: what the select shows IS the saved pace (it is also written when the select changes)
  for (let i = 0; i < 40 && !(self.B11 && B11.S.ledReady); i++) await sleep(100);
  const pre = self.B11 ? await B11.prepare(tg) : { ok: true, active: false };
  if (!pre.ok) { setMsg(pre.msg, 'warn'); refreshButtons(); return; }
  const need = L.clampNeeded(qty.all); let plan;
  if (need.q != null) {
    const E = effQty(), links = parsed.items.map((it) => { const e = E.find((x) => x.key === lkOf(it)); return { n: it.n, vid: it.vid, lc: it.lc, url: it.url, quantity: e && e.q != null ? e.q : need.q }; });
    plan = L.planApi(links, tg, (vid, lc, ckey) => (self.B11 ? B11.used(vid, lc, ckey) : false));
  } else { plan = L.planActions(parsed.items, tg, { used: (vid, lc, ckey) => (self.B11 ? B11.used(vid, lc, ckey) : false) }); }
  batch = { id, state: 'running', pace, created: Date.now(), updated: Date.now(), nextAt: 0, idx: 0, groups: plan.groups, items: plan.items, owner: ROLE, restoreBack: !!settings.restoreBack, needed: need.q };
  if (self.B11) B11.decorate(batch, pre, tg);
  { const om = L.openModeLabel(await bgTabsNow()); batch.openMode = om; (batch.events = batch.events || []).push([Date.now(), 'open mode — ' + om]); }       // 1.1.6.5: one line per run
  own.id = id; own.last = batch; own.stopped = false; own.cleared = false;
  await sset(K.batch, batch);
  settings.pace = pace; sset(K.settings, settings).catch(() => {});
  renderResults();
  setMsg(v === 'unknown' ? 'Opening YouTube… (Focus will be checked on the page)' : 'Opening YouTube…', '');
  advance();
}
async function goInner() {
  if (els.go.disabled) return;
  renderCount();
  if (!parsed.items.length) return;
  if (!self.B17) return goDirect();
  if (discovering) { setMsg('Wait until the channels have been read.', 'warn'); return; }
  els.go.disabled = true; setMsg('Checking YouTube Focus…', '');
  await loadContainers();                                   // fresh names + which container is current
  if (ctrs) { await loadChannelCache(); const have = new Set(ctrs.containers.map((c) => c.id)); for (const id of [...sel]) if (!have.has(id)) sel.delete(id); normalizeSel(); renderContainers(); }
  let tg = healthyTargets(); if (!tg.length) tg = targets();
  if (actionCount() > L.MAX_ACTIONS) { setMsg(`Over the limit of ${L.MAX_ACTIONS} likes per run.`, 'warn'); renderPlan(); return; }
  const asked = await askYtf(1000), v = verdict(asked);
  renderGate(v);
  if (v === 'off') { setMsg('Turn on YouTube Focus comment-only view first.', 'warn'); return; }
  if (v === 'missing') { setMsg('YouTube Focus is not installed or not enabled.', 'warn'); return; }
  for (let i = 0; i < 40 && !(self.B11 && B11.S.ledReady); i++) await sleep(100);
  const E = effQty(), need = L.clampNeeded(qty.all);
  const links = parsed.items.map((it) => { const e = E.find((x) => x.key === lkOf(it)); return { n: it.n, vid: it.vid, lc: it.lc, url: it.url, quantity: e && e.q != null ? e.q : null }; });
  { const ps = await sget(K.pace).catch(() => null); if (!ps || ps.pace !== els.pace.value) await sset(K.pace, { pace: els.pace.value, at: Date.now() }).catch(() => {}); }          // 1.1.6.3: the select IS the saved pace
  const spec = { links, targets: tg, pace: els.pace.value, restoreBack: !!settings.restoreBack, needed: need.q };
  setMsg('Adding to the queue…', '');
  const r = await B17.request({ op: 'submit', spec }, 15000);
  settings.pace = spec.pace; sset(K.settings, settings).catch(() => {});
  if (!r.ok) { setMsg(r.message || 'The order was not accepted.', r.timeout ? '' : 'warn'); return; }
  const sf = (r.short || []).map((x) => `link ${x.n}: only ${x.want - x.missing} of ${x.want}`).join('; ');
  setMsg(r.position > 1 ? `Added to the queue (position ${r.position}).` : (v === 'unknown' ? 'Starting… (Focus will be checked on the page)' : 'Starting…'), '');
  if (sf) setMsg(`Added to the queue. Fewer channels are free than asked — ${sf}.`, 'warn');
  if (self.renderOrders) self.renderOrders();
  els.links.focus();
}
// 1.1.7: the Stop button cancels the order that is running (queued orders have their own Cancel in the Orders panel); no queue loaded = the 1.1.6 stop
async function stopOrder() {
  const b = await sget(K.batch);
  if (self.B17 && b && b.order && b.state === 'running') { const r = await B17.request({ op: 'cancel', oid: b.order }, 8000); if (r && r.ok) { setMsg('Stopping this order…', ''); return; } }
  return stop();
}
async function stop() {
  own.stopped = true;
  const b = await sget(K.batch); if (!b) return;
  sset('p9bn.stop.' + b.id, { at: Date.now() }).catch(() => {});          // 1.1.7: the DEFINITIVE stop of this run id (a rotation / wait for the VPN stops on it; a stale or other run's record never does)
  b.state = 'stopped'; b.updated = Date.now();
  b.items.forEach((it) => { if (it.status === 'queued') { it.status = 'skipped'; it.code = 'stopped'; } else if (it.status === 'running') { it.status = 'stopped'; it.code = 'stopped'; } });
  await sset(K.batch, b); batch = b; renderResults();
  await closeRunTabs(b, 'sweep'); await sweepVerified(null);      // 1.1.2: every registered Bean tab, even when group.tab was lost (1.1.6.3: verified, and swept again twice for a straggler)
  for (const ms of [5000, 15000]) setTimeout(() => { sweepTabs(null).catch(() => {}); }, ms);
}
async function clearResults() { { const cb0 = await sget(K.batch); const cl0 = self.S17 && S17.claims && Object.keys(S17.claims).length; if ((cb0 && cb0.state === 'running') || cl0) { setMsg('A run or a claimed job is active: Clear results does nothing until it ends (use Stop).', 'warn'); return; } }          /* 1.1.7.2 (live: Clear while a job was claimed made the run vanish) */ own.cleared = true; own.last = null; const cb = await sget(K.batch); if (cb) sset('p9bn.stop.' + cb.id, { at: Date.now() }).catch(() => {}); await chrome.storage.local.remove(K.batch); batch = null; setMsg(''); renderResults(); if (cb && (cb.owner || 'popup') === ROLE) await closeRunTabs(cb, cb.id === own.id ? 'sweep' : 'all'); }

// ================================================================ init
els.links.addEventListener('input', renderCount);
// 1.1.6.3: pace is ONE persistent setting (p9bn.pace) for every run: popup runs, API jobs and queued orders. The tab and the popup read it fresh before each gap, so a change applies from the next item on.
function showPace() { const n = document.getElementById('paceNote'); if (n) n.textContent = 'Current pace: ' + L.paceLabel(els.pace.value) + ' — one setting for every run, API order and queued order; a change applies from the next item.'; }
els.pace.addEventListener('change', async () => {
  const p = L.pickPace(els.pace.value, 'normal'); settings.pace = p; sset(K.settings, settings).catch(() => {});
  await sset(K.pace, { pace: p, at: Date.now() }).catch(() => {}); showPace(); renderPlan();
  await mutate((bb) => { if (bb.state !== 'running' || bb.pace === p) return false; bb.pace = p; (bb.events = bb.events || []).push([Date.now(), 'pace changed to ' + L.paceLabel(p) + ' (applies from the next item)']); bb.events = bb.events.slice(-20); }).catch(() => {});
});
els.go.addEventListener('click', go);
els.stop.addEventListener('click', () => stopOrder().catch(() => {}));
els.qall.addEventListener('input', () => { qty.all = els.qall.value; saveLikesNeeded(); updQty(); });
// 1.1.4 PAUSE / RESUME. Pause only sets a request on the run record (pauseReq). The YouTube tab holds at the next item boundary (after the like in progress is verified and recorded: never between the click and
// the verify), and the popup holds before opening the next container: no new page, no VPN change, no tab. Resume clears the request: the next queued item goes on, nothing skipped, nothing repeated.
async function pauseRun(why) { { const c0 = await sget(K.batch); if (!c0 || c0.state !== 'running') return; uiResume = null; uiPause = { bid: c0.id, st: 'pausing', at: Date.now(), seen: Date.now() }; try { renderResults(); } catch (_) { /* drawing never blocks Pause/Resume (1.1.7.2) */ } if (L.pauseWanted(await sget(K.pause), c0)) return; await sset(K.pause, { bid: c0.id, at: Date.now() }); } await mutate((b) => { if (b.state !== 'running' || b.pauseReq) return false; b.pauseReq = Date.now(); b.updated = Date.now(); (b.events = b.events || []).push([Date.now(), 'pause requested' + (why ? ' by Bean (' + why + ')' : '') + ' — the item in progress finishes first']); if (why) b.pauseBy = why; b.events = b.events.slice(-20); }); try { renderResults(); } catch (_) { /* drawing never blocks Pause/Resume (1.1.7.2) */ } setMsg('Pausing…', 'warn'); setTimeout(() => advance().catch(() => {}), 1100); }
async function resumeRun() { { const c0 = await sget(K.batch); uiPause = null; if (c0) uiResume = { bid: c0.id, at: Date.now() }; try { renderResults(); } catch (_) { /* drawing never blocks Pause/Resume (1.1.7.2) */ } if (c0) await sset(K.pause, { bid: c0.id, at: 0, cleared: Date.now() }); } await mutate((b) => { if (b.state !== 'running' || !b.pauseReq) return false; const was = b.pause && b.pause.since; b.pauseReq = 0; b.pause = null; b.updated = Date.now(); b.nextAt = 0; b.graceUntil = 0; (b.events = b.events || []).push([Date.now(), was ? 'resumed' : 'pause cancelled']); b.events = b.events.slice(-20); }); resumeClean(await sget(K.batch).catch(() => null)); try { renderResults(); } catch (_) { /* drawing never blocks Pause/Resume (1.1.7.2) */ } advance().catch(() => {}); }
// 1.1.7.2 (Oluchi's run i7de3vi7mw1sir2y, 08:44-08:46): a Pause that lands while a container is being reopened left this page's memory of the old attempt (an 'opened' key, the old tab id, an expired grace, a spent ping save):
// after Resume the queued container could be taken for one that is already open, or judged silent at once. Resume forgets every trace of a container that is queued now; a container whose tab is really working keeps its own.
function resumeClean(b) { if (!b) return; const t = Date.now(); lastGoneCheck = 0; advance.key = null; for (const g of b.groups || []) { if (g.status !== 'queued') continue; const c = g.cid || ''; for (const k of [...opened]) if (k.indexOf(b.id + ':' + c + ':') === 0) opened.delete(k); const m = mem[b.id + ':' + c]; if (m) { delete m.tab; m.graceUntil = 0; m.lastSeenAt = t; m.pingSaves = 0; m.heard = false; m.vpnChk = 0; } } for (const k of Object.keys(sentSeen)) if (k.indexOf(b.id + '|') === 0) sentSeen[k] = t; }

els.pause.addEventListener('click', () => pauseRun().catch(() => {}));          // a press of the button: no reason (the user's own Pause)
els.resume.addEventListener('click', () => resumeRun().catch(() => {}));
els.clear.addEventListener('click', clearResults);
els.call.addEventListener('click', () => setAll(true));
els.cnone.addEventListener('click', () => setAll(false));
els.refresh.addEventListener('click', () => refreshChannels().catch((e) => { discovering = null; setMsg('Could not read the channels: ' + String((e && e.message) || e).slice(0, 100), 'warn'); renderContainers(); }));
els.cfilter.addEventListener('input', renderContainers);
els.links.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) go(); });
els.links.addEventListener('paste', () => setTimeout(renderCount, 0));
let staleSeen = 0;          // test aid: how many stale older-run records the view ignored
chrome.storage.onChanged.addListener((c, area) => {
  if (area === 'local' && c[K.pace] && c[K.pace].newValue) { const p = L.pickPace(c[K.pace].newValue, els.pace.value); if (els.pace.value !== p) { els.pace.value = p; showPace(); renderPlan(); } }
  if (area !== 'local') return;
  if (c[K.batch] && c[K.batch].newValue && c[K.batch].newValue.state !== 'running' && (c[K.batch].newValue.owner || 'popup') === ROLE) { const eid = c[K.batch].newValue.id; setTimeout(() => cleanMarkers(eid), 3000); }       // 1.1.7: the run is over: its tab-seen / google-check markers go
  if (c[K.batch]) {
    const nv = c[K.batch].newValue || null;
    // 1.1.7.1 ONE ACTIVE RUN, NO FLAPPING (Oluchi 17:49: the popup kept flipping between the job that had just finished and the new one): Panel 9's storage mirror can bring back the OLDER run record for a moment. A record of a DIFFERENT, OLDER run than the one shown is a stale copy: it is never shown; only a newer run (or the run's own newer record) replaces the view.
    if (nv && batch && nv.id !== batch.id && (nv.created || 0) < (batch.created || 0)) { staleSeen++; }
    else { batch = nv; if (batch && batch.id === own.id) { noteFinal(batch); own.last = batch; } renderResults(); }
  }
  for (const k of Object.keys(c)) if (k.indexOf(L.ACT_KEY) === 0) { const v = c[k].newValue; if (v && typeof v === 'object' && v.id) actRec[k.slice(L.ACT_KEY.length)] = v; else delete actRec[k.slice(L.ACT_KEY.length)]; }          // 1.1.7.1: no re-render: only the next plan sees it
  if (!discovering && ctrs && Object.keys(c).some((k) => k.indexOf(L.chKey(pid(), '')) === 0)) loadChannelCache().then(() => { normalizeSel(); renderContainers(); });
  if (Object.keys(c).some((k) => k.indexOf('p9bn.led.') === 0)) { clearTimeout(self.__pl); self.__pl = setTimeout(() => { try { renderPossible(); } catch (_) { /* ignore */ } }, 700); }      // the ledger changed (a run recorded a like / an import): the counts follow
  if (c[K.ytf] && c[K.ytf].newValue) { ytf = c[K.ytf].newValue; renderGate(verdict(Date.now() - 4000)); }
});
setInterval(() => { if (batch && batch.state === 'running') { try { renderResults(); } catch (e) { console.warn('[bean] render', e); } }          /* 1.1.7.2: a drawing error never stops the run loop below */ if (own.id && !own.cleared && (own.last && own.last.state === 'running' || own.stopped || myTabs.size)) { advance().catch(() => {}); } if (myTabs.size && !(own.last && own.last.state === 'running' && !own.cleared) && !discovering) closeRunTabs(null, 'sweep').catch(() => {}); }, 1000);
// ================================================================ run log (1.1.1)
// Every run's items with the reason and the steps the YouTube tab recorded; the last 5 runs are kept in chrome.storage.local ("p9bn.runs") so a failure can still be read
// (and copied / exported) after the run ended or the popup was closed. Nothing secret is in it: no IP address, no cookie, no key.
const RUNS = 'p9bn.runs';
const archived = new Set();
let logSel = 'current', logT = 0, logSig = '';
async function archiveRun(b) {
  if (!b || b.state === 'running' || !Array.isArray(b.items)) return;
  const sig = b.id + ':' + b.state + ':' + (b.updated || 0); if (archived.has(sig)) return; archived.add(sig);
  try {
    const rec = L.runBrief(b); const cur = await sget(RUNS); const list = (Array.isArray(cur) ? cur : []).filter((r) => r && r.id !== b.id); list.push(rec);
    while (list.length > 5 || (list.length > 1 && JSON.stringify(list).length > 900000)) list.shift();
    await sset(RUNS, list);
  } catch (_) { /* best effort */ }
}
function logSoon() { clearTimeout(logT); logT = setTimeout(() => { renderLog().catch(() => {}); }, 400); }
async function logRec() {
  if (logSel === 'current' && batch) return L.runBrief(batch);
  const cur = await sget(RUNS); const list = Array.isArray(cur) ? cur : [];
  return list.find((r) => r.id === logSel) || (batch ? L.runBrief(batch) : list[list.length - 1] || null);
}
async function renderLog() {
  const box = $('sec-log'); if (!box) return;
  const cur = await sget(RUNS); const list = Array.isArray(cur) ? cur : [];
  const opts = []; if (batch) opts.push(['current', 'Current run · ' + L.fmtDT(batch.created)]);
  for (const r of list.slice().reverse()) if (!batch || r.id !== batch.id) opts.push([r.id, L.fmtDT(r.created) + ' · ' + r.count + ' item' + (r.count === 1 ? '' : 's') + ' · ' + r.state]);
  const sel = $('logrun'), sig = JSON.stringify(opts);
  if (sig !== logSig) { logSig = sig; sel.textContent = ''; for (const [v, t] of opts) { const o = document.createElement('option'); o.value = v; o.textContent = t; sel.append(o); } }
  if (!opts.some((o) => o[0] === logSel)) logSel = opts.length ? opts[0][0] : 'current';
  sel.value = logSel;
  $('logsum').textContent = opts.length ? '· ' + opts.length + ' run' + (opts.length === 1 ? '' : 's') : '· none yet';
  if (!box.open) return;
  const rec = await logRec(); $('logview').textContent = rec ? L.logText(rec) : 'No run yet.';
  for (const id of ['logcopy', 'logtxt', 'logjson']) $(id).disabled = !rec;
}
async function copyLog() {
  const rec = await logRec(); if (!rec) return; const text = L.logText(rec);
  let ok = false;
  try { await navigator.clipboard.writeText(text); ok = true; } catch (_) { /* fall back */ }
  if (!ok) { const ta = document.createElement('textarea'); ta.value = text; ta.style.cssText = 'position:fixed;left:-9999px'; document.body.append(ta); ta.select(); try { ok = document.execCommand('copy'); } catch (_) { /* ignore */ } ta.remove(); }
  const b = $('logcopy'), old = 'Copy log'; b.textContent = ok ? 'Copied ✓' : 'Select the text and copy'; setTimeout(() => { b.textContent = old; }, 2000);
}
async function exportLog(kind) {
  const rec = await logRec(); if (!rec) return;
  const d = new Date(rec.created || Date.now()), p2 = (n) => String(n).padStart(2, '0');
  const name = `bean-run-${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}-${String(rec.id).slice(0, 6)}.${kind}`;
  const text = kind === 'json' ? JSON.stringify({ bean: '1.1.7.1', exportedAt: new Date().toISOString(), run: rec }, null, 2) : L.logText(rec);
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: kind === 'json' ? 'application/json' : 'text/plain' })); a.download = name; document.body.append(a); a.click();
  setTimeout(() => { try { URL.revokeObjectURL(a.href); } catch (_) { /* ignore */ } a.remove(); }, 2000);
}
// the "like sent" markers (p9bn.clk.*) older than 60 days are dropped; a Ledger "clear" drops them all (ext11)
async function pruneMarkers() {
  const all = await chrome.storage.local.get(null); const old = [];
  for (const k of Object.keys(all)) if (k.indexOf('p9bn.clk.') === 0 && (!all[k] || (all[k].at || 0) < Date.now() - 60 * 86400000)) old.push(k);
  if (old.length) await chrome.storage.local.remove(old);
}

(async () => {
  const [b, s] = await Promise.all([sget(K.batch), sget(K.settings)]);
  batch = b; settings = s && typeof s === 'object' ? s : {};
  cleanMarkers(null);       // 1.1.7: prune old tab-seen / google-check markers
  if (b && b.state === 'running' && (b.owner || 'popup') === ROLE) { own.id = b.id; own.last = b; }
  { const ps = await sget(K.pace); const p0 = L.pickPace(ps, settings.pace); els.pace.value = p0; if (!ps || ps.pace !== p0) await sset(K.pace, { pace: p0, at: Date.now() }).catch(() => {}); showPace(); }
  // 1.1.7: "Background tabs" switch next to the pace: writes the ONE setting p9bn.bgTabs (true / removed, never false) that every run reads fresh before it opens a tab (popup, API and queued orders alike); kept in step with the stored value
  { const bg = document.getElementById('bgTabs'); if (bg) { const sync = async () => { bg.checked = L.bgTabsOn(await sget(L.BGTABS_KEY).catch(() => null)); }; await sync(); bg.addEventListener('change', async () => { if (bg.checked) await sset(L.BGTABS_KEY, true); else await chrome.storage.local.remove(L.BGTABS_KEY).catch(() => {}); }); chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch[L.BGTABS_KEY]) sync().catch(() => {}); }); } }
  // 1.1.7.9: Parallel / Single toggle (default Parallel). Writes p9bn.parallel so pickOpen capacity is 4 or 1 for every run (popup + API).
  { const pp = document.getElementById('parParallel'), ps = document.getElementById('parSingle');
    if (pp && ps) {
      const sync = async () => { const m = await parallelModeNow(); pp.checked = m !== 'single'; ps.checked = m === 'single'; };
      await sync();
      const onChange = async () => { await saveParallelMode(ps.checked ? 'single' : 'parallel'); };
      pp.addEventListener('change', onChange); ps.addEventListener('change', onChange);
      chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch[PAR_KEY]) sync().catch(() => {}); });
      // ensure a stored value exists so API / runner see the same default as the UI
      if ((await sget(PAR_KEY).catch(() => null)) == null) await saveParallelMode(settings.parallelMode === 'single' ? 'single' : 'parallel');
    }
  }
  const rb = document.getElementById('restoreBack'); if (rb) { rb.checked = !!settings.restoreBack; rb.addEventListener('change', async () => { settings.restoreBack = rb.checked; await sset(K.settings, settings); }); }
  if (settings.likesNeeded != null && settings.likesNeeded !== '') { qty.all = String(settings.likesNeeded); if (els.qall) els.qall.value = qty.all; }
  updLikesNeededHint();
  pruneMarkers().catch(() => {});
  document.getElementById('sec-log').addEventListener('toggle', () => renderLog());
  document.getElementById('logrun').addEventListener('change', () => { logSel = document.getElementById('logrun').value; renderLog(); });
  document.getElementById('logcopy').addEventListener('click', copyLog); document.getElementById('logtxt').addEventListener('click', () => exportLog('txt')); document.getElementById('logjson').addEventListener('click', () => exportLog('json'));
  // tab rule: a tab left behind by a closed window / a crash (finished run, unfinished channel reading) is closed now
  try {
    if (b && b.state !== 'running' && (b.owner || 'popup') === ROLE) await closeRunTabs(b, 'all');
    if (!b || (b.owner || 'popup') === ROLE) await sweepTabs(activeKeep(b));      // 1.1.2: a tab left behind (crash, closed window, lost group.tab) is closed now
    const d = await sget(K.disc); if (d && d.tab != null && ROLE === 'popup') { await closeTabId(d.tab); await sset(K.disc, { id: d.id, state: 'done', created: Date.now() }); }
  } catch (_) { /* best effort */ }
  try {      // 1.1.6.4: a run that was open when Bean was updated / reloaded is kept, paused, with its orphan tab closed
    const ver = chrome.runtime.getManifest().version, prev = await sget(K.ver); if (prev !== ver) await sset(K.ver, ver);
    const r = await recoverAfterReload(prev && prev !== ver ? 'Bean was updated' : 'Bean was reloaded'); if (r) { const nb = await sget(K.batch); if (nb) { batch = nb; own.id = nb.id; own.last = nb; } }
  } catch (_) { /* best effort */ }
  await loadContainers(); await loadChannelCache(); restoreSel(); renderContainers();
  renderCount(); renderResults();
  if (batch && batch.state === 'running') advance().catch(() => {});      // reopened during / after an interrupted run: carry on (within RESUME_MS)
  const asked = await askYtf(900);
  renderGate(verdict(asked));
  if (ROLE === 'popup') els.links.focus();            // 1.1.6.4: only the popup's own text box, only for the visible popup (never from the hidden runner page)
  if (self.B11) await B11.init().catch((e) => { try { console.log('[bean] ext init', e && e.message); } catch (_) { /* ignore */ } });
  if (self.B17) { try { B17.init(); } catch (e) { try { console.log('[bean] orders init', e && e.message); } catch (_) { /* ignore */ } } }
})();
