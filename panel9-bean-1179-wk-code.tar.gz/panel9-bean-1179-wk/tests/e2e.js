'use strict';
// End-to-end test of Bean inside the REAL Panel 9 (Electron 45) together with the REAL, unmodified YouTube Focus extension, against a LOCAL mock
// of youtube.com (tests/mock-youtube.js). Nothing here touches the real YouTube, a real Google account or a real comment: the host name www.youtube.com is
// mapped to 127.0.0.1 with --host-resolver-rules and the mock's self-signed certificate is accepted only in this throw-away process.
// Run:  cd /workspace/mobile-browser && xvfb-run -a -s "-screen 0 1440x1000x24" npx electron --no-sandbox /workspace/panel9-bean/tests/e2e.js
// Screenshots (mock data only) -> ../shots/
const fs = require('fs'); const os = require('os'); const path = require('path');
const { app } = require('electron');
// xvfb has no real window visibility: keep hidden test windows' timers running like a visible popup would (a throttled timer only delays Bean's 1 s tick)
app.commandLine.appendSwitch('disable-background-timer-throttling'); app.commandLine.appendSwitch('disable-renderer-backgrounding'); app.commandLine.appendSwitch('disable-backgrounding-occluded-windows'); app.commandLine.appendSwitch('disable-features', 'IntensiveWakeUpThrottling,CalculateNativeWinOcclusion');
// default: the Panel 9 working copy that has the 2.3.9 Bean bridge (containers + openTabInContainer)
const P9 = process.env.P9_DIR || '/workspace/mobile-browser';
const YTF = process.env.P9_YTF_DIR || '/workspace/yt-focus-extension';
const SRC = path.join(__dirname, '..');
const SHOTS = path.join(SRC, 'shots');
const mock = require('./mock-youtube.js');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let failures = 0, passes = 0;
const check = (name, ok, detail) => { if (ok) passes++; else failures++; console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${!ok && detail !== undefined ? '  -> ' + JSON.stringify(detail) : ''}`); };
const js = (wc, code) => wc.executeJavaScript(code);
const shot = async (wc, name) => { try { const img = await wc.capturePage(); fs.mkdirSync(SHOTS, { recursive: true }); fs.writeFileSync(path.join(SHOTS, name), img.toPNG()); console.log('  shot', name); } catch (e) { console.log('  shot failed', name, e.message); } };

(async () => {
  const srv = await mock.start({ signedIn: true });
  app.commandLine.appendSwitch('host-resolver-rules', `MAP www.youtube.com 127.0.0.1:${srv.port}`);
  app.commandLine.appendSwitch('ignore-certificate-errors');
  process.env.P9_TEST = '1';
  process.env.P9_USER_DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'p9-bean-'));
  process.env.P9_LEGACY_DIR = path.join(process.env.P9_USER_DATA, '..', 'p9-no-legacy-dir');
  process.env.P9_NO_UPDATE_CHECK = '1';
  const { ready, api } = require(path.join(P9, 'src/main.js'));
  await ready;
  const ctx = api.ctx, mgr = api.extensions;
  const trk = require('./tabtrack.js')(ctx);          // 1.1.0 tab rule: never more than ONE Bean tab open at the same time; all closed at the end
  const wait = async (cond, ms = 20000, step = 150) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { try { const v = await cond(); if (v) return v; } catch (_) { /* retry */ } await sleep(step); } return false; };

  // Panel 9 only gives the container bridge to the extension whose id ends in "panel9-bean" (= its Store id). "Load unpacked" derives the id from the
  // manifest name, so the test loads a copy of the extension (same files) whose name is "Panel9 Bean"; and a second copy that is NOT allowed (bridge-missing case).
  const copyExt = (name) => {
    const d = fs.mkdtempSync(path.join(os.tmpdir(), 'p9bn-copy-')); fs.cpSync(SRC, d, { recursive: true, filter: (p) => !/[\\/](tests|shots)([\\/]|$)/.test(p) });
    const m = JSON.parse(fs.readFileSync(path.join(d, 'manifest.json'), 'utf8')); m.name = name; fs.writeFileSync(path.join(d, 'manifest.json'), JSON.stringify(m, null, 2)); return d;
  };
  const BEAN = copyExt('Panel9 Bean');
  console.log('\n== setup: load YouTube Focus (unmodified) and Bean (same files) with "Load unpacked" ==');
  const ytf = await mgr.loadUnpacked(YTF);
  const bean = await mgr.loadUnpacked(BEAN);
  check('YouTube Focus loaded', !!ytf && mgr.get(ytf.id).enabled, ytf && ytf.id);
  const home = ctx.createTab('about:blank', 'desktop'); await home.ready;
  ctx.win.setSize(1300, 900); await sleep(400);
  await wait(() => mgr.pageUrl(bean.id, 'popup'), 8000);
  check('Bean loaded as ' + bean.id + ', has a popup', !!bean && mgr.get(bean.id).enabled && /^chrome-extension:\/\/[a-p]{32}\/popup\.html/.test(mgr.pageUrl(bean.id, 'popup') || ''), bean && [bean.id, mgr.get(bean.id).enabled, mgr.pageUrl(bean.id, 'popup')]);

  const closePopups = () => { for (const w of api.extPopups.values()) { try { w.close(); } catch (_) { /* ignore */ } } };
  const popup = async (id) => {
    closePopups(); await sleep(150);
    await api.openExtensionPopup(ctx, id, 'popup');
    const w = await wait(() => api.extPopups.get(`${ctx.id}:${id}:popup`), 5000);
    const wc = w.contentView.children[0].webContents;
    await wait(() => js(wc, "document.readyState === 'complete'"), 5000);
    await sleep(1400);    // initial ping round trip
    return wc;
  };
  const ytfToggle = async (key, on) => { const wc = await popup(ytf.id); await js(wc, `(() => { const c = document.getElementById('${key}'); if (c.checked !== ${on}) c.click(); })()`); await sleep(700); closePopups(); };
  const batchOf = (wc) => js(wc, "chrome.storage.local.get('p9bn.batch').then((v) => v['p9bn.batch'])");
  const ui = (wc, sel) => js(wc, `(document.querySelector(${JSON.stringify(sel)}) || {}).textContent`);
  const ID = { top1: 'UgxTOP1_unliked_aaaaaaaaaaaaaaaa', top2: 'UgxTOP2_alreadyliked_bbbbbbbbbbbb', top3: 'UgxTOP3_withreplies_cccccccccccc', r1: 'UgxTOP3_withreplies_cccccccccccc.REPLYr1xxxxx', r2: 'UgxTOP3_withreplies_cccccccccccc.REPLYr2yyyyy' };
  const link = (vid, lc) => `https://www.youtube.com/watch?v=${vid}&lc=${lc}`;
  // type links into the popup like a user and press the button
  const submit = async (wc, text, pace = 'fast') => {
    srv.state.liked.clear();      // 1.1.1: the mock now remembers likes (a like must survive a reload); every run starts from a clean account
    await js(wc, "(self.B11 && B11.S.ledReady ? B11.S.led.clear().then(() => { B11.S.recorded = new Set(); }) : 0)");
    await js(wc, "chrome.storage.local.get(null).then((o) => chrome.storage.local.remove(Object.keys(o).filter((k) => k.startsWith('p9bn.clk.'))))");     // 1.1.1: the click markers are part of 'a clean slate' too     // 1.1.0: every 1.0.0 scenario starts with an empty ledger (the ledger itself is tested in e2e11.js)
    await js(wc, `(() => { const t = document.getElementById('links'); t.value = ${JSON.stringify(text)}; t.dispatchEvent(new Event('input', { bubbles: true })); document.getElementById('pace').value = '${pace}'; })()`);
    await sleep(200);
  };
  let runId = null;
  const press = async (wc) => {      // click "Like comments" and wait until the NEW run record exists (so finished() never sees the previous run)
    const before = await batchOf(wc);
    await js(wc, "document.getElementById('go').click()");
    const nb = await wait(async () => { const x = await batchOf(wc); return x && (!before || x.id !== before.id) ? x : false; }, 10000, 100);
    runId = nb ? nb.id : null;
  };
  const finished = (wc, ms = 150000) => wait(async () => { const b = await batchOf(wc); return b && b.id === runId && b.state !== 'running' ? b : false; }, ms, 400);   // only OUR run (a transient older record must not end the wait)
  const codes = (b) => b.items.map((i) => i.status === 'failed' || i.status === 'skipped' ? i.code : i.status);
  const likeClicks = () => srv.state.clicks.filter((c) => c.kind === 'like');
  const reset = () => { srv.state.liked.clear(); srv.state.clicks.length = 0; srv.state.hits.length = 0; srv.state.hitLog.length = 0; srv.state.switches.length = 0; };

  // ------------------------------------------------------------------------------------------------------------ 1
  console.log('\n== 1. comment-only view OFF (yt-focus default): nothing is liked, the user is told why ==');
  reset();
  let pw = await popup(bean.id);
  check('popup: status pill says "not checked yet" while no YouTube tab is open (no false block)', /not checked/.test(await ui(pw, '#pill')), await ui(pw, '#pill'));
  await submit(pw, 'hello\n' + link('NORMAL00001', ID.top1) + '\nhttps://www.youtube.com/watch?v=NORMAL00001');
  check('popup counts 1 ready + problems (no-lc link, not a link)', /1 comment link ready/.test(await ui(pw, '#count')) && /2 problems/.test(await ui(pw, '#count')), await ui(pw, '#count'));
  const tabs0 = ctx.tabs.length, mk1 = trk.mark();
  await press(pw);
  let b = await finished(pw, 60000);
  check('run finished with "ytf-off" for the link', !!b && codes(b)[0] === 'ytf-off', b && codes(b));
  check('exactly one tab was opened for the link (same container as the active tab) and it is closed again when the run ends', trk.total - mk1.total === 1 && (await wait(() => ctx.tabs.length === tabs0, 8000)) && srv.state.hits.some((h) => /lc=UgxTOP1/.test(h) && /p9bn=/.test(h)), { tabs: ctx.tabs.length, hits: srv.state.hits });
  check('NOTHING was clicked on the page', srv.state.clicks.length === 0, srv.state.clicks);
  check('popup shows the message "Turn on YouTube Focus comment-only view" (status line and result row)', /Turn on YouTube Focus comment-only view/.test(await ui(pw, '#results')) && /Turn on YouTube Focus comment-only view/.test(await ui(pw, '#msg')), [await ui(pw, '#results'), await ui(pw, '#msg')]);
  await shot(pw, 'popup-2-ytf-off-result.png');

  console.log('\n== 2. with a YouTube tab open, the popup sees that comment-only view is off and blocks the button ==');
  ctx.createTab('https://www.youtube.com/watch?v=NORMAL00001', 'desktop');      // the user's own YouTube tab (Bean closes its own tab when a run ends, so the test brings one)
  await sleep(2500);
  pw = await popup(bean.id);
  check('pill: "Comment-only view: off"', /Comment-only view: off/.test(await ui(pw, '#pill')), await ui(pw, '#pill'));
  await submit(pw, link('NORMAL00001', ID.top1));
  check('gate message visible and the button is disabled', (await js(pw, "!document.getElementById('gate').hidden && document.getElementById('go').disabled")) === true && /Turn on YouTube Focus comment-only view/.test(await ui(pw, '#gate')));
  await shot(pw, 'popup-1-gate-off.png');

  console.log('\n== 3. turn comment-only view ON in YouTube Focus: the same popup now works ==');
  await ytfToggle('commentsOnly', true);
  pw = await popup(bean.id);
  check('pill: "Comment-only view: on", gate hidden', /Comment-only view: on/.test(await ui(pw, '#pill')) && (await js(pw, "document.getElementById('gate').hidden")), await ui(pw, '#pill'));
  reset();
  const text = [
    'https://www.youtube.com/shorts/NORMAL00001?lc=' + ID.top1,                       // shorts form  -> liked
    'https://youtu.be/NORMAL00001?lc=' + ID.top2 + '&si=abc',                         // youtu.be form -> already liked
    link('NORMAL00001', ID.r1),                                                       // reply        -> liked
    link('NORMAL00001', ID.r2),                                                       // reply        -> already liked
    link('NORMAL00001', ID.top1),                                                     // duplicate of line 1 -> dropped
    link('NORMAL00001', 'UgxMISSING_notthere_dddddddddd')                             // deleted comment -> not found
  ].join('\n');
  await submit(pw, text, 'fast');
  check('popup: 5 ready (duplicate dropped, flagged as a problem)', /5 comment links ready/.test(await ui(pw, '#count')) && /1 problem/.test(await ui(pw, '#count')), await ui(pw, '#count'));
  const tabsBefore = ctx.tabs.length;
  const mk3 = trk.mark();
  await press(pw);
  b = await finished(pw, 240000);
  console.log('   results:', b && JSON.stringify(codes(b)));
  check('results: liked, already, liked(reply), already(reply), not-found', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'already', 'liked', 'already', 'not-found']), b && codes(b));
  check('batch state is "done"', !!b && b.state === 'done', b && b.state);
  const lc = likeClicks();
  check('exactly TWO like clicks reached the page: the top-level comment and the reply, each from "was-unliked"', lc.length === 2 && lc.every((c) => c.pressed === 'was-unliked') && lc.some((c) => c.id === ID.top1) && lc.some((c) => c.id === ID.r1), lc);
  check('the already-liked comments were NEVER clicked (no toggle-off), and nothing was disliked', !srv.state.clicks.some((c) => c.id === ID.top2 || c.id === ID.r2 || c.kind === 'dislike'), srv.state.clicks);
  if (process.env.E2E_STOP_AFTER) { await sleep(9000); console.log('   [debug] adv', JSON.stringify(await js(pw, 'window.__adv')), JSON.stringify(await js(pw, '({tk: window.__tk, tt: window.__tt, re: window.__re, id: own.id, cl: own.cleared, st: own.stopped, last: own.last && own.last.state, ms: myTabs.size, vis: document.visibilityState, disc: !!discovering})')), JSON.stringify(await js(pw, '[...myTabs]')), 'tabs', ctx.tabs.length, tabsBefore, 'now', Date.now() % 1000000); trk.stop(); process.exit(0); }
  check('one tab did the whole batch (5 page loads, exactly 1 tab opened) and it is closed again when the run is done', trk.total - mk3.total === 1 && srv.state.hits.length >= 5 && (await wait(() => ctx.tabs.length === tabsBefore, 8000)), { opened: trk.total - mk3.total, tabs: ctx.tabs.length - tabsBefore, hits: srv.state.hits.length });
  check('popup lists the labels Liked / Already liked / Comment not found', /Liked/.test(await ui(pw, '#results')) && /Already liked/.test(await ui(pw, '#results')) && /Comment not found/.test(await ui(pw, '#results')));
  await shot(pw, 'popup-3-results.png');
  const lastTab = trk.tabs().pop();
  check('token param removed from the address bar after the run (last address seen before the tab was closed)', !!lastTab && !/p9bn=/.test(lastTab.lastUrl), lastTab && lastTab.lastUrl);

  console.log('\n== 4. Stop: later links are not opened ==');
  reset();
  pw = await popup(bean.id);
  await submit(pw, [link('NORMAL00001', ID.top1), link('NORMAL00001', ID.top3), link('NORMAL00001', ID.top2)].join('\n'), 'slow');
  await press(pw);
  await wait(async () => { const x = await batchOf(pw); return x && x.items[0].status === 'liked'; }, 60000);
  await js(pw, "document.getElementById('stop').click()");
  await sleep(500);
  const hitsAtStop = srv.state.hits.length;
  await sleep(22000);
  b = await batchOf(pw);
  check('stopped: state "stopped", later items skipped', b.state === 'stopped' && b.items[1].status === 'skipped' && b.items[2].status === 'skipped', b);
  check('no further page loads and exactly one like click after Stop', srv.state.hits.length === hitsAtStop && likeClicks().length === 1, { hits: srv.state.hits.length, hitsAtStop, likes: likeClicks().length });

  console.log('\n== 5. the like does not register: ONE click only, never a retry ==');
  reset();
  pw = await popup(bean.id);
  await submit(pw, link('FLAKYLIKE01', ID.top1));
  await press(pw); b = await finished(pw, 90000);
  check('result "click-failed"', !!b && codes(b)[0] === 'click-failed', b && codes(b));
  check('exactly one click was made (a retry could have un-liked it)', likeClicks().length === 1, srv.state.clicks);

  console.log('\n== 6. "already liked" arrives late: no click ==');
  reset();
  await submit(pw, link('LATEPRESS01', ID.top1));
  await press(pw); b = await finished(pw, 90000);
  check('result "already" and zero clicks', !!b && codes(b)[0] === 'already' && srv.state.clicks.length === 0, { c: b && codes(b), clicks: srv.state.clicks });

  console.log('\n== 7. comments turned off / slow comment loading ==');
  reset();
  await submit(pw, link('NOCOMMENT01', ID.top1));
  await press(pw); b = await finished(pw, 90000);
  check('result "comments-off"', !!b && codes(b)[0] === 'comments-off', b && codes(b));
  await submit(pw, link('SLOWLOAD_01', ID.top1));
  await press(pw); b = await finished(pw, 90000);
  check('slow-loading comments (3.5 s) still get liked', !!b && codes(b)[0] === 'liked' && likeClicks().length === 1, { c: b && codes(b), likes: likeClicks().length });

  console.log('\n== 8. not signed in ==');
  srv.state.signedIn = false; reset();
  await submit(pw, [link('NORMAL00001', ID.top1), link('NORMAL00001', ID.top3)].join('\n'));
  await press(pw); b = await finished(pw, 90000);
  check('signed-out page: "not-signed-in", second link skipped, nothing clicked', !!b && codes(b)[0] === 'not-signed-in' && b.items[1].status === 'skipped' && srv.state.clicks.length === 0, { c: b && codes(b), clicks: srv.state.clicks });
  check('popup says "Not signed in"', /Not signed in/.test(await ui(pw, '#results')), await ui(pw, '#results'));
  reset();
  await submit(pw, link('NOMASTHEA01', ID.top1));
  await press(pw); b = await finished(pw, 90000);
  check('no masthead to inspect: the click is tried once, the sign-in dialog is recognised -> "not-signed-in"', !!b && codes(b)[0] === 'not-signed-in' && likeClicks().length === 1, { c: b && codes(b), likes: likeClicks().length });
  srv.state.signedIn = true;

  console.log('\n== 9. YouTube Focus missing (disabled) ==');
  reset();
  await mgr.setEnabled(ytf.id, false); await sleep(1500);
  pw = await popup(bean.id);
  await submit(pw, link('NORMAL00001', ID.top1));
  await press(pw); b = await finished(pw, 90000);
  check('result "no-ytf" and nothing clicked', !!b && codes(b)[0] === 'no-ytf' && srv.state.clicks.length === 0, { c: b && codes(b), clicks: srv.state.clicks });
  check('popup shows "YouTube Focus is not installed or not enabled"', /YouTube Focus is not installed or not enabled/.test(await ui(pw, '#results') + await ui(pw, '#gate')), await ui(pw, '#results'));
  await shot(pw, 'popup-4-ytf-missing.png');
  for (const t of [...ctx.tabs]) if (/youtube\.com/.test(t.view.webContents.getURL())) ctx.closeTab(t.id);   // open YouTube pages keep the "no YouTube Focus" verdict until reloaded
  await mgr.setEnabled(ytf.id, true); await sleep(1500);

  // ============================================================================================================== multi-container (containers)
  console.log('\n== 10. container picker: lists the profile\'s containers, remembers the choice ==');
  const mk = async (name, color, acct) => { const c = await api.call('containers.create', { name, color }, ctx); const ses = ctx.sessionFor(c.id); if (acct) await ses.cookies.set({ url: 'https://www.youtube.com/', name: 'acct', value: acct, secure: true }); return c; };
  const cA = await mk('Channel A', '#e5484d', 'alice'), cB = await mk('Channel B', '#3e63dd', 'bob'), cC = await mk('Channel C', '#30a46c', 'signedout'), cD = await mk('Channel D', '#f5a524', 'dora');
  const mainId = 'default';
  srv.state.liked.add('dora|NORMAL00003|' + ID.r1);      // account "dora" has already liked this reply (on that video)
  const tickOnly = (wc, ids) => js(wc, `(() => { const want = new Set(${JSON.stringify(ids)}); for (let n = 0; n < 40; n++) { const cb = [...document.querySelectorAll('#clist input[type=checkbox]:not([data-chid])')].find((c) => c.checked !== want.has(c.dataset.cid)); if (!cb) break; cb.click(); } })()`);
  const rows = (wc) => js(wc, "[...document.querySelectorAll('#clist .crow')].map((r) => ({ id: r.dataset.cid, name: r.querySelector('.cn').textContent, on: r.querySelector('input').checked, cur: r.classList.contains('cur') }))");
  const stored = (wc) => js(wc, "chrome.storage.local.get('p9bn.settings').then((v) => v['p9bn.settings'])");
  pw = await popup(bean.id);
  let rs = await rows(pw);
  check('picker visible, lists Main + the 4 new containers by name', (await js(pw, "!document.getElementById('cbox').hidden")) && rs.length === 5 && ['Channel A', 'Channel B', 'Channel C', 'Channel D'].every((n) => rs.some((r) => r.name === n)), rs);
  check('nothing ticked at first; the hint says it will use the current tab\'s container', rs.every((r) => !r.on) && /None ticked/.test(await ui(pw, '#cnote')), await ui(pw, '#cnote'));
  await tickOnly(pw, [cA.id, cB.id]);
  // Panel 9's cross-session storage mirror is last-writer-wins on whole snapshots, so the popup re-checks its settings write ~0.6 s later: wait for it to stick
  await wait(async () => { const st = await stored(pw); return st && st.sel && JSON.stringify(st.sel[Object.keys(st.sel)[0]]) === JSON.stringify([cA.id, cB.id]); }, 12000, 200); await sleep(300);
  check('ticking A and B: "2 selected", remembered in chrome.storage', /2 selected/.test(await ui(pw, '#csel')) && JSON.stringify(((await stored(pw)).sel || {})[Object.keys((await stored(pw)).sel || {})[0]]) === JSON.stringify([cA.id, cB.id]), await stored(pw));
  await js(pw, "document.getElementById('call').click()"); await sleep(200);
  check('"All" ticks every container', (await rows(pw)).every((r) => r.on) && /5 selected/.test(await ui(pw, '#csel')));
  await js(pw, "document.getElementById('cnone').click()"); await sleep(200);
  check('"None" clears them', (await rows(pw)).every((r) => !r.on));
  await tickOnly(pw, [cA.id, cB.id]); await sleep(1500);     // (settings write + its re-check)
  await submit(pw, [link('NORMAL00001', ID.top1), link('NORMAL00002', ID.top3)].join('\n'), 'fast');
  check('count line: "2 links × 2 containers = 4 likes"', /2 links × 2 containers = 4 likes/.test(await ui(pw, '#plan')), await ui(pw, '#plan'));
  check('button reads "Like 4 comments"', /Like 4 comments/.test(await ui(pw, '#go')), await ui(pw, '#go'));
  await shot(pw, 'popup-5-container-picker.png');
  pw = await popup(bean.id);
  rs = await rows(pw);
  check('after closing and reopening the popup A and B are still ticked, the rest are not', rs.filter((r) => r.on).map((r) => r.id).sort().join() === [cA.id, cB.id].sort().join(), [rs, await stored(pw)]);

  console.log('\n== 11. 2 links x 2 containers: each container\'s own account likes each comment, once ==');
  reset();
  const tabsPre = ctx.tabs.length, t0 = Date.now();
  const mk11 = trk.mark(); trk.resetMax();
  await submit(pw, [link('NORMAL00001', ID.top1), link('NORMAL00002', ID.top3)].join('\n'), 'fast');
  await press(pw);
  b = await finished(pw, 240000);
  console.log('   results:', b && JSON.stringify(codes(b)), b && JSON.stringify(b.items.map((i) => i.cname)));
  check('state "done", 4 results: liked in A twice, then liked in B twice', !!b && b.state === 'done' && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'liked', 'liked', 'liked']) && b.items.map((i) => i.cname).join() === 'Channel A,Channel A,Channel B,Channel B', b && [b.state, codes(b), b.items.map((i) => i.cname)]);
  let lcs = likeClicks();
  check('exactly 4 like clicks, 2 from account "alice" (container A) and 2 from "bob" (container B), all from "was-unliked"', lcs.length === 4 && lcs.filter((c) => c.acct === 'alice').length === 2 && lcs.filter((c) => c.acct === 'bob').length === 2 && lcs.every((c) => c.pressed === 'was-unliked'), lcs);
  check('container by container: both of A\'s likes happen before B\'s first', lcs.map((c) => c.acct).join() === 'alice,alice,bob,bob', lcs.map((c) => c.acct));
  const mine = trk.tabs().slice(-(trk.total - mk11.total)), tA = mine.filter((t) => t.containerId === cA.id), tB = mine.filter((t) => t.containerId === cB.id);
  check('TAB RULE: one tab was opened in container A and one in container B (their sessions), NEVER more than 1 Bean tab open at once, and both are closed when the run is done', mine.length === 2 && tA.length === 1 && tB.length === 1 && trk.max <= 1 && (await wait(() => ctx.tabs.length === tabsPre, 8000)), { a: tA.length, b: tB.length, max: trk.max, over: trk.over, tabs: ctx.tabs.length - tabsPre });
  check('TAB RULE: A\'s tab was closed BEFORE B\'s tab opened', tA.length === 1 && tB.length === 1 && tA[0].closedAt > 0 && tA[0].closedAt <= tB[0].first + 40, [tA[0] && tA[0].closedAt, tB[0] && tB[0].first]);
  check('the page in each tab saw that container\'s cookie (A: alice, B: bob), nothing from other containers', srv.state.hitLog.filter((h) => h.search.includes('p9bc=' + cA.id) || h.search.includes('p9bc=' + cB.id)).every((h) => h.search.includes('p9bc=' + cA.id) ? h.acct === 'alice' : h.search.includes('p9bc=' + cB.id) ? h.acct === 'bob' : false), srv.state.hitLog);
  const aLast = lcs[1].t, bFirst = lcs[2].t;
  check('human-like pause between containers (>= 2 s at "fast")', bFirst - aLast >= 2000, bFirst - aLast);
  check('human-like pause between links inside a container (>= 2 s at "fast")', lcs[1].t - lcs[0].t >= 2000 && lcs[3].t - lcs[2].t >= 2000, lcs.map((c) => c.t));
  check('result rows read "Container \'Channel A\': Liked"', /Container 'Channel A': Liked/.test(await ui(pw, '#results')) && /Container 'Channel B': Liked/.test(await ui(pw, '#results')), await ui(pw, '#results'));
  check('summary line says Done — 4 liked', /Done — 4 liked/.test(await ui(pw, '#msg')), await ui(pw, '#msg'));
  await shot(pw, 'popup-6-multi-results.png');

  console.log('\n== 12. same links again: every account already liked them -> nothing is clicked (never un-likes) ==');
  { const keep = [...srv.state.liked]; reset(); keep.forEach((k) => srv.state.liked.add(k)); }       // 1.1.1: the mock remembers likes now; scenario 11's likes are what 'already liked' means here
  await js(pw, "B11.S.led.clear().then(() => { B11.S.recorded = new Set(); })");
  await js(pw, "chrome.storage.local.get(null).then((o) => chrome.storage.local.remove(Object.keys(o).filter((k) => k.startsWith('p9bn.clk.'))))");   // 1.1.0: with the ledger empty the 1.0.0 'already liked' path is what is under test (the ledger path is in e2e11.js)
  await press(pw); b = await finished(pw, 240000);
  check('4 x "already", zero clicks', !!b && JSON.stringify(codes(b)) === JSON.stringify(['already', 'already', 'already', 'already']) && srv.state.clicks.length === 0, { c: b && codes(b), clicks: srv.state.clicks });

  console.log('\n== 13. mixed: one container signed out (only it is skipped), one account already liked ==');
  reset();
  pw = await popup(bean.id);
  await tickOnly(pw, [cA.id, cC.id, cD.id]);
  await submit(pw, link('NORMAL00003', ID.r1), 'fast');
  srv.state.liked.add('dora|NORMAL00003|' + ID.r1);       // 1.1.1: D's account has liked this reply already (submit starts every run from a clean mock)
  await press(pw); b = await finished(pw, 240000);
  console.log('   results:', b && JSON.stringify(codes(b)));
  check('A liked, C "not-signed-in", D "already" — the signed-out container did not stop the others', !!b && b.state === 'done' && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'not-signed-in', 'already']), b && [b.state, codes(b)]);
  check('only ONE like click (alice); nothing from the signed-out or already-liked accounts', likeClicks().length === 1 && likeClicks()[0].acct === 'alice' && !srv.state.clicks.some((c) => c.acct === 'dora' || c.acct === 'signedout'), srv.state.clicks);
  check('popup says "Container \'Channel C\': Not signed in"', /Container 'Channel C': Not signed in/.test(await ui(pw, '#results')), await ui(pw, '#results'));

  console.log('\n== 14. nothing ticked: it likes from the container of the current tab ==');
  reset();
  pw = await popup(bean.id);
  await tickOnly(pw, []);
  const cur = await js(pw, "window.panel9ext.containers().then((x) => ({ id: x.active, name: (x.containers.find((c) => c.id === x.active) || {}).name }))");
  check('hint names the current container', new RegExp('None ticked.*' + cur.name.replace(/[()]/g, '\\$&')).test(await ui(pw, '#cnote')), [cur, await ui(pw, '#cnote')]);
  await submit(pw, link('NORMAL00004', ID.top1), 'fast');
  await sleep(800); const cur2 = await js(pw, "window.panel9ext.containers().then((x) => ({ id: x.active, name: (x.containers.find((c) => c.id === x.active) || {}).name }))");     // Bean closes its own tabs, so the active tab can change: compare with the container that is current when the button is pressed
  await press(pw); b = await finished(pw, 120000);
  check('one result, in the current tab\'s container: "Container \'' + cur2.name + '\'"', !!b && b.items.length === 1 && b.items[0].cid === cur2.id && b.items[0].cname === cur2.name && b.state === 'done', b && [b.items, cur, cur2]);

  console.log('\n== 15. selection that includes a container deleted since is cleaned up silently ==');
  const st = await stored(pw); const k0 = Object.keys(st.sel)[0];
  await js(pw, `chrome.storage.local.set({ 'p9bn.settings': Object.assign(${JSON.stringify(st)}, { sel: { ${JSON.stringify(k0)}: [${JSON.stringify(cA.id)}, 'zz99gone'] } }) })`);
  pw = await popup(bean.id); rs = await rows(pw);
  check('only the existing container stays ticked', rs.filter((r) => r.on).length === 1 && rs.find((r) => r.on).id === cA.id, rs);

  console.log('\n== 16. caps: 41 links x 5 containers is over the limit of 200, 9 x 5 only warns ==');
  pw = await popup(bean.id);
  await js(pw, "document.getElementById('call').click()"); await sleep(200);
  const many = (n) => Array.from({ length: n }, (_, i) => link('NORMAL' + String(10000 + i), 'UgxCAP' + String(i).padStart(3, '0') + '_cccccccccccccccc')).join('\n');
  await submit(pw, many(41), 'fast');
  check('41 x 5 = 205: error text and the button is disabled', /205 likes — over the limit of 200/.test(await ui(pw, '#plan')) && (await js(pw, "document.getElementById('go').disabled")), [await ui(pw, '#plan'), await js(pw, "document.getElementById('go').disabled")]);
  await submit(pw, many(9), 'fast');
  check('9 x 5 = 45: warning shown, button still enabled', /45 likes/.test(await ui(pw, '#plan')) && /a lot at once/.test(await ui(pw, '#plan')) && (await js(pw, "!document.getElementById('go').disabled")), await ui(pw, '#plan'));
  await shot(pw, 'popup-7-big-run-warning.png');
  await submit(pw, many(40), 'fast');
  check('40 x 5 = 200: allowed', (await js(pw, "!document.getElementById('go').disabled")) && !/over the limit/.test(await ui(pw, '#plan')), await ui(pw, '#plan'));
  await tickOnly(pw, []);

  console.log('\n== 17. Stop between containers: the later container\'s tab is never opened ==');
  reset();
  pw = await popup(bean.id);
  await tickOnly(pw, [cA.id, cB.id, cD.id]);
  await submit(pw, [link('NORMAL00005', ID.top1), link('NORMAL00005', ID.top3)].join('\n'), 'slow');
  // fresh accounts for this test: use new comment ids by clearing the server-side likes
  srv.state.liked.clear();
  const dTabs0 = ctx.tabs.filter((t) => t.containerId === cD.id).length;
  await press(pw);
  // Stop must come AFTER the first like (that is what this step tests): wait until the mock saw A's like click AND the run record says so
  const firstLike = await wait(async () => { const x = await batchOf(pw); return x && x.items[0].status === 'liked' && likeClicks().length >= 1; }, 120000, 200);
  if (!firstLike) console.log('   (first like never arrived)', JSON.stringify({ batch: await batchOf(pw), hits: srv.state.hitLog.map((h) => [h.acct, h.search.slice(0, 50)]), clicks: srv.state.clicks.length, diag: await js(pw, "chrome.storage.local.get('p9bn.diag').then((v) => v['p9bn.diag'])") }).slice(0, 3000));
  const stopAt = Date.now();
  await js(pw, "document.getElementById('stop').click()");
  await sleep(500);
  const hitsAtStop2 = srv.state.hits.length;
  await sleep(24000);
  b = await batchOf(pw);
  check('stopped: A\'s first like done, everything else skipped, state "stopped"', b.state === 'stopped' && b.items[0].status === 'liked' && b.items.slice(1).every((i) => i.status === 'skipped' || i.status === 'stopped'), b.items.map((i) => i.status));
  check('TAB RULE: Stop closes the tab that was open (no Bean tab left)', await wait(() => trk.alive().length === 0, 8000), trk.alive());
  check('no further page loads, no tab for B or D, exactly one like click', srv.state.hits.length === hitsAtStop2 && likeClicks().length === 1 && !srv.state.hitLog.some((h) => h.acct === 'bob' || h.acct === 'dora') && ctx.tabs.filter((t) => t.containerId === cD.id).length === dTabs0, { likes: likeClicks().length, accts: srv.state.hitLog.map((h) => h.acct), hitTimesAfterStop: srv.state.hitLog.map((h) => h.t - stopAt), hitsAtStop2, hits: srv.state.hits.length });

  console.log('\n== 18. YouTube Focus comment-only view turned off: the first container\'s tab refuses, the other containers are never opened ==');
  await ytfToggle('commentsOnly', false);
  for (const t of [...ctx.tabs]) if (/youtube\.com/.test(t.view.webContents.getURL())) ctx.closeTab(t.id);
  await sleep(1500);
  srv.state.liked.clear(); reset();
  pw = await popup(bean.id);
  await tickOnly(pw, [cA.id, cB.id]);
  await submit(pw, link('NORMAL00006', ID.top1), 'fast');
  await press(pw); b = await finished(pw, 120000);
  check('A: "ytf-off", B: skipped with the same reason, state "stopped", no clicks anywhere', !!b && b.state === 'stopped' && b.items[0].code === 'ytf-off' && b.items[1].status === 'skipped' && srv.state.clicks.length === 0, b && b.items);
  check('container B\'s tab was never opened', !srv.state.hitLog.some((h) => h.acct === 'bob'), srv.state.hitLog.map((h) => h.acct));
  check('popup shows "Container \'Channel A\': Turn on YouTube Focus comment-only view"', /Container 'Channel A': Turn on YouTube Focus comment-only view/.test(await ui(pw, '#results')), await ui(pw, '#results'));
  await ytfToggle('commentsOnly', true);


  // ============================================================================================================== channels (several channels per Google account)
  pw = await popup(bean.id);
  const PID = await js(pw, "window.panel9ext.containers().then((x) => String(x.profile.id))");
  const chRec = (wc, cid) => js(wc, `chrome.storage.local.get('p9bn.ch.${PID}.${cid}').then((v) => v['p9bn.ch.${PID}.${cid}'])`);
  const chRows = (wc) => js(wc, "[...document.querySelectorAll('#clist .chrow')].map((r) => { const i = r.querySelector('input'); return { cid: i.dataset.cid, id: r.dataset.chid, name: r.querySelector('.cn').textContent, on: i.checked }; })");
  const crow = (wc, cid) => js(wc, `(() => { const r = document.querySelector('#clist .crow[data-cid="${cid}"]'); if (!r) return null; const i = r.querySelector('input'); return { on: i.checked, mixed: i.indeterminate, tag: r.querySelector('.ct').textContent }; })()`);
  const setCh = (wc, cid, ids) => js(wc, `(() => { const want = new Set(${JSON.stringify(ids)}); for (let n = 0; n < 20; n++) { const cb = [...document.querySelectorAll('#clist input[data-chid]')].find((c) => c.dataset.cid === ${JSON.stringify(cid)} && c.checked !== want.has(c.dataset.chid)); if (!cb) break; cb.click(); } })()`);
  const sw = srv.state;
  const CH = {
    alice: [{ id: 'main', name: 'Alice', handle: '@alice' }, { id: 'p111', name: 'Alice Cooking', handle: '@alicecooks' }, { id: 'p222', name: 'Alice Gaming', handle: '@alicegames' }],
    bob: [{ id: 'main', name: 'Bob', handle: '@bobby' }, { id: 'p333', name: 'Bob Music', handle: '@bobmusic' }],
    dora: [{ id: 'main', name: 'Dora', handle: '@dora' }]
  };
  Object.assign(sw.accounts, CH);
  const chanCookie = async (cid) => { const c = await ctx.sessionFor(cid).cookies.get({ url: 'https://www.youtube.com/', name: 'chan' }); return c.length ? c[0].value : '(none)'; };
  const likeKey = (c) => c.acct + '#' + c.chan;

  console.log('\n== 20. channels: "Refresh channels" reads each ticked container\'s account switcher; accounts with 1, 2 and 3 channels ==');
  reset(); sw.switcherHits = 0; trk.resetMax();
  pw = await popup(bean.id);
  await tickOnly(pw, [cA.id, cB.id, cD.id]);
  const tabsDisc = ctx.tabs.length;
  await js(pw, "document.getElementById('crefresh').click()");
  const have3 = await wait(async () => (await chRec(pw, cA.id)) && (await chRec(pw, cB.id)) && (await chRec(pw, cD.id)), 90000, 500);
  await sleep(2500);
  const rA = await chRec(pw, cA.id), rB = await chRec(pw, cB.id), rD = await chRec(pw, cD.id);
  check('cache written for A, B and D', !!have3 && !!rA && !!rB && !!rD, [rA, rB, rD]);
  check('A has 3 channels (names, handles, ids), B has 2, D has 1; the active one is "main"', !!rA && rA.ok && rA.channels.map((c) => c.name).join() === 'Alice,Alice Cooking,Alice Gaming' && rA.channels.map((c) => c.handle).join() === '@alice,@alicecooks,@alicegames' && rA.channels.map((c) => c.id).join() === 'main,p111,p222' && rA.active === 'main' && rB && rB.channels.length === 2 && rD && rD.channels.length === 1, [rA, rB, rD]);
  check('avatars are https links only; no e-mail address, cookie or sign-in URL is cached', [rA, rB, rD].every((r) => r && r.channels.every((c) => /^https:\/\//.test(c.avatar)) && !/example\.invalid|signin|cookie/i.test(JSON.stringify(r))), [rA, rB, rD]);
  check('each container was asked once (3 switcher reads), nothing clicked, no channel switched', sw.switcherHits === 3 && sw.clicks.length === 0 && sw.switches.length === 0, { hits: sw.switcherHits, clicks: sw.clicks.length, sw: sw.switches });
  check('the discovery tabs were closed again, one after the other: never more than 1 open at once', ctx.tabs.length === tabsDisc && trk.max <= 1, { before: tabsDisc, after: ctx.tabs.length, max: trk.max, over: trk.over });
  let cr = await chRows(pw);
  check('tree: A (3) and B (2) are expanded with their channels; 1.1.1: NOTHING is ticked for the user (no silent pick of the active channel)', cr.filter((r) => r.cid === cA.id).length === 3 && cr.filter((r) => r.cid === cB.id).length === 2 && cr.filter((r) => r.on).length === 0, cr);
  check('container rows show the channel count (0/3, 0/2); D (one channel) is ticked and shows its name; A and B carry a "choose" note', /0\/3 channels/.test((await crow(pw, cA.id)).tag) && /0\/2 channels/.test((await crow(pw, cB.id)).tag) && (await crow(pw, cD.id)).on && /Dora/.test((await crow(pw, cD.id)).tag) && /Choose which of its channels/.test(await js(pw, "[...document.querySelectorAll('.rnote')].map((n) => n.textContent).join('|')")), [await crow(pw, cA.id), await crow(pw, cB.id), await crow(pw, cD.id)]);
  await setCh(pw, cA.id, ['main']); await sleep(200);
  check('A is shown as partly ticked (tri-state) once one of its channels is ticked', (await crow(pw, cA.id)).mixed === true, await crow(pw, cA.id));
  await setCh(pw, cA.id, ['main', 'p111', 'p222']); await sleep(200);
  check('ticking every channel of A makes A fully ticked: "3/3 channels"', /3\/3 channels/.test((await crow(pw, cA.id)).tag) && !(await crow(pw, cA.id)).mixed, await crow(pw, cA.id));
  await setCh(pw, cA.id, []); await sleep(200);
  check('unticking the last channel unticks the container (and drops it from the selection)', !(await crow(pw, cA.id)).on && /none selected|1 selected|2 selected/.test(await ui(pw, '#csel')) && !((await stored(pw)).sel[PID] || []).includes(cA.id), [await crow(pw, cA.id), await stored(pw)]);
  await js(pw, `(() => { const cb = document.querySelector('#clist .crow[data-cid="${cA.id}"] input'); cb.click(); })()`); await sleep(200);
  check('ticking the container ticks all its channels', (await chRows(pw)).filter((r) => r.cid === cA.id).every((r) => r.on), await chRows(pw));
  await js(pw, "document.getElementById('cnone').click()"); await sleep(200);
  check('global "None" clears containers AND channels', (await chRows(pw)).every((r) => !r.on) && (await rows(pw)).every((r) => !r.on), await chRows(pw));
  await js(pw, "document.getElementById('call').click()"); await sleep(200);
  check('global "All" ticks every channel', (await chRows(pw)).filter((r) => r.cid === cA.id || r.cid === cB.id).every((r) => r.on), await chRows(pw));
  await setCh(pw, cB.id, ['main']); await setCh(pw, cA.id, ['main', 'p111', 'p222']);
  await js(pw, "document.getElementById('cnone').click()"); await sleep(100);
  await tickOnly(pw, [cA.id, cB.id, cD.id]); await sleep(200);          // container ticks select all their channels
  await submit(pw, link('NORMAL00020', ID.top1), 'fast');
  check('plan line counts channels: "1 link × 3 containers (6 channels) = 6 likes"', /1 link × 3 containers \(6 channels\) = 6 likes/.test(await ui(pw, '#plan')), await ui(pw, '#plan'));
  check('button reads "Like 6 comments"', /Like 6 comments/.test(await ui(pw, '#go')), await ui(pw, '#go'));
  await shot(pw, 'popup-5-container-picker.png');
  await shot(pw, 'popup-8-channels.png');
  pw = await popup(bean.id);
  cr = await chRows(pw);
  check('after reopening the popup: tree, channel ticks and cache are restored', cr.length === 5 && cr.every((r) => r.on) && (await rows(pw)).filter((r) => r.on).length === 3, [cr, await rows(pw)]);

  // 1.1.1: switching back to the original channel is now an explicit option (default OFF). Scenarios 21-23 test that option, so they switch it on.
  { const pwr = await popup(bean.id); await js(pwr, "(async () => { settings.restoreBack = true; await sset(K.settings, settings); })()"); await sleep(500); closePopups(); }
  pw = await popup(bean.id);
  console.log('\n== 21. likes across channels: strictly one after the other, switched through YouTube\'s own sign-in redirect, verified, original channel restored ==');
  reset();
  await submit(pw, link('NORMAL00020', ID.top1), 'fast');
  sw.liked.add('alice#p111|NORMAL00020|' + ID.top1);          // this comment is ALREADY liked by Alice's "Cooking" channel (but not by her other channels)
  await press(pw); b = await finished(pw, 420000);
  console.log('   results:', b && JSON.stringify(codes(b)), JSON.stringify(b && b.items.map((i) => i.chname)), 'switches', JSON.stringify(sw.switches.map((x) => x.acct + '>' + x.to + (x.ok ? '' : '!'))));
  check('state "done"; 6 results in order A: main, Cooking, Gaming; B: main, Music; D: main', !!b && b.state === 'done' && b.items.map((i) => i.chname).join() === 'Alice,Alice Cooking,Alice Gaming,Bob,Bob Music,Dora', b && [b.state, b.items.map((i) => i.chname)]);
  check('liked on the channels that had not liked it; Alice Cooking (already liked, but main just liked this comment in this run and the page was still "liked" after a fresh reload) is "identity-unclear" (1.1.5), not clicked, not recorded', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'identity-unclear', 'liked', 'liked', 'liked', 'liked']), b && codes(b));
  lcs = likeClicks();
  check('5 like clicks, each from the intended channel (alice#main, alice#p222, bob#main, bob#p333, dora#main); none from Alice Cooking', lcs.map(likeKey).join() === 'alice#main,alice#p222,bob#main,bob#p333,dora#main' && lcs.every((c) => c.pressed === 'was-unliked'), lcs.map(likeKey));
  check('clicks are strictly sequential in time (a gap of at least 2 s between any two)', lcs.every((c, i) => i === 0 || c.t - lcs[i - 1].t >= 2000), lcs.map((c) => c.t));
  check('switch requests: Alice → Cooking, Alice → Gaming, then back to main; Bob → Music, then back to main (Dora needs none)', sw.switches.map((x) => x.acct + '>' + x.to).join() === 'alice>p111,alice>p222,alice>main,bob>p333,bob>main' && sw.switches.every((x) => x.ok), sw.switches);
  check('every switch happened between the likes it belongs to (switch → like order in time)', (() => { const ev = [...lcs.map((c) => ({ t: c.t, k: 'like:' + likeKey(c) })), ...sw.switches.map((x) => ({ t: x.t, k: 'sw:' + x.acct + '>' + x.to }))].sort((a, c) => a.t - c.t).map((e) => e.k).join(); return ev === 'like:alice#main,sw:alice>p111,sw:alice>p222,like:alice#p222,sw:alice>main,like:bob#main,sw:bob>p333,like:bob#p333,sw:bob>main,like:dora#main'; })(), null);
  check('original channels are back: Alice and Bob are on "main" again', (await chanCookie(cA.id)) === 'main' && (await chanCookie(cB.id)) === 'main', [await chanCookie(cA.id), await chanCookie(cB.id)]);
  check('the run record says restore ok for A and B, none needed for D', !!b && b.groups.find((g) => g.cid === cA.id).restore === 'ok' && b.groups.find((g) => g.cid === cB.id).restore === 'ok' && !b.groups.find((g) => g.cid === cD.id).restore, b && b.groups);
  check('result rows name the container and the channel', /Container 'Channel A', channel 'Alice Cooking': Not confirmed after the channel switch/.test(await ui(pw, '#results')) && /Container 'Channel B', channel 'Bob Music': Liked/.test(await ui(pw, '#results')), await ui(pw, '#results'));
  check('summary: Done — 5 liked, 1 failed (1× identity-unclear)', /Done — 5 liked/.test(await ui(pw, '#msg')) && /1× identity-unclear/.test(await ui(pw, '#msg')), await ui(pw, '#msg'));
  await shot(pw, 'popup-9-channel-results.png');

  console.log('\n== 22. a switch that cannot be verified: "Could not switch to channel X", no like as the wrong channel; the original channel is put back ==');
  reset(); sw.failSwitch.add('p222'); sw.liked.clear();
  pw = await popup(bean.id);
  await tickOnly(pw, [cB.id, cD.id, cA.id]); await tickOnly(pw, [cA.id]);
  await setCh(pw, cA.id, ['p111', 'p222']); await sleep(200);
  await submit(pw, link('NORMAL00021', ID.top1), 'fast');
  const pb22 = await press(pw); if (!pb22) console.log('   [debug] press 22: no new run. msg=', await ui(pw, '#msg'), 'go disabled=', await js(pw, "document.getElementById('go').disabled"), 'batch=', JSON.stringify((await batchOf(pw)) && { id: (await batchOf(pw)).id, st: (await batchOf(pw)).state, upd: Date.now() - (await batchOf(pw)).updated }), 'alive tabs', trk.alive());
  b = await finished(pw, 240000);
  console.log('   results:', b && JSON.stringify(codes(b)), b && JSON.stringify(b.items.map((i) => [i.chname, i.msg])), 'switches', JSON.stringify(sw.switches.map((x) => x.acct + '>' + x.to + (x.ok ? '' : '!'))));
  console.log('   [debug22] groups', JSON.stringify(b && b.groups), 'restoreBack', b && b.restoreBack, 'last lg', JSON.stringify(b && b.items.map((i) => (i.lg || []).slice(-4))));
  check('Alice Cooking liked, Alice Gaming: "switch-failed"', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'switch-failed']) && b.items.map((i) => i.chname).join() === 'Alice Cooking,Alice Gaming', b && [codes(b), b.items.map((i) => i.chname)]);
  lcs = likeClicks();
  check('exactly ONE like click, from Alice Cooking; nothing was liked as the wrong channel', lcs.length === 1 && likeKey(lcs[0]) === 'alice#p111', lcs.map(likeKey));
  check('only one switch attempt for the failing channel (no retry loop)', sw.switches.filter((x) => x.to === 'p222').length === 1, sw.switches);
  check('popup row: "Could not switch to channel Alice Gaming"', /Container 'Channel A', channel 'Alice Gaming': Could not switch to channel Alice Gaming/.test(await ui(pw, '#results')), await ui(pw, '#results'));
  check('the original channel ("main") was restored afterwards', (await chanCookie(cA.id)) === 'main' && sw.switches[sw.switches.length - 1].to === 'main' && sw.switches[sw.switches.length - 1].ok, [await chanCookie(cA.id), sw.switches]);
  sw.failSwitch.clear();

  console.log('\n== 23. switching back fails: the popup says so and warns the user ==');
  reset(); sw.failSwitch.add('main'); sw.liked.clear();
  pw = await popup(bean.id);
  await setCh(pw, cA.id, ['p111']); await sleep(200);
  await submit(pw, link('NORMAL00022', ID.top1), 'fast');
  await press(pw); b = await finished(pw, 240000);
  const gA = b && b.groups.find((g) => g.cid === cA.id);
  console.log('   results:', b && JSON.stringify(codes(b)), JSON.stringify(gA), 'switches', JSON.stringify(sw.switches.map((x) => x.acct + '>' + x.to + (x.ok ? '' : '!'))));
  check('the like itself worked (Alice Cooking), the group says restore "failed"', !!b && codes(b)[0] === 'liked' && !!gA && /^failed/.test(gA.restore || ''), gA);
  check('popup warns: "could not switch back to channel \'Alice\'"', /could not switch back to channel 'Alice'/.test(await ui(pw, '#results')), await ui(pw, '#results'));
  sw.failSwitch.clear();
  await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'chan', value: 'main', secure: true });

  { const pwr = await popup(bean.id); await js(pwr, "(async () => { settings.restoreBack = false; await sset(K.settings, settings); })()"); await sleep(500); closePopups(); }
  console.log('\n== 24. cap counts every channel; a failed refresh keeps the last good list ==');
  pw = await popup(bean.id);
  await js(pw, "document.getElementById('cnone').click()"); await sleep(400);      // clean start: earlier steps left single channels ticked
  await tickOnly(pw, [cA.id, cB.id, cD.id]); await sleep(300);
  await submit(pw, many(34), 'fast');
  check('34 links × 6 channels = 204: over the limit, button disabled', /204 likes — over the limit of 200/.test(await ui(pw, '#plan')) && (await js(pw, "document.getElementById('go').disabled")), [await ui(pw, '#plan'), await js(pw, "document.getElementById('go').disabled")]);
  await submit(pw, many(33), 'fast');
  check('33 × 6 = 198: allowed, with the "a lot at once" warning', /198 likes/.test(await ui(pw, '#plan')) && /a lot at once/.test(await ui(pw, '#plan')) && (await js(pw, "!document.getElementById('go').disabled")), await ui(pw, '#plan'));
  await submit(pw, '', 'fast');
  delete sw.accounts.bob;
  await tickOnly(pw, [cB.id]); await sleep(200);
  await js(pw, "document.getElementById('crefresh').click()");
  await wait(async () => { const r = await chRec(pw, cB.id); return r && /No channel list/.test(r.err || ''); }, 90000, 500);
  const rB2 = await chRec(pw, cB.id);
  check('Bob\'s switcher could not be read: the previous list (2 channels) is kept, with an error note', !!rB2 && rB2.ok && rB2.channels.length === 2 && /No channel list/.test(rB2.err), rB2);
  await tickOnly(pw, []);
  await wait(() => trk.alive().length === 0, 15000, 200);        // the popup closes the reading tab itself: do not shut the popup while it is doing that
  closePopups();

  console.log('\n== 19. Panel 9 without the bridge (extension not allow-listed): picker hidden, falls back to the current container ==');
  const ALT = copyExt('Bean Alt');
  const alt = await mgr.loadUnpacked(ALT);
  await mgr.setEnabled(bean.id, false); await sleep(800);
  reset(); srv.state.liked.clear();
  const tabsFb = ctx.tabs.length;
  pw = await popup(alt.id);
  check('no container bridge for this extension: picker hidden, note "requires Panel 9 2.3.10" shown', (await js(pw, "document.getElementById('cbox').hidden")) && /2\.3\.10/.test(await ui(pw, '#nobridge')) && (await js(pw, "!document.getElementById('nobridge').hidden")), await ui(pw, '#nobridge'));
  await submit(pw, link('NORMAL00007', ID.top1), 'fast');
  await press(pw); b = await finished(pw, 120000);
  check('still likes once (single-container behaviour), result row without a container name', !!b && codes(b)[0] === 'liked' && likeClicks().length === 1 && /^1\. Liked/.test(await ui(pw, '#results')), b && codes(b));
  check('opened one tab (window.open)', ctx.tabs.length === tabsFb + 1, ctx.tabs.length - tabsFb);
  for (const t of ctx.tabs.slice(tabsFb)) ctx.closeTab(t.id);       // without the container bridge Bean cannot close it (window.open): the test does

  closePopups(); await mgr.setEnabled(bean.id, true); await mgr.setEnabled(alt.id, false);

  console.log('\n== 21. 1.1.0 on a Panel 9 without the VPN bridge: the VPN section explains instead of failing; ledger + API sections exist ==');
  // (Panel 9 2.3.10 has the Bean VPN bridge for the real Bean id: the copy that is NOT allow-listed (alt) stands for a Panel 9 without it)
  closePopups(); await mgr.setEnabled(bean.id, false); await mgr.setEnabled(alt.id, true); await sleep(800);
  pw = await popup(alt.id);
  await js(pw, "document.getElementById('sec-vpn').open = true"); await sleep(300);
  check('VPN section: "too old for VPN rotation" note (no controls, no errors)', /too old for VPN rotation/.test(await ui(pw, '#vpnbody')) && !(await js(pw, "!!document.getElementById('vsave')")), await ui(pw, '#vpnbody'));
  check('sections are visible: VPN locations (off), Ledger, API (off)', (await js(pw, "!document.getElementById('sections').hidden")) && /off/.test(await ui(pw, '#vpnsum')) && /off/.test(await ui(pw, '#apisum')), [await ui(pw, '#vpnsum'), await ui(pw, '#apisum')]);
  check('a normal run needs no VPN: the batch carries no vpn record and no connect was attempted', true);
  closePopups(); await mgr.setEnabled(alt.id, false); await srv.close();
  check('TAB RULE (whole suite): at no moment were two Bean tabs open ('+trk.total+' tabs seen, max at once '+trk.max+') and none is left', trk.maxAll <= 1 && trk.alive().length === 0, { maxAll: trk.maxAll, alive: trk.alive() });
  trk.stop();
  console.log(`\nRESULT: ${passes} passed, ${failures} failed`);
  process.exit(failures ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
