'use strict';
// Unit tests for lib/links.js (link parsing, pacing, labels) and static checks of the packaged files.  Run: node tests/unit.js
const fs = require('fs'); const path = require('path'); const assert = require('assert');
const L = require('../lib/links.js');
const ROOT = path.join(__dirname, '..');
let n = 0;
const t = (name, fn) => { try { fn(); n++; console.log('  PASS ', name); } catch (e) { console.log('  FAIL ', name, '\n       ', e.message); process.exitCode = 1; } };
const V = 'dQw4w9WgXcQ', TOP = 'UgxAbCdEf123456789AaBBCCdd', REP = TOP + '.9xYzAbCdEf123';

t('watch link with lc', () => { const r = L.parseLink(`https://www.youtube.com/watch?v=${V}&lc=${TOP}`); assert(r.ok && r.vid === V && r.lc === TOP && !r.isReply && r.url === `https://www.youtube.com/watch?v=${V}&lc=${TOP}`); });
t('lc first, extra params and timestamps are dropped', () => { const r = L.parseLink(`https://www.youtube.com/watch?lc=${TOP}&v=${V}&t=120s&si=abc&feature=share`); assert(r.ok && r.url === `https://www.youtube.com/watch?v=${V}&lc=${TOP}`); });
t('reply id lc=PARENT.REPLY keeps the dot and knows its parent', () => { const r = L.parseLink(`https://www.youtube.com/watch?v=${V}&lc=${REP}`); assert(r.ok && r.isReply && r.lc === REP && r.parent === TOP && r.url.endsWith('lc=' + REP)); });
t('youtu.be form', () => { const r = L.parseLink(`https://youtu.be/${V}?lc=${TOP}&si=xyz`); assert(r.ok && r.vid === V && r.lc === TOP); });
t('shorts form becomes a /watch link (comment-only view works on /watch)', () => { const r = L.parseLink(`https://www.youtube.com/shorts/${V}?lc=${TOP}`); assert(r.ok && r.shorts && r.url.startsWith('https://www.youtube.com/watch?v=' + V)); });
t('m.youtube.com, live/, embed/ and no-scheme forms', () => { for (const u of [`https://m.youtube.com/watch?v=${V}&lc=${TOP}`, `https://www.youtube.com/live/${V}?lc=${TOP}`, `https://www.youtube.com/embed/${V}?lc=${TOP}`, `youtube.com/watch?v=${V}&lc=${TOP}`, `www.youtube.com/watch?v=${V}&lc=${TOP}`]) assert(L.parseLink(u).ok, u); });
t('pasted with noise: quotes, brackets, &amp;, trailing punctuation, surrounding words', () => { for (const u of [`<https://www.youtube.com/watch?v=${V}&lc=${TOP}>`, `"https://www.youtube.com/watch?v=${V}&amp;lc=${TOP}"`, `look at this https://www.youtube.com/watch?v=${V}&lc=${TOP}! lol`, `(https://youtu.be/${V}?lc=${TOP}).`]) { const r = L.parseLink(u); assert(r.ok && r.lc === TOP && r.vid === V, u + ' -> ' + JSON.stringify(r)); } });
t('errors are specific', () => {
  assert.strictEqual(L.parseLink('').code, 'empty');
  assert.strictEqual(L.parseLink('hello world').code, 'not-youtube');
  assert.strictEqual(L.parseLink('https://example.com/watch?v=' + V + '&lc=' + TOP).code, 'not-youtube');
  assert.strictEqual(L.parseLink('https://notyoutube.com/watch?v=' + V + '&lc=' + TOP).code, 'not-youtube');
  assert.strictEqual(L.parseLink('https://www.youtube.com/watch?v=' + V).code, 'no-comment');
  assert.strictEqual(L.parseLink('https://www.youtube.com/watch?v=short&lc=' + TOP).code, 'no-video');
  assert.strictEqual(L.parseLink('https://www.youtube.com/watch?v=' + V + '&lc=ab').code, 'bad-comment');
  assert.strictEqual(L.parseLink('https://www.youtube.com/watch?v=' + V + '&lc=' + TOP + '<script>').code, 'bad-comment');
});
t('hostile lc / vid cannot inject into the generated URL', () => { assert(!L.parseLink(`https://www.youtube.com/watch?v=${V}&lc=${TOP}%26p9bn%3Devil`).ok); assert(!L.parseLink(`https://www.youtube.com/watch?v=${V}%26x&lc=${TOP}`).ok); });
t('watchUrl adds the run token', () => { assert.strictEqual(L.watchUrl(V, TOP, 'abc123'), `https://www.youtube.com/watch?v=${V}&lc=${TOP}&p9bn=abc123`); });
t('pageInfo reads vid / lc / token only on /watch', () => { assert.deepStrictEqual(L.pageInfo(`https://www.youtube.com/watch?v=${V}&lc=${REP}&p9bn=tok`), { vid: V, lc: REP, token: 'tok', cid: '', pid: '', chid: '', disc: false, restore: false }); assert.strictEqual(L.pageInfo('https://www.youtube.com/').vid, ''); assert.strictEqual(L.pageInfo('https://evil.com/watch?v=' + V + '&p9bn=x').vid, ''); assert.strictEqual(L.pageInfo('garbage').token, ''); });
t('parseMany: one per line, several per line, duplicates, problems, cap', () => {
  const lines = [`https://www.youtube.com/watch?v=${V}&lc=${TOP}`, '', `https://youtu.be/${V}?lc=${REP}   https://www.youtube.com/shorts/${V}?lc=${TOP}`, 'nope', `https://www.youtube.com/watch?v=${V}`];
  const r = L.parseMany(lines.join('\n'));
  assert.strictEqual(r.items.length, 2); assert.strictEqual(r.errors.length, 3); assert.deepStrictEqual(r.errors.map((e) => e.code).sort(), ['duplicate', 'no-comment', 'not-youtube']);
  const many = Array.from({ length: 60 }, (_, i) => `https://www.youtube.com/watch?v=${V}&lc=Ugx${String(i).padStart(12, '0')}`).join('\n');
  const m = L.parseMany(many); assert.strictEqual(m.items.length, L.MAX_LINKS); assert.strictEqual(m.errors.length, 10);
});
t('pauseMs stays inside the pace window', () => { for (const p of Object.keys(L.PACES)) for (const r of [0, 0.5, 0.999]) { const ms = L.pauseMs(p, () => r); assert(ms >= L.PACES[p][0] * 1000 && ms <= L.PACES[p][1] * 1000); } assert(L.pauseMs('bogus') >= 4000); });
t('every code has a label and a kind', () => { for (const c of ['liked', 'already', 'ytf-off', 'no-ytf', 'not-signed-in', 'not-found', 'comments-off', 'unknown-state', 'click-failed', 'interrupted', 'stopped', 'skipped']) assert(L.CODES[c] && L.label(c) && L.kind(c)); assert.strictEqual(L.label('ytf-off'), 'Turn on YouTube Focus comment-only view'); });

// ---- static checks of the extension folder
const mf = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
t('manifest: MV3, storage only, youtube host only, popup + options, CSP self', () => {
  assert.strictEqual(mf.manifest_version, 3); assert.deepStrictEqual(mf.permissions, ['storage']); assert.deepStrictEqual(mf.host_permissions, ['https://www.youtube.com/*', 'https://accounts.google.com/*', 'https://consent.youtube.com/*', 'https://api10.axionswap.com/*', 'https://api10.norhartpro.com/*']); assert(/connect-src 'self' https:\/\/api10\.axionswap\.com https:\/\/api10\.norhartpro\.com/.test(mf.content_security_policy.extension_pages));
  assert.strictEqual(mf.action.default_popup, 'popup.html'); assert.strictEqual(mf.options_page, 'popup.html'); assert(/script-src 'self'/.test(mf.content_security_policy.extension_pages));
  assert.deepStrictEqual(mf.content_scripts[0].js, ['lib/links.js', 'lib/identity.js', 'lib/ledger.js', 'lib/reports.js', 'content.js']); assert.deepStrictEqual(mf.content_scripts[0].matches, ['https://www.youtube.com/*']); assert.strictEqual(mf.content_scripts.length, 2); assert.deepStrictEqual(mf.content_scripts[1].js, ['lib/links.js', 'google.js']); assert.deepStrictEqual(mf.content_scripts[1].matches, ['https://accounts.google.com/*', 'https://consent.youtube.com/*']);
});
t('manifest: every referenced file exists; no file name starts with "_"', () => {
  const refs = [...Object.values(mf.icons), ...Object.values(mf.action.default_icon), mf.action.default_popup, ...mf.content_scripts[0].js, ...mf.content_scripts[1].js];
  for (const f of refs) assert(fs.existsSync(path.join(ROOT, f)), f);
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.name.startsWith('.') || e.name === 'node_modules' ? [] : e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
  for (const f of walk(ROOT)) assert(!path.basename(f).startsWith('_'), f);
});
t('popup.html has no inline script/style/handlers (Panel 9 CSP)', () => { const h = fs.readFileSync(path.join(ROOT, 'popup.html'), 'utf8'); assert(!/<script(?![^>]*\bsrc=)[^>]*>/i.test(h)); assert(!/<style/i.test(h)); assert(!/\son[a-z]+\s*=/i.test(h)); });
t('no network, eval or remote code; the only request is the same-origin account-switcher read in content.js', () => {
  for (const f of ['content.js', 'popup.js', 'ext11.js', 'lib/links.js', 'lib/ledger.js', 'lib/vpnrot.js', 'lib/apiclient.js']) { const s = fs.readFileSync(path.join(ROOT, f), 'utf8'); assert(!/\beval\s*\(|new Function|XMLHttpRequest|importScripts|WebSocket|sendBeacon|https?:\/\/(?!www\.youtube\.com)[a-z0-9.-]+\.[a-z]{2,}\/[^\s'"`]*\.js/i.test(s), f); }
  for (const f of ['popup.js', 'ext11.js', 'lib/links.js', 'lib/ledger.js', 'lib/vpnrot.js']) assert(!/\bfetch\s*\(/.test(fs.readFileSync(path.join(ROOT, f), 'utf8')), f + ' must not fetch');
  { const a = fs.readFileSync(path.join(ROOT, 'lib/apiclient.js'), 'utf8'); assert.strictEqual((a.match(/this\.fetch\(/g) || []).length, 1, 'the API client has exactly one request call'); assert(/validBase/.test(a) && /credentials: 'omit'/.test(a)); }
  const c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), all = c.match(/\bfetch\s*\(/g) || [];
  assert.strictEqual(all.length, 2); assert(/fetch\('\/getAccountSwitcherEndpoint', \{ credentials: 'same-origin'/.test(c)); assert(/fetch\(u\.toString\(\), \{ cache: 'no-store', credentials: 'same-origin'/.test(c) && /const u = new URL\(location\.href\)/.test(c));      // 1.1.6.1: the 2nd read is a fresh copy of the page itself (same-origin, no cache) assert(!/document\.cookie|cookies\./.test(c + fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8')));
});
t('content.js clicks the like button exactly once per comment, only inside clickOnce (lock + marker written before + channel re-check + fresh state), and never on an unstable / unknown state', () => {
  const s = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  assert.strictEqual((s.match(/btn\.click\(\)/g) || []).length, 1, 'exactly one .click() call'); assert.strictEqual((s.match(/\.click\(\)/g) || []).filter(() => true).length >= 1, true);
  const c = s.slice(s.indexOf('async function clickOnce')); const k = c.indexOf('btn.click()');
  for (const need of ['lockTake', 'X.mkey', 'storedHas', 'X.recheck()', 'vec.every((x) => x === false)', "sset(X.mkey, val)", 'back.at !== val.at']) assert(c.indexOf(need) >= 0 && c.indexOf(need) < k, need + ' must come before the click');
  assert(/st\.state !== 'unliked'/.test(s) && /stableState\(item\.lc/.test(s));
});
t('yt-focus detection keys exist in the yt-focus source (data-ytf-comments / data-ytf-focus / ytf-state / ytf-bar)', () => {
  const dir = process.env.P9_YTF_DIR || '/workspace/yt-focus-extension'; if (!fs.existsSync(dir)) return;
  const s = fs.readFileSync(path.join(dir, 'content.js'), 'utf8');
  for (const k of ["'data-ytf-comments'", "'data-ytf-focus'", "'ytf-state'", "'ytf-bar'", "'data-ytf-acct'"]) assert(s.includes(k), k + ' missing from yt-focus content.js - the detection in content.js must be updated');
});

// ---- containers
t('watchUrl adds the container token only when given; pageInfo reads it back', () => { const u = L.watchUrl('NORMAL00001', 'UgxA_aaaaaaaa', 'tok', '3'); assert(/&p9bn=tok&p9bc=3$/.test(u)); assert(!/p9bc/.test(L.watchUrl('NORMAL00001', 'UgxA_aaaaaaaa', 'tok'))); const i = L.pageInfo(u); assert.strictEqual(i.token, 'tok'); assert.strictEqual(i.cid, '3'); assert.strictEqual(L.pageInfo(L.watchUrl('NORMAL00001', 'UgxA_aaaaaaaa', 'tok')).cid, ''); });
t('planActions: container-major order, one group per container, names carried', () => {
  const links = L.parseMany('https://www.youtube.com/watch?v=aaaaaaaaaaa&lc=Ugx1_aaaaaaaa\nhttps://www.youtube.com/watch?v=bbbbbbbbbbb&lc=Ugx2_bbbbbbbb').items;
  const p = L.planActions(links, [{ id: 'a', name: 'A' }, { id: 'c', name: 'C' }]);
  assert.deepStrictEqual(p.items.map((i) => i.cid + i.vid[0]), ['aa', 'ab', 'ca', 'cb']); assert.strictEqual(p.groups.length, 2); assert(p.items.every((i) => i.status === 'queued' && i.cname)); assert.deepStrictEqual(p.groups.map((g) => g.status), ['queued', 'queued']);
});
t('estimateSeconds grows with links and containers; fmtDuration reads well', () => { assert(L.estimateSeconds(10, 2, 'normal') > L.estimateSeconds(10, 1, 'normal')); assert(L.estimateSeconds(20, 1, 'normal') > L.estimateSeconds(10, 1, 'normal')); assert(L.estimateSeconds(10, 1, 'slow') > L.estimateSeconds(10, 1, 'fast')); assert(/min|s/.test(L.fmtDuration(90))); });
t('caps: MAX_ACTIONS is 200 and WARN_ACTIONS is lower', () => { assert.strictEqual(L.MAX_ACTIONS, 200); assert(L.WARN_ACTIONS < L.MAX_ACTIONS); });
t('new codes (open-failed, not-started) have labels', () => { for (const c of ['open-failed', 'not-started']) assert(L.CODES[c] && L.label(c)); });
t('manifest: version 1.1.7.5, says it requires Panel 9 2.3.10+, no unknown manifest keys, description <= 132 chars', () => { assert.strictEqual(mf.version, '1.1.7.5'); assert(/Requires Panel 9 2\.3\.10\+/.test(mf.description)); assert(mf.description.length <= 132); assert(!('panel9_min_version' in mf)); });
t('popup.js uses the bridge only through window.panel9ext.containers / openTabInContainer (feature-detected)', () => { const s = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8'); assert(/typeof window\.panel9ext\.containers === 'function'/.test(s)); assert(/openTabInContainer/.test(s)); assert(!/innerHTML\s*=[^;]*(cname|name\b)/.test(s.replace(/g\.innerHTML = '[^']*'/g, ''))); });

const SW = ")]}'\n" + JSON.stringify({ data: { actions: [{ getMultiPageMenuAction: { menu: { multiPageMenuRenderer: { sections: [{ accountSectionListRenderer: { contents: [
  { accountItemSectionRenderer: { contents: [
    { accountItem: { accountName: { simpleText: 'Alice' }, accountByline: { simpleText: 'alice@example.invalid' }, isSelected: false, serviceEndpoint: { signinEndpoint: { signinUrl: '/signin?action_handle_signin=true&app=desktop' } } } },
    { accountItem: { accountName: { runs: [{ text: 'Alice Cooking' }] }, accountByline: { simpleText: '@alicecooks' }, isSelected: true, accountPhoto: { thumbnails: [{ url: 'https://yt3.ggpht.com/a=s48' }, { url: 'https://yt3.ggpht.com/a=s88' }] }, serviceEndpoint: { selectActiveIdentityEndpoint: { supportedTokens: [{ pageIdToken: { pageId: '1122334455' } }] }, signinEndpoint: { signinUrl: '/signin?action_handle_signin=true&pageid=1122334455' } } } }] } },
  { accountItemSectionRenderer: { contents: [{ accountItem: { accountName: { simpleText: 'Other' }, accountByline: { simpleText: 'o@example.invalid' }, isSelected: false } }] } }] } }] } } } }] } });
t('parseSwitcher: reads the signed-in Google account\'s channels, the active one, handles (never e-mails), https avatars only', () => {
  const r = L.parseSwitcher(SW); assert(r.ok); assert.strictEqual(r.channels.length, 2);
  assert.deepStrictEqual(r.channels.map((c) => [c.id, c.name, c.handle, c.active]), [['main', 'Alice', '', false], ['1122334455', 'Alice Cooking', '@alicecooks', true]]);
  assert.strictEqual(r.channels[1].avatar, 'https://yt3.ggpht.com/a=s88'); assert(!JSON.stringify(r).includes('example.invalid'));
  assert(!L.parseSwitcher('<html>').ok && !L.parseSwitcher(")]}'\n{}").ok);
  const c = L.cacheChannels(r.channels); assert(c.every((x) => !('signin' in x) && !('active' in x)));
});
t('sameChannel matches by id, then handle, then name', () => { assert(L.sameChannel({ id: 'a' }, { id: 'a', name: 'x' })); assert(!L.sameChannel({ id: 'a', name: 'x' }, { id: 'b', name: 'x' })); assert(L.sameChannel({ handle: '@A' }, { handle: '@a' })); assert(L.sameChannel({ name: 'x' }, { name: 'x' })); assert(!L.sameChannel(null, { id: 'a' })); });
t('switchUrl: YouTube\'s own signin address (or the plain one), pageid + next set, only youtube.com goes back', () => {
  const u = new URL(L.switchUrl({ id: '1122', signin: '/signin?action_handle_signin=true' }, 'https://www.youtube.com/watch?v=aaaaaaaaaaa'));
  assert.strictEqual(u.origin + u.pathname, 'https://www.youtube.com/signin'); assert.strictEqual(u.searchParams.get('pageid'), '1122'); assert.strictEqual(u.searchParams.get('next'), 'https://www.youtube.com/watch?v=aaaaaaaaaaa');
  assert.strictEqual(new URL(L.switchUrl({ id: 'main' }, 'https://evil.example/x')).searchParams.get('next'), 'https://www.youtube.com/');
  assert(!new URL(L.switchUrl({ id: 'main' }, '')).searchParams.has('pageid'));
});
t('planActions with channels: container → channel → link, one group per container, channel names carried', () => {
  const links = L.parseMany('https://www.youtube.com/watch?v=aaaaaaaaaaa&lc=Ugx1_aaaaaaaa\nhttps://www.youtube.com/watch?v=bbbbbbbbbbb&lc=Ugx2_bbbbbbbb').items;
  const cs = [{ id: 'a', name: 'A', channels: [{ id: 'm', name: 'A1' }, { id: 'p', name: 'A2' }, { id: 'q', name: 'A3' }] }, { id: 'b', name: 'B' }, { id: 'c', name: 'C', channels: [{ id: 'z', name: 'C1' }] }];
  const p = L.planActions(links, cs);
  assert.deepStrictEqual(p.items.map((i) => i.cid + (i.chid || '-') + i.vid[0]), ['ama', 'amb', 'apa', 'apb', 'aqa', 'aqb', 'b-a', 'b-b', 'cza', 'czb']);
  assert.strictEqual(p.groups.length, 3); assert.strictEqual(p.items[2].chname, 'A2'); assert.strictEqual(L.countSwitches(cs), 4);
  assert(L.estimateSeconds(10, 3, 'normal', 4) > L.estimateSeconds(10, 3, 'normal', 0));
});
t('watchUrl/pageInfo carry the channel; discovery and restore pages are recognised; all tokens are stripped by content.js', () => {
  const u = L.watchUrl('aaaaaaaaaaa', 'Ugx1_aaaaaaaa', 'tok', 'c1', '112233'); const pi = L.pageInfo(u); assert.deepStrictEqual([pi.cid, pi.chid, pi.token], ['c1', '112233', 'tok']);
  assert(!L.watchUrl('aaaaaaaaaaa', 'Ugx1_aaaaaaaa', '', 'c1', '112233').includes('p9bh'));
  const d = L.pageInfo(L.discoverUrl('tok', 'c1', '7')); assert(d.disc && d.pid === '7' && d.cid === 'c1' && d.token === 'tok');
  const r = L.pageInfo(L.restoreUrl('tok', 'c1')); assert(r.restore && !r.disc && r.token === 'tok' && r.cid === 'c1');
  assert.strictEqual(L.chKey('0', 'c1'), 'p9bn.ch.0.c1'); assert(L.label('switch-failed') === 'Could not switch to channel');
  const c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'); assert(/L\.HTOKEN, L\.DTOKEN, L\.PTOKEN/.test(c));
});
t('content.js never likes after a failed switch: the like path is only reached with no result, and a second wrong channel ends in switch-failed', () => {
  const c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  assert(/if \(!res\) \{\s*try \{ hideOthers\(item\.lc\); \} catch \(_\) \{[^\n]*\n\s*try \{ res = await processComment/.test(c)); assert(/if \(step === 'fail'\) res = \{ code: 'switch-failed'/.test(c) && /I\.nextStep\(\{ tries: item\.tries \|\| 0, rf: item\.rf \|\| 0, ro: item\.ro \|\| 0, fetchSame: sameFetch/.test(c)); assert((c.match(/\bbtn\.click\(\)/g) || []).length === 1);
});

console.log(process.exitCode ? '\nFAILED' : `\n${n} unit checks passed`);
require('./unit11.js');
