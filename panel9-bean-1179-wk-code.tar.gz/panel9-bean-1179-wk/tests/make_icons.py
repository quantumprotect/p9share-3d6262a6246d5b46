#!/usr/bin/env python3
"""Draws Bean's icon (1.1.5, minimal): a flat Panel 9 indigo tile with ONE white coffee-bean shape and its crease. usage: make_icons.py <extension dir>   (writes icons/icon{16,32,48,128}.png and store-icon-512.png)"""
import sys, math, os
from PIL import Image, ImageDraw
OUT = sys.argv[1]
S = 2048                                   # drawn big, then reduced (anti-aliasing)
def lerp(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))
def draw():
    c0, c1 = (0x3d, 0x4b, 0xdf), (0x5a, 0x55, 0xd2)          # Panel 9's indigo, barely a gradient
    tile = Image.new('RGBA', (S, S)); px = tile.load()
    for y in range(S):
        for x in range(S):
            t = (x + y) / (2 * S); px[x, y] = lerp(c0, c1, t) + (255,)
    mask = Image.new('L', (S, S), 0); ImageDraw.Draw(mask).rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * .225), fill=255)
    cx, cy, rx, ry, rot = S * .5, S * .5, S * .31, S * .225, math.radians(-38)
    def pt(u, v): return (cx + u * math.cos(rot) - v * math.sin(rot), cy + u * math.sin(rot) + v * math.cos(rot))
    d = ImageDraw.Draw(tile)
    d.polygon([pt(rx * math.cos(t), ry * math.sin(t)) for t in [i * math.pi / 180 for i in range(360)]], fill=(255, 255, 255, 255))
    w = S * .05                                              # the crease: one S curve in the tile colour
    for i in range(0, 1201):
        u = (i / 1200 - .5) * 2 * rx * .9; v = math.sin((i / 1200) * math.pi * 2) * ry * .3
        x, y = pt(u, v); d.ellipse([x - w / 2, y - w / 2, x + w / 2, y + w / 2], fill=(0x4a, 0x52, 0xd8, 255))
    out = Image.new('RGBA', (S, S), (0, 0, 0, 0)); out.paste(tile, (0, 0), mask)
    return out
big = draw()
os.makedirs(os.path.join(OUT, 'icons'), exist_ok=True)
for n in (16, 32, 48, 128): big.resize((n, n), Image.LANCZOS).save(os.path.join(OUT, 'icons', 'icon%d.png' % n))
big.resize((512, 512), Image.LANCZOS).save(os.path.join(OUT, 'store-icon-512.png'))
print('icons written to', OUT)
