// Bean 1.1.7.4 unit checks: the 1.1.7.3 server-address change (default api10.axionswap.com, saved old default migrates, custom URLs kept)
const assert = require('assert'); const A = require('../lib/apiclient.js'); const fs = require('fs'), path = require('path'); let p = 0, f = 0;
const ok = (n, c) => { if (c) p++; else { f++; console.log('FAIL ' + n); } };
ok('default base is api10.axionswap.com', A.DEFAULT_BASE === 'https://api10.axionswap.com');
ok('empty / missing base -> default', A.effBase('') === A.DEFAULT_BASE && A.effBase(undefined) === A.DEFAULT_BASE && A.effBase(null) === A.DEFAULT_BASE);
ok('saved old default (with / without slash, any case) -> new default', ['https://api10.norhartpro.com', 'https://api10.norhartpro.com/', 'HTTPS://API10.NORHARTPRO.COM', ' https://api10.norhartpro.com '].every((b) => A.effBase(b) === A.DEFAULT_BASE));
ok('a custom server URL is kept', A.effBase('http://127.0.0.1:5010') === 'http://127.0.0.1:5010' && A.effBase('https://example.org') === 'https://example.org' && A.effBase('https://api10.norhartpro.com.evil.com') === 'https://api10.norhartpro.com.evil.com');
ok('a client built with no base uses the new default', new A.BeanApi({ base: '' }).base === 'https://api10.axionswap.com');
const mf = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'manifest.json'), 'utf8'));
ok('both hosts in host_permissions and CSP connect-src', mf.host_permissions.includes('https://api10.axionswap.com/*') && mf.host_permissions.includes('https://api10.norhartpro.com/*') && /connect-src 'self' https:\/\/api10\.axionswap\.com https:\/\/api10\.norhartpro\.com/.test(mf.content_security_policy.extension_pages));
const e = fs.readFileSync(path.join(__dirname, '..', 'ext11.js'), 'utf8');
ok('ext11 builds the client / shows the address through effBase', /base: A\.effBase\(S\.api\.base\)/.test(e) && /A\.effBase\(api\.base\)/.test(e) && /A\.effBase\(\(S\.api && S\.api\.base\) \|\| aui\.base\)/.test(e));
console.log(`unit174: ${p} passed, ${f} failed`); process.exit(f ? 1 : 0);
