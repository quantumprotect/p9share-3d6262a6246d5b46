// Bean 1.1.7.9 unit checks: Likes needed (total + distribute + early stop) and per-step retry in watchdog
const L = require('../lib/links.js'), O = require('../lib/orders.js'), S = require('../lib/steps.js'), fs = require('fs'), path = require('path');
let p = 0, f = 0; const ok = (n, c) => { if (c) p++; else { f++; console.log('FAIL ' + n); } };

ok('manifest 1.1.7.9', JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'manifest.json'), 'utf8')).version === '1.1.7.9');
ok('MAX_STEP_RETRY is 2', S.MAX_STEP_RETRY === 2);
ok('MAX_REOPENS is 2', O.C.MAX_REOPENS === 2);

// clampNeeded / distributeNeeded
ok('clampNeeded empty = null', L.clampNeeded('').q == null && L.clampNeeded('  ').q == null);
ok('clampNeeded 5', L.clampNeeded('5').q === 5);
ok('clampNeeded clamps to 200', L.clampNeeded('999').q === 200 && L.clampNeeded('999').clamped);
ok('clampNeeded rejects 0', L.clampNeeded('0').q == null);
{ const d = L.distributeNeeded(5, [{ n: 1, vid: 'a', lc: '1', max: 3 }, { n: 2, vid: 'b', lc: '2', max: 4 }, { n: 3, vid: 'c', lc: '3', max: 2 }]);
  ok('distributeNeeded greedy 5 -> 3+2+0', d[0].q === 3 && d[1].q === 2 && d[2].q === 0);
  ok('distributeNeeded never overshoots', d.reduce((n, x) => n + x.q, 0) === 5);
}
{ const d = L.distributeNeeded(100, [{ n: 1, vid: 'a', lc: '1', max: 2 }, { n: 2, vid: 'b', lc: '2', max: 2 }]);
  ok('distributeNeeded caps at sum of maxes', d.reduce((n, x) => n + x.q, 0) === 4);
}

// quantityMet with needed
{ const o = { needed: 3, carry: { liked: 2, already: 1 }, links: [{ vid: 'a', lc: '1', quantity: 10 }], done: {} };
  ok('quantityMet true when liked+already >= needed', O.quantityMet(o));
  o.carry.already = 0; ok('quantityMet false when under needed', !O.quantityMet(o));
}
{ const o = { needed: null, carry: { liked: 0, already: 0 }, links: [{ vid: 'a', lc: '1', quantity: 2 }], done: { 'a|1': 2 } };
  ok('quantityMet still honours per-link quantity', O.quantityMet(o));
}

// watchdog per-step retry
{ const b = { state: 'running', groups: [{ cid: 'c0', status: 'running' }], items: [{ cid: 'c0', status: 'running', at: 1, hb: Date.now(), prog: 1, step: 'find-comment' }] };
  const t = Date.now() + 120000;
  const r1 = O.watchdog(b, t, { silentMs: 1, quietMs: 1, maxStepRetry: 2 });
  ok('1st step timeout -> requeued (retry)', r1.changed && b.items[0].status === 'queued' && b.items[0].stepTry['find-comment'] === 1 && b.groups[0].status === 'queued');
  b.items[0].status = 'running'; b.items[0].at = 1; b.items[0].hb = t; b.items[0].prog = 1; b.groups[0].status = 'running';
  O.watchdog(b, t + 120000, { silentMs: 1, quietMs: 1, maxStepRetry: 2 });
  ok('2nd same-step timeout -> still retry', b.items[0].status === 'queued' && b.items[0].stepTry['find-comment'] === 2);
  b.items[0].status = 'running'; b.items[0].at = 1; b.items[0].hb = t; b.items[0].prog = 1; b.groups[0].status = 'running';
  O.watchdog(b, t + 240000, { silentMs: 1, quietMs: 1, maxStepRetry: 2 });
  ok('3rd same-step timeout -> step-timeout fail, slot freed', b.items[0].status === 'failed' && b.items[0].code === 'step-timeout' && b.groups[0].status === 'queued');
}
{ const b = { state: 'running', groups: [{ cid: 'c0', status: 'running' }], items: [{ cid: 'c0', status: 'running', at: 1, hb: Date.now(), prog: 1, step: 'find-comment', sent: Date.now() }] };
  O.watchdog(b, Date.now() + 120000, { silentMs: 1, quietMs: 1, maxStepRetry: 2 });
  ok('sent like on timeout -> liked-unverified, never re-click', b.items[0].status === 'liked' && b.items[0].code === 'liked-unverified');
}
{ const b = { state: 'running', groups: [{ cid: 'c0', status: 'running' }], items: [{ cid: 'c0', status: 'running', at: 1, hb: Date.now(), prog: 1, step: 'channel-switch', stepTry: { 'find-comment': 3 } }] };
  O.watchdog(b, Date.now() + 120000, { silentMs: 1, quietMs: 1, maxStepRetry: 2 });
  ok('different step gets its own retry counter', b.items[0].status === 'queued' && b.items[0].stepTry['channel-switch'] === 1);
}

// static wiring
const ph = fs.readFileSync(path.join(__dirname, '..', 'popup.html'), 'utf8');
const pj = fs.readFileSync(path.join(__dirname, '..', 'popup.js'), 'utf8');
const cj = fs.readFileSync(path.join(__dirname, '..', 'content.js'), 'utf8');
ok('popup shows Likes needed field', /Likes needed/.test(ph) && /id="qall"/.test(ph));
ok('popup distributes + persists likesNeeded', /distributeNeeded/.test(pj) && /saveLikesNeeded/.test(pj) && /settings\.likesNeeded/.test(pj));
ok('popup early-stops when needed reached', /likes needed .* already reached/i.test(pj) || /Likes needed \(' \+ b\.needed/.test(pj));
ok('goInner passes needed', /needed: need\.q/.test(pj));
ok('ext17 copies needed onto batch', /needed: \(o\.needed/.test(fs.readFileSync(path.join(__dirname, '..', 'ext17.js'), 'utf8')));
ok('content handBack tracks stepTry / caps at 2', /stMap\[sn\] > 2/.test(cj) && /stepTry: stMap/.test(cj));
ok('API path untouched (no needed forced)', !/needed:\s*1/.test(fs.readFileSync(path.join(__dirname, '..', 'lib/apijobs.js'), 'utf8')));

console.log(`unit176: ${p} passed, ${f} failed`);
process.exit(f ? 1 : 0);
