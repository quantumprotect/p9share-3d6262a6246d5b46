#!/usr/bin/env python3
"""Server tests for the Bean API (server/bean_api.py). No network, temp SQLite.
Run:  /workspace/appstore/venv/bin/python /workspace/panel9-bean/tests/server_test.py
SERVER_DIR=/path/to/server overrides where bean_api.py / app.py are imported from."""
import json, os, sys, tempfile, time, unittest, sqlite3, importlib

SERVER = os.environ.get("SERVER_DIR", "/workspace/appstore/server")
sys.path.insert(0, SERVER)
TMP = tempfile.mkdtemp(prefix="bean-srv-test-")
os.environ["BEAN_DB"] = os.path.join(TMP, "bean.sqlite")
from flask import Flask
import bean_api as B

app = Flask("bean-test")
bean_api_path = B.init(app, TMP, db_path=os.path.join(TMP, "bean.sqlite"))
C = app.test_client()
VID = "dQw4w9WgXcQ"
LC1 = "UgxAbCdEfGhIjKlMnOp"
LC_R = "UgxAbCdEfGhIjKlMnOp.9xYzAbCdEfGh"
L1 = f"https://www.youtube.com/watch?v={VID}&lc={LC1}"
L2 = f"https://youtu.be/{VID}?lc={LC_R}"
SAVED = ["p:111", "p:222", "h:@alice", "c:cont1"]


def H(tok): return {"Authorization": "Bearer " + tok}


def mk_install(name="Bot A", iid=None, channels=SAVED):
    iid = iid or "inst_" + os.urandom(8).hex()
    tok = "bit_" + os.urandom(24).hex()
    r = C.post("/api/bean/agent/register", json={"install_id": iid, "install_token": tok, "name": name, "version": "1.1.0"})
    assert r.status_code == 201, r.data
    key = r.get_json()["api_key"]
    if channels is not None:
        r = C.put("/api/bean/agent/config", json={"channels": channels, "gate": "on", "vpn": {"on": True, "n": 3}}, headers=H(tok))
        assert r.status_code == 200, r.data
    return iid, tok, key


class T(unittest.TestCase):
    def setUp(self):
        B._buckets.clear()
        B.CFG.update(online_s=45, lease_s=120, queue_ttl_s=86400, result_ttl_s=7 * 86400, rate_key_per_min=120, rate_jobs_per_min=10, rate_register_per_hour=10, rate_authfail_per_min=30, max_queue=25, poll_max_wait=25)

    # ------------------------------------------------------------ keys: create / regenerate / revoke, hashing, binding
    def test_register_returns_key_once_and_stores_only_hashes(self):
        iid, tok, key = mk_install("Hash test")
        self.assertTrue(key.startswith("bean_") and len(key) > 40)
        raw = open(os.path.join(TMP, "bean.sqlite"), "rb").read()
        for p in (".sqlite-wal",):
            if os.path.exists(os.path.join(TMP, "bean.sqlite") + "-wal"): raw += open(os.path.join(TMP, "bean.sqlite") + "-wal", "rb").read()
        self.assertNotIn(key.encode(), raw, "clear API key must not be stored")
        self.assertNotIn(tok.encode(), raw, "clear install token must not be stored")
        row = sqlite3.connect(os.path.join(TMP, "bean.sqlite")).execute("select key_hash, token_hash, key_hint from installs where install_id=?", (iid,)).fetchone()
        self.assertEqual(len(row[0]), 64); self.assertEqual(len(row[1]), 64); self.assertTrue("\u2026" in row[2] and key[-4:] in row[2] and key not in row[2])
        r = C.get("/api/bean/v1/install", headers=H(key)); self.assertEqual(r.status_code, 200)
        j = r.get_json(); self.assertEqual(j["name"], "Hash test"); self.assertEqual(j["install_id"], iid); self.assertNotIn("api_key", j); self.assertEqual(j["saved_channels"], 4)

    def test_duplicate_register_conflicts_and_bad_input(self):
        iid, tok, key = mk_install()
        r = C.post("/api/bean/agent/register", json={"install_id": iid, "install_token": "bit_" + "x" * 40, "name": "again"}); self.assertEqual(r.status_code, 409)
        self.assertEqual(r.get_json()["error"]["code"], "install_exists")
        r = C.post("/api/bean/agent/register", json={"install_id": "short", "install_token": tok, "name": "n"}); self.assertEqual(r.status_code, 400)
        r = C.post("/api/bean/agent/register", json={"install_id": "a" * 20, "install_token": "nope", "name": "n"}); self.assertEqual(r.status_code, 400)
        r = C.post("/api/bean/agent/register", json={"install_id": "b" * 20, "install_token": "bit_" + "y" * 40, "name": "<script>"}); self.assertEqual(r.status_code, 400)
        r = C.post("/api/bean/agent/register", data="not json", content_type="application/json"); self.assertEqual(r.status_code, 400)

    def test_regenerate_invalidates_old_key_revoke_kills_everything(self):
        iid, tok, key = mk_install("Regen")
        r = C.post("/api/bean/agent/regenerate", headers=H(tok)); self.assertEqual(r.status_code, 200); key2 = r.get_json()["api_key"]
        self.assertNotEqual(key, key2)
        self.assertEqual(C.get("/api/bean/v1/install", headers=H(key)).status_code, 401)
        self.assertEqual(C.get("/api/bean/v1/install", headers=H(key2)).status_code, 200)
        # API key cannot call agent endpoints and the install token cannot call the external API
        self.assertEqual(C.get("/api/bean/agent/poll", headers=H(key2)).status_code, 401)
        self.assertEqual(C.get("/api/bean/v1/install", headers=H(tok)).status_code, 401)
        # a queued job is cancelled by revoke
        C.post("/api/bean/v1/jobs", json={"links": [L1], "quantity": 1}, headers=H(key2))
        r = C.post("/api/bean/agent/revoke", json={}, headers=H(tok)); self.assertEqual(r.status_code, 200)
        self.assertEqual(C.get("/api/bean/v1/install", headers=H(key2)).status_code, 401)
        self.assertEqual(C.get("/api/bean/agent/poll", headers=H(tok)).status_code, 403)
        c = sqlite3.connect(os.path.join(TMP, "bean.sqlite")); self.assertEqual(c.execute("select count(*) from jobs where install_id=? and status='queued'", (iid,)).fetchone()[0], 0)
        # same install identity can create the API again (ledger kept)
        tok2 = "bit_" + os.urandom(24).hex()
        r = C.post("/api/bean/agent/register", json={"install_id": iid, "install_token": tok2, "name": "Regen again"}); self.assertEqual(r.status_code, 201)
        self.assertEqual(C.get("/api/bean/v1/install", headers=H(r.get_json()["api_key"])).get_json()["name"], "Regen again")

    def test_key_of_install_A_cannot_drive_install_B(self):
        ia, ta, ka = mk_install("Install A"); ib, tb, kb = mk_install("Install B")
        r = C.post("/api/bean/v1/jobs", json={"links": [L1], "quantity": 1}, headers=H(ka)); self.assertEqual(r.status_code, 202); jid = r.get_json()["job_id"]
        # B's key: A's job does not exist, cannot be read, cancelled; B's list is empty; B's capacity ignores A's reservations
        self.assertEqual(C.get("/api/bean/v1/jobs/" + jid, headers=H(kb)).status_code, 404)
        self.assertEqual(C.post(f"/api/bean/v1/jobs/{jid}/cancel", headers=H(kb)).status_code, 404)
        self.assertEqual(C.get("/api/bean/v1/jobs", headers=H(kb)).get_json()["jobs"], [])
        self.assertEqual(C.get("/api/bean/v1/install", headers=H(kb)).get_json()["name"], "Install B")
        self.assertEqual(C.get("/api/bean/v1/capacity", query_string={"link": L1}, headers=H(kb)).get_json()["capacity"][0]["max_likes"], 4)
        # B's agent cannot see or report A's job; polling B yields nothing
        self.assertEqual(C.get("/api/bean/agent/poll", headers=H(tb)).get_json()["jobs"], [])
        r = C.post(f"/api/bean/agent/jobs/{jid}/report", json={"state": "finished", "results": []}, headers=H(tb)); self.assertEqual(r.status_code, 404)
        # A's agent gets it
        self.assertEqual(len(C.get("/api/bean/agent/poll", headers=H(ta)).get_json()["jobs"]), 1)
        # unknown / missing keys
        self.assertEqual(C.get("/api/bean/v1/install").status_code, 401)
        self.assertEqual(C.get("/api/bean/v1/install", headers=H("bean_" + "z" * 43)).status_code, 401)
        self.assertEqual(C.get("/api/bean/v1/install", headers=H(ka)).status_code, 200)

    def test_link_existing_key_restores_install_and_ledger(self):
        iid, tok, key = mk_install("Linkme")
        C.post("/api/bean/agent/ledger", json={"entries": [[VID, LC1, "p:111", "l", int(time.time() * 1000)], [VID, LC1, "h:@alice", "a", int(time.time() * 1000)]]}, headers=H(tok))
        tok2 = "bit_" + os.urandom(24).hex()      # reinstall: new local token, the saved API key proves ownership
        r = C.post("/api/bean/agent/link", json={"api_key": key, "install_token": tok2}); self.assertEqual(r.status_code, 200)
        j = r.get_json(); self.assertEqual(j["install_id"], iid); self.assertEqual(j["ledger_entries"], 2)
        self.assertEqual(C.get("/api/bean/agent/status", headers=H(tok)).status_code, 401, "the old install token stops working")
        self.assertEqual(C.get("/api/bean/agent/status", headers=H(tok2)).status_code, 200)
        self.assertEqual(C.get("/api/bean/v1/install", headers=H(key)).status_code, 200, "the API key keeps working")
        self.assertEqual(C.post("/api/bean/agent/link", json={"api_key": "bean_" + "q" * 43, "install_token": tok2}).status_code, 401)
        # ledger restore pages
        pages, after = [], 0
        while True:
            g = C.get("/api/bean/agent/ledger", query_string={"after": after, "limit": 1}, headers=H(tok2)).get_json(); pages += g["entries"]; after = g["next"]
            if g["done"]: break
        self.assertEqual(sorted(e[2] for e in pages), ["h:@alice", "p:111"]); self.assertEqual(g["total"], 2)

    # ------------------------------------------------------------ capacity math, quantity clamp / reject
    def test_capacity_is_saved_channels_minus_ledger(self):
        iid, tok, key = mk_install("Cap")
        cap = lambda l: C.get("/api/bean/v1/capacity", query_string={"link": l}, headers=H(key)).get_json()["capacity"][0]
        c = cap(L1); self.assertEqual((c["channels_saved"], c["channels_used"], c["max_likes"], c["vid"], c["lc"]), (4, 0, 4, VID, LC1))
        C.post("/api/bean/agent/ledger", json={"entries": [[VID, LC1, "p:111", "l", 0], [VID, LC1, "h:@alice", "a", 0], [VID, LC1, "p:999", "l", 0]]}, headers=H(tok))   # p:999 is not a saved channel: does not count
        c = cap(L1); self.assertEqual((c["channels_used"], c["max_likes"]), (2, 2))
        self.assertEqual(cap(L2)["max_likes"], 4, "a reply is a different comment from its parent")
        self.assertTrue(cap(L2)["is_reply"])
        # URL variants of the same comment are the same ledger key
        self.assertEqual(cap(f"https://m.youtube.com/watch?v={VID}&lc={LC1}&feature=shared")["max_likes"], 2)
        self.assertEqual(cap(f"https://www.youtube.com/watch?v={VID}&lc={LC1.replace('Ugx', 'Ugx')}")["max_likes"], 2)
        # saving fewer channels lowers it
        C.put("/api/bean/agent/config", json={"channels": ["p:111", "p:222"]}, headers=H(tok)); self.assertEqual(cap(L1)["max_likes"], 1)
        C.put("/api/bean/agent/config", json={"channels": []}, headers=H(tok))
        r = C.post("/api/bean/v1/jobs", json={"links": [L1]}, headers=H(key)); self.assertEqual((r.status_code, r.get_json()["error"]["code"]), (409, "no_channels_saved"))
        # POST capacity with several links; bad link
        C.put("/api/bean/agent/config", json={"channels": SAVED}, headers=H(tok))
        r = C.post("/api/bean/v1/capacity", json={"links": [L1, {"link": L2}]}, headers=H(key)); self.assertEqual([x["max_likes"] for x in r.get_json()["capacity"]], [2, 4])
        r = C.get("/api/bean/v1/capacity", query_string={"link": f"https://www.youtube.com/watch?v={VID}"}, headers=H(key)); self.assertEqual((r.status_code, r.get_json()["error"]["code"]), (400, "invalid_link"))

    def test_quantity_default_clamp_reject(self):
        iid, tok, key = mk_install("Qty"); B.CFG["rate_jobs_per_min"] = 1000
        C.post("/api/bean/agent/ledger", json={"entries": [[VID, LC1, "p:111", "l", 0]]}, headers=H(tok))    # max for L1 = 3
        sub = lambda body: C.post("/api/bean/v1/jobs", json=body, headers=H(key))
        r = sub({"links": [L1]}); j = r.get_json(); self.assertEqual(r.status_code, 202)
        self.assertEqual((j["links"][0]["accepted"], j["links"][0]["requested"], j["links"][0]["clamped"]), (3, None, False), "no quantity = all available")
        self.assertEqual(j["status"], "queued"); self.assertEqual(j["progress"]["total_likes"], 3)
        # reserved by the queued job: L1 has nothing left for a second job
        r = sub({"links": [L1]}); self.assertEqual((r.status_code, r.get_json()["error"]["code"]), (422, "no_capacity"))
        cap = C.get("/api/bean/v1/capacity", query_string={"link": L1}, headers=H(key)).get_json()["capacity"][0]; self.assertEqual((cap["max_likes"], cap["reserved_by_queued_jobs"]), (0, 3))
        # reject (default) above capacity, clamp when asked; all-or-nothing
        r = sub({"links": [{"link": L2, "quantity": 9}, {"link": L1, "quantity": 1}]}); e = r.get_json()["error"]
        self.assertEqual((r.status_code, e["code"]), (422, "quantity_exceeds_capacity")); self.assertEqual(len(e["details"]["problems"]), 2)
        r = sub({"links": [{"link": L2, "quantity": 9}]}); e = r.get_json()["error"]
        self.assertEqual((r.status_code, e["code"], e["details"]["problems"][0]["max_likes"], e["details"]["problems"][0]["requested"]), (422, "quantity_exceeds_capacity", 4, 9))
        self.assertEqual(C.get("/api/bean/v1/jobs", headers=H(key)).get_json()["jobs"].__len__(), 1, "a rejected request queues nothing")
        r = sub({"links": [{"link": L2, "quantity": 9}], "over_quantity": "clamp"}); j = r.get_json()
        self.assertEqual((r.status_code, j["links"][0]["accepted"], j["links"][0]["clamped"], j["links"][0]["requested"]), (202, 4, True, 9))
        for bad in ({"links": [{"link": L2, "quantity": 0}]}, {"links": [{"link": L2, "quantity": "2"}]}, {"links": [{"link": L2, "quantity": 1.5}]}, {"links": [{"link": L2, "quantity": 5000}]}, {"links": []}, {"links": "x"}, {}):
            r = sub(bad); self.assertEqual(r.status_code, 400, bad)
        r = sub({"links": [L1, L1.replace("youtube.com", "m.youtube.com")]}); self.assertEqual((r.status_code, r.get_json()["error"]["code"]), (400, "duplicate_link"))
        r = sub({"links": ["https://example.com/watch?v=%s&lc=%s" % (VID, LC1)]}); self.assertEqual((r.status_code, r.get_json()["error"]["code"]), (400, "invalid_link"))
        r = sub({"links": [L1] * 1 + ["https://www.youtube.com/watch?v=%s&lc=%s" % (VID, "UgxZZZZZZZZZZZZ%d" % i) for i in range(25)]}); self.assertEqual((r.status_code, r.get_json()["error"]["code"]), (400, "too_many_links"))
        r = sub({"links": [L2], "over_quantity": "maybe"}); self.assertEqual(r.status_code, 400)

    def test_idempotency_and_queue_cap(self):
        iid, tok, key = mk_install("Idem", channels=["p:%d" % i for i in range(200)])
        body = {"links": [L1], "quantity": 1}
        r1 = C.post("/api/bean/v1/jobs", json=body, headers={**H(key), "Idempotency-Key": "k1"}); r2 = C.post("/api/bean/v1/jobs", json=body, headers={**H(key), "Idempotency-Key": "k1"})
        self.assertEqual((r1.status_code, r2.status_code), (202, 200)); self.assertEqual(r1.get_json()["job_id"], r2.get_json()["job_id"]); self.assertTrue(r2.get_json()["idempotent_replay"])
        B.CFG["max_queue"] = 3
        codes = [C.post("/api/bean/v1/jobs", json={"links": [{"link": f"https://www.youtube.com/watch?v={VID}&lc=UgxQUEUE{i:08d}", "quantity": 1}]}, headers=H(key)).status_code for i in range(4)]
        self.assertEqual(codes, [202, 202, 429, 429])

    # ------------------------------------------------------------ job lifecycle: claim, report, finish, cancel
    def test_job_lifecycle_end_to_end(self):
        iid, tok, key = mk_install("Life")
        j = C.post("/api/bean/v1/jobs", json={"links": [{"link": L1, "quantity": 2}, {"link": L2}], "note": "hello"}, headers=H(key)).get_json(); jid = j["job_id"]
        self.assertEqual(j["status"], "queued")
        p = C.get("/api/bean/agent/poll", headers=H(tok)).get_json()
        self.assertEqual(len(p["jobs"]), 1); self.assertEqual(p["jobs"][0]["job_id"], jid)
        self.assertEqual([(l["vid"], l["lc"], l["quantity"]) for l in p["jobs"][0]["links"]], [(VID, LC1, 2), (VID, LC_R, 4)])
        self.assertEqual(C.get("/api/bean/agent/poll", headers=H(tok)).get_json()["jobs"], [], "one job at a time, not handed out twice")
        self.assertEqual(C.get(f"/api/bean/v1/jobs/{jid}", headers=H(key)).get_json()["status"], "running")
        res = [{"n": 1, "seq": 0, "status": "liked", "code": "liked", "container": "Main", "channel": "Alice", "at": int(time.time() * 1000), "vpn": {"location": "UK - London", "ip_changed": True}},
               {"n": 1, "seq": 1, "status": "already", "code": "already", "container": "Main", "channel": "Bob"},
               {"n": 2, "seq": 0, "status": "failed", "code": "vpn-failed", "message": "stuck", "container": "B", "channel": "C"}]
        r = C.post(f"/api/bean/agent/jobs/{jid}/report", json={"state": "running", "results": res}, headers=H(tok)); self.assertEqual(r.get_json()["status"], "running")
        v = C.get(f"/api/bean/v1/jobs/{jid}", headers=H(key)).get_json(); self.assertEqual((v["progress"]["done"], v["progress"]["liked"], v["progress"]["already_liked"], v["progress"]["failed"], v["progress"]["total_likes"]), (3, 1, 1, 1, 6))
        # re-reporting the same (n, seq) replaces, never duplicates
        C.post(f"/api/bean/agent/jobs/{jid}/report", json={"state": "running", "results": res[:1]}, headers=H(tok))
        self.assertEqual(len(C.get(f"/api/bean/v1/jobs/{jid}", headers=H(key)).get_json()["results"]), 3)
        r = C.post(f"/api/bean/agent/jobs/{jid}/report", json={"state": "finished", "warnings": ["Container 'X' uses Outside VPN"], "results": []}, headers=H(tok)); self.assertEqual(r.get_json()["status"], "partial")
        v = C.get(f"/api/bean/v1/jobs/{jid}", headers=H(key)).get_json()
        self.assertEqual((v["status"], v["warnings"]), ("partial", ["Container 'X' uses Outside VPN"])); self.assertTrue(v["finished_at"]); self.assertEqual(v["results"][0]["vpn"]["location"], "UK - London"); self.assertNotIn("ip", json.dumps(v["results"][0]["vpn"]).replace("ip_changed", ""))
        self.assertEqual(C.get("/api/bean/v1/jobs?status=partial", headers=H(key)).get_json()["jobs"][0]["job_id"], jid)
        # completed / failed derivation
        j2 = C.post("/api/bean/v1/jobs", json={"links": [{"link": L1.replace(LC1, "UgxOTHER000000001"), "quantity": 1}]}, headers=H(key)).get_json()["job_id"]
        C.get("/api/bean/agent/poll", headers=H(tok))
        r = C.post(f"/api/bean/agent/jobs/{j2}/report", json={"state": "finished", "results": [{"n": 1, "seq": 0, "status": "liked"}]}, headers=H(tok)); self.assertEqual(r.get_json()["status"], "completed")
        j3 = C.post("/api/bean/v1/jobs", json={"links": [{"link": L1.replace(LC1, "UgxOTHER000000002"), "quantity": 1}]}, headers=H(key)).get_json()["job_id"]
        C.get("/api/bean/agent/poll", headers=H(tok))
        r = C.post(f"/api/bean/agent/jobs/{j3}/report", json={"state": "finished", "error": {"code": "gate_off", "message": "Turn on YouTube Focus comment-only view"}, "results": []}, headers=H(tok)); self.assertEqual(r.get_json()["status"], "failed")
        v = C.get(f"/api/bean/v1/jobs/{j3}", headers=H(key)).get_json(); self.assertEqual(v["error"]["code"], "gate_off")
        # a finished job ignores late reports
        r = C.post(f"/api/bean/agent/jobs/{j3}/report", json={"state": "running", "results": [{"n": 1, "seq": 0, "status": "liked"}]}, headers=H(tok)); self.assertTrue(r.get_json()["ignored"])

    def test_agent_jobs_lists_running_and_queued_of_this_install_only_without_secrets(self):
        # 1.1.7 (read-only): Bean's popup shows the API jobs of THIS install: the running one first, then the queue in line order, with the links, quantities, status, created time and the caller's note
        iid, tok, key = mk_install("List A"); iid2, tok2, key2 = mk_install("List B")
        self.assertEqual(C.get("/api/bean/agent/jobs").status_code, 401, "no token: refused")
        self.assertEqual(C.get("/api/bean/agent/jobs", headers=H(key)).status_code, 401, "an API key is not an install token")
        self.assertEqual(C.get("/api/bean/agent/jobs", headers=H(tok)).get_json()["jobs"], [])
        a = C.post("/api/bean/v1/jobs", json={"links": [{"link": L1, "quantity": 2}], "note": "YT Panel batch 7"}, headers=H(key)).get_json()["job_id"]
        b = C.post("/api/bean/v1/jobs", json={"links": [{"link": L2, "quantity": 1}], "note": "YT Panel retry 7.1"}, headers=H(key)).get_json()["job_id"]
        c3 = C.post("/api/bean/v1/jobs", json={"links": [{"link": L1.replace(LC1, "UgxOTHER000000009"), "quantity": 1}]}, headers=H(key)).get_json()["job_id"]
        other = C.post("/api/bean/v1/jobs", json={"links": [{"link": L1, "quantity": 1}], "note": "somebody else"}, headers=H(key2)).get_json()["job_id"]
        v = C.get("/api/bean/agent/jobs", headers=H(tok)).get_json()
        self.assertEqual([(j["job_id"], j["status"], j["place"]) for j in v["jobs"]], [(a, "queued", 1), (b, "queued", 2), (c3, "queued", 3)])
        C.get("/api/bean/agent/poll", headers=H(tok))                  # the first job is handed out: it is running now
        v = C.get("/api/bean/agent/jobs", headers=H(tok)).get_json()
        self.assertEqual([(j["job_id"], j["status"], j["place"]) for j in v["jobs"]], [(a, "running", 0), (b, "queued", 1), (c3, "queued", 2)])
        j0 = v["jobs"][0]
        self.assertEqual((j0["note"], j0["links"][0]["vid"], j0["links"][0]["comment_id"], j0["links"][0]["requested"], j0["links"][0]["accepted"], j0["progress"]["total_likes"]), ("YT Panel batch 7", VID, LC1, 2, 2, 2))
        self.assertTrue(j0["created_at"] and j0["started_at"] and v["jobs"][1]["started_at"] is None and v["jobs"][1]["note"] == "YT Panel retry 7.1")
        self.assertNotIn(other, json.dumps(v), "never another install's job")
        blob = json.dumps(v).lower()
        for secret in (tok, key, "token", "key_hash", "token_hash", "bit_", "bean_"): self.assertNotIn(secret.lower(), blob, "no secret in the list: " + secret)
        C.post(f"/api/bean/agent/jobs/{a}/report", json={"state": "finished", "results": [{"n": 1, "seq": 0, "status": "liked"}]}, headers=H(tok))
        self.assertEqual([(j["job_id"], j["place"]) for j in C.get("/api/bean/agent/jobs", headers=H(tok)).get_json()["jobs"]], [(b, 1), (c3, 2)], "finished jobs leave the list")

    def test_cancel_queued_and_running(self):
        iid, tok, key = mk_install("Cancel")
        a = C.post("/api/bean/v1/jobs", json={"links": [{"link": L1, "quantity": 1}]}, headers=H(key)).get_json()["job_id"]
        b = C.post("/api/bean/v1/jobs", json={"links": [{"link": L2, "quantity": 1}]}, headers=H(key)).get_json()["job_id"]
        self.assertEqual(C.post(f"/api/bean/v1/jobs/{b}/cancel", headers=H(key)).get_json()["status"], "cancelled")
        p = C.get("/api/bean/agent/poll", headers=H(tok)).get_json(); self.assertEqual([x["job_id"] for x in p["jobs"]], [a])
        v = C.post(f"/api/bean/v1/jobs/{a}/cancel", headers=H(key)).get_json(); self.assertEqual((v["status"], v["cancel_requested"]), ("running", True))
        self.assertEqual(C.get("/api/bean/agent/poll", headers=H(tok)).get_json()["cancel"], [a])
        r = C.post(f"/api/bean/agent/jobs/{a}/report", json={"state": "finished", "results": [{"n": 1, "seq": 0, "status": "skipped", "code": "cancelled"}]}, headers=H(tok)); self.assertEqual(r.get_json()["status"], "cancelled")
        self.assertIn("already finished", C.post(f"/api/bean/v1/jobs/{a}/cancel", headers=H(key)).get_json().get("message", ""))

    # ------------------------------------------------------------ expiry, leases
    def test_expiry_queue_results_and_lease(self):
        iid, tok, key = mk_install("Expire")
        B.CFG["queue_ttl_s"] = 1
        q = C.post("/api/bean/v1/jobs", json={"links": [{"link": L1, "quantity": 1}]}, headers=H(key)).get_json()["job_id"]
        time.sleep(1.2); B.sweep(force=True)
        v = C.get(f"/api/bean/v1/jobs/{q}", headers=H(key)).get_json(); self.assertEqual(v["status"], "expired")
        self.assertEqual(C.get("/api/bean/agent/poll", headers=H(tok)).get_json()["jobs"], [], "an expired job is never handed to the agent")
        B.CFG["queue_ttl_s"] = 86400; B.CFG["result_ttl_s"] = 1
        q2 = C.post("/api/bean/v1/jobs", json={"links": [{"link": L2, "quantity": 1}]}, headers=H(key)).get_json()["job_id"]
        C.get("/api/bean/agent/poll", headers=H(tok))
        C.post(f"/api/bean/agent/jobs/{q2}/report", json={"state": "finished", "results": [{"n": 1, "seq": 0, "status": "liked"}]}, headers=H(tok))
        self.assertEqual(C.get(f"/api/bean/v1/jobs/{q2}", headers=H(key)).status_code, 200)
        time.sleep(1.2); B.sweep(force=True)
        self.assertEqual(C.get(f"/api/bean/v1/jobs/{q2}", headers=H(key)).status_code, 404, "results are deleted after the retention time")
        # lease: silent agent -> requeue when nothing was done yet, failed/partial afterwards
        B.CFG["result_ttl_s"] = 7 * 86400; B.CFG["lease_s"] = 1
        j = C.post("/api/bean/v1/jobs", json={"links": [{"link": L1, "quantity": 2}]}, headers=H(key)).get_json()["job_id"]
        C.get("/api/bean/agent/poll", headers=H(tok)); time.sleep(1.2); B.sweep(force=True)
        self.assertEqual(C.get(f"/api/bean/v1/jobs/{j}", headers=H(key)).get_json()["status"], "queued", "no results yet: given back to the queue")
        self.assertEqual(len(C.get("/api/bean/agent/poll", headers=H(tok)).get_json()["jobs"]), 1)
        C.post(f"/api/bean/agent/jobs/{j}/report", json={"state": "running", "results": [{"n": 1, "seq": 0, "status": "liked"}]}, headers=H(tok))
        time.sleep(1.2); B.sweep(force=True)
        v = C.get(f"/api/bean/v1/jobs/{j}", headers=H(key)).get_json(); self.assertEqual((v["status"], v["error"]["code"]), ("partial", "agent_lost"))

    # ------------------------------------------------------------ rate limits, online status, limits
    def test_rate_limits(self):
        iid, tok, key = mk_install("Rate")
        B.CFG["rate_key_per_min"] = 5; B._buckets.clear()
        codes = [C.get("/api/bean/v1/install", headers=H(key)).status_code for _ in range(8)]
        self.assertEqual(codes[:5], [200] * 5); self.assertEqual(set(codes[5:]), {429})
        r = C.get("/api/bean/v1/install", headers=H(key)); self.assertIn("Retry-After", r.headers); self.assertEqual(r.get_json()["error"]["code"], "rate_limited")
        B.CFG["rate_key_per_min"] = 120; B.CFG["rate_jobs_per_min"] = 2; B._buckets.clear()
        ch = [C.post("/api/bean/v1/jobs", json={"links": [{"link": f"https://www.youtube.com/watch?v={VID}&lc=UgxRATE{i:010d}", "quantity": 1}]}, headers=H(key)).status_code for i in range(4)]
        self.assertEqual(ch, [202, 202, 429, 429])
        B.CFG["rate_key_per_min"] = 120; B._buckets.clear()
        r = C.get("/api/bean/v1/install", headers=H(key)); self.assertIn("X-RateLimit-Remaining", r.headers)
        B.CFG["rate_authfail_per_min"] = 3; B._buckets.clear()
        bad = [C.get("/api/bean/v1/install", headers=H("bean_" + "n" * 43)).status_code for _ in range(6)]
        self.assertEqual(bad[:3], [401] * 3); self.assertEqual(set(bad[3:]), {429})
        B._buckets.clear(); B.CFG["rate_register_per_hour"] = 2
        rr = [C.post("/api/bean/agent/register", json={"install_id": "r" * 20 + str(i), "install_token": "bit_" + "t" * 38 + str(i), "name": "n"}).status_code for i in range(4)]
        self.assertEqual(rr, [201, 201, 429, 429])

    def test_online_status_and_long_poll(self):
        iid, tok, key = mk_install("Online")
        self.assertTrue(C.get("/api/bean/v1/install", headers=H(key)).get_json()["online"])      # registered just now
        B.CFG["online_s"] = 1; time.sleep(1.3)
        j = C.get("/api/bean/v1/install", headers=H(key)).get_json(); self.assertFalse(j["online"]); self.assertGreaterEqual(j["seconds_since_seen"], 1)
        C.get("/api/bean/agent/poll", headers=H(tok), query_string={"v": "1.1.0", "p9": "2.3.10"})
        self.assertTrue(C.get("/api/bean/v1/install", headers=H(key)).get_json()["online"])
        B.CFG["online_s"] = 45
        t0 = time.time(); r = C.get("/api/bean/agent/poll", headers=H(tok), query_string={"wait": 2}); self.assertEqual(r.get_json()["jobs"], []); self.assertGreaterEqual(time.time() - t0, 1.8)
        import threading
        out = {}
        def poller(): out["r"] = C.get("/api/bean/agent/poll", headers=H(tok), query_string={"wait": 10}).get_json()
        th = threading.Thread(target=poller); th.start(); time.sleep(0.4)
        C.post("/api/bean/v1/jobs", json={"links": [{"link": L1, "quantity": 1}]}, headers=H(key)); th.join(5)
        self.assertEqual(len(out["r"]["jobs"]), 1, "a long poll returns as soon as a job is submitted")

    def test_ledger_agent_endpoint_is_idempotent_and_validated(self):
        iid, tok, key = mk_install("Led")
        e = [[VID, LC1, "p:111", "l", int(time.time() * 1000)]]
        self.assertEqual(C.post("/api/bean/agent/ledger", json={"entries": e}, headers=H(tok)).get_json()["added"], 1)
        self.assertEqual(C.post("/api/bean/agent/ledger", json={"entries": e}, headers=H(tok)).get_json()["added"], 0)
        r = C.post("/api/bean/agent/ledger", json={"entries": [["bad", LC1, "p:1", "l"], [VID, "x", "p:1", "l"], [VID, LC1, "zzz", "l"], "junk"]}, headers=H(tok)); self.assertEqual(r.get_json()["accepted"], 0)
        self.assertEqual(C.post("/api/bean/agent/ledger", json={"entries": [[VID, LC1, "p:1", "l"]] * 1001}, headers=H(tok)).status_code, 400)

    def test_unknown_routes_are_json_and_cors_preflight(self):
        r = C.get("/api/bean/v1/nope"); self.assertEqual((r.status_code, r.get_json()["error"]["code"]), (404, "not_found"))
        r = C.post("/api/bean/v1/jobs", data="x" * 10, content_type="application/json", headers=H("bean_" + "a" * 43)); self.assertEqual(r.status_code, 401)
        self.assertEqual(C.get("/api/bean/v1/health").get_json()["ok"], True)


class FullApp(unittest.TestCase):
    """the real app.py with the Bean blueprint: Bean routes work AND the store's own routes still answer exactly as before"""
    def test_store_routes_unchanged_and_bean_present(self):
        os.environ["BEAN_DB"] = os.path.join(TMP, "full.sqlite")
        apps = os.path.join(TMP, "apps"); os.makedirs(os.path.join(apps, "demo")); os.environ["APPSTORE_APPS_DIR"] = apps
        json.dump({"id": "demo", "name": "Demo", "type": "extension", "targets": ["panel-9"], "releases": [{"version": "1.0.0", "platform": "any", "sha256": "0" * 64, "size": 1, "file": "d.zip", "date": "2026-01-01", "storage": "r2", "notes": "n"}]}, open(os.path.join(apps, "demo", "manifest.json"), "w"))
        sys.modules.pop("app", None); sys.modules.pop("bean_api", None)
        m = importlib.import_module("app")
        c = m.app.test_client()
        h = c.get("/health"); self.assertEqual(h.status_code, 200); self.assertTrue(h.get_json()["ok"]); self.assertIn("X-Served-By", h.headers)
        self.assertEqual(c.get("/").get_json()["name"], "App Store API")
        self.assertEqual([a["id"] for a in c.get("/api/apps").get_json()["apps"] if True] if isinstance(c.get("/api/apps").get_json(), dict) else [a["id"] for a in c.get("/api/apps").get_json()], ["demo"])
        self.assertEqual(c.get("/api/apps/demo/latest").get_json()["version"], "1.0.0")
        self.assertEqual(c.get("/api/extensions?target=panel-9").status_code, 200)
        self.assertEqual(c.get("/api/apps/nope/latest").status_code, 404)
        self.assertEqual(c.get("/api/bean/v1/health").get_json()["service"], "bean-api")
        self.assertEqual(c.get("/api/bean/v1/install").status_code, 401)
        self.assertEqual(c.get("/api/apps/demo/latest", headers={"Origin": "https://x.example"}).headers.get("Access-Control-Allow-Origin") in ("*", "https://x.example"), True)
        pf = c.open("/api/bean/v1/jobs", method="OPTIONS", headers={"Origin": "chrome-extension://abc", "Access-Control-Request-Method": "POST", "Access-Control-Request-Headers": "authorization,content-type"})
        self.assertIn(pf.status_code, (200, 204)); self.assertIn("authorization", (pf.headers.get("Access-Control-Allow-Headers") or "").lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
