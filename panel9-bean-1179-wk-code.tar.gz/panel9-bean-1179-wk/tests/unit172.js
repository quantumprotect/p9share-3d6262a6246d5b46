// Bean 1.1.7.2 unit checks: click evidence (mkSeen) beats a stale record that lost "sent"
const O = require('../lib/orders.js'); let p = 0, f = 0;
const ok = (n, c) => { if (c) p++; else { f++; console.log('FAIL ' + n); } };
{ const its = [{ status: 'queued', mkSeen: 1 }, { status: 'queued' }, { status: 'running', mkSeen: 1 }, { status: 'running' }, { status: 'running', sent: 1 }];
  O.endItems(its, 100);
  ok('queued+mkSeen -> liked-unverified', its[0].status === 'liked' && its[0].code === 'liked-unverified');
  ok('queued -> not-started', its[1].code === 'not-started');
  ok('running+mkSeen -> liked-unverified', its[2].code === 'liked-unverified');
  ok('running -> interrupted', its[3].code === 'interrupted');
  ok('running+sent -> liked-unverified', its[4].code === 'liked-unverified'); }
{ const b = { items: [{ cid: '1', status: 'queued', mkSeen: 1 }, { cid: '1', status: 'running' }], groups: [{ cid: '1', status: 'running', reopens: 0 }] };
  O.reopenGroup(b, b.groups[0], 1000, { seen: true });
  ok('reopen: marker-proven item is only VERIFIED (verify flag, queued, never a fresh click)', b.items[0].status === 'queued' && !!b.items[0].verify && !!b.items[0].sent);
  for (let k = 0; k < 4; k++) O.reopenGroup(b, b.groups[0], 2000 + k, { seen: true });
  ok('reopens exhausted: marker-proven item ends liked-unverified, not "nothing was clicked"', b.items[0].status === 'liked' && b.items[0].code === 'liked-unverified');
  ok('reopens exhausted: item without evidence still fails plainly', b.items[1].status === 'failed'); }
(async () => {
  const { World } = require('./sim17.js'); const w = new World(); const d = new O.Dispatcher({ store: w.store(), clock: w.clock, ports: w.ports({}) });
  const r = await d.submit({ src: 'api', jobId: 'jG', links: [{ n: 1, vid: 'dQw4w9WgXcQ', lc: 'UgxGONEAAAAAAAAAAAAAAAAAAAAA', quantity: 3, url: '' }], targets: w.targets });
  const r2 = await d.submit({ src: 'api', jobId: 'jN', links: [{ n: 1, vid: 'abcdefghijk', lc: 'UgxBBBBBBBBBBBBBBBBBBBBBBBBB', quantity: 1, url: '' }], targets: w.targets });
  let gone = false, nextStarted = 0, goneBatches = new Set();
  for (let k = 0; k < 400; k++) { w.t += 1000;
    const b = w.batch; if (b && b.state === 'running' && b.items[0].vid === 'dQw4w9WgXcQ' && !gone) { gone = true; b.items.forEach((it, i) => { it.status = 'failed'; it.code = 'comment-gone'; }); b.groups.forEach((g) => { g.status = 'done'; }); b.state = 'done'; b.updated = w.t; }
    if (b && b.items[0].vid === 'abcdefghijk' && !nextStarted) nextStarted = k; if (b && b.items[0].vid === 'dQw4w9WgXcQ') goneBatches.add(b.id);
    await d.tick(); }
  const all = (d.d.hist || []).concat(d.d.queue || []); const og = all.find((o) => o.jobId === 'jG');
  ok('comment-gone: the order ends failed with code comment-gone, no retry round, no spare channel', !!og && og.state === 'failed' && og.err && og.err.code === 'comment-gone' && (og.round || 0) <= 1);
  ok('comment-gone: only ONE batch was run for the gone comment, then the next job started', goneBatches.size === 1 && nextStarted > 0 && nextStarted < 30);
  { const fs = require('fs'), src17 = fs.readFileSync(__dirname + '/../ext17.js', 'utf8'), rc = src17.slice(src17.indexOf('async function reconcile'), src17.indexOf('function init17'));
    ok('fix 3: only the executor judges orphaned jobs (a just-opened popup never does)', /!S17\.disp \|\| !B\.executor\(\)\) return;/.test(rc));
    const harv = src17.slice(src17.indexOf('function harvest'), src17.indexOf('const shortResults'));
    ok('fix 2: never-tried (not-started) items are not reported to the server', /if \(it\.code === 'not-started'\) return;/.test(harv)); }
  console.log(`unit172: ${p} passed, ${f} failed`); process.exit(f ? 1 : 0);
})();
// ${p} passed, ${f} failed`); process.exit(f ? 1 : 0);
