'use strict';
// Watches the browser's tab list every 40 ms and records the tabs Bean opened (a youtube.com URL that carries Bean's run/discovery token, p9bn=).
// "Tab rule" assertions: the number of Bean tabs open at the same moment never exceeds 1, and every one is closed again at the end.
module.exports = function track(ctx) {
  const known = new Map();            // tab id -> { containerId, first, lastUrl, closedAt }
  const T = { logged: new Set(), max: 0, maxAll: 0, maxPerCid: 0, total: 0, over: [], samples: 0 };
  const urlOf = (t) => { try { return t.view.webContents.getURL() || ''; } catch (_) { return ''; } };
  const tick = () => {
    T.samples++; const live = new Set(ctx.tabs.map((t) => t.id));
    for (const t of ctx.tabs) { const u = urlOf(t); if (/youtube\.com/.test(u) && /[?&]p9bn=/.test(u) && !known.has(t.id)) { known.set(t.id, { containerId: t.containerId || '', first: Date.now(), lastUrl: u, closedAt: 0 }); T.total++; } const k = known.get(t.id); if (k && u) k.lastUrl = u; }
    let n = 0; const per = {}; for (const [id, k] of known) { if (live.has(id)) { n++; per[k.containerId] = (per[k.containerId] || 0) + 1; } else if (!k.closedAt) k.closedAt = Date.now(); }
    for (const c of Object.keys(per)) if (per[c] > T.maxPerCid) T.maxPerCid = per[c];          // 1.1.7.5: up to 3 containers at once, but never 2 Bean tabs of the SAME container
    if (n > T.maxAll) T.maxAll = n;
    if (n > 1 && !T.logged.has([...known].filter(([id]) => live.has(id)).map(([id]) => id).join())) { const ids = [...known].filter(([id]) => live.has(id)); T.logged.add(ids.map(([id]) => id).join()); console.log('  [tabtrack] ' + n + ' Bean tabs open at once: ' + ids.map(([id, k]) => id + '@' + k.containerId + ' ' + String(k.lastUrl).replace(/^https:\/\/www\.youtube\.com\//, '').slice(0, 70)).join(' | ')); }
    if (n > T.max) { T.max = n; if (n > 1) T.over.push([...known].filter(([id]) => live.has(id)).map(([id, k]) => id + '@' + k.containerId)); }
  };
  const iv = setInterval(tick, 40);
  T.alive = () => { const live = new Set(ctx.tabs.map((t) => t.id)); return [...known.keys()].filter((id) => live.has(id)); };
  T.tabs = () => [...known.entries()].map(([id, k]) => Object.assign({ id }, k));
  T.mark = () => ({ total: T.total, max: T.max });
  T.resetMax = () => { T.max = T.alive().length; T.over.length = 0; };
  T.stop = () => clearInterval(iv);
  return T;
};
