#!/usr/bin/env python3
"""Build /workspace/panel9-bean-1.1.7.9.zip: manifest.json first, runtime files only (no tests/, shots/, patches, build notes), then secret-scan every byte."""
import json, os, re, sys, zipfile
SRC = "/workspace/panel9-bean-1179-wk"; OUT = "/workspace/panel9-bean-1.1.7.9.zip"
m = json.load(open(os.path.join(SRC, "manifest.json")))
assert m["version"] == "1.1.7.9", m["version"]
files = ["manifest.json"]
for root, dirs, fs in os.walk(SRC):
    dirs[:] = sorted(d for d in dirs if d not in ("tests", "shots", "real-logs", "__pycache__", "node_modules", ".git"))
    for f in sorted(fs):
        rel = os.path.relpath(os.path.join(root, f), SRC)
        if rel == "manifest.json" or f.startswith(".") or f.endswith(".orig") or f.endswith((".md", ".patch", ".txt", ".diff")) and not rel.startswith("fonts/") or rel == "store-icon-512.png": continue
        files.append(rel)
files = ["manifest.json"] + sorted(set(files[1:]))
if os.path.exists(OUT): os.remove(OUT)
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for rel in files:
        zi = zipfile.ZipInfo(rel, date_time=(2026, 10, 30, 12, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16
        z.writestr(zi, open(os.path.join(SRC, rel), "rb").read())
# ---- secret scan of the zip contents
PAT = [rb"-----BEGIN [A-Z ]*PRIVATE KEY", rb"AKIA[0-9A-Z]{16}", rb"bean_[A-Za-z0-9_-]{43}", rb"bit_[A-Za-z0-9_-]{43}", rb"bi_[A-Za-z0-9_-]{24}\b", rb"R2_SECRET", rb"admin_token", rb"Bearer [A-Za-z0-9_\-\.]{20,}",
       rb"(?i)(password|passwd|secret|api[_-]?key)\s*[:=]\s*['\"][^'\"\s]{8,}", rb"ghp_[A-Za-z0-9]{30,}", rb"sk-[A-Za-z0-9]{20,}", rb"xox[bap]-[A-Za-z0-9-]{10,}", rb"eyJ[A-Za-z0-9_-]{20,}\.eyJ"]
bad = []
with zipfile.ZipFile(OUT) as z:
    assert z.namelist()[0] == "manifest.json"
    for n in z.namelist():
        data = z.read(n)
        if n.endswith((".png", ".woff2")): continue
        for p in PAT:
            for mm in re.finditer(p, data): bad.append((n, p.decode()[:30], data[max(0, mm.start() - 20):mm.start()].decode("utf8", "replace")[-20:].replace("\n", " ")))
print("files:", len(files)); print("\n".join(files))
print("SECRET-SCAN:", "CLEAN" if not bad else bad)
sys.exit(1 if bad else 0)
