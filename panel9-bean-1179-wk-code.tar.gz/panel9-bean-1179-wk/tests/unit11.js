'use strict';
// 1.1.0 unit tests: ledger, canonical ids, API job planning, VPN rotation (mock bridge), API client.  Run: node tests/unit.js  (it requires this file)  or  node tests/unit11.js
const fs = require('fs'); const path = require('path'); const assert = require('assert');
const L = require('../lib/links.js'); const LG = require('../lib/ledger.js'); const V = require('../lib/vpnrot.js'); const A = require('../lib/apiclient.js');
const ROOT = path.join(__dirname, '..');
let n = 0; const queue = [];
const t = (name, fn) => queue.push([name, fn]);
const VID = 'dQw4w9WgXcQ', VID2 = 'aaaaaaaaaaa', TOP = 'UgxAbCdEf123456789AaBBCCdd', REP = TOP + '.9xYzAbCdEf123';
const memStore = () => { const m = {}; return { m, all: async () => JSON.parse(JSON.stringify(m)), get: async (ks) => { const o = {}; for (const k of [].concat(ks)) if (k in m) o[k] = JSON.parse(JSON.stringify(m[k])); return o; }, set: async (o) => { for (const k of Object.keys(o)) m[k] = JSON.parse(JSON.stringify(o[k])); }, remove: async (ks) => { for (const k of [].concat(ks)) delete m[k]; } }; };

// ---------------------------------------------------------------- canonical ids + ledger
t('ledger: a channel is recorded once per comment; reply ids are separate comments from their parent; lookups are canonical', async () => {
  const led = new LG.Ledger(memStore()); await led.load();
  assert.strictEqual(led.add(VID, TOP, 'p:111', 'l'), 'added'); assert.strictEqual(led.add(VID, TOP, 'p:111', 'a'), 'dup');
  assert(led.has(VID, TOP, 'p:111')); assert(!led.has(VID, TOP, 'p:222')); assert(!led.has(VID2, TOP, 'p:111'));
  assert(!led.has(VID, REP, 'p:111'), 'a reply is a different comment from its parent');
  assert.strictEqual(led.add(VID, REP, 'p:111', 'l'), 'added'); assert(led.has(VID, REP, 'p:111'));
  assert.strictEqual(led.add('bad', TOP, 'p:1', 'l'), 'bad'); assert.strictEqual(led.add(VID, '', 'p:1', 'l'), 'bad');
  assert.deepStrictEqual(led.used(VID, TOP), ['p:111']);
  // canonicalisation: whitespace / trailing punctuation around the id and the same link written differently give the same key
  assert.strictEqual(led.add(VID, ' ' + TOP + ' ', 'p:111', 'l'), 'dup'); assert.strictEqual(led.add(VID, TOP + ',', 'p:111', 'l'), 'dup');
  const a = L.parseLink(`https://youtu.be/${VID}?lc=${REP}&si=x`), b = L.parseLink(`https://www.youtube.com/watch?lc=${REP}&v=${VID}&t=5s`);
  assert.strictEqual(L.commentKey(a.vid, a.lc), L.commentKey(b.vid, b.lc)); assert.strictEqual(led.add(a.vid, a.lc, 'p:111', 'l'), 'dup');
});
t('ledger: persists in shards, reloads identically, flush is a union (a stale copy never removes an entry), the mirror queue is acked', async () => {
  const st = memStore(); const a = new LG.Ledger(st); await a.load();
  for (let i = 0; i < 300; i++) a.add(VID, 'Ugx' + String(i).padStart(10, '0'), 'p:' + (i % 7), i % 2 ? 'l' : 'a');
  await a.flush(); assert(Object.keys(st.m).filter((k) => /^p9bn\.led\.[0-9a-f]{2}$/.test(k)).length > 20, 'spread over many shards');
  const b = new LG.Ledger(st); await b.load(); assert.strictEqual(b.stats().comments, 300); assert(b.has(VID, 'Ugx0000000007', 'p:0'));
  // a second writer with a stale copy adds one entry and flushes: nothing is lost
  const c = new LG.Ledger(st); await c.load(); b.add(VID2, TOP, 'p:9', 'l'); await b.flush(); c.add(VID2, REP, 'p:8', 'l'); await c.flush();
  const d = new LG.Ledger(st); await d.load(); assert(d.has(VID2, TOP, 'p:9') && d.has(VID2, REP, 'p:8') && d.stats().comments === 302, d.stats());
  const out = d.takeOut(1000); assert(out.length >= 0);
  const e = new LG.Ledger(st); await e.load(); const pend = e.stats().pending; assert(pend >= 300); await e.ackOut(100); assert.strictEqual(e.stats().pending, pend - 100);
});
t('ledger: restore from the server copy fills a fresh install without queueing a mirror; export/import round trip; prune; clear; bounded', async () => {
  const a = new LG.Ledger(memStore()); await a.load();
  a.add(VID, TOP, 'p:1', 'l', Date.now()); a.add(VID, REP, 'h:@x', 'a', Date.now()); a.add(VID2, TOP, 'c:c1', 'l', Date.UTC(2026, 0, 3));
  const j = JSON.parse(a.exportJson()); assert(j.bean === 'ledger' && j.entries.length === 3);
  const b = new LG.Ledger(memStore()); await b.load(); const r = b.addMany(j.entries, { noOut: true }); assert.strictEqual(r.added, 3); assert.strictEqual(b.stats().pending, 0);
  assert(b.has(VID, REP, 'h:@x')); assert.strictEqual(b.addMany(j.entries, { noOut: true }).dup, 3);
  assert.strictEqual(b.prune(30), 1); assert(!b.has(VID2, TOP, 'c:c1') && b.has(VID, TOP, 'p:1'));
  await b.clear(); assert.strictEqual(b.stats().comments, 0);
});
t('ledger: 30 000 comments stay fast and small (one flush touches only changed shards)', async () => {
  const st = memStore(), led = new LG.Ledger(st); await led.load(); const t0 = Date.now();
  for (let i = 0; i < 30000; i++) led.add(VID, 'Ugx' + i.toString(36).padStart(12, '0'), 'p:' + (i % 40), 'l', Date.now(), { noOut: true });
  assert(Date.now() - t0 < 4000, 'add time ' + (Date.now() - t0)); await led.flush(); const size = JSON.stringify(st.m).length; assert(size < 4.5e6, 'size ' + size);
  assert.strictEqual(led.add(VID, 'Ugx' + (30000).toString(36).padStart(12, '0'), 'p:1', 'l'), 'full', 'the comment cap is a hard bound');
  led.add(VID2, TOP, 'p:1', 'l'); const before = JSON.stringify(st.m); led.dirty.clear();
  const l2 = new LG.Ledger(st); await l2.load(); assert.strictEqual(l2.stats().comments, 30000); assert(before.length > 0);
});
t('planActions: a channel already in the ledger is skipped with the exact label, and a container with nothing left is done', () => {
  const links = L.parseMany(`https://www.youtube.com/watch?v=${VID}&lc=${TOP}\nhttps://www.youtube.com/watch?v=${VID}&lc=${REP}`).items;
  const cs = [{ id: 'a', name: 'A', channels: [{ id: '111', name: 'A1' }, { id: '222', name: 'A2' }] }, { id: 'b', name: 'B' }];
  const used = (v, c, k) => (c === TOP && k === 'p:111') || (k === 'c:b');
  const p = L.planActions(links, cs, { used });
  const skipped = p.items.filter((i) => i.code === 'ledger-used'); assert.strictEqual(skipped.length, 3);
  assert(skipped.every((i) => i.status === 'skipped' && i.msg === 'Channel already used on this comment')); assert.strictEqual(L.label('ledger-used'), 'Channel already used on this comment');
  assert.strictEqual(p.groups.find((g) => g.cid === 'b').status, 'done'); assert.strictEqual(p.groups.find((g) => g.cid === 'a').status, 'queued');
  assert.strictEqual(p.items.filter((i) => i.status === 'queued').length, 3);
});
t('planApi: quantity per link takes distinct unused channels in plan order; a shortfall is reported, never silently dropped', () => {
  const links = [{ n: 1, vid: VID, lc: TOP, url: 'u1', quantity: 2 }, { n: 2, vid: VID, lc: REP, url: 'u2', quantity: 5 }];
  const cs = [{ id: 'a', name: 'A', channels: [{ id: '111', name: 'A1' }, { id: '222', name: 'A2' }] }, { id: 'b', name: 'B' }];
  const p = L.planApi(links, cs, (v, c, k) => c === TOP && k === 'p:111');
  const by = (jn) => p.items.filter((i) => i.jn === jn).map((i) => i.ck);
  assert.deepStrictEqual(by(1), ['p:222', 'c:b']); assert.deepStrictEqual(by(2), ['p:111', 'p:222', 'c:b']);
  assert.deepStrictEqual(p.shortfalls, [{ jn: 2, missing: 2 }]); assert.deepStrictEqual(p.items.filter((i) => i.jn === 2).map((i) => i.seq), [0, 1, 2]);
  assert(p.items.every((i, k) => i.n === k + 1)); assert.deepStrictEqual(new Set(p.items.map((i) => i.cid)), new Set(['a', 'b']));
});

// ---------------------------------------------------------------- VPN rotation against a mock bridge (the same three ops Panel 9 gives Bean)
function mockBridge(o) {
  o = Object.assign({ mode: 'ok', ips: { 'Germany - Frankfurt': '198.51.100.1', 'France - Paris': '198.51.100.2', 'Japan - Tokyo': '198.51.100.3' }, real: '203.0.113.5', calls: [] }, o || {});
  const s = { state: 'disconnected', location: '', since: 0, target: '', mode: o.mode, ip: () => (s.state === 'connected' ? o.ips[s.location] || '198.51.100.99' : o.real) };
  const call = async (a) => {
    o.calls.push(a);
    if (o.mode === 'old') throw new Error('not allowed');
    if (o.mode === 'noexpress') throw new Error('ExpressVPN support is not available');
    if (a.op === 'regions') return { regions: Object.keys(o.ips).map((n) => ({ id: n, name: n, cc: '' })).concat([{ id: 'smart', name: 'Smart Location', cc: '' }]) };
    if (a.op === 'connect') {
      // Panel 9 2.3.10 rule: ONLY the exact string 'smart' or an exact id from the regions list (no labels, prefixes, case/space variants, 'smart-location'); everything else is rejected
      if (typeof a.location !== 'string' || (a.location !== 'smart' && !Object.prototype.hasOwnProperty.call(o.ips, a.location))) { o.rejected = (o.rejected || []).concat([a.location]); throw new Error('Unknown ExpressVPN location'); }
      if (o.mode === 'cli') { const e = new Error('ExpressVPN refused the command'); throw e; } s.state = 'connecting'; s.target = a.location; s.since = o.calls.length; return { ok: true }; }
    if (a.op === 'state') {
      if (o.mode === 'admin') return { ok: true, vpn: { state: 'unavailable', reason: 'admin', message: 'ExpressVPN refused the command: it needs Panel 9 to run as administrator.', location: '', exitIp: '' }, routes: [] };
      if (o.mode === 'blip' && s.state === 'connecting' && o.calls.length % 3 === 0) throw new Error('network lock');
      if (s.state === 'connecting' && o.mode !== 'stuck' && !(o.stuckOn && o.stuckOn.includes(s.target)) && o.calls.length - s.since >= 3) { s.state = 'connected'; s.location = s.target; }
      if (s.state === 'connecting' && ((o.mode === 'stuck') || (o.stuckOn && o.stuckOn.includes(s.target)))) { /* never connects */ }
      const ip = a.noip || s.state === 'connecting' ? '' : o.mode === 'sameip' && s.state === 'connected' ? o.real : o.mode === 'noip' ? '' : s.ip();
      return { ok: true, vpn: { state: s.state, location: s.location, reason: '', message: '', exitIp: ip }, routes: o.routes || [] };
    }
    throw new Error('not allowed');
  };
  return { call, o, s };
}
const rotor = (b, extra) => new V.Rotator({ call: b.call, sleep: async () => { b.o.t = (b.o.t || 0) + 1; }, now: (() => { let c = 0; return () => (c += 400); })(), timeouts: Object.assign({ connectMs: 20000, ipMs: 8000, pollMs: 1, attempts: 2, settleMs: 0 }, extra || {}) });
const LOCS = [{ id: 'Germany - Frankfurt', name: 'Germany - Frankfurt' }, { id: 'France - Paris', name: 'France - Paris' }, { id: 'Japan - Tokyo', name: 'Japan - Tokyo' }];
t('vpn: rotates through the saved locations in order; each switch is confirmed by "connected there" AND a changed exit address', async () => {
  const b = mockBridge(); const r = rotor(b); let ptr = 0; const seen = [];
  for (let i = 0; i < 4; i++) { const x = await r.rotate(LOCS, ptr); assert(x.ok, JSON.stringify(x)); seen.push(x.location); assert.strictEqual(x.ipChanged, true); ptr = (x.idx + 1) % LOCS.length; }
  assert.deepStrictEqual(seen, ['Germany - Frankfurt', 'France - Paris', 'Japan - Tokyo', 'Germany - Frankfurt']);
  assert(b.o.calls.every((c) => ['state', 'connect', 'regions'].includes(c.op)), 'only the three bridge operations are used'); assert(!JSON.stringify(b.o.calls).includes('publicIp'));
});
t('vpn: a stuck "connecting" skips that like (vpn-stuck); one stuck location falls back to the next saved one within the retry bound', async () => {
  const b = mockBridge({ mode: 'stuck' }); const x = await rotor(b).rotate(LOCS, 0); assert(!x.ok && x.code === 'vpn-stuck', JSON.stringify(x)); assert(/connecting/.test(x.msg));
  assert.strictEqual(b.o.calls.filter((c) => c.op === 'connect').length, 2, 'retries are bounded to 2 attempts');
  const b2 = mockBridge({ stuckOn: ['Germany - Frankfurt'] }); const y = await rotor(b2).rotate(LOCS, 0); assert(y.ok && y.location === 'France - Paris' && y.idx === 1, JSON.stringify(y));
});
t('vpn: never likes on the wrong address — an unchanged exit IP is vpn-noip, an unreadable one too', async () => {
  const b = mockBridge({ mode: 'sameip' }); const x = await rotor(b).rotate(LOCS, 0); assert(!x.ok && x.code === 'vpn-noip', JSON.stringify(x));
  const b2 = mockBridge({ mode: 'noip' }); const y = await rotor(b2).rotate(LOCS, 0); assert(!y.ok && y.code === 'vpn-noip' && /read/.test(y.msg), JSON.stringify(y));
});
t('vpn: CLI unavailable / not admin / old Panel 9 / no ExpressVPN support give clear, distinct answers', async () => {
  const a = await rotor(mockBridge({ mode: 'admin' })).preflight(); assert(!a.ok && a.code === 'vpn-unavailable' && /administrator/.test(a.msg), JSON.stringify(a));
  const a2 = await rotor(mockBridge({ mode: 'admin' })).rotate(LOCS, 0); assert(!a2.ok && a2.code === 'vpn-unavailable' && /administrator/.test(a2.msg));
  const o = await rotor(mockBridge({ mode: 'old' })).preflight(); assert(!o.ok && o.support === 'old' && /too old/.test(o.msg), JSON.stringify(o));
  const ne = await rotor(mockBridge({ mode: 'noexpress' })).preflight(); assert(!ne.ok && ne.support === 'none');
  const none = await new V.Rotator({ call: null }).preflight(); assert(!none.ok && none.support === 'none');
  const c = await rotor(mockBridge({ mode: 'cli' })).rotate(LOCS, 0); assert(!c.ok && /could not start/.test(c.msg));
  const ok = await rotor(mockBridge()).preflight(); assert(ok.ok && ok.support === 'yes');
});
t('vpn: containers that bypass the VPN are reported by preflight (routes), a mid-switch state error does not break the wait, one saved location needs no switch when already there', async () => {
  const pf = await rotor(mockBridge({ routes: [{ id: 'default', route: 'vpn' }, { id: 'c1', route: 'bypass' }, { id: 'c2', route: 'proxy' }] })).preflight(); assert.deepStrictEqual(pf.routes, { default: 'vpn', c1: 'bypass', c2: 'proxy' });
  const b = mockBridge({ mode: 'blip' }); const x = await rotor(b).rotate(LOCS, 1); assert(x.ok && x.location === 'France - Paris', JSON.stringify(x));
  const b2 = mockBridge(); const r = rotor(b2); const one = [LOCS[0]]; const f = await r.rotate(one, 0); assert(f.ok); const g = await r.rotate(one, 0); assert(g.ok && g.same === true && b2.o.calls.filter((c) => c.op === 'connect').length === 1);
  assert(V.sameLoc('Germany - Frankfurt - 1', LOCS[0]) && !V.sameLoc('France - Paris', LOCS[0]) && !V.sameLoc('', LOCS[0]));
});

// ---------------------------------------------------------------- exact-id rule (Panel 9 2.3.10: connect accepts ONLY 'smart' or an exact id from the regions list) + noip polling
t('vpn exact ids: the mock enforces Panel 9 2.3.10 (exact id or exactly "smart"; labels, prefixes, case/space variants and "smart-location" are rejected)', async () => {
  const b = mockBridge(); await b.call({ op: 'connect', location: 'smart' }); await b.call({ op: 'connect', location: 'Japan - Tokyo' });
  for (const bad of ['smart-location', 'Smart Location', 'SMART', 'smart ', ' smart', 'smart2', 'japan - tokyo', 'Japan - Tokyo ', 'Japan', 'Germany', '', undefined, null, 5]) {
    await assert.rejects(b.call({ op: 'connect', location: bad }), /Unknown ExpressVPN location/, String(bad));
  }
});
t('vpn exact ids: rotation only ever sends exact region ids (never smart / labels / prefixes); Smart Location is not offered; the mock never had to reject anything', async () => {
  const b = mockBridge(); const r = rotor(b); const regs = await r.regions(); assert.deepStrictEqual(regs.map((x) => x.id), Object.keys(b.o.ips)); assert(!regs.some((x) => /smart/i.test(x.id + x.name)));
  let ptr = 0; for (let i = 0; i < 4; i++) { const x = await r.rotate(LOCS, ptr); assert(x.ok, JSON.stringify(x)); ptr = (x.idx + 1) % LOCS.length; }
  const cons = b.o.calls.filter((c) => c.op === 'connect').map((c) => c.location); assert(cons.length >= 4 && cons.every((l) => Object.keys(b.o.ips).includes(l)), JSON.stringify(cons)); assert(!b.o.rejected);
});
t('vpn exact ids: a saved location that is not an exact id is NEVER sent to connect (vpn-badloc, no connect call), whatever it looks like', async () => {
  for (const bad of [{ id: 'smart-location', name: 'Smart Location' }, { id: 'smart', name: 'Smart Location' }, { id: 'germany - frankfurt', name: 'Germany - Frankfurt' }, { id: 'Germany - Frankfurt ', name: 'Germany - Frankfurt' }, { id: 'Germany', name: 'Germany - Frankfurt' }, { id: 'Atlantis', name: 'Atlantis' }, { id: 7, name: 'x' }, {}]) {
    const b = mockBridge(); const x = await rotor(b).rotate([bad], 0); assert(!x.ok && x.code === 'vpn-badloc', JSON.stringify([bad, x]));
    assert(!b.o.calls.some((c) => c.op === 'connect'), 'no connect for ' + JSON.stringify(bad)); assert(!b.o.rejected);
  }
});
t('vpn exact ids: a region list that cannot be read stops the switch (vpn-unavailable), never a guess', async () => {
  const b = mockBridge(); const orig = b.call; const r = rotor({ o: b.o, call: async (a) => { if (a.op === 'regions') throw new Error('ExpressVPN needs Panel 9 to run as administrator'); return orig(a); } });
  const x = await r.rotate(LOCS, 0); assert(!x.ok && x.code === 'vpn-unavailable' && /administrator/.test(x.msg), JSON.stringify(x)); assert(!b.o.calls.some((c) => c.op === 'connect'));
});
t('vpn saved-location migration: non-exact stored values become the exact id they stand for, or are dropped with a clear note; exact ones are untouched', () => {
  const regs = Object.keys(mockBridge().o.ips).map((n) => ({ id: n, name: n, cc: '' })).concat([{ id: 'smart', name: 'Smart Location', cc: '' }]);
  const exact = LOCS.map((x) => ({ id: x.id, name: x.name, cc: '' }));
  const same = V.migrateLocs(exact, regs); assert.strictEqual(same.changed, false); assert.deepStrictEqual(same.locs, exact); assert.strictEqual(same.note, '');
  const m = V.migrateLocs([{ id: 'smart-location', name: 'Smart Location' }, 'smart', { id: 'Smart', name: 'x' }, { id: 'germany - frankfurt', name: 'Germany - Frankfurt' }, ' France - Paris ', { id: 'xx', name: 'Japan - Tokyo' }, { id: 'Japan - Tokyo', name: 'Japan - Tokyo' }, 'Atlantis', null, 42, { id: 'Germany' }], regs);
  assert.deepStrictEqual(m.locs.map((x) => x.id), ['Germany - Frankfurt', 'France - Paris', 'Japan - Tokyo'], JSON.stringify(m)); assert(m.changed);
  assert.strictEqual(m.migrated.length, 3); assert(m.dropped.length >= 4 && m.dropped.some((d) => /Atlantis/.test(d)) && m.dropped.some((d) => /Smart/i.test(d)));
  assert(/exact location id/.test(m.note) && /not in ExpressVPN's list/.test(m.note) && /Atlantis/.test(m.note));
  assert(m.locs.every((x) => regs.some((r) => r.id === x.id) && !/smart/i.test(x.id)), 'every result is an exact, non-smart id');
  // ambiguous (two regions with the same label) is dropped, not guessed; an empty region list never wipes anything (caller guards)
  const amb = V.migrateLocs(['Paris'], [{ id: 'France - Paris', name: 'Paris' }, { id: 'Texas - Paris', name: 'Paris' }]); assert.deepStrictEqual(amb.locs, []); assert.strictEqual(amb.dropped.length, 1);
  assert.deepStrictEqual(V.migrateLocs([], regs).locs, []);
});
t('vpn polling: the preflight probe and the wait-for-connected polls pass `noip` (no third-party lookup); only the baseline and the post-connect check read the exit address', async () => {
  const b = mockBridge(); const r = rotor(b); const pf = await r.preflight(); assert(pf.ok); const x = await r.rotate(LOCS, 0); assert(x.ok);
  const st = b.o.calls.filter((c) => c.op === 'state'); const withIp = st.filter((c) => !c.noip);
  assert(st.filter((c) => c.noip).length >= 2, 'noip used on the probe and the waiting polls'); assert(withIp.length >= 2 && withIp.length <= 4, 'exit address read only for the baseline + the post-connect check: ' + withIp.length);
  assert(b.o.calls.every((c) => c.noip === undefined || c.noip === true) && !b.o.calls.some((c) => 'publicIp' in c));
});

// ---------------------------------------------------------------- 1.1.1: "Possible likes" (counted like the API's /capacity) + per-container refresh (static rules)
t('possibleLikes: per comment = distinct ticked channels; per link = those minus the ledger-used ones; total adds up', () => {
  const cs = [{ id: 'a', name: 'A', channels: [{ id: 'main', name: 'Alice', handle: '@alice' }, { id: '111', name: 'Cook' }, { id: '222', name: 'Pets' }] }, { id: 'b', name: 'B', channels: [{ id: 'main', name: 'Bob', handle: '@bob' }] }, { id: 'd', name: 'D' }];
  const links = [{ vid: VID, lc: TOP }, { vid: VID, lc: REP }, { vid: VID2, lc: TOP }];
  const usedSet = new Set([VID + '|' + TOP + '|p:111', VID + '|' + TOP + '|h:@bob', VID2 + '|' + TOP + '|c:d']);
  const P = L.possibleLikes(cs, links, (v, c, k) => usedSet.has(v + '|' + c + '|' + k));
  assert.strictEqual(P.per, 5); assert.deepStrictEqual(P.perLink.map((x) => [x.n, x.total, x.used, x.avail]), [[1, 5, 2, 3], [2, 5, 0, 5], [3, 5, 1, 4]]);
  assert.deepStrictEqual(P.totals, { all: 15, used: 3, avail: 12, expected: 12 }); assert.deepStrictEqual(P.skipped, []);
  const none = L.possibleLikes([], [], null); assert.strictEqual(none.per, 0); assert.deepStrictEqual(none.perLink, []); assert.strictEqual(none.totals.all, 0);
});
t('possibleLikes == the API capacity logic: saved keys deduped, used ∩ saved, max_likes = saved − used (checked against planApi with no quantity, which is what a job takes)', () => {
  // the same brand channel (p:111) managed from two containers is ONE saved channel (Bean sends distinct keys to the server)
  const cs = [{ id: 'a', name: 'A', channels: [{ id: '111', name: 'Brand' }, { id: 'main', name: 'Alice', handle: '@alice' }] }, { id: 'b', name: 'B', channels: [{ id: '111', name: 'Brand' }] }, { id: 'c', name: 'C' }];
  const links = [{ vid: VID, lc: TOP, n: 1 }, { vid: VID, lc: REP, n: 2 }];
  const ledger = new Set([VID + '|' + TOP + '|p:111', VID + '|' + TOP + '|c:c']); const used = (v, c, k) => ledger.has(v + '|' + c + '|' + k);
  const P = L.possibleLikes(cs, links, used);
  // server formula (bean_api.capacity_of)
  const saved = [...new Set(cs.flatMap((c) => (c.channels && c.channels.length ? c.channels : [null]).map((ch) => L.chanKey(ch, c.id))))];
  for (const [i, l] of links.entries()) { const usedSaved = saved.filter((k) => used(l.vid, l.lc, k)).length; assert.strictEqual(P.perLink[i].total, saved.length); assert.strictEqual(P.perLink[i].used, usedSaved); assert.strictEqual(P.perLink[i].avail, Math.max(0, saved.length - usedSaved)); }
  const plan = L.planApi(links.map((l) => Object.assign({}, l)), cs, used);
  for (const [i, l] of links.entries()) assert.strictEqual(new Set(plan.items.filter((it) => it.jn === l.n).map((it) => it.ck)).size, P.perLink[i].avail, 'a job without quantity takes exactly the possible likes');
});
t('possibleLikes: containers that will be skipped (signed out / bypass) are listed and only reduce the "expected" estimate; the API-style numbers stay', () => {
  const cs = [{ id: 'a', name: 'A', channels: [{ id: '111', name: 'Cook' }, { id: '222', name: 'Pets' }] }, { id: 'b', name: 'B' }, { id: 'c', name: 'C' }];
  const links = [{ vid: VID, lc: TOP }]; const used = (v, c, k) => k === 'p:111';
  const P = L.possibleLikes(cs, links, used, (c) => (c.id === 'b' ? 'signed out' : c.id === 'a' ? 'bypasses the VPN' : ''));
  assert.strictEqual(P.per, 4); assert.deepStrictEqual(P.perLink[0], { n: 1, vid: VID, lc: TOP, total: 4, used: 1, avail: 3, expected: 1 });
  assert.deepStrictEqual(P.skipped.map((x) => [x.cid, x.chname, x.reason]), [['a', 'Cook', 'bypasses the VPN'], ['a', 'Pets', 'bypasses the VPN'], ['b', '', 'signed out']]);
  assert.deepStrictEqual(P.totals, { all: 4, used: 1, avail: 3, expected: 1 });
});
t('static: per-container refresh — one container, ticked or not; refused during a run / another reading; one tab at a time, awaited close, tab id in p9bn.disc; a failed read keeps the old list and writes the error', () => {
  const p = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8');
  assert(/async function refreshOne\(cid\)/.test(p) && /refreshContainers\(\[c\], true\)/.test(p), 'refreshOne reads exactly one container');
  assert(!/sel\.has\(cid\)|sel\.has\(c\.id\)\s*\)\s*return refreshContainers/.test(p.slice(p.indexOf('async function refreshOne'), p.indexOf('async function refreshContainers'))), 'not limited to ticked containers');
  const rc = p.slice(p.indexOf('async function refreshContainers'));
  assert(/running\(batch\) \|\| running\(live\)/.test(rc) && /A run is in progress/.test(rc), 'refused during a run'); assert(/dc\.state === 'running'/.test(rc) && /Another channel reading is still running/.test(rc), 'refused during another reading');
  assert(/await closeTabId\(tab\.tabId\)/.test(rc) && /tab: tab\.tabId/.test(rc) && /await sleep\(1500/.test(rc), 'close awaited before the next open; tab id recorded');
  assert(/const fail = async \(why\)[\s\S]*Object\.assign\(\{\}, old, \{ at: Date\.now\(\), err: why \}\)/.test(rc), 'a failed read keeps the previous list and records the error');
  assert(/let rbusy = false/.test(p) && /discovering = \{ i: 0/.test(rc), 'a synchronous guard against double clicks; controls disabled at once');
  assert(/rf\.disabled = rfOff/.test(p) && /els\.refresh\.disabled = !!discovering \|\| running\(batch\)/.test(p), 'the buttons are disabled while reading / running');
  assert(!/cookies|document\.cookie|getAll\(|\.token\b/.test(rc), 'no cookies or tokens in the refresh path');
  const h = fs.readFileSync(path.join(ROOT, 'popup.html'), 'utf8'); assert(/id="possible"/.test(h) && /id="crefresh"/.test(h), 'possible-likes panel + the existing Refresh channels button');
});

// ---------------------------------------------------------------- API client (fake fetch)
t('api client: base URL must be https (http only for this computer); identity + token shapes; one request path with a bearer header', async () => {
  assert.strictEqual(A.validBase('https://api10.norhartpro.com/'), 'https://api10.norhartpro.com'); assert.strictEqual(A.validBase('http://127.0.0.1:5010'), 'http://127.0.0.1:5010');
  for (const bad of ['http://api10.norhartpro.com', 'ftp://x', 'javascript:alert(1)', '', 'http://localhost.evil.com']) assert.strictEqual(A.validBase(bad), '', bad);
  const id = A.newIdentity(); assert(/^bi_[A-Za-z0-9_-]{24}$/.test(id.installId) && /^bit_[A-Za-z0-9_-]{43}$/.test(id.token)); assert.notStrictEqual(A.newIdentity().token, id.token);
  const calls = []; const fake = async (url, init) => { calls.push({ url, init }); return { ok: true, status: 200, headers: { get: () => '' }, json: async () => ({ jobs: [], cancel: [] }) }; };
  const c = new A.BeanApi({ base: 'https://api10.norhartpro.com', fetch: fake, getToken: () => id.token }); await c.poll(20, '1.1.0', '2.3.9');
  assert.strictEqual(calls[0].url, 'https://api10.norhartpro.com/api/bean/agent/poll?wait=20&v=1.1.0&p9=2.3.9'); assert.strictEqual(calls[0].init.headers.Authorization, 'Bearer ' + id.token); assert.strictEqual(calls[0].init.credentials, 'omit');
  await c.register(id, 'studio', '1.1.0'); assert(!calls[1].init.headers.Authorization, 'register sends the install token in the body only'); assert.strictEqual(JSON.parse(calls[1].init.body).install_token, id.token);
});
t('api client: server errors keep their code and message; a dead network is a clear "network" error', async () => {
  const bad = async () => ({ ok: false, status: 409, headers: { get: () => '' }, json: async () => ({ error: { code: 'install_exists', message: 'This install already has an API.' } }) });
  const c = new A.BeanApi({ base: 'https://api10.norhartpro.com', fetch: bad, getToken: () => 'bit_x' });
  await assert.rejects(c.regenerate(), (e) => e.status === 409 && e.code === 'install_exists' && /already has/.test(e.message));
  const down = new A.BeanApi({ base: 'https://api10.norhartpro.com', fetch: async () => { throw new TypeError('fetch failed'); } });
  await assert.rejects(down.status(), (e) => e.network === true && e.code === 'network' && /Could not reach/.test(e.message));
});
t('static: Bean never reads the real IP bridge field, the API key is never stored, the tab only talks to the owner through storage', () => {
  const v = fs.readFileSync(path.join(ROOT, 'lib/vpnrot.js'), 'utf8').replace(/\/\/.*$/gm, ''); assert(!/publicIp|pubip/.test(v));
  const e = fs.readFileSync(path.join(ROOT, 'ext11.js'), 'utf8'); assert(!/sset\(KK\.api, \{[^}]*api_key/.test(e)); assert(!/console\.log\([^)]*(token|api_key|S\.key)/.test(e)); assert(/S\.key = r\.api_key/.test(e));
  const c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'); assert(/vpnSwitch\(vpnReq, say, alive, ev\)/.test(c) && /if \(!vr\.ok\) return \{ code: vr\.code/.test(c), 'a failed switch returns before the click'); assert(c.indexOf('vpnSwitch(vpnReq') < c.indexOf('btn.click()'));
});

t('1.1.1: every result code has a plain-English hint; the run log lists every item with reason + code + steps and never an IP address', () => {
  const Lk = require('../lib/links.js');
  for (const c of Object.keys(Lk.CODES)) assert(Lk.hint(c) && Lk.hint(c).length > 10, 'hint for ' + c);
  const b = { id: 'abc', state: 'done', created: Date.now(), updated: Date.now(), pace: 'fast', vpn: { on: true }, items: [
    { vid: 'AAAAAAAAAAA', lc: 'Ugx1', status: 'failed', code: 'wrong-channel', msg: "active is 'A', selected is 'B'", cname: 'C1', chname: 'B', at: Date.now(), lg: [[Date.now(), 'switch', 'verified'], [Date.now(), 'vpn', "connected to 'USA'; exit address changed: yes"]] },
    { vid: 'BBBBBBBBBBB', lc: 'Ugx2', status: 'liked', code: 'liked', cname: 'C1', chname: 'A', at: Date.now(), vpn: { location: 'UK' } }] };
  const r = Lk.runBrief(b), txt = Lk.logText(r);
  assert.strictEqual(r.count, 2); assert.deepStrictEqual(r.by, { 'wrong-channel': 1, liked: 1 });
  assert(/FAILED/.test(txt) && /wrong-channel/.test(txt) && /why:/.test(txt) && /switch — verified/.test(txt) && /exit address changed: yes/.test(txt) && /container 'C1', channel 'B'/.test(txt));
  assert(!/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/.test(txt));
});
t('1.1.1: ledger.storedHas reads ONE shard and answers per channel key', async () => {
  const Lg = require('../lib/ledger.js'); const store = { data: {}, async all() { return this.data; }, async get(k) { const o = {}; for (const x of [].concat(k)) if (x in this.data) o[x] = this.data[x]; return o; }, async set(o) { Object.assign(this.data, o); }, async remove() {} };
  const led = new Lg.Ledger(store); await led.load(); led.add('AAAAAAAAAAA', 'UgxTOP1_unliked_aaaaaaaaaaaaaaaa', 'p:p111', 'l'); await led.flush();
  const get = async (k) => store.get(k);
  assert.strictEqual(await Lg.storedHas(get, 'AAAAAAAAAAA', 'UgxTOP1_unliked_aaaaaaaaaaaaaaaa', 'p:p111'), true);
  assert.strictEqual(await Lg.storedHas(get, 'AAAAAAAAAAA', 'UgxTOP1_unliked_aaaaaaaaaaaaaaaa', 'p:other'), false);
  assert.strictEqual(await Lg.storedHas(get, 'AAAAAAAAAAA', 'UgxTOP2_alreadyliked_bbbbbbbbbbbb', 'p:p111'), false);
});
t('1.1.1: a rotation stops at once when the run is over (no VPN activity after Done)', async () => {
  const V = require('../lib/vpnrot.js'); const calls = [];
  const rot = new V.Rotator({ call: async (a) => { calls.push(a.op); return { ok: true, vpn: { state: 'connected', location: 'x', exitIp: '1' }, routes: [] }; }, timeouts: { connectMs: 500, ipMs: 500, pollMs: 50, settleMs: 0, attempts: 2 } });
  const r = await rot.rotate([{ id: 'a', name: 'A' }, { id: 'b', name: 'B' }], 0, { stop: () => true });
  assert.strictEqual(r.code, 'stopped'); assert.strictEqual(calls.length, 0);
});

t('1.1.1: Panel 9 first-seed race guard — 2 s after the last storage write before a container\'s first tab; the run record is re-verified inside the tab right before the click', () => {
  const pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8'), c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  assert(/lastWriteAt = Date\.now\(\)/.test(pj) && /2000 - \(Date\.now\(\) - lastWriteAt\)/.test(pj) && pj.indexOf('2000 - (Date.now() - lastWriteAt)') < pj.indexOf('openInContainer(toOpen.cid, toOpen.url), ST.stepMs('));
  const k = c.slice(c.indexOf('async function clickOnce')); assert(k.indexOf("cur.state !== 'running'") > 0 && k.indexOf("cur.state !== 'running'") < k.indexOf('btn.click()'));
});

t('1.1.2: ledger — count per comment, manual removal of ONE entry survives a reload and leaves the others (and the pending mirror queue) alone', async () => {
  const st = memStore(); const led = new LG.Ledger(st); await led.load();
  led.add(VID, TOP, 'p:111', 'l'); led.add(VID, TOP, 'p:222', 'a'); led.add(VID2, TOP, 'p:111', 'l'); await led.flush();
  assert.strictEqual(led.count(VID, TOP), 2); assert.strictEqual(led.count(VID, REP), 0);
  assert.strictEqual(led.remove(VID, TOP, 'p:111'), true); assert.strictEqual(led.remove(VID, TOP, 'p:111'), false, 'removing twice does nothing');
  await led.flushAll();
  const b = new LG.Ledger(st); await b.load();
  assert(!b.has(VID, TOP, 'p:111') && b.has(VID, TOP, 'p:222') && b.has(VID2, TOP, 'p:111'));
  assert.strictEqual(b.count(VID, TOP), 1); assert.strictEqual(b.stats().pairs, 2);
  assert(!b.out.some((e) => e[1] === TOP && e[2] === 'p:111' && e[0] === VID), 'a removed entry is not sent to the server any more');
  assert.strictEqual(b.remove(VID, TOP, 'p:222'), true); assert.strictEqual(b.stats().comments, 1);
});
t('1.1.2: static — a channel-reading (discovery) tab is registered too, so a popup closed mid-read cannot leave it open; a freshly opened tab that never loads is given up after OPEN_GRACE_MS', () => {
  const c = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8');
  assert(/regTab\(tab\.tabId, 'disc'/.test(c) && /unregTab\(tab\.tabId\)/.test(c)); assert(/b\.graceUntil = now \+ OPEN_GRACE_MS/.test(c)); assert(/OPEN_GRACE_MS = 45000/.test(c));
});
t('1.1.3: a like that could not be confirmed is shown as "not confirmed" (never as "Liked … YouTube still showed it as liked"); not-started no longer blames the popup', () => {
  const b = { id: 'r', state: 'running', updated: Date.now(), created: Date.now(), items: [{ vid: 'aaaaaaaaaaa', lc: 'Ugx1_aaaaaaaa', status: 'liked', code: 'liked-unverified', msg: 'x', lg: [] }, { vid: 'aaaaaaaaaaa', lc: 'Ugx1_aaaaaaaa', status: 'skipped', code: 'not-started', lg: [] }], groups: [] };
  const r = L.runBrief(b); assert.strictEqual(r.items[0].code, 'liked-unverified'); assert(!/still showed it as liked/.test(r.items[0].why)); assert(/not confirmed|could not be confirmed|did not report back/i.test(r.items[0].label + r.items[0].why));
  assert(!/popup was closed/.test(r.items[1].label)); assert(r.items[0].status === 'ok');
  assert(/did not report back/.test(fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8')));
  const t = L.logText(Object.assign(L.runBrief(b), { orphans: [[Date.now(), '1', '/watch', 'no queued/running item']] })); assert(/could not find their run/.test(t) && /\/watch — no queued/.test(t));
});
t('1.1.3: static — every navigation inside a run goes through goTo (hand-over + explicit URL with the tokens), never location.reload(); the hand-over is bound to video + comment + container + channel, needs the run to still wait for that item, and lasts for at most 6 replacement pages', () => {
  const c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  assert(!/location\.reload\(/.test(c.replace(/\/\/.*$/gm, '')), 'no location.reload() left');
  assert.strictEqual((c.match(/await goTo\(/g) || []).length, 6, 'switch (always from the freshly read list), 1.1.6.1 refresh (same page, unique address), fresh re-read after a stale like, verify, 1.1.6.3 verify-retry (fresh page), next');
  assert(/function adoptBind/.test(c) && /\(bd\.n \|\| 0\) >= 6/.test(c) && /rb\.state !== 'running'/.test(c) && /L\.NAV_GRACE_MS \+ 60000/.test(c) && /u\.pathname !== '\/watch'/.test(c) && /sameV/.test(c));
  assert(/else adoptBind\(\)\.then/.test(c), 'only a page WITHOUT tokens asks for a hand-over');
  assert(/function orphan\(/.test(c) && (c.match(/orphan\(/g) || []).length >= 4);
  const pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8'); assert(/remove\('p9bn\.bind'\)/.test(pj));
});
t('1.1.2: staleAt — a page that announced a navigation keeps the run alive for the grace period; otherwise 45 s', () => {
  const L = require('../lib/links.js'); const now = Date.now();
  assert(L.staleAt({ updated: now - 50000 }) < now);                                       // quiet for 50 s, no navigation announced: lost
  assert(L.staleAt({ updated: now - 50000, graceUntil: now + 60000 }) > now);              // announced a reload / switch / first load: alive
  assert(L.staleAt({ updated: now - 200000, graceUntil: now - 1 }) < now);                 // grace over: lost
  assert(L.NAV_GRACE_MS >= 60000 && L.STALE_MS === 45000);
  const b = { state: 'running', updated: now - 50000, graceUntil: now + 60000, items: [{ status: 'running', vid: 'x' }] };
  assert(L.runBrief(b).items[0].code === 'running' || L.runBrief(b).items[0].code !== 'interrupted');
  assert(L.label('liked-unverified') && L.hint('liked-unverified') && L.kind('liked-unverified') === 'warn');
});
t('1.1.2: static — reloads/switches announce graceUntil; tab registry; dead groups end as liked-unverified / not-started; VPN never switched in parallel with a page load', () => {
  const c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8'), e = fs.readFileSync(path.join(ROOT, 'ext11.js'), 'utf8');
  assert((c.match(/graceUntil: Date\.now\(\) \+ L\.NAV_GRACE_MS/g) || []).length >= 5);        // switch, verify reload, next item, restore, group.active fast path
  assert(/p9bn\.tab\./.test(pj) && /async function regTab/.test(pj) && /async function sweepTabs/.test(pj) && /sweepTabs\(null\)/.test(pj.slice(pj.indexOf('async function stop()'))));
  assert(/liked-unverified/.test(pj) && /not-started/.test(pj.slice(pj.indexOf('function endItems'))) && /it\.sent \|\| it\.verify/.test(pj));
  const pc = c.slice(c.indexOf('async function processComment'), c.indexOf('1.1.1 click safety'));
  assert(!/const vpnP\s*=/.test(pc) && !/await vpnP/.test(pc));                                  // no parallel switch any more
  assert(pc.indexOf("vpnSwitch(Object.assign({}, vpnReq, { check: true") > pc.indexOf('stableState('));        // the confirm is a state read right before the click, after the page is stable
  assert(/vpnBeforeOpen/.test(pj) && pj.indexOf('vpnBeforeOpen(toOpen)') < pj.indexOf('openInContainer(toOpen.cid, toOpen.url), ST.stepMs('));   // the first item's switch happens BEFORE the tab exists
  assert(/rotateNow/.test(e) && /checkNow/.test(e) && /rq\.check \? await checkNow/.test(e));
  assert(/hideOthers/.test(c) && /display:none !important/.test(c) && !/removeChild|\.remove\(\)|cloneNode/.test(c.slice(c.indexOf('function hideOthers'), c.indexOf('async function processComment'))));
});
t('1.1.2: progress panel exists and is computed from the run record only', () => {
  const h = fs.readFileSync(path.join(ROOT, 'popup.html'), 'utf8'), pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8');
  for (const id of ['progress', 'pcount', 'pbar', 'pfill', 'pc-liked', 'pc-already', 'pc-failed', 'pc-left', 'pnow', 'ptime']) assert(h.includes('id="' + id + '"'), id);
  assert(/function progressInfo\(b, now\)/.test(pj) && /elapsed \/ done \* left/.test(pj));
});

t('1.1.4: Pause / Resume wiring (buttons, hold points, 6 h limit, staleness, progress label)', () => {
  const h = fs.readFileSync(path.join(ROOT, 'popup.html'), 'utf8'), pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8'), c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  const L = require(path.join(ROOT, 'lib/links.js'));
  assert(h.includes('id="pause"') && h.includes('id="resume"') && h.indexOf('id="pause"') < h.indexOf('id="stop"'));
  assert(L.PAUSE_MAX_MS === 6 * 3600000);
  const run = { state: 'running', updated: 1000, graceUntil: 0, pauseReq: 5, pause: { since: 2000 } };
  assert(L.staleAt(run) >= 2000 + 6 * 3600000 && L.pauseState(run) === 'paused');
  assert(L.staleAt({ state: 'running', updated: 1000, pauseReq: 5 }) === 1000 + L.STALE_MS && L.pauseState({ state: 'running', pauseReq: 5 }) === 'pausing' && L.pauseState({ state: 'running' }) === '' && L.pauseState({ state: 'done', pauseReq: 5 }) === '');
  assert((c.match(/await holdIfPaused\(/g) || []).length === 6);                       // before the next item's VPN switch, before loading it, before switching back
  const tail = c.slice(c.indexOf('const holdIfPaused'), c.indexOf('const holdIfPaused') + 1500);
  assert(!/location\.assign|goTo\(|\.click\(\)|vpnSwitch/.test(tail));                    // the hold itself never navigates, clicks or switches
  assert(c.indexOf("await holdIfPaused('before the next item')") > c.indexOf('finishGroup(bb, cid)'));       // only reached when this group has another item; always AFTER the item's final result was recorded
  assert(/paused for more than 6 hours/.test(pj) && /L\.PAUSE_MAX_MS/.test(pj) && /!\(b\.pause && b\.pauseReq\) && now - runHeardAt\(b\) > RESUME_MS/.test(pj));
  assert(/pauseReq/.test(pj.slice(pj.indexOf('async function advance'))) && pj.indexOf('if (b.pauseReq) { if (openNow.length)') < pj.indexOf('if (!openNow.length && b.nextAt && now < b.nextAt)'));
  assert(/PAUSED since/.test(pj) && /L\.pauseState\(b\)/.test(pj));
});

t('1.1.5: a liked state on the first page after a channel switch is not believed (one fresh cache-busted reload first); watchUrl bust param', () => {
  const c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), L = require(path.join(ROOT, 'lib/links.js'));
  assert(/code: 'stale-liked'/.test(c) && /\(item\.tries \|\| 0\) >= 1 && !item\.fresh/.test(c) && /res\.code === 'stale-liked'/.test(c));
  assert(c.indexOf("code: 'stale-liked'") < c.indexOf("{ code: 'already', vpn: vpnInfo, msg: item.fresh"));          // the stale check comes before "already" is concluded
  assert(/p9bt=/.test(L.watchUrl('abcdefghijk', 'UgxAAAAAAAAAAAAAAAA', 'tok', 'c1', 'main', 'zz')) && !/p9bt/.test(L.watchUrl('abcdefghijk', 'UgxAAAAAAAAAAAAAAAA', 'tok', 'c1', 'main')));
});

t('1.1.5: Ledger.removeKind removes ONLY the "already" entries of ONE comment (liked entries and other comments untouched)', async () => {
  const LG = require(path.join(ROOT, 'lib/ledger.js'));
  const mem = {}; const store = { all: async () => ({ ...mem }), get: async (ks) => { const o = {}; for (const k of [].concat(ks)) if (k in mem) o[k] = mem[k]; return o; }, set: async (o) => { Object.assign(mem, o); }, remove: async (ks) => { for (const k of [].concat(ks)) delete mem[k]; } };
  const l = new LG.Ledger(store); await l.load();
  const V = 'DEMOvideo01', C = 'UgzDEMOcomment_aaaaaaaaaaaaaaaa', C2 = 'UgzDEMOother_bbbbbbbbbbbbbbbbbb';
  l.add(V, C, 'p:p111', 'l'); l.add(V, C, 'h:@a', 'a'); l.add(V, C, 'h:@b', 'a'); l.add(V, C2, 'h:@a', 'a'); l.add('DEMOvideo02', C, 'h:@a', 'a');
  assert.deepStrictEqual(l.kinds(V, C), { l: ['p:p111'], a: ['h:@a', 'h:@b'] });
  assert.strictEqual(l.removeKind(V, C, 'a'), 2);
  assert.deepStrictEqual(l.kinds(V, C), { l: ['p:p111'], a: [] });
  assert.strictEqual(l.count(V, C2), 1); assert.strictEqual(l.count('DEMOvideo02', C), 1);               // other comments untouched
  assert.strictEqual(l.removeKind(V, C, 'a'), 0);                                                         // nothing left to remove
  assert.ok(l.has(V, C, 'p:p111') && !l.has(V, C, 'h:@a'));                                               // the liked entry stays, the cleared channel may be used again
  await l.flushAll(); const l2 = new LG.Ledger(store); await l2.load(); assert.deepStrictEqual(l2.kinds(V, C), { l: ['p:p111'], a: [] }); assert.strictEqual(l2.count(V, C2), 1);   // persisted
});

t('1.1.5: VPN request path: the tab re-sends every 4 s (fallback flag after 20 s, gives up after 45 s); the owner polls; the runner may answer a fallback; one answerer per request; ledger bar wiring', () => {
  const c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), e = fs.readFileSync(path.join(ROOT, 'ext11.js'), 'utf8');
  const v = c.slice(c.indexOf('async function vpnSwitch'), c.indexOf('async function vpnSwitch') + 3500);
  assert(/nextTry = t0 \+ 4000/.test(v) && /fallback: !!fallback/.test(v) && /> 20000\) *\)/.test(v.replace(/\s+/g, ' ')) || /Date\.now\(\) - t0 > 20000/.test(v));
  assert(/Date\.now\(\) - t0 > 45000/.test(v) && !/> 15000/.test(v));
  const o = e.slice(e.indexOf('async function onVpnReq('), e.indexOf('async function onVpnReq(') + 2600);
  assert(/S\.vseen/.test(o) && /rq\.fallback/.test(o) && /ROLE === 'runner'/.test(o) && /cur\.rid === rq\.rid\) return false/.test(o));    // fallback only by the runner; whoever finds an answer does nothing
  assert(/sget\(KK\.vreq\)\.then\(\(rq\) => \{ if \(rq\) return onVpnReq\(rq\)/.test(e));                 // the 1.5 s poll
  assert(/'remove-already'/.test(e) && /id: 'ledclearalready'/.test(e) && /confirm2\(b, 'Really clear them\?'/.test(e));
  assert(!/removeKind\(.*'l'\)/.test(e));                                                                  // Bean never removes "liked" entries in bulk
});

t('1.1.6: identityVerdict (page ytcfg vs target channel), vote/identity diagnostics, VPN location adopted instead of switched again', () => {
  const L = require(path.join(ROOT, 'lib/links.js')), c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), e = fs.readFileSync(path.join(ROOT, 'ext11.js'), 'utf8');
  const PID = '123456789012345678901';
  assert(L.identityVerdict({ dsid: PID, sync: PID + '||999999999999' }, PID).verdict === 'match');
  assert(L.identityVerdict({ dsid: '', sync: '999999999999||' }, 'main').verdict === 'match');
  assert(L.identityVerdict({ dsid: PID, sync: PID + '||999' }, 'main').verdict === 'MISMATCH');                 // the page is still the brand channel while the main channel is wanted
  assert(L.identityVerdict({ dsid: '', sync: '999||' }, PID).verdict === 'MISMATCH');
  assert(L.identityVerdict({}, PID).verdict === 'unreadable');
  assert(!L.identityVerdict({ dsid: PID, sync: PID + '||999999999999' }, PID).text.includes(PID));              // only the last 6 digits are ever shown
  assert(/ev\('votes', voteText\(c, btn\)\)/.test(c) && /function pageIdentity\(\)/.test(c) && /function voteText\(/.test(c));
  assert(!/\.click\(|dispatchEvent/.test(c.slice(c.indexOf('function pageIdentity'), c.indexOf('function likeButton'))));   // diagnostics are read-only
  assert(/la\.bid === vpnReq\.bid && la\.idx === vpnReq\.idx/.test(c) && /rid: rq\.rid, bid: rq\.bid, idx: rq\.idx, stage: 'done'/.test(e));
  assert(c.indexOf('is adopted (') < c.indexOf("no location was set before this page loaded"));                  // adopt first, switch only when there is nothing to adopt
  assert(/res\.vpn \? \{ vpn:/.test(c));                                                                       // the stale-liked fresh reload keeps the location
});

(async () => {
  for (const [name, fn] of queue) { try { await fn(); n++; console.log('  PASS ', name); } catch (e) { console.log('  FAIL ', name, '\n       ', (e && e.stack || e).toString().split('\n').slice(0, 4).join('\n        ')); process.exitCode = 1; } }
  console.log(process.exitCode ? '\n1.1.0 unit: FAILED' : `\n${n} 1.1.0 unit checks passed`);
})();

t('1.1.6: the Pause request lives in its own storage key (a stale write of the run record cannot wipe it); the tab obeys it, the popup heals the mirror; holds before switching and before an item is processed', () => {
  const L = require(path.join(ROOT, 'lib/links.js')), c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8');
  const b = { id: 'r1', state: 'running' };
  assert(L.pauseWanted({ bid: 'r1', at: 5 }, b) === true && L.pauseWanted({ bid: 'r1', at: 0 }, { id: 'r1', pauseReq: 9 }) === false);   // the key wins over a stale mirror
  assert(L.pauseWanted({ bid: 'OLD', at: 5 }, { id: 'r1', pauseReq: 0 }) === false && L.pauseWanted(null, { id: 'r1', pauseReq: 3 }) === true);   // a key of another run is ignored; no key: the mirror (older runs)
  const w = { id: 'r1', state: 'running', pauseReq: 0 };
  assert(L.applyPauseKey(w, { bid: 'r1', at: 7 }) === true && w.pauseReq === 7 && L.applyPauseKey(w, { bid: 'r1', at: 7 }) === false);        // a wiped mirror is restored
  w.pause = { since: 1 }; assert(L.applyPauseKey(w, { bid: 'r1', at: 0 }) === true && w.pauseReq === 0 && w.pause === null);                    // a resurrected mirror is cleared on Resume
  assert(L.applyPauseKey({ id: 'r1', state: 'done', pauseReq: 0 }, { bid: 'r1', at: 7 }) === false && L.applyPauseKey({ id: 'r2', state: 'running' }, { bid: 'r1', at: 7 }) === false);
  assert(/const pauseOn = async/.test(c) && /L\.pauseWanted\(pk, c\)/.test(c) && /if \(!\(await pauseOn\(c2\)\)\) break;/.test(c) && /patch\(b\.id, null, null, \{\}, mark\)/.test(c));
  assert(/await holdIfPaused\('before switching channel'\)/.test(c) && /await holdIfPaused\('before this item is processed/.test(c) && /X\.hold\('before the VPN location and the like of this item/.test(c));
  assert(c.indexOf("await holdIfPaused('before switching channel')") < c.indexOf("await goTo(target, b, item, cid, 'switch')"));
  assert(/await sset\(K\.pause, \{ bid: c0\.id, at: Date\.now\(\) \}\)/.test(pj) && /at: 0, cleared: Date\.now\(\)/.test(pj) && /let ch = L\.applyPauseKey\(b, pk\)/.test(pj));
});

t('1.1.6: the channel is confirmed from several signals (page session, account menu, header picture) before any click: state machine, retries <= 2, switch-failed, click-time recheck, verify page', () => {
  const c = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  assert(/const sameFetch = L\.sameChannel\(activeNow, want\)/.test(c) && /I\.nextStep\(/.test(c) && /identityNow\(item, await readIdentity\(alive\), cur\)/.test(c));
  const rc = c.slice(c.indexOf('const recheck = async'), c.indexOf('const recheck = async') + 1200);
  assert(/identityNow\(item, info, r\)/.test(rc) && /if \(!idn\.ok\) return \{ ok: false, code: 'wrong-channel'/.test(rc) && rc.indexOf('readIdentity') < rc.indexOf('await readChannels()'));
  assert(/idPre\.verdict === 'confirmed'\)/.test(c) && /I\.orderFirst|one switch saved/.test(c) && /I\.backoffMs\(item\.tries\)/.test(c));
  assert(/verify page: ' \+ vi\.text/.test(c) && /vi\.verdict !== 'confirmed'\) return X\.marker \? \{ code: 'verify-retry'/.test(c) && /\{ code: 'identity-unclear', msg: 'after the click/.test(c));
});

t('1.1.6: lib/identity.js: ytcfg parsing, one verdict from three signals, switch state machine, order planning, page kinds', () => {
  const I = require(path.join(ROOT, 'lib/identity.js'));
  const cfg = (ds, sy) => I.parseYtcfg(['var x=1;', `ytcfg.set({"DELEGATED_SESSION_ID":"${ds}","DATASYNC_ID":"${sy}","SESSION_INDEX":"0","LOGGED_IN":true});`]);
  const brand = cfg('111222333444555666777', '111222333444555666777||999'), main = cfg('', '999||'), brand2 = cfg('', '111222333444555666777||999');
  assert.strictEqual(I.pageChannelId(brand), '111222333444555666777'); assert.strictEqual(I.pageChannelId(main), 'main'); assert.strictEqual(I.pageChannelId(brand2), '111222333444555666777'); assert.strictEqual(I.pageChannelId({}), null);
  const B = { id: '111222333444555666777', name: 'Brand', avatar: 'https://yt3.ggpht.com/a/B=s88-c-k' }, M = { id: 'main', name: 'Me', avatar: 'https://yt3.ggpht.com/a/M=s88-c-k' };
  const full = (info, tgt, act, src) => I.combine(I.signalPage(info, tgt.id), I.signalMenu(act, tgt), I.signalMasthead(src, tgt, act));
  assert.strictEqual(full(brand, B, B, 'https://yt3.ggpht.com/a/B=s24').verdict, 'confirmed');
  assert.strictEqual(full(main, B, B, 'https://yt3.ggpht.com/a/B=s24').verdict, 'mismatch');            // the page is the personal channel: never click
  assert.strictEqual(full(brand, B, M, 'https://yt3.ggpht.com/a/B=s24').verdict, 'conflict');           // page says brand, the menu says personal
  assert.strictEqual(full(brand, B, B, 'https://yt3.ggpht.com/a/M=s24').verdict, 'conflict');           // header picture of another channel
  assert.strictEqual(full(brand, B, B, '').verdict, 'confirmed');                                      // header picture not readable: tolerated, said so
  assert(/not readable: not counted/.test(full(brand, B, B, '').text));
  assert.strictEqual(I.combine(I.signalPage({}, B.id), I.signalMenu(B, B), null).verdict, 'unknown');  // ytcfg unreadable: unknown, never clicks
  assert.strictEqual(I.combine(I.signalPage(brand, B.id), I.signalMenu(null, B), null).verdict, 'unknown');
  assert(!/111222333444555666777/.test(full(brand, B, B, '').text) && /…555666777|…666777/.test(full(brand, B, B, '').text));   // only the last 6 digits are shown
  assert.strictEqual(I.nextStep({ tries: 0, fetchSame: true, verdict: 'confirmed' }), 'proceed');
  assert.strictEqual(I.nextStep({ tries: 0, fetchSame: false, verdict: null }), 'switch'); assert.strictEqual(I.nextStep({ tries: 1, fetchSame: false, verdict: null }), 'fail');
  assert.strictEqual(I.nextStep({ tries: 0, fetchSame: true, verdict: 'mismatch' }), 'switch'); assert.strictEqual(I.nextStep({ tries: 1, fetchSame: true, verdict: 'unknown' }), 'switch'); assert.strictEqual(I.nextStep({ tries: 2, fetchSame: true, verdict: 'conflict' }), 'fail');
  assert(I.backoffMs(1) > 0 && I.backoffMs(1) < I.backoffMs(2) && I.backoffMs(50) <= 6000);
  assert.deepStrictEqual(I.orderFirst(['a', 'b', 'c'], 'c'), ['c', 'a', 'b']); assert.deepStrictEqual(I.orderFirst(['a', 'b'], 'x'), ['a', 'b']); assert.deepStrictEqual(I.orderFirst(['a', 'b'], 'a'), ['a', 'b']);
  assert.strictEqual(I.pageKind({}, 'https://consent.youtube.com/m?continue=x'), 'interstitial'); assert.strictEqual(I.pageKind({ loggedIn: false }, 'https://www.youtube.com/watch?v=x'), 'signed-out'); assert.strictEqual(I.pageKind({ loggedIn: true }, 'https://www.youtube.com/watch'), 'normal');
});

t('1.1.6: Ledger.removeComment removes EVERY entry (liked and already, for every channel) of ONE comment, nothing else; the ledger op also drops its "like sent" markers and voids the old run record items (in-memory store only)', async () => {
  const LG = require(path.join(ROOT, 'lib/ledger.js')), e = fs.readFileSync(path.join(ROOT, 'ext11.js'), 'utf8');
  const mem = {}; const store = { all: async () => ({ ...mem }), get: async (ks) => { const o = {}; for (const k of [].concat(ks)) if (k in mem) o[k] = mem[k]; return o; }, set: async (o) => { Object.assign(mem, o); }, remove: async (ks) => { for (const k of [].concat(ks)) delete mem[k]; } };
  const l = new LG.Ledger(store); await l.load();
  const V = 'DEMOvideo01', C = 'UgzDEMOcomment_aaaaaaaaaaaaaaaa', C2 = 'UgzDEMOother_bbbbbbbbbbbbbbbbbb';
  // Oluchi's case: channel 2 was recorded as liked (the like went to channel 3), channel 3 was recorded as liked (already) and an unticked one as "already": ALL of them go
  l.add(V, C, 'p:ch2', 'l'); l.add(V, C, 'p:ch3', 'l'); l.add(V, C, 'h:@a', 'a'); l.add(V, C2, 'h:@a', 'l'); l.add('DEMOvideo02', C, 'h:@a', 'l');
  assert.strictEqual(l.removeComment(V, C), 3);
  assert.deepStrictEqual(l.kinds(V, C), { l: [], a: [] }); assert.strictEqual(l.has(V, C, 'p:ch2'), false); assert.strictEqual(l.has(V, C, 'p:ch3'), false);
  assert.strictEqual(l.count(V, C2), 1); assert.strictEqual(l.count('DEMOvideo02', C), 1);               // other comments and other videos untouched
  assert.strictEqual(l.removeComment(V, C), 0);
  await l.flushAll(); const l2 = new LG.Ledger(store); await l2.load(); assert.strictEqual(l2.count(V, C), 0); assert.strictEqual(l2.count(V, C2), 1);
  assert(/op === 'remove-comment'/.test(e) && /id: 'ledclearcomment'/.test(e) && /confirm2\(b0, 'Really clear them\?'/.test(e) && /it\.ledgerVoid\) return/.test(e) && /k\.indexOf\('p9bn\.clk\.'\) === 0 && all\[k\]/.test(e));
  assert(/q\.op === 'remove-comment'/.test(e));
});

t('1.1.6: capacity: ledgerRemove posts the removal rows; savedKeys leaves out flagged channels; removals are queued and sent before new entries; pushConfig is serialized and retried; the swap of order planning is re-asserted', async () => {
  const calls = []; const fake = async (url, init) => { calls.push({ url, init }); return { ok: true, status: 200, headers: { get: () => '' }, json: async () => ({ ok: true }) }; };
  const c = new A.BeanApi({ base: 'https://api10.norhartpro.com', fetch: fake, getToken: () => 'bit_x' }); await c.ledgerRemove([['DEMOvideo01', 'UgzDEMOcomment_aaaaaaaaaaaaaaaa', '*']]);
  assert.strictEqual(calls[0].url, 'https://api10.norhartpro.com/api/bean/agent/ledger/remove'); assert.strictEqual(calls[0].init.method, 'POST'); assert.deepStrictEqual(JSON.parse(calls[0].init.body), { entries: [['DEMOvideo01', 'UgzDEMOcomment_aaaaaaaaaaaaaaaa', '*']] });
  const e = fs.readFileSync(path.join(ROOT, 'ext11.js'), 'utf8'), ct = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), pp = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8');
  assert(/s\.has\(ch\.id\) && !badCh\(c\.id, ch\.id\)/.test(e) && /bad: badCh/.test(e), 'savedKeys leaves out flagged channels');
  assert(/L\.possibleLikes\(healthyTargets\(\)/.test(pp) && /!\(x\.channels && !x\.channels\.length\)/.test(pp), 'the possible-likes panel uses the same filter');
  assert(/await flushRm\(\);\s*\n\s*if \(S\.led\.stats\(\)\.overflow\)/.test(e), 'removals go to the server before new entries');
  assert(/queueRm\(\[\[L\.canonVid\(vid\), L\.canonLc\(lc\), '\*'\]\]\)/.test(e) && /e\.status === 404/.test(e) && /await flushRm\(\)\.catch/.test(e), 'comment clear is queued even when this device has none; an old server (404) is tolerated; restore flushes first');
  assert(/if \(S\.cfgBusy\) \{ S\.cfgAgain = true/.test(e) && /S\.cfgRetryT = setTimeout/.test(e), 'one push at a time, failed pushes retried');
  assert(/markStale\(item\.cid, item\.chid, 'the channel could not be switched to'\)/.test(ct) && /markStale\(item\.cid, item\.chid, 'not in the account menu'\)/.test(ct) && /clearStale\(cid, okc\[cid\]\)/.test(e), 'flags are set by the run and lifted by a like');
  assert(/healIdentity = \{ b: b\.id, idx, sj/.test(ct) && /if \(healIdentity && healIdentity\.b === b\.id\)/.test(ct), 'the order-planning trade is re-asserted on every write');
  assert(!/movie_player|ytd-player|googlevideo|querySelector\('video/.test(ct.replace(/\/\/.*$/gm, '')), 'Bean never relies on the player (YouTube Focus 1.4.0 blocks its scripts in comments-only mode)');
  assert(fs.existsSync(path.join(ROOT, 'server-patch-ledger-remove.diff')) && /\/agent\/ledger\/remove/.test(fs.readFileSync(path.join(ROOT, 'tests/server-patched/bean_api.py'), 'utf8')));
});
t('1.1.6.1: switch hotfix — nextStep (refresh when a fresh copy of the page says target; bounded), freshSays, switchMethod; the page-menu click can reach nothing but the avatar, the "Switch account" row and a channel row', () => {
  const I = require('../lib/identity.js'); const ct = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  const S = (o) => I.nextStep(o);
  // 1.1.6.2: the real 1.1.6.1 run showed that same-tab reloads do not help: a NEW tab (reopen) comes first, the same-tab reload is the last resort
  assert.strictEqual(S({ tries: 0, fetchSame: true, verdict: 'mismatch', fresh: 'target' }), 'reopen');
  assert.strictEqual(S({ tries: 1, ro: 1, fetchSame: true, verdict: 'unknown', fresh: 'target' }), 'reopen');
  assert.strictEqual(S({ tries: 1, ro: 2, rf: 0, fetchSame: true, verdict: 'mismatch', fresh: 'target' }), 'switch');          // 1.1.7: no same-tab refresh any more (MAX_REFRESH 0)
  assert.strictEqual(I.MAX_REFRESH, 0);
  assert.strictEqual(S({ tries: 1, ro: 2, rf: 2, fetchSame: true, verdict: 'mismatch', fresh: 'target' }), 'switch');     // budgets spent: the normal switch path (attempt 2)
  assert.strictEqual(S({ tries: 2, ro: 2, rf: 2, fetchSame: true, verdict: 'mismatch', fresh: 'target' }), 'fail');       // …and then it ends: never an endless loop
  assert.strictEqual(S({ tries: 0, fetchSame: true, verdict: 'mismatch', fresh: 'other' }), 'switch');             // the sign-in did not take: switch (again)
  assert.strictEqual(S({ tries: 0, fetchSame: true, verdict: 'mismatch', fresh: 'unknown' }), 'switch');
  assert.strictEqual(S({ tries: 1, fetchSame: true, verdict: 'mismatch', fresh: 'unknown' }), 'reopen');
  assert.strictEqual(S({ tries: 2, fetchSame: true, verdict: 'mismatch', fresh: 'other' }), 'fail');
  assert.strictEqual(S({ tries: 0, fetchSame: false, verdict: null, fresh: 'target' }), 'switch');                 // the menu itself does not say target: a fresh page cannot override it
  assert.strictEqual(S({ tries: 0, fetchSame: true, verdict: 'confirmed', fresh: 'other' }), 'proceed');
  assert.strictEqual(S({ tries: 0, fetchSame: true, verdict: 'conflict' }), 'switch');
  // reopen + refresh + switch attempts are each bounded: no sequence of verdicts can exceed MAX_REOPEN + MAX_REFRESH + MAX_SWITCH_TRIES page loads
  for (const fr of ['target', 'other', 'unknown']) { let tries = 0, rf = 0, ro = 0, loads = 0; for (;;) { const s = S({ tries, rf, ro, fetchSame: true, verdict: 'mismatch', fresh: fr }); if (s === 'fail') break; loads++; if (s === 'refresh') rf++; else if (s === 'reopen') ro++; else tries++; assert(loads < 12); } assert(loads <= I.MAX_REOPEN + I.MAX_REFRESH + I.MAX_SWITCH_TRIES, fr + ' ' + loads); }
  const ytc = (id) => 'ytcfg.set({"DELEGATED_SESSION_ID":"' + id + '","DATASYNC_ID":"' + id + '||1","SESSION_INDEX":"0","LOGGED_IN":true});';
  assert.strictEqual(I.freshSays(I.parseYtcfg(['<html><script>' + ytc('111222333444555666777') + '</script>']), '111222333444555666777'), 'target');
  assert.strictEqual(I.freshSays(I.parseYtcfg([ytc('999')]), '111'), 'other'); assert.strictEqual(I.freshSays({}, '111'), 'unknown'); assert.strictEqual(I.freshSays(I.parseYtcfg([ytc('1')]), ''), 'unknown');
  assert.strictEqual(I.switchMethod(0), 'url'); assert.strictEqual(I.switchMethod(1), 'ui');
  // static: the account-menu helper never touches a like/comment element; it only clicks the avatar, the "Switch account" row and a channel row (and is never reached from the like path)
  const a = ct.indexOf('async function uiSwitch'), z = ct.indexOf('function pageIdentity'), ui = ct.slice(a, z);
  assert(a > 0 && z > a);
  assert((ui.match(/\.click\(\)/g) || []).length === 3, 'exactly 3 clicks: avatar, Switch account row, channel row');
  assert(!/like|dislike|vote|ytd-comment|comment/i.test(ui.replace(/\/\/.*$/gm, '')), 'no like / comment element is named in the menu helper');
  assert(!/dispatchEvent\(new (Mouse|Pointer)/.test(ui));
  assert(ct.split('uiSwitch(').length === 3, 'called from exactly one place (the switch step), defined once');
  const sw = ct.slice(ct.indexOf("else if (step === 'refresh')"), ct.indexOf("} else { item.chname = want.name; ev('switch', `verified"));
  assert(!/processComment|clickOnce|btn\.click/.test(sw), 'neither the refresh nor the switch step can reach the like path');
  assert(/rf: \(item\.rf \|\| 0\) \+ 1/.test(sw) && /goTo\(L\.watchUrl\(item\.vid, item\.lc, b\.id, cid, item\.chid, Date\.now\(\)\.toString\(36\)\), b, item, cid, 'switch'\)/.test(sw), 'refresh counts itself and loads a unique address');
  assert(/L\.switchUrl\(want, L\.watchUrl\(item\.vid, item\.lc, b\.id, cid, item\.chid, Date\.now\(\)\.toString\(36\)\)\)/.test(sw), 'the sign-in next= is a unique address too');
  assert(/I\.nextStep\(\{ tries: item\.tries \|\| 0, rf: item\.rf \|\| 0, ro: item\.ro \|\| 0, fetchSame: sameFetch, verdict: idn \? idn\.verdict : null, fresh \}\)/.test(ct));
  assert(/unregister\(\)/.test(ct) && /caches\.delete\(k\)/.test(ct) && /getRegistrations/.test(ct));
  assert(/identityNow\(item, info, r\)/.test(ct) && /right before the click: /.test(ct), 'the gate right before the click is unchanged (3 signals)');
});

t('1.1.6.2: reopen (a NEW tab after a switch: the real 1.1.6.1 run) never reaches the like path and is bounded; the menu switch finds its row by structure only (no label text, any language)', () => {
  const ct = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), I = require('../lib/identity.js'), pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8');
  const ro = ct.slice(ct.indexOf('const reopenNow = async'), ct.indexOf('const idPre =')) + ct.slice(ct.indexOf("else if (step === 'reopen')"), ct.indexOf("} else if (step === 'refresh')"));
  assert(ro.length > 200 && ro.length < 3500 && /await reopenNow\(/.test(ro));
  assert(!/processComment|clickOnce|btn\.click|goTo\(|\.click\(/.test(ro), 'the reopen step clicks nothing and navigates nowhere: it only hands the item back');
  assert(/status: 'queued'/.test(ro) && /ro: \(item\.ro \|\| 0\) \+ 1/.test(ro) && /gg\.status = 'queued'/.test(ro) && /gg\.recycle = \(gg\.recycle \|\| 0\) \+ 1/.test(ro) && /stripToken\(\);/.test(ro));
  assert.strictEqual(I.MAX_REOPEN, 2);
  assert(/next\.recycle \|\| 0/.test(pj) && /opened\.delete\(toOpen\.okey\)/.test(pj), 'the popup opens a reopened container once more (the opened-key carries the reopen count)');
  const a = ct.indexOf('function switchRows'), z = ct.indexOf('function pageIdentity'), ui = ct.slice(a, z).replace(/\/\/.*$/gm, '');
  assert(a > 0 && z > a);
  assert(!/[^\x00-\x7f]/.test(ui), 'no non-ASCII (language-specific) text in the menu helper');
  assert(!/switch account|sign out|SWITCH_ROW|\.textContent\)?\.test|\/[a-z|\s]{6,}\/i/i.test(ui.replace(/ytd-[a-z-]+|tp-yt-paper-[a-z-]+/g, '')), 'no label matching');
  assert(!/textContent/.test(ui.slice(ui.indexOf('async function uiSwitch'), ui.indexOf('const norm'))), 'the switcher row is chosen without reading any text');
  assert(/hasAddr/.test(ui) && /rows\.length >= 3 \? rows\.slice\(0, -1\)/.test(ui) && /cands\.length !== 1/.test(ui), 'structure only: rows without an address, never the last row of a 3-row section, exactly one candidate');
  assert(!/SWITCH_ROW/.test(ct));
});

t('1.1.6.2: the settle poll only asks fresh copies (no navigation, no click) and is bounded', () => {
  const ct = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  const a = ct.indexOf('let fp = straight'), z = ct.indexOf('fresh = fp.says;', a), sl = ct.slice(a, z);
  assert(a > 0 && z > a && /SETTLE_POLLS/.test(sl) && /sleep\(SETTLE_MS\)/.test(sl) && !/goTo\(|\.click\(|processComment|location\./.test(sl));
  assert(/const SETTLE_POLLS = 3, SETTLE_MS = 3000;/.test(ct));
});

t('1.1.7: ONE VPN rotation per like attempt: an item that already has its location (pre-switched, or reopened in a fresh tab, or handed back) keeps it before its tab opens', () => {
  const pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8'), a = pj.indexOf('async function vpnBeforeOpen'), body = pj.slice(a, a + 4200);
  const k = body.indexOf('it.vpn && it.vpn.location !== undefined'), r = body.indexOf('B11.rotateNow');
  assert(k > 0 && r > k, 'the keep-the-location check comes BEFORE the rotation');
  assert(/kept the location/.test(body) && /vpnSkip/.test(body));
});

// ======================================================================================================== 1.1.6.3 (the real 1.1.6.2 run z09pnf5pmvyrefxt)
t('1.1.6.3: after a switch the not-confirmed tab goes STRAIGHT to a fresh tab (no probe, no settle wait, no same-tab reload); the reopened tab probes as before', () => {
  const ct = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  assert(/const straight = sameFetch && \(item\.tries \|\| 0\) >= 1 && \(item\.ro \|\| 0\) < 1;/.test(ct));
  assert(/let fp = straight \? \{ says: 'target'[^}]*straight: true \} : await freshProbe\(item\.chid\);/.test(ct));
  assert(/for \(let k = 0; !fp\.straight && k < SETTLE_POLLS/.test(ct));
  assert(/bb\.nextAt = nowR \+ 1500;/.test(ct), 'the reopen gap is 1.5 s');
  assert.strictEqual(require('../lib/identity.js').MAX_REFRESH, 0);
});
t('1.1.6.3: ONE VPN rotation per like attempt: an item that already has its location keeps it before its tab opens (a reopen / hand-back is not a new like)', () => {
  const pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8'), a = pj.indexOf('async function vpnBeforeOpen'), body = pj.slice(a, a + 4200);
  const k = body.indexOf('it.vpn && it.vpn.location !== undefined'), r = body.indexOf('B11.rotateNow');
  assert(k > 0 && r > k, 'the keep-the-location check comes BEFORE the rotation');
  assert(/kept the location/.test(body) && /vpnSkip/.test(body));
});
t('1.1.6.3: VERIFY never says not-found / never clicks again: a sent like whose fresh page shows no comment, no button, an unclear session or an unreadable state is read again (bounded), then ends as liked-unverified with the reason', () => {
  const ct = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  assert(/X\.verify && X\.marker\) return \{ code: 'verify-retry', msg: 'the comment was not on the fresh page'/.test(ct));
  assert(/X\.verify && X\.marker \? \{ code: 'verify-retry', msg: 'the like button was not on the fresh page' \}/.test(ct));
  assert(/code: 'verify-retry', msg: 'the like state could not be read on the fresh page'/.test(ct));
  assert(/const VERIFY_TRIES = 3;/.test(ct) && /vt < VERIFY_TRIES/.test(ct) && /code: 'liked-unverified', msg: `The like was sent/.test(ct));
  const a = ct.indexOf("res.code === 'verify-retry' && !stop"), z = ct.indexOf("if (stop) { clearInterval(poll); toast('Bean · stopped'", a), seg = ct.slice(a, z);
  assert(a > 0 && z > a && !/\.click\(|clickOnce|processComment/.test(seg), 'the retry path cannot click');
  assert(/res\.code === 'liked-unverified' \? 'liked'/.test(ct), 'recorded as liked (sent), kept in the ledger');
});
t('1.1.6.3: the click line is always logged: it lives in the safety marker too and is restored on the verify page; the run record write after the click is awaited (bounded)', () => {
  const ct = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  assert(/clickEv: \[Date\.now\(\), 'click'/.test(ct) && /recovered from the safety marker/.test(ct));
  assert(/await Promise\.race\(\[X\.onSent\(\), sleep\(2500\)\]\)/.test(ct));
});
t('1.1.6.3: a tab counts as closed only after the bridge confirmed it; the registry is read back after a write; a tab that will not close stops the next open (one-tab rule)', () => {
  const pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8');
  const a = pj.indexOf('async function closeTabId'), z = pj.indexOf('// close the tabs of a run', a), seg = pj.slice(a, z);
  assert(/closing\.has\(key\)/.test(seg) && /for \(let n = 0; n < 3; n\+\+\)/.test(seg));
  assert(seg.indexOf('closedTabs.add') > seg.indexOf('await bridge().closeTab'), 'closedTabs is only set after the call succeeded');
  assert(!/closedTabs\.add\(key\);\s*try/.test(seg), 'not marked closed before the call');
  assert(/async function sweepVerified/.test(pj) && /const sv = await ST\.step\('verify-closed', sweepVerified\(keepOthers\(b, toOpen\.cid\)\)\)/.test(pj) && /if \(!sv\.ok\)/.test(pj) && /tabCloseFails/.test(pj));
  const r = pj.indexOf('async function regTab'), rz = pj.indexOf('async function unregTab', r);
  assert(/read back|readback|some\(\(x\) => x\.id === id\)\) return; await put\(\)/.test(pj.slice(r, rz)));
  assert(/for \(const ms of \[5000, 15000\]\) setTimeout/.test(pj), 'stop sweeps again for a straggler');
});
t('1.1.6.3: eco pace; no idle polling loops (the page-state report is not a 2 s timer on every YouTube page; the API loop sleeps 8 s while the API is off)', () => {
  assert.deepStrictEqual(Object.keys(L.PACES), ['fast', 'normal', 'slow', 'eco']); assert(L.PACES.eco[0] >= 14);
  assert(/value="eco"/.test(fs.readFileSync(path.join(ROOT, 'popup.html'), 'utf8')));
  const ct = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), e = fs.readFileSync(path.join(ROOT, 'ext11.js'), 'utf8');
  assert(!/setInterval\(\(\) => report\(false\), 2000\)/.test(ct) && /report\(false\); \}, 15000\)/.test(ct));
  assert(/await sleep\(S\.client && apiOn\(\) \? 1500 : 8000\)/.test(e));
});

t('1.1.6.3: ONE persistent pace (p9bn.pace) for popup runs, API jobs and queued orders: read fresh before every gap, shown in the popup and in the run log', () => {
  assert.strictEqual(L.PACE_KEY, 'p9bn.pace');
  assert.strictEqual(L.pickPace({ pace: 'eco' }, 'fast'), 'eco'); assert.strictEqual(L.pickPace(null, 'fast'), 'fast'); assert.strictEqual(L.pickPace({ pace: 'bogus' }, 'bogus'), 'normal'); assert.strictEqual(L.pickPace('slow', 'x'), 'slow');
  assert.strictEqual(L.paceLabel('eco'), 'Eco (14–30 s)'); assert.strictEqual(L.paceLabel('nope'), 'Normal (4–10 s)');
  const ct = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8'), e = fs.readFileSync(path.join(ROOT, 'ext11.js'), 'utf8'), ph = fs.readFileSync(path.join(ROOT, 'popup.html'), 'utf8');
  assert(/pace: 'p9bn\.pace'/.test(ct) && /async function readPace/.test(ct) && /if \(first\) await readPace\(b, ev\);/.test(ct) && /L\.pauseMs\(L\.pickPace\(paceStored, b\.pace\)\)/.test(ct) && /L\.pauseMs\(L\.pickPace\(paceStored, bb\.pace\)\)/.test(ct), 'the tab reads it before each gap');
  assert(!/L\.pauseMs\(b\.pace\)|L\.pauseMs\(bb\.pace\)/.test(ct + pj), 'no gap uses the pace frozen in the run record');
  assert(/pace: 'p9bn\.pace'/.test(pj) && /L\.pauseMs\(L\.pickPace\(pcs, b\.pace\)\)/.test(pj) && /function showPace/.test(pj) && /pace changed to /.test(pj) && /c\[K\.pace\]/.test(pj), 'the popup: stored, gap, note, event, storage sync');
  assert(/id="paceNote"/.test(ph));
  assert(/pace = L\.pickPace\(await sget\(K\.pace\), settings\.pace\)/.test(e), 'API jobs use the saved pace');
  const log = L.logText({ id: 'r1', state: 'done', created: 1, updated: 2, pace: 'eco', vpnOn: false, items: [], by: {}, count: 0 }); assert(/pace: Eco \(14–30 s\)/.test(log), log.slice(0, 200));
});

t('1.1.6.3: a page that follows a switch and whose own session is still another channel goes straight to a fresh tab BEFORE the switcher read / probe (one shared reopenNow), the VPN location is kept', () => {
  const ct = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8');
  const a = ct.indexOf('const reopenNow = async'), k = ct.indexOf("idPre.verdict === 'mismatch'"), r = ct.indexOf('await readChannels(', k), sk = ct.indexOf('const skipRead');
  assert(a > 0 && k > a && k < sk && sk < r, 'the shortcut comes before the channel list is read');
  assert(/\(item\.tries \|\| 0\) >= 1 && \(item\.ro \|\| 0\) < 1 && idPre/.test(ct));
  assert((ct.match(/await reopenNow\(/g) || []).length === 3, 'the shortcut, the probe path and the unanswered-step path share one reopen');
  assert(!/readChannels|freshProbe|goTo\(|\.click\(/.test(ct.slice(ct.indexOf("if (item.chid && !verifyMode && (item.tries || 0) >= 1 && (item.ro || 0) < 1 && idPre"), sk)), 'no read, probe, navigation or click on that path');
});

t('1.1.6.4: Bean never takes focus: no focus()/hasFocus/visibilityState/document.hidden in the tab script or the runner, a tab open asks Panel 9 for a BACKGROUND tab only when p9bn.bgTabs is true, the popup focuses only its own box', () => {
  const ct = fs.readFileSync(path.join(ROOT, 'content.js'), 'utf8'), pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8'), e11 = fs.readFileSync(path.join(ROOT, 'ext11.js'), 'utf8');
  const strip = (x) => x.replace(/\/\/[^\n]*/g, '').replace(/\/\*[\s\S]*?\*\//g, '');
  const bad = [/\.focus\(/, /hasFocus/, /visibilityState/, /document\.hidden/, /window\.focus/, /chrome\.(tabs|windows)\./];
  for (const re of bad) assert(!re.test(strip(ct)), 'content.js must not use ' + re);
  assert(!/hasFocus|visibilityState|window\.focus|chrome\.(tabs|windows)\./.test(strip(e11)) && !/hasFocus|visibilityState|window\.focus|chrome\.(tabs|windows)\./.test(strip(pj)));
  // 1.1.6.5: the flag is only sent when p9bn.bgTabs === true (see the next test); there is no unconditional background: true any more
  assert(!/openTabInContainer\(\{[^}]*\bbackground: true/.test(strip(pj).replace(/\.\.\.\(\(await bgTabsNow\(\)\) \? \{ background: true \} : \{\}\)/, '')) && !/background: true \}\)/.test(strip(pj)), 'no unconditional background: true')
  assert(/if \(ROLE === 'popup'\) els\.links\.focus\(\)/.test(pj) && (strip(pj).match(/\b\w+(\.\w+)?\.focus\(/g) || []).every((m) => /^(els\.links|e2)\.focus\($/.test(m)));      // only the popup's own text boxes (a user action in the popup page)
});

t('1.1.6.5: background tabs are off by default: background:true is sent ONLY for p9bn.bgTabs === true (strict), at both tab opens; the run log names the open mode', () => {
  const pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8'), e11 = fs.readFileSync(path.join(ROOT, 'ext11.js'), 'utf8');
  assert.strictEqual(L.BGTABS_KEY, 'p9bn.bgTabs');
  assert.strictEqual(L.bgTabsOn(true), true);
  for (const v of [undefined, null, false, 0, 1, 'true', 'on', {}, { on: true }, []]) assert.strictEqual(L.bgTabsOn(v), false, 'off for ' + JSON.stringify(v));
  assert.strictEqual(L.openModeLabel(false), 'tabs open normally'); assert.strictEqual(L.openModeLabel(true), 'background tabs requested');
  const strip = (x) => x.replace(/\/\/[^\n]*/g, '').replace(/\/\*[\s\S]*?\*\//g, '');
  // the run opener builds { url, containerId } and adds background only when the fresh setting is true
  assert(/const args = \{ url, containerId: cid \}; lastOpenBg = await bgTabsNow\(\); if \(lastOpenBg\) args\.background = true; return b\.openTabInContainer\(args\)/.test(strip(pj)), 'run opener');
  assert(/\.\.\.\(\(await bgTabsNow\(\)\) \? \{ background: true \} : \{\}\)/.test(strip(pj)), 'discovery opener');
  assert(!/background\s*:\s*(true|false)/.test(strip(e11)), 'ext11 never sets background');
  assert(/bgTabsNow = async \(\) => \{ try \{ return L\.bgTabsOn\(await sget\(L\.BGTABS_KEY\)\)/.test(strip(pj)));
  // the run log shows the mode
  const b = { id: 'x1', state: 'done', created: 1, updated: 2, pace: 'normal', items: [], groups: [], openMode: 'tabs open normally', events: [[3, 'open mode — tabs open normally']] };
  const txt = L.logText(L.runBrief(b));
  assert(/open mode: tabs open normally/.test(txt) && /open mode — tabs open normally/.test(txt), txt.slice(0, 300));
  assert(/open mode: background tabs requested/.test(L.logText(L.runBrief(Object.assign({}, b, { openMode: 'background tabs requested' })))));
  assert(/^1\.1\.7/.test(JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8')).version));
});

t('1.1.7: the settings switch "Background tabs (needs Panel 9 2.3.24+)": a plain checkbox next to the pace, default off, writes ONLY the key p9bn.bgTabs (true, or the key removed)', () => {
  const h = fs.readFileSync(path.join(ROOT, 'popup.html'), 'utf8'), pj = fs.readFileSync(path.join(ROOT, 'popup.js'), 'utf8');
  assert(/<label class="opt" for="bgTabs"><input type="checkbox" id="bgTabs">(?![^>]*checked)/.test(h), 'unchecked checkbox in the same label.opt style as the other switches');
  assert(/Background tabs \(needs Panel 9 2\.3\.24\+\)/.test(h), 'label text');
  assert(h.indexOf('id="pace"') < h.indexOf('id="bgTabs"') && h.indexOf('id="bgTabs"') < h.indexOf('id="go"'), 'sits after the pace, before the buttons');
  assert(/if \(bg\.checked\) await sset\(L\.BGTABS_KEY, true\); else await chrome\.storage\.local\.remove\(L\.BGTABS_KEY\)/.test(pj), 'writes true / removes the key');
  assert(!/sset\(L\.BGTABS_KEY, false\)/.test(pj));
});
