// Bean 1.1.7.9: parallel open must not kill sibling tabs; stuck opening must free the wave
const fs = require('fs'), path = require('path'), S = require('../lib/steps.js');
let p = 0, f = 0; const ok = (n, c) => { if (c) p++; else { f++; console.log('FAIL ' + n); } };
const root = path.join(__dirname, '..');
const pj = fs.readFileSync(path.join(root, 'popup.js'), 'utf8');
ok('manifest 1.1.7.9', JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8')).version === '1.1.7.9');
ok('closeExcept only kills target cid tabs', /one-tab-per-container only for THIS cid/.test(pj) && /Never close another parallel container/.test(pj));
ok('closeExcept does not sweep myTabs of siblings', /async function closeExcept[\s\S]*?for \(const id of kill\) await closeTabId/.test(pj) && !/async function closeExcept[\s\S]*?for \(const id of \[\.\.\.myTabs\]\)/.test(pj));
ok('keepOthers keeps mem/tabOf/wave siblings even if record lost opening/running', /stale mirror copy can lose other groups/.test(pj) && /tabOf\.has\(b\.id \+ ':' \+ c\)/.test(pj) && /w\.cids/.test(pj));
ok('sweepVerified never called with null while opening next wave member', /keepSiblings/.test(pj) && /NEVER sweepVerified\(null\) while other containers/.test(pj));
ok('closeOneGroup never closeRunTabs all on null keep', /never closeRunTabs\('all'\)/.test(pj) && !/if \(!keep\) \{ await closeRunTabs\(b, 'all'\)/.test(pj));
ok('open with no tabId hands back (no wedged opening)', /open returned no tab id/.test(pj) && /handBackHung\(toOpen/.test(pj));
ok('VPN prepare null hands back previous open', /VPN prepare returned no URL/.test(pj) && /handBack\(prevOpen/.test(pj));
ok('stuck opening >90s with no tab frees the slot', /stuck opening >90 s with no tab/.test(pj) && /g\.status === 'opening' && g\.openedAt && now - g\.openedAt > 90000/.test(pj));
// pickOpen: a stuck opening container still occupies a slot; after we hand it back to queued, next can open
{ const b = { groups: [{ cid: 'c0', status: 'opening' }, { cid: 'c1', status: 'queued' }, { cid: 'c2', status: 'queued' }, { cid: 'c3', status: 'queued' }], items: [], vpn: { on: true } };
  ok('opening occupies a parallel slot', S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0'] }, cap: 4 }).cid === 'c1');
  b.groups[0].status = 'queued'; // handed back after stuck-opening watchdog
  const r = S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0'] }, lastOpenAt: 0, cap: 4 });
  ok('after stuck-opening handback, same wave member can reopen', r.cid === 'c0');
}
{ const b = { groups: [{ cid: 'c0', status: 'opening', openedAt: 1 }, { cid: 'c1', status: 'running' }, { cid: 'c2', status: 'running' }, { cid: 'c3', status: 'queued' }], items: [], vpn: { on: false } };
  ok('4th cannot open while 3 slots busy including stuck opening', S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0','c1','c2'] }, cap: 3 }).cid === null);
  b.groups[0].status = 'queued'; delete b.groups[0].openedAt;
  ok('freeing stuck opening unblocks wave progress', S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0','c1','c2'] }, lastOpenAt: 0, cap: 3 }).cid === 'c0' || S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c1','c2'] }, lastOpenAt: 0, cap: 3 }).cid != null);
}
console.log('unit179: ' + p + ' passed, ' + f + ' failed');
process.exit(f ? 1 : 0);
