// Bean 1.1.7.9: Parallel / Single popup toggle -> pickOpen capacity 4 vs 1
const S = require('../lib/steps.js'), fs = require('fs'), path = require('path');
let p = 0, f = 0; const ok = (n, c) => { if (c) p++; else { f++; console.log('FAIL ' + n); } };
const root = path.join(__dirname, '..');
const mk = (n) => { const groups = [], items = []; for (let i = 0; i < n; i++) { groups.push({ cid: 'c' + i, status: 'queued' }); items.push({ cid: 'c' + i, status: 'queued' }); } return { id: 'r', groups, items, vpn: { on: false } }; };
const open = (b) => b.groups.filter((g) => g.status === 'opening' || g.status === 'running');
function drive(b, cap) {
  let wave = null, t = 1e6, last = 0, maxOpen = 0, passes = 0, rnd = 7;
  const r = () => { rnd = (rnd * 1103515245 + 12345) % 2147483648; return rnd / 2147483648; };
  while (b.groups.some((g) => g.status !== 'done') && passes < 20000) {
    passes++; t += 1000;
    for (const g of open(b)) if (r() < 0.01) g.status = 'done';
    const pl = S.pickOpen(b, { now: t, wave, lastOpenAt: last, cap });
    if (pl.wave) wave = pl.wave;
    if (pl.cid != null) { const g = b.groups.find((x) => x.cid === pl.cid); g.status = 'opening'; last = t; }
    maxOpen = Math.max(maxOpen, open(b).length);
  }
  return { finished: b.groups.every((g) => g.status === 'done'), maxOpen, waves: wave ? wave.n : 0 };
}
ok('manifest 1.1.7.9', JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8')).version === '1.1.7.9');
{ const r = drive(mk(6), 4); ok('Parallel cap=4: finishes and reaches 4 open', r.finished && r.maxOpen === 4); ok('Parallel 6 containers = 2 waves (4+2)', r.waves === 2); }
{ const r = drive(mk(6), 1); ok('Single cap=1: finishes and never >1 open', r.finished && r.maxOpen === 1); ok('Single 6 containers = 6 waves of 1', r.waves === 6); }
{ const b = mk(3); b.groups[0].status = 'running'; ok('Single: second container waits while first open', S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0'] }, cap: 1 }).cid === null); }
{ const b = mk(3); b.groups[0].status = 'done'; const r = S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0'] }, cap: 1 }); ok('Single: next wave of 1 starts after previous done', r.cid === 'c1' && r.wave && r.wave.n === 2 && r.wave.cids[0] === 'c1'); }
const ph = fs.readFileSync(path.join(root, 'popup.html'), 'utf8');
const pj = fs.readFileSync(path.join(root, 'popup.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'popup.css'), 'utf8');
ok('popup has Parallel / Single radios', /id="parParallel"/.test(ph) && /id="parSingle"/.test(ph) && /> Parallel </.test(ph) && /> Single </.test(ph));
ok('Likes needed visible in runopts (no hidden attr on qrow)', /id="runopts"/.test(ph) && /id="qrow" class="qrow"><label for="qall">Likes needed/.test(ph) && !/<div id="qrow"[^>]*\bhidden\b/.test(ph));
{ const iRun = ph.indexOf('id="runopts"'), iQrow = ph.indexOf('id="qrow"'), iCboxEnd = ph.indexOf('</div>\n    <div id="nobridge"');
  ok('qrow lives inside runopts, outside cbox', iRun > 0 && iQrow > iRun && (iCboxEnd < 0 || iQrow > iCboxEnd)); }
ok('toggle persists via p9bn.parallel / saveParallelMode', /PAR_KEY = 'p9bn\.parallel'/.test(pj) && /saveParallelMode/.test(pj) && /parallelModeNow/.test(pj));
ok('parallelCap reads PAR_KEY (Single=1 Parallel=4)', /sget\(PAR_KEY\)/.test(pj) && /async function parallelCap/.test(pj));
ok('Likes needed never gated: updLikesNeededHint keeps qrow visible', /updLikesNeededHint/.test(pj) && /els\.qrow\.hidden = false/.test(pj));
ok('runopts styles present', /\.runopts/.test(css) && /\.paropt/.test(css));
console.log('unit178: ' + p + ' passed, ' + f + ' failed');
process.exit(f ? 1 : 0);
