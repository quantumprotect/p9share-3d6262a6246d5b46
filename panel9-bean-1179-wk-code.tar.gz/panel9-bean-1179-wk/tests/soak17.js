'use strict';
// Bean 1.1.7 ACCELERATED SOAK (node, fake clock). Simulates many hours of unattended work in seconds: popup + API orders arriving, the real Dispatcher / lease / pump / watchdog / recycle /
// endItems / housekeeping modules, and a simulated tab pool with random outcomes and injected faults (tab crash, stalls, crash right after a click, Focus off, VPN down, background runner
// outages, Panel 9 restarts, duplicate requests, user cancels / moves).
// Run: node tests/soak17.js            (SOAK_HOURS=12 SOAK_SEEDS=1,2,3 to change)
const L = require('../lib/links.js'), O = require('../lib/orders.js'), E = require('../lib/errors.js');
const { World, rng } = require('./sim17.js');
const HOURS = Number(process.env.SOAK_HOURS || 12), SEEDS = String(process.env.SOAK_SEEDS || '1').split(',').map(Number);
let totalFail = 0;
const vid = (i) => 'v' + String(i).padStart(10, '0'), lcid = (i) => 'Ugx' + String(i).padStart(25, 'K');

async function soak(seed) {
  const R = rng(seed * 7919 + 13); const w = new World({ seed, vpn: true, itemMs: 15000 }); const io = w.store();
  const mkPage = (id) => new O.Dispatcher({ store: io, clock: w.clock, ports: w.ports({ onFinal: async (o) => { w.finals.push(JSON.parse(JSON.stringify(o))); } }) });
  const pages = { runner: { d: mkPage('runner'), up: true }, popup: { d: mkPage('popup'), up: true } };
  const t0 = w.t, end = t0 + HOURS * 3600000, drainEnd = end + 5 * 3600000;
  let reqN = 0, jobN = 0, nextOrder = t0 + 60000, nextApi = t0 + 120000, nextFault = t0 + 30 * 60000, nextCancel = t0 + 40 * 60000, nextRestart = t0 + 3 * 3600000, nextMetric = t0;
  const out = { orders: 0, api: 0, refused: 0, cancels: 0, moves: 0, restarts: 0, runnerOutages: 0, focusOff: 0, vpnDown: 0, dups: 0, maxBytes: 0, maxOpen: 0, maxHist: 0 };
  let focusUntil = 0, vpnUntil = 0, runnerUntil = 0, linkI = 0;
  const targetsNow = () => w.targets;
  const reqs = []; const popupSubmit = async () => {
    const n = 1 + Math.floor(R() * 3), links = []; for (let i = 0; i < n; i++) { const k = linkI++ % 240; links.push({ n: i + 1, vid: vid(k % 40), lc: lcid(k), quantity: R() < 0.35 ? 1 + Math.floor(R() * 4) : null, url: '' }); }
    const cur = (await io.get(O.INBOX)) || []; const r = { id: 'r' + (++reqN), op: 'submit', spec: { links, targets: targetsNow(), pace: 'fast' }, at: w.t }; cur.push(r); if (R() < 0.05) { cur.push(Object.assign({}, r)); out.dups++; } await io.set(O.INBOX, cur.slice(-100)); out.orders++;
  };
  const apiSubmit = async () => { const k = linkI++ % 240; const spec = { src: 'api', jobId: 'job' + (++jobN), links: [{ n: 1, vid: vid(k % 40), lc: lcid(k), quantity: 1 + Math.floor(R() * 5), url: '' }], targets: targetsNow() }; const exec = pages.runner.up && w.t > runnerUntil ? pages.runner : pages.popup; const r = await (exec.d.held ? exec.d.submit(spec) : (async () => { await O.pump(exec.d, io, exec === pages.runner ? 'runner' : 'popup'); return exec.d.submit(spec); })()); out.api++; if (!r.ok) out.refused++; if (R() < 0.04) { const r2 = await exec.d.submit(spec); if (!r2.dup) w.violations.push('api dup not idempotent'); } };
  let sec = 0;
  while (w.t < drainEnd) {
    const now = w.t;
    // arrivals and faults while the soak runs
    if (now < end) {
      if (now >= nextOrder) { await popupSubmit(); nextOrder = now + (2 + R() * 8) * 60000; }
      if (now >= nextApi) { await apiSubmit(); nextApi = now + (4 + R() * 14) * 60000; }
      if (now >= nextFault) { const k = R(); if (k < 0.35) { focusUntil = now + (3 + R() * 20) * 60000; out.focusOff++; } else if (k < 0.7) { vpnUntil = now + (3 + R() * 25) * 60000; out.vpnDown++; } else { runnerUntil = now + (2 + R() * 10) * 60000; out.runnerOutages++; } nextFault = now + (20 + R() * 50) * 60000; }
      if (now >= nextCancel) { const d = (pages.runner.up && now > runnerUntil ? pages.runner : pages.popup).d; const open = d.d.queue.filter(O.isOpen); if (open.length > 1) { const o = open[1 + Math.floor(R() * (open.length - 1))]; const rq = (await io.get(O.INBOX)) || []; if (R() < 0.6) rq.push({ id: 'r' + (++reqN), op: 'cancel', oid: o.id }); else rq.push({ id: 'r' + (++reqN), op: 'move', oid: o.id, dir: R() < 0.5 ? -1 : 1 }); await io.set(O.INBOX, rq.slice(-100)); out.cancels++; } nextCancel = now + (10 + R() * 40) * 60000; }
      if (now >= nextRestart) { // Panel 9 restart: every page loses memory, the open tab is gone, the run record stays
        w.dead = true; w.closeTab(); pages.runner.d = mkPage('runner'); pages.popup.d = mkPage('popup'); out.restarts++; nextRestart = now + (2 + R() * 3) * 3600000; runnerUntil = now + 90000; }
    }
    w.focusOff = now < focusUntil; w.vpnDown = now < vpnUntil;
    w.step(1000);
    // pages: the runner pumps only while it is up; the popup always (it is "open" 40% of the time, but as a fallback executor it must take over when the runner is silent)
    const runnerUp = w.t > runnerUntil; const popupOpen = (Math.floor((w.t - t0) / 600000) % 5) < 2 || !runnerUp;
    if (runnerUp) await O.pump(pages.runner.d, io, 'runner'); else pages.runner.d.held = false;
    if (popupOpen && ++sec % 1 === 0) await O.pump(pages.popup.d, io, 'popup'); else pages.popup.d.held = false;
    // the popup prunes its inbox of acked ids
    if (sec % 30 === 0) { const ack = await io.get(O.ACK), rq = await io.get(O.INBOX); if (ack && Array.isArray(rq)) { const s = new Set(ack.ids); await io.set(O.INBOX, rq.filter((r) => !s.has(r.id))); } }
    if (sec % 60 === 0) { const d = (pages.runner.d.held ? pages.runner.d : pages.popup.d); w.checkReservations(d.d); out.maxOpen = Math.max(out.maxOpen, d.d.queue.length); out.maxHist = Math.max(out.maxHist, d.d.hist.length); }
    if (w.t >= nextMetric) { nextMetric = w.t + 600000; out.maxBytes = Math.max(out.maxBytes, w.bytes()); }
    if (w.t > end && !(await io.get(O.KEY) || { queue: [{}] }).queue.length && !w.batch) break;
  }
  // ---- verdict ----
  const st = await io.get(O.KEY) || { queue: [], hist: [] }; const bad = [];
  const chk = (name, c, d) => { if (!c) bad.push(name + (d !== undefined ? ' ' + JSON.stringify(d).slice(0, 200) : '')); };
  chk('no like twice / no tab overlap / reservations disjoint', !w.violations.length, w.violations.slice(0, 5));
  chk('queue drained (no open order left)', !st.queue.length, st.queue.map((o) => [o.id, o.state]));
  chk('at most one tab open at any time', w.tabsMax <= 1, w.tabsMax);
  chk('history capped', st.hist.length <= O.C.MAX_HIST, st.hist.length);
  chk('storage bounded (< 2 MB)', out.maxBytes < 2 * 1024 * 1024, out.maxBytes);
  const valid = new Set(['done', 'partial', 'failed', 'stopped', 'cancelled']);
  for (const o of w.finals) {
    chk('final state valid ' + o.id, valid.has(o.state), o.state);
    chk('error typed ' + o.id, !o.err || !!E.T[o.err.code], o.err);
    chk('no reservation left on a finished order ' + o.id, !Object.keys(o.res || {}).length);
    if (o.state === 'done') for (const l of o.links) if (l.quantity != null) chk('quantity met on a done order ' + o.id, (o.done[O.lkey(l.vid, l.lc)] || 0) >= l.quantity, { want: l.quantity, got: o.done[O.lkey(l.vid, l.lc)] });
    if (o.shortfall && o.shortfall.length && o.state !== 'cancelled' && o.state !== 'stopped') chk('shortfall is reported ' + o.id, o.err && (o.err.code === 'shortfall' || o.err.code), o.err);
  }
  // every ledger entry has exactly one origin: a click (liked / unverified) or an "already liked" read; and every click that ended 'liked' is in the ledger
  for (const [k, n] of w.clicks) chk('one click at most ' + k, n === 1, n);
  const ids = new Set(); for (const o of w.finals) { chk('order finalised once ' + o.id, !ids.has(o.id)); ids.add(o.id); }
  const retried = w.finals.filter((o) => o.round > 0).length, types = {}; for (const o of w.finals) { types[o.state] = (types[o.state] || 0) + 1; }
  console.log(`seed ${seed}: ${HOURS} simulated hours -> ${w.finals.length} orders ended ${JSON.stringify(types)}, ${w.stats.clicks} clicks, ${w.ledger.size} ledger entries, ${retried} orders used retry/spare rounds, recycles ${w.stats.recycles}, stalls ${w.stats.stalls}, crashes ${w.stats.crashes}, restarts ${out.restarts}, runner outages ${out.runnerOutages}, Focus-off ${out.focusOff}, VPN-down ${out.vpnDown}, cancels/moves ${out.cancels}, dup requests ${out.dups}, max storage ${Math.round(out.maxBytes / 1024)} KB, max queue ${out.maxOpen}, tabs max ${w.tabsMax}, sim end ${((w.t - t0) / 3600000).toFixed(1)} h`);
  // the 60-day marker horizon: jump the clock and let housekeeping run once
  for (let i = 0; i < 200; i++) w.kv.set('p9bn.clk.old' + i, { at: w.t - 61 * 86400000 }); const hk = await O.housekeeping(w.raw(), w.t + 1000); chk('housekeeping prunes 60-day-old markers', hk.markers >= 200 && ![...w.kv.keys()].some((k) => k.indexOf('p9bn.clk.old') === 0), hk);
  if (bad.length) { console.log('  FAIL seed ' + seed + ':\n   - ' + bad.slice(0, 15).join('\n   - ')); totalFail += bad.length; } else console.log('  PASS seed ' + seed);
}
(async () => { for (const s of SEEDS) await soak(s); console.log(totalFail ? `soak17: ${totalFail} FAILED` : 'soak17: all seeds passed'); process.exit(totalFail ? 1 : 0); })().catch((e) => { console.log('CRASH', e && e.stack || e); process.exit(2); });
