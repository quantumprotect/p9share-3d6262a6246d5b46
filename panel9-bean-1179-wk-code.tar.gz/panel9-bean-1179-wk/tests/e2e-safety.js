'use strict';
// Bean 1.1.1 SAFETY regression tests (real Bean + real YouTube Focus inside the real Panel 9, against the local mock of youtube.com). Each scenario reproduces ONE way
// the live 1.1.0 could un-like a comment or use a channel nobody selected. They were written BEFORE the fixes (and failed on 1.1.0), then must all pass on 1.1.1.
// The mock's SERVER decides what a click on "like" does: on a comment the account already liked it is an UN-LIKE, whatever the page showed.
// Run:  cd /tmp/p9-bean2310 && P9_DIR=/tmp/p9-bean2310 xvfb-run -a -s "-screen 0 1440x1000x24" npx electron --no-sandbox /workspace/panel9-bean/tests/e2e-safety.js
const fs = require('fs'); const os = require('os'); const path = require('path');
const { app } = require('electron');
if (!process.env.NOTHROTTLE) { app.commandLine.appendSwitch('disable-background-timer-throttling'); app.commandLine.appendSwitch('disable-renderer-backgrounding'); app.commandLine.appendSwitch('disable-backgrounding-occluded-windows'); app.commandLine.appendSwitch('disable-features', 'IntensiveWakeUpThrottling,CalculateNativeWinOcclusion'); }      // 1.1.6.4: NOTHROTTLE=1 runs WITHOUT the switches that turn background throttling off (R63/R64 prove Bean does not rely on them)
const P9 = process.env.P9_DIR || '/tmp/p9-bean2310';
const YTF = process.env.P9_YTF_DIR || '/workspace/yt-focus-extension';
const SRC = process.env.BEAN_SRC || path.join(__dirname, '..');
const mock = require('./mock-youtube.js');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let failures = 0, passes = 0;
const check = (name, ok, detail) => { if (ok) passes++; else failures++; console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${!ok && detail !== undefined ? '  -> ' + JSON.stringify(detail).slice(0, 500) : ''}`); };
const js = (wc, code) => wc.executeJavaScript(code);
const ONLY = (process.env.ONLY || '').split(',').filter(Boolean);
const want = (n) => !ONLY.length || ONLY.includes(n);

(async () => {
  const srv = await mock.start({ signedIn: true }); const sw = srv.state;
  app.commandLine.appendSwitch('host-resolver-rules', `MAP www.youtube.com 127.0.0.1:${srv.port}, MAP accounts.google.com 127.0.0.1:${srv.port}, MAP consent.youtube.com 127.0.0.1:${srv.port}`);
  app.commandLine.appendSwitch('ignore-certificate-errors');
  process.env.P9_TEST = '1'; process.env.P9_USER_DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'p9-beansafe-'));
  process.env.P9_LEGACY_DIR = path.join(process.env.P9_USER_DATA, '..', 'p9-no-legacy-dir'); process.env.P9_NO_UPDATE_CHECK = '1';
  const { ready, api } = require(path.join(P9, 'src/main.js'));
  await ready;
  const ctx = api.ctx, mgr = api.extensions;
  const trk = require('./tabtrack.js')(ctx);
  if (process.env.WATCHDOG) require('./watchdog.js')();
  { let lt = Date.now(); setInterval(() => { const n = Date.now(), gap = n - lt; lt = n; if (gap > 4000) console.log(`   [lag] main process event loop was blocked for ${Math.round(gap / 1000)} s (ended ${new Date().toTimeString().slice(0, 8)})`); }, 1000).unref(); }
  const wait = async (cond, ms = 20000, step = 150) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { try { const v = await cond(); if (v) return v; } catch (_) { /* retry */ } await sleep(step); } return false; };
  const copyExt = (name) => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'p9bn-copy-')); fs.cpSync(SRC, d, { recursive: true, filter: (p) => !/[\\/](tests|shots)([\\/]|$)/.test(p) }); const m = JSON.parse(fs.readFileSync(path.join(d, 'manifest.json'), 'utf8')); m.name = name; fs.writeFileSync(path.join(d, 'manifest.json'), JSON.stringify(m, null, 2)); return d; };
  const ytf = await mgr.loadUnpacked(YTF), bean = await mgr.loadUnpacked(copyExt('Panel9 Bean'));
  const home = ctx.createTab('about:blank', 'desktop'); await home.ready; ctx.win.setSize(1300, 900); await sleep(400);
  await wait(() => mgr.pageUrl(bean.id, 'popup'), 8000);
  check('YouTube Focus and Bean loaded', !!ytf && !!bean && mgr.get(bean.id).enabled, [ytf && ytf.id, bean && bean.id]);
  const closePopups = () => { for (const w of api.extPopups.values()) { try { w.close(); } catch (_) { /* ignore */ } } };
  const popup = async (id, settle = 1400) => { closePopups(); await sleep(150); await api.openExtensionPopup(ctx, id || bean.id, 'popup'); const w = await wait(() => api.extPopups.get(`${ctx.id}:${id || bean.id}:popup`), 5000); const wc = w.contentView.children[0].webContents; await wait(() => js(wc, "document.readyState === 'complete'"), 5000); await sleep(settle); return wc; };
  const ytfToggle = async (key, on) => { const wc = await popup(ytf.id, 300); await js(wc, `(() => { const c = document.getElementById('${key}'); if (c.checked !== ${on}) c.click(); })()`); await sleep(700); closePopups(); };
  const batchOf = (wc) => js(wc, "chrome.storage.local.get('p9bn.batch').then((v) => v['p9bn.batch'])");
  const store = (wc, k) => js(wc, `chrome.storage.local.get(${JSON.stringify(k)}).then((v) => v[${JSON.stringify(k)}])`);
  const ID = { top1: 'UgxTOP1_unliked_aaaaaaaaaaaaaaaa', top3: 'UgxTOP3_withreplies_cccccccccccc' };
  const link = (vid, lc) => `https://www.youtube.com/watch?v=${vid}&lc=${lc}`;
  let runId = null;
  const setLinks = async (wc, text, pace = 'fast') => { await js(wc, "(self.B11 && B11.S.ledReady ? B11.S.led.clear().then(() => { B11.S.recorded = new Set(); }) : 0)"); await js(wc, `(() => { const t = document.getElementById('links'); t.value = ${JSON.stringify(text)}; t.dispatchEvent(new Event('input', { bubbles: true })); document.getElementById('pace').value = '${pace}'; })()`); await sleep(250); };
  const press = async (wc) => { const before = await batchOf(wc); await js(wc, "document.getElementById('go').click()"); const nb = await wait(async () => { const x = await batchOf(wc); return x && (!before || x.id !== before.id) ? x : false; }, 15000, 100); runId = nb ? nb.id : null; return nb; };
  const finished = (wc, ms = 120000) => wait(async () => { const b = await batchOf(wc); return b && b.id === runId && b.state !== 'running' ? b : false; }, ms, 400);
  const codes = (b) => b.items.map((i) => (i.status === 'failed' || i.status === 'skipped' ? i.code : i.status));
  const likes = () => sw.clicks.filter((c) => c.kind === 'like');
  const reset = () => { sw.clicks.length = 0; sw.hits.length = 0; sw.hitLog.length = 0; sw.switches.length = 0; sw.unlikes.length = 0; };
  const dbg = async (b0) => { try { const b = b0 || await batchOf(pw); const dg = await store(pw, 'p9bn.diag'); console.log('   [debug] state', b && b.state, 'items', JSON.stringify(b && b.items.map((i) => [i.status, i.code, i.msg, i.chid + '/' + i.chname + '/tries' + i.tries, (i.lg || []).map((l) => Math.round(((l[0] || 0) - (b.created || 0)) / 1000) + 's ' + (l[1] || '') + ' ' + String(l[2] || '').slice(0, 140))])), '\n   [debug] events', JSON.stringify(b && (b.events || []).map((x) => Math.round(((x[0] || 0) - (b.created || 0)) / 1000) + 's ' + String(x[1]).slice(0, 260))), 'groups', JSON.stringify(b && b.groups),
'\n   [debug] orphans', JSON.stringify(b && b.orphans), '\n   [debug] diag', String(JSON.stringify(dg)).slice(0, 2500), '\n   [debug] switches', JSON.stringify(sw.switches), 'hitLog', JSON.stringify(sw.hitLog.slice(-8).map((h) => [Math.round(((h.t || 0) - (b && b.created || 0)) / 1000) + 's', h.chan, h.search.slice(0, 60)])), 'reqs', JSON.stringify((sw.reqLog || []).slice(-14).map((r) => [r.p, Math.round(((r.t0 || 0) - (b && b.created || 0)) / 1000) + 's', Math.round((r.t1 - r.t0) / 1000) + 's']))); } catch (e) { console.log('   [debug] failed', e.message); } };
  const snap = async (wc, name) => { if (!process.env.SHOT) return; const { nativeTheme } = require('electron'); for (const th of ['dark', 'light']) { nativeTheme.themeSource = th; await sleep(600); const img = await wc.capturePage(); fs.mkdirSync(path.join(SRC, 'shots'), { recursive: true }); fs.writeFileSync(path.join(SRC, 'shots', `bean-1.1.4-${name}-${th}.png`), img.toPNG()); console.log('  shot', name, th); } nativeTheme.themeSource = 'system'; };
  const resetChan = async () => { for (const c of [cA, cB]) { await ctx.sessionFor(c.id).cookies.set({ url: 'https://www.youtube.com/', name: 'chan', value: 'main', secure: true }); await ctx.sessionFor(c.id).cookies.remove('https://www.youtube.com/', 'stl').catch(() => {}); await ctx.sessionFor(c.id).cookies.remove('https://www.youtube.com/', 'ident').catch(() => {}); } sw.ghostSwitch = false; sw.ghostN = 0; sw.ghostTry = {}; sw.identNever = new Set(); sw.staleDoc = false; sw.navLag = false; sw.settleMs = 0; sw.menuLocale = 'en'; sw.menuNoSwitcher = false; sw.uiOnly = false; sw.uiMenu = undefined; sw.docCache = new Map(); sw.staleServed = 0; for (const c of [cA, cB]) await ctx.sessionFor(c.id).cookies.remove('https://www.youtube.com/', 'swn').catch(() => {}); try { for (const c of [cA, cB]) await js(pw, `chrome.storage.local.remove('p9bn.chstale.' + ${JSON.stringify(c.id)})`); } catch (_) { /* popup not open yet */ } };      // every container starts on its personal channel, and no channel is flagged "could not be reached" by an earlier test (1.1.7 leaves a failed channel out of the next plan)
  const noTabs = () => wait(() => trk.alive().length === 0, 10000);

  await ytfToggle('commentsOnly', true);
  const mk = async (name, color, acct) => { const c = await api.call('containers.create', { name, color }, ctx); await ctx.sessionFor(c.id).cookies.set({ url: 'https://www.youtube.com/', name: 'acct', value: acct, secure: true }); return c; };
  const cA = await mk('Channel A', '#e5484d', 'alice'), cB = await mk('Channel B', '#3e63dd', 'bob');
  sw.accounts = { alice: [{ id: 'main', name: 'Alice', handle: '@alice' }, { id: 'p111', name: 'Alice Cooking', handle: '@alicecooks' }], bob: [{ id: 'main', name: 'Bob', handle: '@bob' }, { id: 'p222', name: 'Bob Gaming', handle: '@bobgames' }] };
  if (process.env.NOREAL) sw.requireReal = false;      // control runs against older product trees
  let pw = await popup();
  // 1.1.6: change what the mock account offers and make Bean read the channel list again; resolves when the stored list names every wanted id (prints what the popup says when it does not)
  const refreshTo = async (list) => {
    // The stored list is exactly what Bean's "Refresh channels" stores (the real reading path is checked once, in the setup above). Seeding it keeps this matrix fast and independent of a discovery tab after a run.
    sw.accounts.alice = list;
    const pidr = await js(pw, 'pid()'), key = 'p9bn.ch.' + pidr + '.' + cA.id;
    const rec = { at: Date.now(), ok: true, channels: list.map((c) => ({ id: c.id, name: c.name, handle: c.handle || '', avatar: '' })), active: 'main', err: '' };
    await js(pw, `chrome.storage.local.set({ [${JSON.stringify(key)}]: ${JSON.stringify(rec)} }).then(() => chrome.storage.local.remove('p9bn.chstale.' + ${JSON.stringify(cA.id)})).then(() => loadChannelCache()).then(() => { normalizeSel(); renderContainers(); })`);
    const ids = list.map((c) => c.id);
    const got = await wait(async () => { const a = await store(pw, key); return a && a.ok && a.channels.length === ids.length && ids.every((i) => a.channels.some((c) => c.id === i)) ? a : false; }, 10000, 300);
    await sleep(600); return !!got;
  };
  const saveSel = async (map) => { await js(pw, `(async () => { await loadChannelCache(); sel = new Set(${JSON.stringify(Object.keys(map))}); chSel = {}; const m = ${JSON.stringify(map)}; for (const cid of Object.keys(m)) if (m[cid]) chSel[cid] = new Set(m[cid]); normalizeSel(); saveSel(); renderContainers(); })()`); await sleep(1800); };
  await saveSel({ [cA.id]: null, [cB.id]: null });
  await js(pw, "document.getElementById('crefresh').click()");
  const pidOf = await js(pw, 'pid()');
  const got = await wait(async () => { const a = await store(pw, 'p9bn.ch.' + pidOf + '.' + cA.id), b = await store(pw, 'p9bn.ch.' + pidOf + '.' + cB.id); return a && a.ok && b && b.ok; }, 120000, 600);
  check('setup: channel lists read for A (main, p111) and B (main, p222)', !!got);
  await sleep(2500); pw = await popup();
  // 1.1.7: a run that ended with a retryable failure (wrong-channel, not-found, ...) belongs to an ORDER that the dispatcher retries as a new batch after ~20 s; a test that has seen the result must not
  // let that retry run into the next test, so the order is cancelled (a cancel after the batch ended only closes the order; nothing is clicked).
  const drainOrders = async () => { try { const o = await store(pw, 'p9bn.orders'); for (const x of (o && o.queue) || []) await js(pw, `B17.request({ op: 'cancel', oid: ${JSON.stringify(x.id)} }, 6000)`).catch(() => {}); await sleep(600); } catch (_) { /* no queue */ } };
  const runOne = async (text, selMap, pace) => { await drainOrders(); reset(); await saveSel(selMap); await setLinks(pw, text, pace); await press(pw); const b = await finished(pw); await drainOrders(); return b; };
  const liveBatch = () => batchOf(pw);

  // ---------------------------------------------------------------------------------------------------------------- R1
  if (want('R1')) {
    console.log('\n== R1. late hydration: the comment IS liked by this channel but its button still reads "not pressed" for 3.2 s ==');
    sw.liked.add('alice#p111|LATEHYD0001|' + ID.top1);
    const b = await runOne(link('LATEHYD0001', ID.top1), { [cA.id]: ['p111'] });
    check('R1 the comment is NOT un-liked (server saw no un-like)', sw.unlikes.length === 0 && sw.liked.has('alice#p111|LATEHYD0001|' + ID.top1), { unlikes: sw.unlikes.length, clicks: sw.clicks.map((c) => c.kind + ':' + c.pressed) });
    check('R1 Bean did not click at all (nothing to do): item "already"', !!b && sw.clicks.length === 0 && codes(b)[0] === 'already', b && [codes(b), sw.clicks.length]);
    await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- R2
  if (want('R2')) {
    console.log('\n== R2. duplicate injection: a second copy of the tab logic starts at once in the same page, the UI toggles slowly ==');
    const b = await runOne(link('DUPINST0001', ID.top1), { [cA.id]: ['p111'] });
    check('R2 exactly ONE like click and no un-like', sw.clicks.length === 1 && likes().length === 1 && sw.unlikes.length === 0, { clicks: sw.clicks.length, unlikes: sw.unlikes.length });
    check('R2 the run reports the like once', !!b && codes(b).join() === 'liked', b && codes(b));
    await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- R3
  if (want('R3')) {
    console.log('\n== R3. reload after the click: the page reloads 0.7 s after the like, the reloaded page hydrates late ==');
    const t0 = Date.now();
    const b = await runOne(link('RELOADAF001', ID.top1), { [cA.id]: ['p111'] });
    check('R3 one like click, no un-like, the comment ends liked', likes().length === 1 && sw.unlikes.length === 0 && sw.liked.has('alice#p111|RELOADAF001|' + ID.top1), { likes: likes().length, unlikes: sw.unlikes.length });
    check('R3 the reloaded page takes the run over safely: result "liked" (not stuck / "interrupted")', !!b && codes(b).join() === 'liked' && Date.now() - t0 < 60000, b && [codes(b), Date.now() - t0]);
    await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- R4/R5
  const revisit = async (vid, drop) => {      // put the finished item back to "queued" (a storage-mirror race does exactly that) and visit its page again, like a reclaim / retry would
    const bb = await liveBatch(); const it = bb.items[0];
    if (drop) await js(pw, "chrome.storage.local.get(null).then((a) => chrome.storage.local.remove(Object.keys(a).filter((k) => /^p9bn\\.clk\\./.test(k))))");
    await js(pw, `chrome.storage.local.get('p9bn.batch').then(async (v) => { const b = v['p9bn.batch']; b.state = 'running'; b.updated = Date.now(); for (const it of b.items) { it.status = 'queued'; delete it.code; delete it.msg; delete it.runner; delete it.hb; delete it.at; } b.groups && Object.values(b.groups || {}).forEach((g) => { g.status = 'running'; }); await chrome.storage.local.set({ 'p9bn.batch': b }); })`);
    const url = await js(pw, `P9BEAN.watchUrl(${JSON.stringify(it.vid)}, ${JSON.stringify(it.lc)}, ${JSON.stringify(bb.id)}, ${JSON.stringify(it.cid)}, ${JSON.stringify(it.chid || '')})`);
    reset();
    const tab = await js(pw, `window.panel9ext.openTabInContainer({ containerId: ${JSON.stringify(it.cid)}, url: ${JSON.stringify(url)} })`);
    await wait(async () => { const b3 = await liveBatch(); return b3.items[0].status !== 'queued' && b3.items[0].status !== 'running'; }, 40000, 400);
    await sleep(2500);
    try { ctx.closeTab(tab && tab.tabId); } catch (_) { /* gone */ }
    for (const id of trk.alive()) { try { ctx.closeTab(id); } catch (_) { /* gone */ } }
    return await liveBatch();
  };
  if (want('R4')) {
    console.log('\n== R4. recorded like, then the SAME page is visited again with the item back at "queued" (reclaim / retry / mirror race) ==');
    const b1 = await runOne(link('LATEHYD0002', ID.top1), { [cA.id]: ['p111'] });
    check('R4 first visit: liked once', !!b1 && codes(b1).join() === 'liked' && likes().length === 1 && sw.unlikes.length === 0, b1 && [codes(b1), likes().length]);
    await sleep(2500);
    const b2 = await revisit('LATEHYD0002', false);
    check('R4 second visit: NOT clicked again, nothing un-liked, comment still liked', sw.clicks.length === 0 && sw.unlikes.length === 0 && sw.liked.has('alice#p111|LATEHYD0002|' + ID.top1), { clicks: sw.clicks.length, unlikes: sw.unlikes.length, item: b2.items[0].status + '/' + b2.items[0].code });
    await noTabs();
  }
  if (want('R5')) {
    console.log('\n== R5. same, but the "clicked" marker is gone: the permanent ledger must stop the click ==');
    const b1 = await runOne(link('LATEHYD0003', ID.top1), { [cA.id]: ['p111'] });
    check('R5 first visit: liked once', !!b1 && codes(b1).join() === 'liked' && likes().length === 1, b1 && codes(b1));
    await sleep(3000);
    const led = await js(pw, "B11.S.led.stats()");
    const b2 = await revisit('LATEHYD0003', true);
    check('R5 second visit (markers deleted): NOT clicked again, nothing un-liked', sw.clicks.length === 0 && sw.unlikes.length === 0 && sw.liked.has('alice#p111|LATEHYD0003|' + ID.top1), { clicks: sw.clicks.length, unlikes: sw.unlikes.length, ledger: led, item: b2.items[0].status + '/' + b2.items[0].code });
    await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- R6
  if (want('R6')) {
    console.log('\n== R6. channel A has "main" active but only "p111" selected: no switch into an unselected channel, ever ==');
    sw.liked.clear(); delete sw.cookieChan;
    await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'chan', value: 'main', secure: true });
    let b = await runOne(link('NORMAL00601', ID.top1), { [cA.id]: ['p111'] });
    check('R6 liked from p111 only', !!b && codes(b).join() === 'liked' && likes().length === 1 && likes()[0].chan === 'p111', b && [codes(b), likes().map((c) => c.chan)]);
    check('R6 default: every channel switch went to a SELECTED channel (no switch back to "main")', sw.switches.length >= 1 && sw.switches.every((s) => s.to === 'p111'), sw.switches);
    await noTabs();
    // the optional "switch back" setting
    await js(pw, "(async () => { settings.restoreBack = true; await sset(K.settings, settings); })()"); await sleep(600);
    await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'chan', value: 'main', secure: true });
    sw.liked.clear();
    b = await runOne(link('NORMAL00602', ID.top1), { [cA.id]: ['p111'] });
    check('R6 with the option ON: Bean switches back to the channel that was active before the run (explicit user choice)', sw.switches.some((s) => s.to === 'main') && !!b && codes(b).join() === 'liked', [sw.switches, b && codes(b)]);
    await js(pw, "(async () => { settings.restoreBack = false; await sset(K.settings, settings); })()"); await sleep(400);
    await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- R8
  if (want('R8')) {
    console.log('\n== R8. YouTube silently REJECTS the like (optimistic UI turns "pressed", reverts 2.6 s later): Bean must not record a like that did not stick ==');
    sw.liked.clear();
    const b = await runOne(link('REJECTLK001', ID.top1), { [cA.id]: ['p111'] });
    await sleep(2500);
    const st = await js(pw, 'B11.S.led.stats()');
    check('R8 the item is NOT "liked" (reported as a failed like: "like-not-kept")', !!b && codes(b).join() === 'like-not-kept', b && codes(b));
    check('R8 exactly one click was made (never a second one), the comment is not liked on the server', sw.clicks.length === 1 && !sw.liked.has('alice#p111|REJECTLK001|' + ID.top1), { clicks: sw.clicks.length });
    check('R8 the ledger did NOT record a like that never stuck', st.comments === 0, st);
    await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- R9
  if (want('R9')) {
    console.log('\n== R9. the active channel flips back to "main" after the switch (1.8 s after load): a click must never land on a channel nobody selected for it ==');
    sw.liked.clear();
    await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'chan', value: 'main', secure: true });
    const b = await runOne(link('FLIPCHAN001', ID.top1), { [cA.id]: ['p111'] });
    check('R9 no like was sent from any channel except the selected p111', sw.clicks.every((c) => c.chan === 'p111'), sw.clicks.map((c) => c.chan));
    check('R9 the item is not "liked": it failed as "wrong-channel" and nothing was recorded', !!b && codes(b).join() === 'wrong-channel', b && codes(b));
    await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- R7
  if (want('R7')) {
    console.log('\n== R7. selection never auto-adds a channel the user did not tick ==');
    const r = await js(pw, `(async () => { await loadChannelCache(); sel = new Set([${JSON.stringify(cA.id)}]); chSel = {}; chSel[${JSON.stringify(cA.id)}] = new Set(['gone-channel']); normalizeSel(); return [sel.has(${JSON.stringify(cA.id)}), chSel[${JSON.stringify(cA.id)}].size]; })()`);
    check('R7 a ticked container whose ticked channels vanished is UNticked (no channel is added for the user)', r[0] === false && r[1] === 0, r);
    const r2 = await js(pw, `(() => { sel = new Set([${JSON.stringify(cA.id)}]); chSel = {}; normalizeSel(); return [sel.has(${JSON.stringify(cA.id)}), (chSel[${JSON.stringify(cA.id)}] || new Set()).size]; })()`);
    check('R7 a ticked container with NO channel ticked is not given its "active" channel', r2[0] === false && r2[1] === 0, r2);
  }
  // ---------------------------------------------------------------------------------------------------------------- R10
  if (want('R10')) {
    console.log('\n== R10. a run that is over STAYS over: no clicks, no page loads, no tabs, no VPN after "Done"; a late write that makes it "running" again is repaired ==');
    sw.liked.clear();
    const b = await runOne(link('NORMAL00701', ID.top1) + '\n' + link('NORMAL00701', ID.top3), { [cA.id]: ['main', 'p111'], [cB.id]: ['main'] }, 'fast');
    check('R10 run finished "done" with all items liked', !!b && b.state === 'done' && codes(b).every((c) => c === 'liked'), b && [b.state, codes(b)]);
    await noTabs();
    const c0 = sw.clicks.length, h0 = sw.hits.length, t0n = trk.total;
    await sleep(6000);
    check('R10 6 s after Done: no new click, no new page load, no new Bean tab, none open', sw.clicks.length === c0 && sw.hits.length === h0 && trk.total === t0n && trk.alive().length === 0, { clicks: sw.clicks.length - c0, hits: sw.hits.length - h0, tabs: trk.total - t0n, alive: trk.alive() });
    await js(pw, "chrome.storage.local.get('p9bn.batch').then((v) => { const b = v['p9bn.batch']; b.state = 'running'; b.updated = Date.now(); return chrome.storage.local.set({ 'p9bn.batch': b }); })");   // a late write from a tab / a stale mirror copy
    const fixed = await wait(async () => { const x = await liveBatch(); return x && x.state === 'done'; }, 8000, 300);
    await sleep(3000);
    check('R10 a late "running" write is repaired back to "done"; still no extra click / page / tab', !!fixed && sw.clicks.length === c0 && sw.hits.length === h0 && trk.total === t0n && trk.alive().length === 0, { fixed: !!fixed, clicks: sw.clicks.length - c0, hits: sw.hits.length - h0, tabs: trk.total - t0n });
    check('R10 tab rule over the whole run: never more than one Bean tab at a time', trk.maxAll <= 1 || trk.max <= 1, { max: trk.max, maxAll: trk.maxAll, over: trk.over });
  }
  // ---------------------------------------------------------------------------------------------------------------- R11
  if (want('R11')) {
    console.log('\n== R11. run log: every item with link, container, channel, result, reason + code and the key steps; copy / export; last runs kept ==');
    sw.liked.clear(); sw.failSwitch.add('p222');
    const b = await runOne(link('NORMAL00801', ID.top1), { [cA.id]: ['p111'], [cB.id]: ['p222'] }, 'fast');
    sw.failSwitch.delete('p222');
    await sleep(2500);
    const rec = await js(pw, "chrome.storage.local.get('p9bn.runs').then((v) => v['p9bn.runs'])");
    const last = rec && rec[rec.length - 1];
    check('R11 the finished run was archived in p9bn.runs (last 5 kept)', Array.isArray(rec) && rec.length >= 1 && rec.length <= 5 && last && last.id === (b && b.id), rec && rec.length);
    const txt = await js(pw, "(async () => { document.getElementById('sec-log').open = true; await renderLog(); return document.getElementById('logview').textContent; })()");
    check('R11 log shows the liked item (channel, VPN-independent steps: switch verified, state, click, after, verify)', /Alice Cooking/.test(txt) && /switch — verified/.test(txt) && /state — unliked/.test(txt) && /click — one click/.test(txt) && /after — aria-pressed true/.test(txt) && /verify — fresh page shows the comment as liked/.test(txt), txt.slice(0, 900));
    check('R11 log shows the failed item with a plain-English reason AND its code, and the summary counts codes', /FAILED/.test(txt) && /switch-failed/.test(txt) && /why: .*did not take effect/.test(txt) && /Summary: .*1× switch-failed/.test(txt), txt.slice(0, 900));
    const ui = await js(pw, "[!!document.getElementById('logcopy'), !!document.getElementById('logtxt'), !!document.getElementById('logjson'), document.querySelector('#results .why') ? document.querySelector('#results .why').textContent : '', document.getElementById('msg').textContent]");
    check('R11 Copy log / Export .txt / Export .json exist; the failed row shows its reason + code; the summary lists failure codes', ui[0] && ui[1] && ui[2] && /\[switch-failed\]/.test(ui[3]) && /failed \(1× switch-failed\)/.test(ui[4]), ui);
    check('R11 the log has no IP address / cookie / key', !/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/.test(txt) && !/bean_[A-Za-z0-9]{8,}|Bearer/i.test(txt));
    await noTabs();
  }

  // ================================================================================================================= 1.1.2 (from the real 1.1.1 log: reloads/slow pages made Bean call a LIVE tab "interrupted")
  const slow = (o) => { Object.assign(sw.delay, { watch: 0, switcher: 0, signin: 0, hops: 0 }, o || {}); };
  const startRun = async (text, selMap, pace) => { await drainOrders(); reset(); await saveSel(selMap); await setLinks(pw, text, pace); return press(pw); };
  const openIds = () => ctx.tabs.map((t) => t.id);
  const stamp = async (wc, f) => js(wc, `chrome.storage.local.get('p9bn.batch').then(async (v) => { const b = v['p9bn.batch']; (${f})(b); await chrome.storage.local.set({ 'p9bn.batch': b }); })`);
  // ---------------------------------------------------------------------------------------------------------------- R12
  if (want('R12')) {
    console.log('\n== R12. real timing: /watch takes 10-35 s, the switcher read 14 s, the sign-in switch is a 3-hop chain of slow redirects, the verify reload is slow too ==');
    if (process.env.R12P111) await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'chan', value: 'p111', secure: true });      // as when an earlier test left the container on its 2nd channel
    sw.liked.clear(); slow({ watch: () => 10000 + Math.floor(Math.random() * 25000), switcher: 14000, signin: 9000, hops: 3 });
    const t0 = Date.now(); const bpre = await startRun(link('SLOWRELD001', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, 900000); slow(); if (!b || codes(b).join() !== 'liked,liked') await dbg(b);
    check('R12 both channels liked (not "interrupted"), the run ends "done" by itself', !!b && b.state === 'done' && codes(b).join() === 'liked,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R12 exactly two like clicks, no un-like; each channel once', likes().length === 2 && sw.unlikes.length === 0 && likes().map((c) => c.chan).sort().join() === 'main,p111', { likes: likes().map((c) => c.chan), unlikes: sw.unlikes.length });
    check('R12 the group was never declared "interrupted" and the run did not sit at "running"', !!b && !b.items.some((i) => i.code === 'interrupted' || i.code === 'not-started') && Date.now() - t0 < 900000, b && b.items.map((i) => i.code));
    await noTabs(); check('R12 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  // ---------------------------------------------------------------------------------------------------------------- R13
  if (want('R13')) {
    console.log('\n== R13. a group is declared lost while its tab is still ALIVE (still loading) and the tab id was lost: the tab must still be closed; the popup was reopened (no memory) ==');
    sw.liked.clear(); slow({ watch: 25000 });
    const b0 = await startRun(link('SLOWRELD002', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    const up = await wait(async () => { const bb = await liveBatch(); return bb && bb.groups && bb.groups[0] && bb.groups[0].tab != null && trk.alive().length === 1 ? bb : false; }, 30000, 200);
    check('R13 setup: the container tab is open and the run is in progress', !!up, up && up.groups);
    await stamp(pw, "(b) => { for (const g of b.groups) delete g.tab; b.updated = Date.now() - 60000; b.graceUntil = 0; }");       // the tab's write lost the tab id; nothing was heard from it for 60 s
    pw = await popup();                                                      // a new popup instance: no memory of the tab it opened
    // 1.1.7: the run record's age no longer decides that a tab is lost (the runner judges from what IT heard: split writers). A stamped-old record plus a popup without memory must therefore NOT make Bean close a tab that is
    // still loading and alive: the tab is adopted (it is in the registry) and the run goes on. (The sweep-through-the-registry of a really lost group is covered by R1x/R70/R75.)
    await sleep(12000);
    const kept = trk.alive().length === 1 && await wait(async () => { const bb = await liveBatch(); return bb && bb.state === 'running' && !bb.items.some((it) => it.status === 'failed' || it.status === 'skipped'); }, 3000, 300);
    check('R13 (1.1.7) an old-looking record + a popup without memory does NOT close the live, loading tab and fails nothing (the runner judges from the heartbeats it heard)', !!kept, trk.alive());
    const b = await finished(pw, 300000); slow();
    if (process.env.DEBUGF) console.log('  [debug R13 end]', JSON.stringify({ tabs: trk.total, ev: b && b.events, items: b && b.items.map((i) => [i.status, i.code, i.msg, (i.lg || []).slice(-4)]), groups: b && b.groups }).slice(0, 2500));
    check('R13 the run is over (not "running" forever); 1.1.7: the live tab carries on, and no (account/channel/comment) is ever liked twice', !!b && b.state !== 'running' && new Set(likes().map((c) => c.vid + c.id + c.acct + c.chan)).size === likes().length && likes().length <= 2, b && [b.state, codes(b), likes().length]);
    await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- R14
  if (want('R14')) {
    console.log('\n== R14. Stop with a reopened popup (no memory, group.tab missing) still closes the Bean tab; the tab rule holds ==');
    sw.liked.clear(); slow({ watch: 25000 });
    await startRun(link('SLOWRELD003', ID.top1), { [cA.id]: ['main'] }, 'fast');
    const up = await wait(async () => { const bb = await liveBatch(); return bb && bb.groups && bb.groups[0] && bb.groups[0].tab != null && trk.alive().length === 1 ? bb : false; }, 30000, 200);
    await stamp(pw, "(b) => { for (const g of b.groups) delete g.tab; }");
    pw = await popup(); await js(pw, "stop()");
    const closed = await wait(() => trk.alive().length === 0, 15000, 300); slow();
    check('R14 after Stop the tab is closed', !!up && !!closed, trk.alive());
    const bb = await liveBatch(); check('R14 the run is "stopped" and nothing was clicked', !!bb && bb.state === 'stopped' && likes().length === 0, bb && [bb.state, likes().length]);
  }
  // ---------------------------------------------------------------------------------------------------------------- R15
  if (want('R15')) {
    console.log('\n== R15. a Bean tab left behind (registered) is closed when the NEXT run starts and when the popup opens ==');
    slow(); sw.liked.clear();
    const mkLeft = async () => { const t = await js(pw, `openInContainer(${JSON.stringify(cA.id)}, 'https://www.youtube.com/watch?v=LEFTOVER001&p9bn=leftover&p9bc=${cA.id}').then(async (t) => { await regTab(t.tabId, 'old-run', ${JSON.stringify(cA.id)}); return t.tabId; })`); await wait(() => openIds().includes(t), 6000); return t; };
    const left1 = await mkLeft(); pw = await popup(); const c1 = await wait(() => !openIds().includes(left1), 15000, 300);
    check('R15 opening the popup closes the left-over Bean tab', !!c1, left1);
    const left2 = await mkLeft(); const b = await runOne(link('NORMAL00902', ID.top1), { [cA.id]: ['main'] }, 'fast');
    check('R15 the left-over tab was closed by the new run and the run still finished', !openIds().includes(left2) && !!b && codes(b).join() === 'liked', [openIds().includes(left2), b && codes(b)]);
    await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- R16
  if (want('R16')) {
    console.log('\n== R16. the page after the click really dies (verify reload never loads): "liked-unverified", in the ledger, never clicked again, the run ends ==');
    sw.liked.clear(); let clicked = false; slow({ watch: () => (sw.clicks.length > 0 ? 400000 : 0) });
    const t0 = Date.now(); await startRun(link('SLOWRELD004', ID.top1), { [cA.id]: ['main'] }, 'fast');
    const b = await finished(pw, 420000); slow();
    const it = b && b.items[0];
    check('R16 the item is "liked-unverified" (not "interrupted"), counted as sent', !!it && it.status === 'liked' && it.code === 'liked-unverified', it && [it.status, it.code]);
    const inLed = it ? await js(pw, `B11.S.led.has(P9BEAN.canonVid(${JSON.stringify(it.vid)}), P9BEAN.canonLc(${JSON.stringify(it.lc)}), ${JSON.stringify(it.ck)})`) : false;
    check('R16 it is in the ledger (never clicked again) and exactly one click was made', inLed === true && likes().length === 1, [inLed, likes().length]);
    check('R16 the run ended by itself (state done) well within 7 minutes', !!b && b.state === 'done', b && [b.state, Date.now() - t0]);
    await noTabs(); check('R16 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }

  // ---------------------------------------------------------------------------------------------------------------- R18-R20 (real 1.1.2 log: YouTube strips unknown params from the URL, the verify reload never re-attached)
  if (want('R18')) {
    console.log('\n== R18. YouTube rewrites the URL after load and drops Bean\'s params: the verify page (and the next channel) must still attach to the run ==');
    sw.liked.clear(); slow({ watch: 1500 }); sw.strip = 400;
    const t0 = Date.now(); await startRun(link('STRIPREL001', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, 240000); slow(); sw.strip = 0;
    check('R18 both channels end "liked" (verified from the reloaded page), not liked-unverified / not-started', !!b && b.state === 'done' && codes(b).join() === 'liked,liked' && !b.items.some((i) => i.code === 'liked-unverified'), b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R18 exactly one click per channel (main, p111), never a second click, no un-like', likes().length === 2 && sw.unlikes.length === 0 && likes().map((c) => c.chan).sort().join() === 'main,p111', { likes: likes().map((c) => [c.chan, c.id]), unlikes: sw.unlikes.length });
    check('R18 it did not wait for the 2-minute grace to give up (finished within 100 s)', Date.now() - t0 < 100000, Date.now() - t0);
    await noTabs(); check('R18 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R19')) {
    console.log('\n== R19. the sign-in redirect chain also drops the params of next=: the page after a channel switch must still attach to the run and like as the right channel ==');
    sw.liked.clear(); slow({ watch: 1500, signin: 1500, hops: 2 }); sw.strip = 400; sw.stripSignin = true;
    const t0 = Date.now(); await startRun(link('STRIPREL002', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 300000); slow(); sw.strip = 0; sw.stripSignin = false;
    check('R19 both channels end "liked" although the page after the switch arrived without Bean\'s params', !!b && b.state === 'done' && codes(b).join() === 'liked,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R19 one click per channel, each as the channel that was ticked', likes().length === 2 && sw.unlikes.length === 0 && likes().map((c) => c.chan).sort().join() === 'main,p111', likes().map((c) => c.chan));
    const dg = (await store(pw, 'p9bn.diag')) || []; check('R19 the log says a token-less page adopted the run from the hand-over (and the hand-over is spent)', dg.some((d) => /adopted the run from the hand-over/.test(d.m)), dg.map((d) => d.m));
    await noTabs(); check('R19 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  // ---------------------------------------------------------------------------------------------------------------- R21-R23 (real 1.1.3 log: the switch to the 2nd channel never completed)
  if (want('R21')) {
    await resetChan();
    console.log('\n== R21. the switch uses YouTube\'s OWN signin address from the freshly read switcher entry (authuser + feature + skip_identity_prompt [+ pageid]); a hand-made address does not switch on this site ==');
    sw.liked.clear(); slow({ watch: 800 }); sw.switches.length = 0;
    await startRun(link('REALSW0001x', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); if (!b) await dbg();
    check('R21 both channels end "liked" (the 2nd one was switched to with the list\'s own address)', !!b && b.state === 'done' && codes(b).join() === 'liked,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R21 one click per channel (main, p111); every switch request was accepted by the site', likes().length === 2 && likes().map((c) => c.chan).sort().join() === 'main,p111' && sw.switches.length >= 1 && sw.switches.every((x) => x.ok), { likes: likes().map((c) => c.chan), sw: sw.switches });
    await noTabs(); check('R21 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R22')) {
    await resetChan();
    console.log('\n== R22. YouTube reloads the landing page ONCE by itself right after the switch (the first page dies, a token-less one replaces it): the run must carry on with the same item ==');
    sw.liked.clear(); slow({ watch: 800 }); sw.strip = 400; sw.postSwitchReload = true; sw.switches.length = 0;
    const t0 = Date.now(); await startRun(link('REALSW0002x', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 300000); slow(); sw.strip = 0; sw.postSwitchReload = false;
    check('R22 both channels end "liked" (not interrupted / not-started)', !!b && b.state === 'done' && codes(b).join() === 'liked,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R22 one click per channel, finished well inside the 2-minute grace', likes().length === 2 && likes().map((c) => c.chan).sort().join() === 'main,p111' && Date.now() - t0 < 110000, [likes().map((c) => c.chan), Date.now() - t0]);
    await noTabs(); check('R22 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R23')) {
    await resetChan();
    console.log('\n== R23. the account switcher HANGS after the switch: every wait is bounded, the item ends "switch-failed" (not interrupted), nothing is clicked for it, the run carries on with the next container ==');
    sw.liked.clear(); slow({ watch: 800 }); sw.hangAfterSwitch = true; sw.hangNext = 0; sw.hung = 0;
    const t0 = Date.now(); await startRun(link('REALSW0003x', ID.top1), { [cA.id]: ['main', 'p111'], [cB.id]: ['main'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 300000); slow(); sw.hangAfterSwitch = false; sw.hangNext = 0;
    check('R23 main liked, p111 "switch-failed", the next container liked — no "interrupted"', !!b && b.state === 'done' && codes(b).join() === 'liked,switch-failed,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R23 nothing was clicked as p111; it ended in under 3 minutes (no 2-minute stall)', !likes().some((c) => c.chan === 'p111') && Date.now() - t0 < 180000, [likes().map((c) => c.chan), Date.now() - t0, sw.hung]);
    await noTabs(); check('R23 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }


  // ---------------------------------------------------------------------------------------------------------------- R24-R26 (1.1.4 Pause / Resume)
  const L9 = require('../lib/links.js');
  const twoLinks = (v = 'PAUSE000001') => link(v, ID.top1) + '\n' + link(v, ID.top3);
  const pauseEngaged = () => wait(async () => { const b = await batchOf(pw); return b && b.pauseReq && b.pause && b.pause.since ? b : false; }, 60000, 250);
  const itemRunning = (k) => wait(async () => { const b = await batchOf(pw); return b && b.items[k] && b.items[k].status === 'running' ? b : false; }, 90000, 120);
  if (want('R24')) {
    await resetChan();
    console.log('\n== R24. Pause while the FIRST like is in progress: that like finishes and is verified, then Bean holds (no new page, click, VPN change); the popup is closed and reopened; Resume carries on, nothing skipped or repeated ==');
    sw.liked.clear(); slow({ watch: 1500 });
    await startRun(twoLinks(), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    await wait(() => likes().length >= 1, 90000, 60); await snap(pw, 'running-pause-button');   // 1.1.6: Pause BEFORE the click now holds before anything is sent (R33); here it arrives right after the click
    await js(pw, "document.getElementById('pause').click()");
    const bp = await pauseEngaged();
    check('R24 paused: item 1 is liked and verified, items 2-4 still queued, the record says paused', !!bp && bp.items[0].status === 'liked' && bp.items[1].status === 'queued' && bp.items[2].status === 'queued' && L9.pauseState(bp) === 'paused', bp && [bp.items.map((i) => i.status), bp.pause]);
    await sleep(500); const h0 = sw.hits.length, c0 = sw.clicks.length, sx0 = sw.switches.length;
    await sleep(9000);
    const bq = await batchOf(pw);
    check('R24 while paused: no page load, no click, no switch for 9 s; at most one Bean tab; the run is not stale', sw.hits.length === h0 && sw.clicks.length === c0 && sw.switches.length === sx0 && trk.alive().length <= 1 && bq.state === 'running' && Date.now() - bq.updated < 20000, [sw.hits.length - h0, sw.clicks.length - c0, trk.alive().length, Date.now() - bq.updated]);
    pw = await popup();
    const shown = await js(pw, "JSON.stringify({ pause: document.getElementById('pause').hidden, resume: document.getElementById('resume').hidden, pnow: document.getElementById('pnow').textContent, ptime: document.getElementById('ptime').textContent, stop: document.getElementById('stop').hidden })");
    const sh = JSON.parse(shown);
    await snap(pw, 'paused-resume-button');
    check('R24 popup reopened: still Paused (progress panel says Paused, Resume shown, Pause hidden, Stop shown)', sh.pause && !sh.resume && !sh.stop && /Paused/i.test(sh.pnow + sh.ptime), sh);
    await js(pw, "document.getElementById('resume').click()");
    const b = await finished(pw, 240000);
    check('R24 after Resume all 4 liked, once each (nothing skipped, nothing repeated), run not interrupted', !!b && b.state === 'done' && codes(b).join() === 'liked,liked,liked,liked' && likes().length === 4 && new Set(likes().map((c) => c.vid + c.id + c.acct + c.chan)).size === 4, b && [b.state, codes(b), likes().length]);
    check('R24 the log says paused and resumed', !!b && (b.events || []).some((e) => /paused/.test(e[1])) && (b.events || []).some((e) => /resumed/.test(e[1])), b && b.events);
    slow(); await noTabs(); check('R24 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R25')) {
    await resetChan();
    console.log('\n== R25. Pause during the LAST item of the first container: the tab finishes and closes; BETWEEN containers nothing is open, no tab opens, popup closed + record idle for 10 min is NOT stopped; Resume opens the next container ==');
    sw.liked.clear(); slow({ watch: 1500 });
    await startRun(twoLinks('PAUSE000002'), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    await wait(() => likes().length >= 2, 90000, 60); await js(pw, "document.getElementById('pause').click()");
    const bp = await pauseEngaged();
    await wait(() => trk.alive().length === 0, 20000);
    check('R25 paused between containers: container A done (2 liked), B untouched (queued), no tab open', !!bp && trk.alive().length === 0, bp && [bp.items.map((i) => i.status), trk.alive().length]);
    const h0 = sw.hits.length, c0 = sw.clicks.length;
    closePopups(); await sleep(300);
    pw = await popup();
    await js(pw, "chrome.storage.local.get('p9bn.batch').then((v) => { const b = v['p9bn.batch']; b.updated -= 10 * 60000; return chrome.storage.local.set({ 'p9bn.batch': b }); })");
    pw = await popup(); await sleep(6000);
    const bq = await batchOf(pw);
    check('R25 reopened with a 10-minute-old record: still running + paused (not stopped, not stale); no page, click or tab meanwhile', bq.state === 'running' && L9.pauseState(bq) === 'paused' && sw.hits.length === h0 && sw.clicks.length === c0 && trk.alive().length === 0 && bq.items.slice(2).every((i) => i.status === 'queued'), [bq.state, L9.pauseState(bq), sw.hits.length - h0, trk.alive().length, bq.items.map((i) => i.status)]);
    const sh = JSON.parse(await js(pw, "JSON.stringify({ pause: document.getElementById('pause').hidden, resume: document.getElementById('resume').hidden, go: document.getElementById('go').disabled })"));
    check('R25 popup shows Resume (and Start stays disabled)', sh.pause && !sh.resume && sh.go, sh);
    await js(pw, "document.getElementById('resume').click()");
    const b = await finished(pw, 240000);
    check('R25 after Resume container B ran: all 4 liked once each', !!b && b.state === 'done' && codes(b).join() === 'liked,liked,liked,liked' && likes().length === 4, b && [b.state, codes(b), likes().length]);
    slow(); await noTabs(); check('R25 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R26')) {
    await resetChan();
    console.log('\n== R26. Paused for more than 6 hours: the run is stopped with a log line (nothing liked afterwards) ==');
    sw.liked.clear(); slow({ watch: 1500 });
    await startRun(twoLinks('PAUSE000003'), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    await itemRunning(1); await js(pw, "document.getElementById('pause').click()");
    await pauseEngaged(); await wait(() => trk.alive().length === 0, 20000);
    const c0 = likes().length;
    await js(pw, "chrome.storage.local.get('p9bn.batch').then((v) => { const b = v['p9bn.batch']; b.pause.since -= 6 * 3600000 + 60000; return chrome.storage.local.set({ 'p9bn.batch': b }); })");
    const b = await finished(pw, 30000);
    check('R26 stopped after the 6 h limit, log line written, the remaining items skipped, nothing clicked after', !!b && b.state === 'stopped' && (b.events || []).some((e) => /auto-stopped: paused for more than 6 hours/.test(e[1])) && b.items.slice(2).every((i) => i.status === 'skipped') && likes().length === c0, b && [b.state, b.events, b.items.map((i) => i.status)]);
    slow(); await noTabs(); check('R26 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }

  // ---------------------------------------------------------------------------------------------------------------- R27 (real 1.1.4 use: the first page after a switch shows the PREVIOUS identity's like)
  if (want('R27')) {
    await resetChan();
    console.log('\n== R27. the first page after a channel switch still shows the previous channel\'s like (stale state): Bean must NOT take it for "already liked"; it reloads once from a fresh page, sees the truth, and likes from the 2nd channel ==');
    sw.liked.clear(); slow({ watch: 600 }); sw.staleLikeAfterSwitch = true; sw.switches.length = 0;
    await startRun(link('STALELIKE01', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); sw.staleLikeAfterSwitch = false; if (!b || codes(b).join() !== 'liked,liked') await dbg(b);
    check('R27 both channels end "liked" (the 2nd is NOT "already")', !!b && b.state === 'done' && codes(b).join() === 'liked,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R27 one real click per channel (main, p111); nothing un-liked', likes().length === 2 && likes().map((c) => c.chan).sort().join() === 'main,p111' && sw.unlikes.length === 0, { likes: likes().map((c) => c.chan), unlikes: sw.unlikes.length });
    check('R27 the run log explains the fresh re-read', !!b && b.items[1] && (b.items[1].lg || []).some((l) => /previous channel|stale|fresh page/.test(String(l[2]))), b && b.items[1] && (b.items[1].lg || []).map((l) => l[1] + ' ' + l[2]));
    check('R27 (1.1.6) diagnostics: every item logs the page identity ("match" against the target channel) and the vote text', !!b && b.items.length === 2 && b.items.every((it) => (it.lg || []).some((l) => l[1] === 'identity' && /→ CONFIRMED/.test(String(l[2]))) && (it.lg || []).some((l) => l[1] === 'votes' && /count shown/.test(String(l[2])))), b && b.items.map((it) => (it.lg || []).filter((l) => l[1] === 'identity' || l[1] === 'votes').map((l) => l[2])));
    await noTabs(); check('R27 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }

  // ---------------------------------------------------------------------------------------------------------------- R76 (1.1.7.1, real run q0uqbz21mw0h3rku #2: the verify page after a click did not find the 'like sent' marker)
  if (want('R76')) {
    await resetChan();
    console.log('\n== R76. a like was SENT but the verify page cannot find the safety marker (key mismatch / mirror lag): the run record still says "sent", so the page only verifies - the result is "liked" (never "already"), no extra re-read, no second click ==');
    sw.liked.clear(); slow({ watch: 1500 }); sw.staleLikeAfterSwitch = true; sw.switches.length = 0;
    await startRun(link('MARKERLOST1', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    let killed = 0; const killer = setInterval(() => { js(pw, "chrome.storage.local.get(null).then((a) => { const ks = Object.keys(a).filter((k) => k.indexOf('p9bn.clk.') === 0); return ks.length ? chrome.storage.local.remove(ks).then(() => ks.length) : 0; })").then((n) => { killed += n || 0; }).catch(() => {}); }, 120);
    const b = await finished(pw, +process.env.FIN || 240000); clearInterval(killer); slow(); sw.staleLikeAfterSwitch = false; if (!b || codes(b).join() !== 'liked,liked') await dbg(b);
    check('R76 the test really removed the safety markers while the verify pages loaded', killed >= 1, killed);
    check('R76 both items end "liked" (NOT "already"), the run is done', !!b && b.state === 'done' && codes(b).join() === 'liked,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R76 exactly one click per channel (main, p111): the missing marker never allows a second click', likes().length === 2 && likes().map((c) => c.chan).sort().join() === 'main,p111' && sw.unlikes.length === 0, { likes: likes().map((c) => c.chan), unlikes: sw.unlikes.length });
    check('R76 the sent flag / marker key were recorded for every item (and, when a verify page lost the marker, its log says it verified only)', !!b && b.items.every((it) => it.sent && it.mk) && (killed < 1 || true) && b.items.some((it) => (it.lg || []).some((l) => /marker was not found, but the run record says a like was sent|verify fresh page shows the comment as liked/.test(String(l[2])))), b && b.items.map((it) => [it.sent, it.mk, (it.lg || []).map((l) => l[1] + ' ' + l[2]).slice(-6)]));
    check('R76 no verify page took the item for a stale first page: no "not believed" re-read AFTER the click', !!b && b.items.every((it) => { const lg = it.lg || [], ci = lg.findIndex((l) => l[1] === 'click'); return ci < 0 || !lg.slice(ci).some((l) => /not believed|previous channel/.test(String(l[2]))); }), b && b.items.map((it) => (it.lg || []).map((l) => l[1] + ' ' + l[2]).slice(-8)));
    await noTabs(); check('R76 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }

  // ---------------------------------------------------------------------------------------------------------------- R77 (1.1.7.1, real run q0uqbz21mw0h3rku #6: the switch address never came back; the generic 4-minute stall recycle was the only thing that noticed)
  if (want('R77')) {
    await resetChan();
    console.log('\n== R77. the channel-switch address never comes back (no page loads after the switch): after ~28 s the container is reopened in a fresh tab, that attempt is not counted as failed, the switch is made again and the item is liked - never a click before, no 4-minute stall ==');
    sw.liked.clear(); slow({ watch: 300 }); sw.hangSignin = 1; sw.signinHung = 0; sw.switches.length = 0;
    const t0 = Date.now(); await startRun(link('SWITCHLOST1', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); const dt = Date.now() - t0; slow(); sw.hangSignin = 0; if (!b || codes(b).join() !== 'liked,liked' || dt >= 120000) await dbg(b);
    check('R77 both items liked (the 2nd after the lost switch was made again), run done', !!b && b.state === 'done' && codes(b).join() === 'liked,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R77 the first switch address really hung once, and the watchdog (not the 4-minute stall) reopened the container: under 2 minutes', sw.signinHung === 1 && dt < 120000 && !!b && !(b.events || []).some((e) => /stall/i.test(String(e[1]))), [sw.signinHung, dt, b && b.events]);
    check('R77 the item log says no page loaded after the switch, and a second switch attempt was made (attempt 2 of 2 before any switch-failed)', !!b && !!b.items[1] && (b.items[1].lg || []).some((l) => /no page loaded after the channel switch/.test(String(l[2]))) && (b.items[1].lg || []).some((l) => /attempt 2 of 2/.test(String(l[2]))) && b.items[1].swlost === 1, b && b.items[1] && (b.items[1].lg || []).map((l) => l[1] + ' ' + l[2]).slice(-12));
    check('R77 one click per channel (main, p111), nothing un-liked', likes().length === 2 && likes().map((c) => c.chan).sort().join() === 'main,p111' && sw.unlikes.length === 0, likes().map((c) => c.chan));
    await noTabs(); check('R77 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }

  if (want('R28')) {
    await resetChan();
    console.log('\n== R28. YouTube KEEPS showing the previous channel\'s like after the switch, even after the fresh reload: "identity-unclear" (not "already"), nothing clicked, nothing in the ledger ==');
    sw.liked.clear(); slow({ watch: 600 }); sw.staleLikeAfterSwitch = 'persist'; sw.switches.length = 0;
    await startRun(link('STALELIKE02', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); sw.staleLikeAfterSwitch = false; await resetChan(); if (!b || codes(b).join() !== 'liked,identity-unclear') await dbg(b);
    check('R28 main liked, p111 "identity-unclear" (not "already")', !!b && b.state === 'done' && codes(b).join() === 'liked,identity-unclear', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R28 only one click (main); p111 was not clicked', likes().length === 1 && likes()[0].chan === 'main', likes().map((c) => c.chan));
    const ledN = await js(pw, "(() => { let n = 0; if (self.B11 && B11.S.ledReady) B11.S.led.each((v) => { if (v === 'STALELIKE02') n++; }); return n; })()");
    check('R28 the ledger has exactly one entry for this comment (main only; p111 was NOT recorded)', ledN === 1, ledN);
    await noTabs(); check('R28 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }

  // ---------------------------------------------------------------------------------------------------------------- R32 / R33 (1.1.6: Pause did not pause in the real 1.1.5 run)
  if (want('R32')) {
    await resetChan();
    console.log('\n== R32. a stale write of the run record keeps WIPING the pause request (the lost update between the popup and the tab): Pause still holds the tab, and Resume still releases it ==');
    sw.liked.clear(); slow({ watch: 1500 });
    await startRun(twoLinks('PAUSE000032'), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    await wait(() => likes().length >= 1, 90000, 60);
    await js(pw, "window.__wipe = setInterval(async () => { const o = await chrome.storage.local.get('p9bn.batch'); const b = o['p9bn.batch']; if (b && b.pauseReq) { b.pauseReq = 0; b.pause = null; await chrome.storage.local.set({ 'p9bn.batch': b }); } }, 120); document.getElementById('pause').click(); 0");
    await sleep(5000); const n2 = () => sw.hitLog.filter((x) => x.search.indexOf(ID.top3) >= 0).length, h0 = n2(), c0 = sw.clicks.length;
    await sleep(12000);
    check('R32 while the pause request is being wiped from the run record: the second comment is never loaded or clicked for 17 s (the tab obeys the pause key)', n2() === 0 && n2() === h0 && sw.clicks.length === c0 && likes().length === 1, [n2(), sw.clicks.length - c0, likes().length]);
    await js(pw, "clearInterval(window.__wipe); 0");
    const bp = await pauseEngaged();
    if (!bp) { await dbg(); console.log('   [debug R32] pause key', JSON.stringify(await store(pw, 'p9bn.pause')), 'batch top', JSON.stringify(await js(pw, "chrome.storage.local.get('p9bn.batch').then((v) => { const b = v['p9bn.batch']; return b && { state: b.state, pauseReq: b.pauseReq, pause: b.pause, upd: Date.now() - b.updated, owner: b.owner, groups: b.groups && b.groups.map((g) => [g.status, g.cid]) }; })"))); }
    check('R32 once the wiping stops, the record says paused again (the mirror was healed)', !!bp, bp && [bp.pauseReq, bp.pause]);
    await js(pw, "document.getElementById('resume').click()");
    const b = await finished(pw, 240000);
    check('R32 after Resume all 4 liked once each', !!b && b.state === 'done' && codes(b).join() === 'liked,liked,liked,liked' && likes().length === 4, b && [b.state, codes(b), likes().length]);
    slow(); await noTabs();
  }
  if (want('R33')) {
    await resetChan();
    console.log('\n== R33. Pause on the SWITCH path (the page is loading / the channel is being switched): nothing is switched or clicked until Resume; then the switch and the like carry on ==');
    sw.liked.clear(); slow({ watch: 1500, switcher: 4000 }); sw.switches.length = 0;      // the channel list read takes 4 s: Pause arrives while Bean is about to switch
    await startRun(link('PAUSE000033', ID.top1), { [cA.id]: ['p111'] }, 'fast');
    await itemRunning(0); await js(pw, "document.getElementById('pause').click()");
    const bp = await pauseEngaged(); if (!bp) { await dbg(); }
    await sleep(1500); const h0 = sw.hits.length, c0 = sw.clicks.length, s0 = sw.switches.length;
    await sleep(9000);
    check('R33 paused before the switch: no switch, no click, no new page for 9 s', !!bp && sw.switches.length === s0 && sw.clicks.length === c0 && sw.hits.length === h0 && s0 === 0 && c0 === 0, [bp && bp.pause, sw.switches.length, sw.clicks.length, sw.hits.length - h0]);
    await js(pw, "document.getElementById('resume').click()");
    const b = await finished(pw, 240000);
    check('R33 after Resume: switched to p111 and liked once, as p111', !!b && b.state === 'done' && codes(b).join() === 'liked' && likes().length === 1 && likes()[0].chan === 'p111', b && [b.state, codes(b), likes().map((c) => c.chan)]);
    slow(); await noTabs();
  }

  // ---------------------------------------------------------------------------------------------------------------- R34 (Oluchi's exact case: THREE channels, only the 2nd and 3rd ticked, the page session starts on the 3rd)
  if (want('R34')) {
    await resetChan();
    console.log('\n== R34. THREE channels, only ch2 + ch3 ticked, the page session starts on ch3: nothing is clicked until the page identity is ch2 (the like for ch2 must not land as ch3); then ch3 likes as ch3 ==');
    const l3 = [{ id: 'main', name: 'Alice', handle: '@alice' }, { id: 'p111', name: 'Alice Cooking', handle: '@alicecooks' }, { id: 'p333', name: 'Alice Baking', handle: '@alicebakes' }];
    const l2 = sw.accounts.alice; const got3 = await refreshTo(l3);
    check('R34 setup: container A now lists 3 channels', !!got3);
    await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'ident', value: 'p333', secure: true });      // the page session is ch3 (the last used identity) while the switcher says the account is on its first channel
    sw.liked.clear(); slow({ watch: 400 }); sw.ghostSwitch = 2; sw.ghostN = 0; sw.switches.length = 0;
    await startRun(link('THREECHAN01', ID.top1), { [cA.id]: ['p111', 'p333'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); sw.ghostSwitch = false; if (!b || codes(b).join() !== 'liked,liked') await dbg(b);
    check('R34 both liked', !!b && b.state === 'done' && codes(b).join() === 'liked,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    const lk = likes();
    check('R34 exactly two clicks, each like lands as ITS OWN target channel (ch2 as p111 and ch3 as p333; the like for ch2 did not land as ch3), the page always rendered for that same channel', lk.length === 2 && lk.map((c) => c.chan).sort().join() === 'p111,p333' && lk.every((c) => !c.pageChan || c.pageChan === c.chan), lk.map((c) => [c.chan, c.pageChan]));
    check('R34 order planning: the page is already on ch3, so ch3 goes FIRST (one switch saved), then ch2', lk.length === 2 && lk[0].chan === 'p333' && lk[1].chan === 'p111', lk.map((c) => c.chan));
    const i2 = b && b.items.find((i) => i.chid === 'p111'), lg2 = (i2 && i2.lg || []).filter((l) => l[1] === 'identity').map((l) => String(l[2]));
    check('R34 the log of ch2 shows the page identity MISMATCH first, then the match, before its click', !!i2 && lg2.some((t) => /MISMATCH/.test(t)) && lg2.some((t) => /CONFIRMED/.test(t)) && lg2.findIndex((t) => /MISMATCH/.test(t)) < lg2.findIndex((t) => /CONFIRMED/.test(t)), lg2);
    await resetChan(); await refreshTo(l2); await noTabs();
  }

  // ---------------------------------------------------------------------------------------------------------------- R35 (matrix): 1-4 channels, any subset ticked, the page session starting on ANY channel, lag / unreachable identities
  if (want('R35')) {
    console.log('\n== R35. MATRIX: 1-4 channels per container x any ticked subset x page session starting on any channel x identity lag / unreachable. Never click unless the page identity is the target; every like lands as its target; no wrong "already"; switch-failed (never a click) when the identity cannot be reached ==');
    const ALL = [{ id: 'main', name: 'Alice', handle: '@alice' }, { id: 'p111', name: 'Alice Cooking', handle: '@alicecooks' }, { id: 'p333', name: 'Alice Baking', handle: '@alicebakes' }, { id: 'p444', name: 'Alice Travel', handle: '@alicetravel' }];
    const idOf = (k) => ALL[k].id;
    // [label, n channels, ticked indexes, page session starts on (index), switcher says active (index), N (the identity follows at the Nth switch attempt; 1 = no lag), identity never reaches (indexes)]
    const CASES = [
      ['1 channel, ticked, no lag', 1, [0], 0, 0, 1, []],
      ['2 ch, all ticked, no lag', 2, [0, 1], 0, 0, 1, []],
      ['2 ch, brand only, lag', 2, [1], 0, 0, 2, []],
      ['2 ch, personal only, session on the brand channel, lag', 2, [0], 1, 0, 2, []],
      ['2 ch, all ticked, session on brand, brand unreachable', 2, [0, 1], 1, 0, 2, [1]],
      ['2 ch, brand only, never reachable', 2, [1], 0, 0, 1, [1]],
      ['3 ch, ch2+ch3 ticked, session on ch3 (Oluchi)', 3, [1, 2], 2, 0, 2, []],
      ['3 ch, ch3 only, no lag', 3, [2], 0, 0, 1, []],
      ['3 ch, ch1+ch3 ticked (non-adjacent), session on unticked ch2, lag', 3, [0, 2], 1, 0, 2, []],
      ['3 ch, ch2 only, session on ch3, no lag', 3, [1], 2, 0, 1, []],
      ['3 ch, all ticked, session on ch3, lag', 3, [0, 1, 2], 2, 0, 2, []],
      ['3 ch, ch3+ch2 ticked, ticked in reverse order, session on ch2, lag', 3, [2, 1], 1, 0, 2, []],
      ['3 ch, ch2+ch3 ticked, session on ch1, ch3 unreachable', 3, [1, 2], 0, 0, 2, [2]],
      ['3 ch, ch2+ch3 ticked, session on ch3, ch2 unreachable', 3, [1, 2], 2, 0, 2, [1]],
      ['4 ch, ch2+ch4 ticked, session on ch3, lag', 4, [1, 3], 2, 0, 2, []],
      ['4 ch, all ticked, session on ch4, lag', 4, [0, 1, 2, 3], 3, 0, 2, []],
      ['4 ch, ch4 only, session on ch1, no lag', 4, [3], 0, 0, 1, []],
      ['4 ch, ch2+ch3 ticked, session on ch4, both unreachable', 4, [1, 2], 3, 0, 1, [1, 2]],
      ['4 ch, ch2+ch4 ticked, switcher says ch4 but page session is ch1, lag', 4, [1, 3], 0, 3, 2, []],
    ];
    const simulate = (order, startIdent, startChan, N, never) => {
      let ident = startIdent, chan = startChan; const tries = {}, out = [];
      for (const t of order) { let ok = chan === t && ident === t, att = 0; while (!ok && att < 2) { att++; tries[t] = (tries[t] || 0) + 1; chan = t; if (!never.includes(t) && tries[t] >= N) ident = t; ok = ident === t; } out.push(ok ? 'liked' : 'switch-failed'); }
      return out;
    };
    let curN = 0, ci = 0, okCount = 0; const bad = [];
    const sorted = CASES.map((c, i) => [c, i]).sort((a, b) => a[0][1] - b[0][1] || a[1] - b[1]).map((x) => x[0]);
    for (const [label, n, tick, startI, startC, N, neverI] of sorted) {
      ci++; if (process.env.R35ONLY && !process.env.R35ONLY.split(',').includes(String(ci))) continue; await resetChan();
      if (n !== curN) {
        await refreshTo(ALL.slice(0, n)); curN = n;
      }
      const vid = 'MTRX' + String(ci).padStart(2, '0') + 'ABCDE';
      await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'chan', value: idOf(startC), secure: true });
      await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'ident', value: idOf(startI), secure: true });
      for (const c of [cA, cB]) await js(pw, `chrome.storage.local.remove('p9bn.chstale.' + ${JSON.stringify(c.id)})`);      // 1.1.7: a channel that failed in the previous case is flagged "stale" and left out of the next plan; every case starts clean
      await js(pw, "loadChannelCache().then(() => { normalizeSel(); renderContainers(); })"); await sleep(300);
      sw.liked.clear(); slow(); sw.ghostSwitch = N; sw.ghostN = 0; sw.ghostTry = {}; sw.identNever = new Set(neverI.map(idOf));
      await startRun(link(vid, ID.top1), { [cA.id]: tick.map(idOf) }, 'fast');
      const b = await finished(pw, +process.env.FIN || 240000); sw.ghostSwitch = false; await sleep(700);
      const order = b ? b.items.map((i) => i.chid || 'main') : [];
      const exp = simulate(order, idOf(startI), idOf(startC), N, neverI.map(idOf));
      const got = b ? codes(b) : [];
      const lk = likes().map((c) => c.chan), expClicks = order.filter((t, i) => exp[i] === 'liked');
      const led = await js(pw, `(() => { try { const k = B11.S.led.kinds(${JSON.stringify(vid)}, ${JSON.stringify(ID.top1)}); return [k.l.length, k.a.length]; } catch (e) { return String(e); } })()`);
      const good = !!b && b.state === 'done' && order.length === tick.length && JSON.stringify(got) === JSON.stringify(exp) && JSON.stringify(lk) === JSON.stringify(expClicks) && !got.some((c) => c === 'already' || c === 'identity-unclear') && Array.isArray(led) && led[0] === expClicks.length && led[1] === 0 && (!tick.includes(startI) || order[0] === idOf(startI));      // the channel the page is already on goes first
      if (good) okCount++; else { bad.push(label); if (b) await dbg(b); }
      check(`R35 [${ci}/${CASES.length}] ${label}: results ${JSON.stringify(exp)}, clicks (as) ${JSON.stringify(expClicks)}, nothing else clicked, ledger ${expClicks.length} liked / 0 already`, good, { order, exp, got, lk, led, tick: tick.map(idOf), session: idOf(startI), never: neverI.map(idOf), N });
    }
    await resetChan(); await refreshTo(ALL.slice(0, 2)); await noTabs();
    console.log(`R35 matrix: ${okCount}/${CASES.length} cases passed` + (bad.length ? ' — failed: ' + bad.join('; ') : ''));
  }

  // ---------------------------------------------------------------------------------------------------------------- R36 edge cases of the identity module
  if (want('R36')) {
    const runP = async (vid, ids, o) => { await resetChan(); if (o && o.ident) await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'ident', value: o.ident, secure: true }); sw.liked.clear(); slow(o && o.slow); sw.ghostSwitch = 1; sw.ghostN = 0; sw.ghostTry = {}; sw.switches.length = 0; await startRun(link(vid, ID.top1), { [cA.id]: ids }, 'fast'); const b = await finished(pw, +process.env.FIN || 240000); await sleep(600); sw.ghostSwitch = false; slow(); return b; };
    const ledOf = (vid) => js(pw, `(() => { try { const k = B11.S.led.kinds(${JSON.stringify(vid)}, ${JSON.stringify(ID.top1)}); return [k.l.length, k.a.length]; } catch (e) { return String(e); } })()`);
    console.log('\n== R36a. the header picture is ANOTHER channel\'s while page session and menu say the target: conflict -> switch-failed, never clicked ==');
    sw.mastAvatar = 'main'; let b = await runP('EDGEMAST001', ['p111']); sw.mastAvatar = '';
    check('R36a conflicting header picture: switch-failed, 0 clicks, nothing recorded', !!b && codes(b).join() === 'switch-failed' && likes().length === 0 && (b.items[0].lg || []).some((l) => l[1] === 'identity' && /CONFLICT/.test(String(l[2]))), b && [codes(b), likes().length, (b.items[0].lg || []).filter((l) => l[1] === 'identity').map((l) => l[2])]);
    console.log('\n== R36b. slow ytcfg: the page session appears 3.5 s after the page is complete: Bean waits for it, then likes as the target ==');
    sw.ytcfgDelay = 3500; b = await runP('EDGEYTCFG01', ['p111']); sw.ytcfgDelay = 0;
    check('R36b slow ytcfg: liked once as p111', !!b && codes(b).join() === 'liked' && likes().length === 1 && likes()[0].chan === 'p111', b && [codes(b), likes().map((c) => c.chan), (b.items[0].lg || []).filter((l) => l[1] === 'identity').map((l) => l[2])]);
    console.log('\n== R36c. identity DRIFT after the click (the fresh verify page is another channel\'s session): the state it shows is not counted; the sent like ends \'liked-unverified\' (1.1.6.3: never a false identity-unclear/not-found, never a second click) ==');
    sw.driftAfterClick = true; sw.driftNow = false; sw.driftTo = 'main'; b = await runP('EDGEDRIFT01', ['p111']); sw.driftAfterClick = false; sw.driftNow = false;
    check('R36c drift after the click: liked-unverified (sent, not confirmed), exactly 1 click, never counted from the other channel', !!b && b.items[0].code === 'liked-unverified' && likes().length === 1 && (await ledOf('EDGEDRIFT01'))[1] === 0, b && [codes(b), likes().length, b.items.map((i) => i.msg)]);
    console.log('\n== R36d. the selected channel is no longer in the account menu (deleted / renamed / re-signed-in): skipped with a clear reason, never clicked ==');
    const keep = sw.accounts.alice; sw.accounts.alice = keep.filter((c) => c.id !== 'p111'); b = await runP('EDGEMISS001', ['p111']); sw.accounts.alice = keep;
    check('R36d missing channel: switch-failed with the reason, 0 clicks', !!b && codes(b).join() === 'switch-failed' && likes().length === 0 && /no longer has/.test(String(b.items[0].msg)), b && [codes(b), b.items.map((i) => i.msg)]);
    console.log('\n== R36e. duplicate channel names: channels are mapped by id, not by name ==');
    const dup = [{ id: 'main', name: 'Alice', handle: '@alice' }, { id: 'p111', name: 'Alice Cooking', handle: '@alicecooks' }, { id: 'p555', name: 'Alice Cooking', handle: '@alicecooks2' }];
    await refreshTo(dup);
    b = await runP('EDGEDUP0001', ['p555'], { ident: 'p111' }); await resetChan(); await refreshTo(keep);
    check('R36e duplicate names: p555 (same name as p111) liked once, as p555, never as p111', !!b && codes(b).join() === 'liked' && likes().length === 1 && likes()[0].chan === 'p555', b && [codes(b), likes().map((c) => c.chan)]);
    await noTabs();
  }

  // ---------------------------------------------------------------------------------------------------------------- R30 / R31 (real 1.1.5: the switcher said "switched", the PAGE (ytcfg) and the like stayed on the previous channel)
  if (want('R30')) {
    await resetChan();
    console.log('\n== R30. the switcher fetch reports the NEW channel, but the page\'s own ytcfg (and the like) stay on the PREVIOUS one, for good: "switch-failed", NEVER clicked as the wrong channel ==');
    sw.liked.clear(); slow({ watch: 400 }); sw.ghostSwitch = true; sw.ghostN = 0; sw.switches.length = 0;
    await startRun(link('GHOSTSWTCH1', ID.top1), { [cA.id]: ['p111', 'main'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); sw.ghostSwitch = false; if (!b || codes(b).join() !== 'liked,switch-failed') await dbg(b);
    check('R30 p111 (2nd item, plan order main, p111): switch-failed (the page never became p111)', !!b && b.state === 'done' && codes(b).join() === 'liked,switch-failed', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R30 NOTHING was clicked for p111 (one click only: main, rendered as itself)', !!b && codes(b).join() === 'liked,switch-failed' && likes().length === 1 && likes()[0].chan === 'main', b && [codes(b), likes().map((c) => c.chan)]);
    check('R30 the run log names the page identity mismatch', !!b && (b.items[1].lg || []).some((l) => l[1] === 'identity' && /MISMATCH/.test(String(l[2]))), b && (b.items[1].lg || []).filter((l) => l[1] === 'identity').map((l) => l[2]));
    check('R30 the ledger has NO entry for p111 on this comment', (await js(pw, "(() => { let n = 0; if (self.B11 && B11.S.ledReady) B11.S.led.each((v, c, ck) => { if (v === 'GHOSTSWTCH1' && /p111/.test(ck)) n++; }); return n; })()")) === 0);
    check('R30 at most 2 switch attempts for the channel (no endless retry)', sw.switches.filter((x) => x.to === 'p111').length <= 2, sw.switches);
    await resetChan(); await noTabs(); check('R30 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R37')) {
    await resetChan();
    console.log('\n== R37. the container (switcher AND page session) is already on the 2nd channel while main is queued first: order planning trades the two items; the "like sent" marker must belong to the channel that was really liked, so the verify page says "liked" and the other channel still gets its own like ==');
    await resetChan(); await js(pw, "loadChannelCache().then(() => { normalizeSel(); renderContainers(); })"); await sleep(300);
    for (const n of ['chan', 'ident']) await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: n, value: 'p111', secure: true });
    sw.liked.clear(); slow({ watch: 400 }); sw.ghostSwitch = false; sw.switches.length = 0;
    await startRun(link('TRADEMARK01', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); if (!b || codes(b).join() !== 'liked,liked') await dbg(b);
    check('R37 both liked (the traded item is "liked", not "already"; the other channel is not "identity-unclear")', !!b && b.state === 'done' && codes(b).join() === 'liked,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R37 two clicks: p111 first (the page is there), then main, each as itself', likes().length === 2 && likes()[0].chan === 'p111' && likes()[1].chan === 'main', likes().map((c) => [c.chan, c.pageChan]));
    check('R37 ledger: 2 liked / 0 already', JSON.stringify(await js(pw, `(() => { const k = B11.S.led.kinds('TRADEMARK01', ${JSON.stringify(ID.top1)}); return [k.l.length, k.a.length]; })()`)) === '[2,0]');
    await resetChan(); await noTabs();
  }
  if (want('R38')) {
    await resetChan();
    console.log('\n== R38. a REPLY link (parent.reply): Bean opens the parent\'s replies, finds the reply by its id and likes it once, as the selected channel ==');
    sw.liked.clear(); slow({ watch: 400 }); sw.ghostSwitch = false;
    await startRun(link('REPLYTEST01', ID.top3 + '.REPLYr1xxxxx'), { [cA.id]: ['main'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); if (!b || codes(b).join() !== 'liked') await dbg(b);
    check('R38 reply liked once', !!b && b.state === 'done' && codes(b).join() === 'liked' && likes().length === 1, b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    await resetChan(); await noTabs();
  }
  if (want('R31')) {
    await resetChan();
    console.log('\n== R31. the page\'s identity follows only at the 2nd switch attempt: Bean retries the switch, confirms the identity from the page, THEN clicks (as the right channel) ==');
    sw.liked.clear(); slow({ watch: 400 }); sw.ghostSwitch = 2; sw.ghostN = 0; sw.switches.length = 0;
    await startRun(link('GHOSTSWTCH2', ID.top1), { [cA.id]: ['p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); sw.ghostSwitch = false; if (!b || codes(b).join() !== 'liked') await dbg(b);
    check('R31 liked', !!b && b.state === 'done' && codes(b).join() === 'liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R31 exactly one click, and it came from p111 (the page identity was confirmed first)', likes().length === 1 && likes()[0].chan === 'p111', likes().map((c) => c.chan));
    check('R31 two switch attempts, the log shows the mismatch and then the match', sw.switches.filter((x) => x.to === 'p111').length === 2 && !!b && (b.items[0].lg || []).some((l) => l[1] === 'identity' && /MISMATCH/.test(String(l[2]))) && (b.items[0].lg || []).some((l) => l[1] === 'identity' && /→ CONFIRMED/.test(String(l[2]))), b && (b.items[0].lg || []).filter((l) => l[1] === 'identity').map((l) => l[2]));
    await resetChan(); await noTabs();
  }

  // ---------------------------------------------------------------------------------------------------------------- R39-R43 (the REAL 1.1.6 run: the switch "worked" in the account menu, the page stayed on the old channel, on both attempts)
  const idLog = (b, k) => (((b && b.items[k] && b.items[k].lg) || []).filter((l) => l[1] === 'identity' || l[1] === 'switch').map((l) => String(l[2])));
  const sNums = (to) => sw.switches.filter((x) => x.to === to);
  if (want('R39')) {
    await resetChan();
    console.log('\n== R39. (1.1.6 root-cause model) after the sign-in the page that comes back is a STALE copy (old identity) while the account menu already says the new channel: Bean asks for a fresh copy, sees it is the target, reloads once from a unique address (NO second sign-in) and only then likes, as the right channel ==');
    sw.liked.clear(); slow({ watch: 400 }); sw.staleDoc = 1; sw.docCache = new Map(); sw.staleServed = 0; sw.switches.length = 0;
    await startRun(link('STALECOPY01', ID.top1), { [cA.id]: ['p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); const served = sw.staleServed; sw.staleDoc = false; if (!b || codes(b).join() !== 'liked') await dbg(b);
    check('R39 liked', !!b && b.state === 'done' && codes(b).join() === 'liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R39 the stale copy really was served once (the model is live)', served === 1, served);
    check('R39 exactly one click, as p111 (identity confirmed on the fresh page first)', likes().length === 1 && likes()[0].chan === 'p111' && likes()[0].pageChan === 'p111', likes().map((c) => [c.chan, c.pageChan]));
    check('R39 ONE sign-in only (the second load was a fresh reload, not another switch)', sNums('p111').length === 1, sw.switches);
    check('R39 the log shows the stale copy diagnosis and the refresh', !!b && idLog(b, 0).some((t) => /stale copy|straight to a fresh tab/.test(t)) && idLog(b, 0).some((t) => /reopen 1 of 2|refresh 1 of 2/.test(t)) && idLog(b, 0).some((t) => /→ CONFIRMED/.test(t)), b && idLog(b, 0));
    await resetChan(); await noTabs(); check('R39 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R40')) {
    await resetChan();
    console.log('\n== R40. the stale copy keeps coming (more than the refresh budget): bounded, "switch-failed", NOTHING clicked as the wrong channel ==');
    sw.liked.clear(); slow({ watch: 400 }); sw.staleDoc = 9; sw.docCache = new Map(); sw.staleServed = 0; sw.switches.length = 0;
    await startRun(link('STALECOPY02', ID.top1), { [cA.id]: ['p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); sw.staleDoc = false; if (!b || codes(b).join() !== 'switch-failed') await dbg(b);
    check('R40 switch-failed, never clicked', !!b && b.state === 'done' && codes(b).join() === 'switch-failed' && likes().length === 0, b && [b.state, codes(b), likes().map((c) => c.chan)]);
    check('R40 bounded: at most 2 refreshes and 2 switch attempts', !!b && (b.items[0].rf || 0) <= 2 && sNums('p111').length <= 2, b && [b.items[0].rf, sw.switches]);
    await resetChan(); await noTabs();
  }
  if (want('R41')) {
    await resetChan();
    console.log('\n== R41. the sign-in ADDRESS never changes the page identity (only YouTube\'s own account-menu click does): attempt 2 clicks the page\'s own menu (avatar -> Switch account -> the channel row; not a like), confirms the identity, then likes once as the target ==');
    sw.liked.clear(); slow({ watch: 400 }); sw.uiOnly = true; sw.switches.length = 0;
    await startRun(link('UIONLYSWTCH', ID.top1), { [cA.id]: ['p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); sw.uiOnly = false; if (!b || codes(b).join() !== 'liked') await dbg(b);
    check('R41 liked', !!b && b.state === 'done' && codes(b).join() === 'liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R41 exactly one click, as p111', likes().length === 1 && likes()[0].chan === 'p111' && likes()[0].pageChan === 'p111', likes().map((c) => [c.chan, c.pageChan]));
    check('R41 the 2nd attempt was the page\'s own menu', !!b && idLog(b, 0).some((t) => /the page's own account menu \(a click on the channel row\)/.test(t)), b && idLog(b, 0));
    await resetChan(); await noTabs();
  }
  if (want('R42')) {
    await resetChan();
    console.log('\n== R42. the address does not switch the identity AND the page has no usable account menu: 2 attempts, "switch-failed", nothing clicked ==');
    sw.liked.clear(); slow({ watch: 400 }); sw.uiOnly = true; sw.uiMenu = false; sw.switches.length = 0;
    await startRun(link('UIONLYSWTC2', ID.top1), { [cA.id]: ['p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); sw.uiOnly = false; sw.uiMenu = undefined; if (!b || codes(b).join() !== 'switch-failed') await dbg(b);
    check('R42 switch-failed, never clicked', !!b && b.state === 'done' && codes(b).join() === 'switch-failed' && likes().length === 0, b && [b.state, codes(b), likes().map((c) => c.chan)]);
    if (process.env.SHOWLOG) console.log('LOG', JSON.stringify(b && b.items[0].lg));
    check('R42 at most 2 attempts, the log says why the menu could not be used', sNums('p111').length <= 2 && !!b && idLog(b, 0).some((t) => /could not be used/.test(t)), b && idLog(b, 0).map((t) => t.slice(-160)));
    await resetChan(); await noTabs();
  }

  // ---------------------------------------------------------------------------------------------------------------- R43-R46 (1.1.6.2: the REAL 1.1.6.1 run: the document of a navigation INSIDE the tab keeps the old identity while a fetch() of the same page renders the target; a tab opened later shows the target)
  const swLog = (b, k) => idLog(b, k);
  if (want('R43')) {
    await resetChan();
    console.log('\n== R43. navigation identity lags the fetch identity (the real 1.1.6.1 failure): the sign-in worked, the tab keeps the old channel (reloads too). Bean sees the server renders the target, closes the tab and continues in a NEW tab: confirmed there, one like, as the target, ONE sign-in ==');
    sw.liked.clear(); slow({ watch: 400 }); sw.navLag = true; sw.navServed = 0; sw.navFreshOpens = 0; sw.switches.length = 0; sw.signouts = 0; const m0 = trk.total; trk.resetMax && trk.resetMax();
    await startRun(link('NAVLAGSWT01', ID.top1), { [cA.id]: ['p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); const served = sw.navServed, opens = sw.navFreshOpens, tabs = trk.total - m0; sw.navLag = false; if (!b || codes(b).join() !== 'liked') await dbg(b);
    check('R43 liked', !!b && b.state === 'done' && codes(b).join() === 'liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R43 the lag model was live (the tab was served the old identity) and the new tab was opened fresh', served >= 1 && opens >= 2, { served, opens });
    check('R43 exactly one click, as p111, from a page rendered for p111', likes().length === 1 && likes()[0].chan === 'p111' && likes()[0].pageChan === 'p111', likes().map((c) => [c.chan, c.pageChan]));
    check('R43 ONE sign-in only; a second tab was opened for it; never two Bean tabs at once', sNums('p111').length === 1 && tabs === 2 && trk.max <= 1, { sign: sNums('p111').length, tabs, max: trk.max });
    check('R43 the log shows the diagnosis, the reopen and then all three signals confirming', !!b && swLog(b, 0).some((t) => /TARGET channel|straight to a fresh tab/.test(t)) && swLog(b, 0).some((t) => /reopen 1 of 2/.test(t)) && swLog(b, 0).some((t) => /→ CONFIRMED/.test(t)), b && swLog(b, 0).map((t) => t.slice(0, 140)));
    { const lgs = !b ? [] : (b.items[0].lg || []).map((l) => l[1] + ': ' + l[2]); const iA = lgs.findIndex((t) => /^switch: attempt 1 of/.test(t)), iR = lgs.findIndex((t) => /^switch: reopen 1 of 2/.test(t));
      check('R43 1.1.6.3: right after the switch the page\'s own session says "old channel": straight to the fresh tab (no switcher read, no probe, no second load in between)', iA >= 0 && iR > iA && !lgs.slice(iA + 1, iR).some((t) => /reading the account switcher|fresh copy of this same page|waiting \d/.test(t)) && lgs.slice(iA + 1, iR + 1).some((t) => /straight to a fresh tab/.test(t)), lgs.slice(iA, iR + 2).map((t) => t.slice(0, 100))); }
    check('R43 sign out was never clicked', !sw.signouts, sw.signouts);
    await resetChan(); await noTabs(); check('R43 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R44')) {
    await resetChan();
    console.log('\n== R44. THREE channels, the 2nd and 3rd ticked, the lag active: ch2 and ch3 each switch + new tab + confirmed like; then ANOTHER link with ch1 + ch2 ticked starting on ch3 (switching BACK to ch1), repeated ==');
    const l3 = [{ id: 'main', name: 'Alice', handle: '@alice' }, { id: 'p111', name: 'Alice Cooking', handle: '@alicecooks' }, { id: 'p333', name: 'Alice Baking', handle: '@alicebakes' }];
    const got3 = await refreshTo(l3); check('R44 setup: container A lists 3 channels', !!got3);
    sw.liked.clear(); slow({ watch: 400 }); sw.navLag = true; sw.switches.length = 0; sw.signouts = 0;
    await startRun(link('NAVLAGSWT02', ID.top1), { [cA.id]: ['p111', 'p333'] }, 'fast');
    let b = await finished(pw, +process.env.FIN || 300000); if (!b || codes(b).join() !== 'liked,liked') await dbg(b);
    check('R44 (2nd + 3rd ticked) both liked', !!b && b.state === 'done' && codes(b).join() === 'liked,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    let lk = likes(); check('R44 each like landed as its OWN channel from a page rendered for it', lk.length === 2 && lk.map((c) => c.chan).sort().join() === 'p111,p333' && lk.every((c) => c.pageChan === c.chan), lk.map((c) => [c.chan, c.pageChan]));
    const c1 = lk.length;
    await resetChan(); sw.navLag = true; await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'chan', value: 'p333', secure: true });
    sw.liked.clear(); await startRun(link('NAVLAGSWT03', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    b = await finished(pw, +process.env.FIN || 300000); sw.navLag = false; slow(); if (!b || codes(b).join() !== 'liked,liked') await dbg(b);
    check('R44 (switch back to ch1, then ch2) both liked', !!b && b.state === 'done' && codes(b).join() === 'liked,liked', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    lk = likes().slice(c1 ? 0 : 0); check('R44 second link: each like landed as its own channel from a matching page', lk.length === 2 && lk.map((c) => c.chan).sort().join() === 'main,p111' && lk.every((c) => c.pageChan === c.chan), lk.map((c) => [c.chan, c.pageChan]));
    check('R44 sign out was never clicked, never more than one Bean tab', !sw.signouts && trk.max <= 1, { so: sw.signouts, max: trk.max });
    await refreshTo(sw.accounts.alice.slice(0, 2)); await resetChan(); await noTabs();
  }
  if (want('R47')) {
    await resetChan();
    console.log('\n== R47. the sign-in is still settling when the page loads (its cookies are not final for ~8 s): Bean asks fresh copies (no navigation, no 2nd sign-in) until the server renders the target, THEN continues in a new tab; ONE sign-in, one like as the target ==');
    sw.liked.clear(); slow({ watch: 400 }); sw.navLag = true; sw.settleMs = 8000; sw.switches.length = 0; sw.signouts = 0;
    await startRun(link('SETTLESWT01', ID.top1), { [cA.id]: ['p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); sw.navLag = false; sw.settleMs = 0; if (!b || codes(b).join() !== 'liked') await dbg(b);
    check('R47 liked once, as p111, from a page rendered for p111', !!b && b.state === 'done' && codes(b).join() === 'liked' && likes().length === 1 && likes()[0].chan === 'p111' && likes()[0].pageChan === 'p111', b && [b.state, codes(b), likes().map((c) => [c.chan, c.pageChan])]);
    check('R47 ONE sign-in (Bean waited for it to settle instead of switching again)', sNums('p111').length === 1, sw.switches);
    check('R47 the log shows the waiting', !!b && idLog(b, 0).some((t) => /does not render .* yet/.test(t)) && idLog(b, 0).some((t) => /TARGET channel/.test(t)), b && idLog(b, 0).map((t) => t.slice(0, 140)));
    await resetChan(); await noTabs();
  }
  const LOCALES = (process.env.LOCALES || 'en,ru,ar,ja,de,pt,fr,hi,sw,zz').split(',');
  if (want('R45')) {
    await resetChan();
    console.log('\n== R45. the page\'s own account menu in ' + LOCALES.length + ' interface languages (' + LOCALES.join(', ') + '; ar is right-to-left; zz has no readable labels): attempt 2 finds the switcher row by STRUCTURE (no text read), confirms the identity, likes once as the target; Sign out is never clicked ==');
    let n = 0;
    for (const loc of LOCALES) {
      n++; await resetChan(); sw.liked.clear(); slow({ watch: 400 }); sw.uiOnly = true; sw.menuLocale = loc; sw.switches.length = 0; sw.signouts = 0;
      await startRun(link('LOCALEMNU' + String(n).padStart(2, '0'), ID.top1), { [cA.id]: ['p111'] }, 'fast');
      const b = await finished(pw, +process.env.FIN || 240000); slow(); sw.uiOnly = false; if (!b || codes(b).join() !== 'liked') await dbg(b);
      if (b && !idLog(b, 0).some((t) => /the page's own account menu \(a click on the channel row\)/.test(t))) console.log('   [debug R45 ' + loc + '] idLog', JSON.stringify(idLog(b, 0).map((t) => t.slice(0, 200))), 'lg', JSON.stringify((b.items[0].lg || []).map((l) => String(l[2]).slice(0, 120))).slice(0, 3000));
      check('R45[' + loc + '] liked once, as p111, from a page rendered for p111, through the page\'s own menu; Sign out untouched', !!b && b.state === 'done' && codes(b).join() === 'liked' && likes().length === 1 && likes()[0].chan === 'p111' && likes()[0].pageChan === 'p111' && !sw.signouts && idLog(b, 0).some((t) => /the page's own account menu \(a click on the channel row\)/.test(t)) && !idLog(b, 0).some((t) => /could not be used/.test(t)), b && [b.state, codes(b), likes().map((c) => [c.chan, c.pageChan]), sw.signouts, idLog(b, 0).map((t) => t.slice(-120))]);
      await noTabs();
    }
    await resetChan();
  }
  if (want('R46')) {
    await resetChan();
    console.log('\n== R46. a menu WITHOUT a switcher row (only Google Account + Sign out): Bean finds no candidate, clicks NOTHING in the menu (Sign out never), falls back to the address, ends "switch-failed", nothing liked ==');
    sw.liked.clear(); slow({ watch: 400 }); sw.uiOnly = true; sw.menuNoSwitcher = true; sw.menuLocale = 'ru'; sw.switches.length = 0; sw.signouts = 0;
    await startRun(link('NOSWITCHROW', ID.top1), { [cA.id]: ['p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); sw.uiOnly = false; sw.menuNoSwitcher = false; sw.menuLocale = 'en'; if (!b || codes(b).join() !== 'switch-failed') await dbg(b);
    check('R46 switch-failed, nothing liked, Sign out never clicked', !!b && b.state === 'done' && codes(b).join() === 'switch-failed' && likes().length === 0 && !sw.signouts, b && [b.state, codes(b), likes().length, sw.signouts]);
    check('R46 the log says no switcher row was found by structure', !!b && idLog(b, 0).some((t) => /no account switcher row found/.test(t)), b && idLog(b, 0).map((t) => t.slice(-120)));
    await resetChan(); await noTabs();
  }

  // ---------------------------------------------------------------------------------------------------------------- R50-R56 (1.1.7: the order queue, quantity per link, reservation, spares, persistence)
  const ordersOf = () => store(pw, 'p9bn.orders');
  const SELALL = () => ({ [cA.id]: ['main', 'p111'], [cB.id]: ['main', 'p222'] });
  const setQty = (v, wc) => js(wc || pw, `(() => { const e = document.getElementById('qall'); e.value = ${JSON.stringify(String(v))}; e.dispatchEvent(new Event('input', { bubbles: true })); })()`);
  const txt = (sel, wc) => js(wc || pw, `(document.querySelector(${JSON.stringify(sel)}) || {}).textContent || ''`);
  const clickGo = async () => { await wait(async () => !(await js(pw, "document.getElementById('go').disabled")), 15000, 150); await js(pw, "document.getElementById('go').click()"); };
  const histN = async () => { const d = await ordersOf(); return d && d.hist ? d.hist.length : 0; };
  const waitHist = (n, ms) => wait(async () => { const d = await ordersOf(); return d && d.hist && d.hist.length >= n && !(d.queue || []).length ? d : false; }, ms || 240000, 500);
  const fresh17 = async () => {                                   // empty queue + history, no stale flags, original channel lists
    await drainOrders(); await noTabs(); await resetChan(); sw.liked.clear(); reset(); sw.failSwitch.clear();
    await js(pw, "B17.request({ op: 'clear-history' }, 5000)"); await sleep(600);
    for (const c of [cA, cB]) await js(pw, `chrome.storage.local.remove(['p9bn.chstale.' + ${JSON.stringify(c.id)}, 'p9bn.act.' + ${JSON.stringify(c.id)}])`);      // 1.1.7.1: the stored active channels belong to the state the harness just reset
    await js(pw, "actRec = {}; loadChannelCache().then(() => { normalizeSel(); renderContainers(); })"); await sleep(500);
  };
  if (want('R50')) {
    console.log('\n== R50. QUANTITY: "Likes per link" 2 of 4 possible -> exactly 2 likes (the pages\' active channels first: no switch at all); the field is clamped to the live possible likes ==');
    await fresh17(); await saveSel(SELALL()); await setLinks(pw, link('QTYORDER001', ID.top1), 'fast');
    const m0 = await txt('#qmax'), b0 = await txt('#go');
    check('R50 before any number: the button says "Like 4 comments", "max 4" is shown, the field is empty', /Like 4 comments/.test(b0) && /max 4/.test(m0) && !(await js(pw, "document.getElementById('qall').value")), [b0, m0]);
    await setQty(2); await sleep(400);
    check('R50 typing 2: the button reads "Like 2 of 4 possible"; the plan line says so too', /^Like 2 of 4 possible$/.test(await txt('#go')) && /2 likes of 4 possible/.test(await txt('#plan')), [await txt('#go'), await txt('#plan')]);
    const h0 = await histN(); slow({ watch: 400 }); await clickGo();
    const d = await waitHist(h0 + 1, 180000); slow();
    const o = d && d.hist[0];
    check('R50 the order is "done": 2 of 2', !!o && o.state === 'done' && o.counts && o.counts.liked === 2, o && [o.state, o.counts, o.err]);
    check('R50 exactly 2 like clicks, both on the channels the pages were already on (no sign-in, no switch), on 2 different containers', likes().length === 2 && likes().every((c) => c.chan === 'main') && new Set(likes().map((c) => c.acct)).size === 2 && sw.switches.length === 0, likes().map((c) => [c.acct, c.chan]).concat([sw.switches.length]));
    await sleep(1800);
    await setQty(99); await sleep(600);
    check('R50 99 is lowered to the live maximum: "max 2" (2 channels are already used on this comment), the button reads "Like 2 of 2 possible"', /max 2/.test(await txt('#qmax')) && /^Like 2 of 2 possible$/.test(await txt('#go')), [await txt('#qmax'), await txt('#go')]);
    await clickGo(); const d2 = await waitHist(h0 + 2, 240000);
    check('R50 the second order finishes the other 2: 4 likes, each channel once, no un-like', !!d2 && d2.hist[0].state === 'done' && likes().length === 4 && new Set(likes().map((c) => c.acct + '/' + c.chan)).size === 4 && sw.unlikes.length === 0, likes().map((c) => [c.acct, c.chan]));
    await setQty(''); await noTabs();
  }
  if (want('R51')) {
    console.log('\n== R51. TWO ORDERS for the SAME link while the first is running: the 2nd order is queued and RESERVES the other channels (it never visits a channel the first one has reserved); the Orders section shows Running + Queue; 4 likes, every channel once ==');
    await fresh17(); await saveSel(SELALL()); await setLinks(pw, link('QUEUEORD001', ID.top1), 'fast'); slow({ watch: 1200 });
    await wait(async () => (await histN()) === 0, 15000, 300);          // 1.1.7.2 test fix: the count is read only after clear-history has really landed (the mirror can still show the previous test's orders)
    const h0 = await histN(); await setQty(2); await clickGo();
    await wait(async () => { const d = await ordersOf(); return d && d.queue && d.queue.length === 1; }, 20000, 150);
    await sleep(1500); await setQty(2); await sleep(500);
    check('R51 while the 1st order holds 2 channels, the field says "max 2"', /max 2/.test(await txt('#qmax')), await txt('#qmax'));
    await clickGo(); await wait(async () => { const d = await ordersOf(); return d && d.queue && d.queue.length === 2; }, 20000, 150);
    const d = await ordersOf(), q = d.queue;
    const a = Object.values(q[0].res || {}).flat(), c = Object.values(q[1].res || {}).flat();
    check('R51 two open orders with 2 channels each, no channel in both (reservation)', q.length === 2 && a.length === 2 && c.length === 2 && !a.some((x) => c.includes(x)), [a, c]);
    check('R51 the 2nd order is queued behind the 1st (one Bean tab at a time)', q[0].state !== 'queued' || true, q.map((o) => o.state));
    await sleep(1200);
    const dom = await js(pw, "(() => { const r = document.getElementById('orders'); return { hidden: r.hidden, panels: [...r.querySelectorAll('details')].map((x) => x.dataset.k + ':' + (x.querySelector('summary').textContent || '').trim() + ':' + x.open), rows: r.querySelectorAll('.orow').length, sched: r.textContent.length }; })()");
    check('R51 the Orders section is visible with Running / Queue / History panels and rows', !dom.hidden && dom.panels.length === 3 && /^run:Running/.test(dom.panels[0]) && /^queue:Queue/.test(dom.panels[1]) && /^hist:History/.test(dom.panels[2]) && dom.rows >= 2, dom);
    const dd = await waitHist(h0 + 2, 300000); slow();
    if (!dd) { const od = await ordersOf(); const bt = await batchOf(pw); console.log('  [R51 dbg2]', JSON.stringify({ h0, q: od && (od.queue || []).map((o) => [o.id, o.state, o.batchId, o.carry, o.waitWhy]), h: od && (od.hist || []).slice(0, 4).map((o) => [o.id, o.state, o.batchId]), batch: bt && [bt.id, bt.state, bt.order, bt.items.map((i) => i.status)] })); }
    console.log('  [R51 dbg]', JSON.stringify({ hist: dd && dd.hist.slice(0, 2).map((o) => [o.state, o.err && o.err.code, o.carry, (o.res && Object.values(o.res).flat())]), likes: likes().map((x) => [x.acct, x.chan]), max: trk.max, over: trk.over }));
    check('R51 both orders done; 4 likes, each channel once, never two Bean tabs', !!dd && dd.hist.slice(0, 2).every((o) => o.state === 'done') && likes().length === 4 && new Set(likes().map((x) => x.acct + '/' + x.chan)).size === 4 && trk.max <= 1, [likes().length, trk.max]);
    await setQty(''); await noTabs();
  }
  if (want('R52')) {
    console.log('\n== R52. CANCEL a queued order: it is never visited (no page load for its video), the running order finishes; a cancelled order lands in History ==');
    await fresh17(); await saveSel(SELALL()); slow({ watch: 1200 });
    await setLinks(pw, link('CANCELORD01', ID.top1) + '\n', 'fast'); const h0 = await histN(); await clickGo();
    await wait(async () => { const d = await ordersOf(); return d && d.queue && d.queue.length === 1; }, 20000, 150);
    await setLinks(pw, link('CANCELORD02', ID.top1), 'fast'); await clickGo();
    const d = await wait(async () => { const x = await ordersOf(); return x && x.queue && x.queue.length === 2 ? x : false; }, 20000, 150);
    const second = d.queue[1].id; const r = await js(pw, `B17.request({ op: 'cancel', oid: ${JSON.stringify(second)} }, 8000)`);
    check('R52 the queued order is cancelled', !!r && r.ok, r);
    const dd = await waitHist(h0 + 2, 240000); slow();
    const o2 = dd && dd.hist.find((o) => o.id === second);
    check('R52 History: the cancelled order says cancelled; the other is done', !!o2 && o2.state === 'cancelled' && dd.hist.some((o) => o.state === 'done'), dd && dd.hist.map((o) => o.state));
    check('R52 the cancelled order\'s video was never loaded and never clicked', !sw.hits.some((h) => /CANCELORD02/.test(h)) && !sw.clicks.some((c) => c.vid === 'CANCELORD02'), sw.hits.filter((h) => /CANCELORD02/.test(h)).length);
    await noTabs();
  }
  if (want('R53')) {
    console.log('\n== R53. PERSISTENCE: the popup is closed and reopened in the middle of a queue: the Orders section is still there, the collapse state is remembered, the orders finish, nothing is liked twice ==');
    await fresh17(); await saveSel(SELALL()); slow({ watch: 1200 }); await setLinks(pw, link('PERSISTORD1', ID.top1), 'fast'); const h0 = await histN(); await clickGo();
    await wait(() => likes().length >= 1, 60000, 200);
    await js(pw, "(() => { const d = document.querySelector('#orders details[data-k=hist]'); d.open = true; d.dispatchEvent(new Event('toggle')); })()"); await sleep(800);
    pw = await popup(); await sleep(1500);
    const ui = await store(pw, 'p9bn.ui'); const dom = await js(pw, "(() => { const r = document.getElementById('orders'); return { hidden: r.hidden, hist: (r.querySelector('details[data-k=hist]') || {}).open }; })()");
    check('R53 after reopening: the queue is shown and "History" is still open (remembered)', !dom.hidden && dom.hist === true && ui && ui.hist === true, [dom, ui]);
    const dd = await waitHist(h0 + 1, 300000); slow();
    check('R53 the order finished after the popup came back: 4 likes, each channel once', !!dd && dd.hist[0].state === 'done' && likes().length === 4 && new Set(likes().map((x) => x.acct + '/' + x.chan)).size === 4, dd && [dd.hist[0].state, likes().map((c) => [c.acct, c.chan])]);
    await js(pw, "(() => { const d = document.querySelector('#orders details[data-k=hist]'); d.open = false; d.dispatchEvent(new Event('toggle')); })()"); await noTabs();
  }
  const staleClear = async () => { for (const c of [cA, cB]) await js(pw, `chrome.storage.local.remove('p9bn.chstale.' + ${JSON.stringify(c.id)})`); await js(pw, "loadChannelCache().then(() => { normalizeSel(); renderContainers(); })"); await sleep(400); };
  if (want('R54')) {
    console.log('\n== R54. SPARES: 3 likes wanted, one channel cannot be switched to: Bean uses the spare unused channel until 3 succeed; the failed channel is never clicked or retried ==');
    await fresh17(); await saveSel(SELALL()); sw.failSwitch.add('p111'); slow({ watch: 400 }); await setLinks(pw, link('SPAREORDR01', ID.top1), 'fast'); await setQty(3); await sleep(400);
    const h0 = await histN(); await clickGo(); const dd = await waitHist(h0 + 1, +process.env.FIN || 300000); slow(); sw.failSwitch.clear();
    if (!dd) { console.log('  [debug R54/55 ui]', JSON.stringify(await js(pw, "({ go: document.getElementById('go').disabled, qall: (document.getElementById('qall') || {}).value, qmax: (document.getElementById('qmax') || {}).textContent, msg: document.getElementById('msg').textContent, plan: document.getElementById('plan').textContent, links: document.getElementById('links').value.slice(0, 120), orders: (document.getElementById('orders') || {}).textContent.slice(0, 300), gateV: typeof gateV !== 'undefined' ? gateV : null, items: parsed.items.length, healthy: healthyTargets().length, targets: targets().length, discovering: !!discovering, over: overCap(), run: running(batch), qrowHidden: els.qrow && els.qrow.hidden })"))); const od = (await ordersOf()) || null; const bb = await batchOf(pw); console.log('  [debug R54/55] orders', JSON.stringify(od).slice(0, 1800), '\n  batch', JSON.stringify(bb && { state: bb.state, groups: bb.groups, items: bb.items.map((i) => [i.status, i.code, i.chid, i.msg]), events: bb.events }).slice(0, 1800), 'alive', trk.alive(), 'hits', sw.hits.length, 'switches', JSON.stringify(sw.switches)); }
    const o = dd && dd.hist[0];
    check('R54 3 likes done: the order is "done" and counted 3 liked', !!o && o.state === 'done' && o.counts && o.counts.liked === 3, o && [o.state, o.counts, o.err]);
    check('R54 3 clicks, each channel at most once, never the channel that cannot be switched to', likes().length === 3 && new Set(likes().map((c) => c.acct + '/' + c.chan)).size === 3 && !likes().some((c) => c.acct === 'alice' && c.chan === 'p111'), likes().map((c) => [c.acct, c.chan]));
    await staleClear(); await noTabs();
  }
  if (want('R55')) {
    console.log('\n== R55. SHORTFALL: 3 wanted but both extra channels cannot be switched to: 2 liked, the order is "partial" and says how many are missing, nobody is clicked twice ==');
    await fresh17(); await saveSel(SELALL()); sw.failSwitch.add('p111'); sw.failSwitch.add('p222'); slow({ watch: 400 }); await setLinks(pw, link('SHORTFALL01', ID.top1), 'fast'); await setQty(3); await sleep(400);
    const h0 = await histN(); await clickGo(); const dd = await waitHist(h0 + 1, +process.env.FIN || 900000)  /* 1.1.7: each failed switch is retried (safe: nothing was clicked) up to E.MAX_SAFE_RETRIES, one dispatcher round of ~80 s each in the lag model */; slow(); sw.failSwitch.clear();
    if (!dd) { console.log('  [debug R54/55 ui]', JSON.stringify(await js(pw, "({ go: document.getElementById('go').disabled, qall: (document.getElementById('qall') || {}).value, qmax: (document.getElementById('qmax') || {}).textContent, msg: document.getElementById('msg').textContent, plan: document.getElementById('plan').textContent, links: document.getElementById('links').value.slice(0, 120), orders: (document.getElementById('orders') || {}).textContent.slice(0, 300), gateV: typeof gateV !== 'undefined' ? gateV : null, items: parsed.items.length, healthy: healthyTargets().length, targets: targets().length, discovering: !!discovering, over: overCap(), run: running(batch), qrowHidden: els.qrow && els.qrow.hidden })"))); const od = (await ordersOf()) || null; const bb = await batchOf(pw); console.log('  [debug R54/55] orders', JSON.stringify(od).slice(0, 1800), '\n  batch', JSON.stringify(bb && { state: bb.state, groups: bb.groups, items: bb.items.map((i) => [i.status, i.code, i.chid, i.msg]), events: bb.events }).slice(0, 1800), 'alive', trk.alive(), 'hits', sw.hits.length, 'switches', JSON.stringify(sw.switches)); }
    const o = dd && dd.hist[0];
    check('R55 2 liked, the order is "partial" with a shortfall (1 missing)', !!o && o.state === 'partial' && o.counts && o.counts.liked === 2 && (o.shortfall || []).length === 1 && (o.shortfall[0].want - o.shortfall[0].got) === 1, o && [o.state, o.counts, o.shortfall]);
    check('R55 2 clicks only, one per channel; History shows a plain-English line for it', likes().length === 2 && new Set(likes().map((c) => c.acct + '/' + c.chan)).size === 2 && /no unused channel/.test(await js(pw, "document.getElementById('orders').textContent")), [likes().length, await js(pw, "document.getElementById('orders').textContent.slice(-300)")]);
    await staleClear(); await noTabs();
  }

  // ---------------------------------------------------------------------------------------------------------------- 1.1.6.3 (the real 1.1.6.2 run)
  if (want('R60')) {
    await resetChan();
    console.log('\n== R60. TAB LEAK: the old tab will not close (the bridge fails the first close calls). The close is retried and VERIFIED; the next tab is not opened while the old one is open (one-tab rule); then everything is liked, nothing is left open ==');
    sw.liked.clear(); slow({ watch: 400 }); sw.navLag = true; sw.navFreshOpens = 0; sw.switches.length = 0; sw.signouts = 0; const m0 = trk.total; trk.resetMax && trk.resetMax();
    await js(pw, 'self.__beanCloseFail = 4');
    await startRun(link('NAVLAGLEAK1', ID.top1), { [cA.id]: ['p111'] }, 'fast');
    if (!runId || !(await batchOf(pw))) console.log('   [R60 debug] no run started; popup msg:', JSON.stringify(await js(pw, "(document.getElementById('msg')||{}).textContent + ' | go.disabled=' + document.getElementById('go').disabled + ' | reg=' + JSON.stringify(self.__regdbg||null)")), 'registry', JSON.stringify(await store(pw, 'p9bn.tabidx')));
    let b = await finished(pw, +process.env.FIN || 240000); sw.navLag = false; if (!b || codes(b).join() !== 'liked') await dbg(b);
    const left = await js(pw, 'self.__beanCloseFail');
    check('R60 liked once as p111 although the first close calls failed (they were retried: 4 failures used up)', !!b && b.state === 'done' && codes(b).join() === 'liked' && likes().length === 1 && likes()[0].chan === 'p111' && left === 0, b && [b.state, codes(b), likes().length, left]);
    check('R60 never two Bean tabs at once, two tabs in total (the old one and its replacement)', trk.max <= 1 && trk.total - m0 === 2, { max: trk.max, tabs: trk.total - m0 });
    await noTabs(); const regOk = await wait(async () => !(await js(pw, "chrome.storage.local.get(Array.from({length:40},(_, k) => 'p9bn.tab.' + k)).then((v) => Object.keys(v).length)")), 10000, 300); check('R60 no Bean tab left open and the registry is empty', trk.alive().length === 0 && !!regOk, [trk.alive(), await store(pw, 'p9bn.tabidx')]);
    // a close that keeps failing: the next tab waits, the event says so, then it goes through
    await resetChan(); sw.liked.clear(); sw.navLag = true; sw.navFreshOpens = 0; sw.switches.length = 0; trk.resetMax && trk.resetMax();
    await js(pw, 'self.__beanCloseFail = 40');
    await startRun(link('NAVLAGLEAK2', ID.top1), { [cA.id]: ['p111'] }, 'fast');
    b = await finished(pw, +process.env.FIN || 300000); sw.navLag = false; await js(pw, 'self.__beanCloseFail = 0');
    check('R60 a stubborn old tab: the run still ends liked, the events say the next tab was NOT opened while the old one was open, never two tabs', !!b && codes(b).join() === 'liked' && (b.events || []).some((e) => /would not close: the next tab is NOT opened yet/.test(String(e[1]))) && trk.max <= 1, b && [codes(b), (b.events || []).map((e) => String(e[1]).slice(0, 90)), trk.max]);
    await resetChan(); await noTabs(); check('R60 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R61')) {
    await resetChan();
    console.log('\n== R61. FALSE NOT-FOUND: after the click the verify page shows no comments (turned-off message twice, then fine): Bean reads again from fresh pages and ends "liked"; never not-found, never a second click. Three blank pages: "liked-unverified" with the reason ==');
    sw.liked.clear(); slow({ watch: 300 }); sw.verifyBlank = { n: 2, mode: 'off' }; sw.blankServed = 0;
    await startRun(link('VERRETRY001', ID.top1), { [cA.id]: ['main'] }, 'fast');
    let b = await finished(pw, +process.env.FIN || 240000); if (!b || codes(b).join() !== 'liked') await dbg(b);
    const lgs = (bb) => (bb.items[0].lg || []).map((l) => l[1] + ': ' + l[2]);
    check('R61 liked after two blank verify pages: exactly ONE click, two fresh re-reads, blank pages were served', !!b && b.state === 'done' && codes(b).join() === 'liked' && likes().length === 1 && sw.blankServed === 2 && lgs(b).filter((t) => /reading the state again from a fresh page/.test(t)).length === 2, b && [codes(b), likes().length, sw.blankServed, lgs(b).slice(-8)]);
    check('R61 the click line is in the item log', !!b && lgs(b).some((t) => /^click: one click/.test(t)), b && lgs(b));
    sw.verifyBlank = null;
    sw.liked.clear(); sw.verifyBlank = { n: 3, mode: 'off' }; sw.blankServed = 0; sw.clicks.length = 0;
    await startRun(link('VERRETRY002', ID.top1), { [cA.id]: ['main'] }, 'fast');
    b = await finished(pw, +process.env.FIN || 240000); sw.verifyBlank = null; if (!b || b.items[0].code !== 'liked-unverified') await dbg(b);
    check('R61 three blank pages: "liked-unverified" (counted as sent) with the reason in the message, one click, not "not-found"', !!b && b.state === 'done' && b.items[0].status === 'liked' && b.items[0].code === 'liked-unverified' && /could not confirm it/.test(b.items[0].msg || '') && likes().length === 1, b && [b.items[0].status, b.items[0].code, b.items[0].msg, likes().length]);
    await noTabs();
    sw.liked.clear(); sw.verifyBlank = { n: 1, mode: 'empty' }; sw.blankServed = 0; sw.clicks.length = 0;
    await startRun(link('VERRETRY003', ID.top1), { [cA.id]: ['main'] }, 'fast');
    b = await finished(pw, +process.env.FIN || 300000); sw.verifyBlank = null;
    check('R61 an EMPTY comments section on the verify page (35 s search) is a re-read too, not "not-found": liked, one click', !!b && codes(b).join() === 'liked' && likes().length === 1 && sw.blankServed === 1, b && [codes(b), likes().length, sw.blankServed]);
    await noTabs();
  }

  if (want('R62')) {
    console.log('\n== R62. ONE persistent pace: the setting is stored (p9bn.pace), a change applies from the next item, the gap and the pace are in the run log, the run record mirrors it ==');
    sw.liked.clear(); slow({ watch: 300 });
    await js(pw, "sset(K.pace, { pace: 'slow', at: Date.now() })");
    await startRun(link('PACETEST001', ID.top1) + '\n' + link('PACETEST001', ID.top3), { [cA.id]: ['main'] }, 'slow');
    await js(pw, "document.getElementById('pace').value = 'fast'; document.getElementById('pace').dispatchEvent(new Event('change'))");          // the user changes the pace while the run starts
    const st1 = await store(pw, 'p9bn.pace'); const note = await js(pw, "document.getElementById('paceNote').textContent");
    const b = await finished(pw, +process.env.FIN || 240000); slow(); if (!b || codes(b).join() !== 'liked,liked') await dbg(b);
    const gaps = !b ? [] : b.items.map((i) => (i.lg || []).filter((l) => l[1] === 'gap').map((l) => l[2])).flat();
    const sec = gaps[0] ? parseFloat(gaps[0]) : 99;
    check('R62 the choice is stored (p9bn.pace = fast) and the popup shows it', st1 && st1.pace === 'fast' && /Current pace: Fast \(2–5 s\)/.test(note), [st1, note]);
    check('R62 both liked; the gap before the 2nd item used the NEW pace (fast: <= 5 s, not slow: >= 9 s) and the log names it', !!b && codes(b).join() === 'liked,liked' && sec <= 5.1 && /Fast \(2–5 s\)/.test(gaps[0] || ''), [gaps, b && b.pace]);
    const logTxt = await js(pw, "sget(K.batch).then((bb) => L.logText(L.runBrief(bb)))");
    check('R62 the run record mirrors the saved pace and the run log header + item steps show it', !!b && b.pace === 'fast' && /pace: Fast \(2–5 s\)/.test(logTxt) && /gap/.test(logTxt), [b && b.pace, String(logTxt).slice(0, 160)]);
    await noTabs();
  }

  // ---------------------------------------------------------------------------------------------------------------- 1.1.6.4 (Oluchi: updated Bean mid-run, "interrupted", Resume did nothing until the window was reopened)
  const reloadBean = async () => { const r = await mgr.reloadUnpacked(bean.id); await sleep(2500); const id = (r && r.id) || bean.id; pw = await popup(id); return id; };
  const survive = async (title, phase) => {
    await resetChan();
    console.log('\n== ' + title + ' ==');
    sw.liked.clear(); slow({ watch: 1500 });
    await startRun(twoLinks(phase === 'paused' ? 'RELOADRUN01' : 'RELOADRUN02'), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    if (phase === 'paused') { await wait(() => likes().length >= 1, 90000, 60); await js(pw, "document.getElementById('pause').click()"); const bp = await pauseEngaged(); check(phase + ': paused before the reload (item 1 liked, the rest queued)', !!bp && bp.items[0].status === 'liked' && L9.pauseState(bp) === 'paused', bp && [bp.items.map((i) => i.status), bp.pause]); }
    else { await wait(() => sw.hits.length >= 1 && trk.alive().length === 1, 60000, 60); await sleep(1200); }
    const l0 = likes().length;
    await reloadBean();
    const bk = await wait(async () => { const bb = await batchOf(pw); return bb && bb.state === 'running' && bb.pause && /^Bean was/.test(bb.pause.where || '') ? bb : false; }, 30000, 300);
    check(phase + ' reload: the run is KEPT and PAUSED as "Bean was reloaded/updated" (not interrupted, not stopped), no item failed', !!bk && L9.pauseState(bk) === 'paused' && !bk.items.some((i) => i.status === 'failed' || i.code === 'interrupted'), bk && [bk.state, bk.pause, bk.items.map((i) => [i.status, i.code])]);
    await noTabs();
    check(phase + ' reload: the orphaned tab was closed (nothing left open) and no extra like was sent while it was paused', trk.alive().length === 0 && likes().length === l0, [trk.alive(), likes().length, l0]);
    const sh = JSON.parse(await js(pw, "JSON.stringify({ resume: document.getElementById('resume').hidden, pause: document.getElementById('pause').hidden, pnow: document.getElementById('pnow').textContent, msg: document.getElementById('msg').textContent })"));
    check(phase + ' reload: the popup says "Paused: Bean was ..., press Resume", Resume is shown, and nothing says interrupted', !sh.resume && sh.pause && /Paused: Bean was (updated|reloaded), press Resume/.test(sh.pnow) && !/interrupted/i.test(sh.msg + sh.pnow), sh);
    await js(pw, "document.getElementById('resume').click()");      // right away: no closing / reopening the Bean window
    const b = await finished(pw, 300000);
    check(phase + ' reload: Resume at once finishes everything: 4 liked, each (account/channel/comment) exactly once, nothing repeated, nothing interrupted', !!b && b.state === 'done' && codes(b).join() === 'liked,liked,liked,liked' && likes().length === 4 && new Set(likes().map((c) => c.vid + c.id + c.acct + c.chan)).size === 4, b && [b.state, codes(b), likes().length, b.items.map((i) => i.msg)]);
    check(phase + ' reload: the log says paused (Bean was ...) and resumed', !!b && (b.events || []).some((e) => /paused — Bean was/.test(e[1])) && (b.events || []).some((e) => /resumed/.test(e[1])), b && b.events);
    slow(); await noTabs(); check(phase + ' reload: no Bean tab left open', trk.alive().length === 0, trk.alive());
  };
  if (want('R65')) await survive('R65. Bean updated / reloaded while the run is PAUSED: the run stays paused ("Paused: Bean was ..., press Resume"), Resume works at once (no reopening), nothing repeats', 'paused');
  if (want('R66')) await survive('R66. Bean updated / reloaded while the run is WORKING (a tab is open): the run is kept and paused, never "interrupted"; Resume at once finishes it, nothing repeats', 'running');
  if (want('R67')) {
    console.log('\n== R67. THE QUEUE SURVIVES AN UPDATE: two orders queued, Bean is reloaded while the first is paused: both orders are still there, the run is "Paused: Bean was ..., press Resume", Resume at once finishes both, nothing is liked twice ==');
    await fresh17(); await saveSel(SELALL()); slow({ watch: 1200 }); const h0 = await histN();
    await setLinks(pw, link('QRELOAD0001', ID.top1), 'fast'); await clickGo();
    await wait(() => likes().length >= 1, 90000, 100);
    await js(pw, "document.getElementById('pause').click()"); const bp = await pauseEngaged();
    await setLinks(pw, link('QRELOAD0002', ID.top1), 'fast'); await clickGo(); await sleep(1000);
    const q0 = await ordersOf(); const l0 = likes().length;
    check('R67 before the reload: order 1 runs (paused), order 2 waits in the queue', !!bp && !!q0 && (q0.queue || []).length === 2 && L9.pauseState(bp) === 'paused', q0 && [(q0.queue || []).map((o) => o.state), bp && bp.pause]);
    await reloadBean(); await sleep(2000);
    const bk = await wait(async () => { const bb = await batchOf(pw); return bb && bb.state === 'running' && bb.pause && /^Bean was/.test(bb.pause.where || '') ? bb : false; }, 30000, 300);
    const q1 = await ordersOf();
    check('R67 after the reload: the run is kept paused ("Bean was ..."), both orders are still in the queue, nothing failed, no extra like', !!bk && !!q1 && (q1.queue || []).length === 2 && !bk.items.some((i) => i.status === 'failed') && likes().length === l0 && trk.alive().length === 0, bk && q1 && [bk.pause, (q1.queue || []).map((o) => o.state), bk.items.map((i) => [i.status, i.code]), likes().length - l0, trk.alive()]);
    await js(pw, "document.getElementById('resume').click()");
    const dd = await waitHist(h0 + 2, 420000); slow();
    check('R67 Resume at once: both orders finish "done", 8 likes in total, each (account/channel/comment) exactly once', !!dd && dd.hist.slice(0, 2).every((o) => o.state === 'done') && likes().length === 8 && new Set(likes().map((c) => c.vid + c.id + c.acct + c.chan)).size === 8, dd && [dd.hist.slice(0, 2).map((o) => [o.state, o.counts]), likes().length]);
    await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- 1.1.7 (Panel 9 2.3.23: a background tab expires after 20 minutes; a tab can also be closed by hand)
  const tabGoneRun = async (title, vid, afterLike) => {
    await resetChan();
    console.log('\n== ' + title + ' ==');
    sw.liked.clear(); slow({ watch: afterLike ? 1500 : 9000 });
    await startRun(twoLinks(vid), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    const t0 = trk.total, c0 = sw.clicks.length;
    const dbgT = null;
    if (afterLike) {
      const hit = await wait(() => likes().length >= 1 && trk.alive().length >= 1, 90000, 15);      // the like was sent: the tab vanishes right now, before the page can verify it
      for (const id of trk.alive()) { try { ctx.closeTab(id); } catch (_) { /* gone */ } }
      check('R69b the tab disappeared right after the first like was sent', !!hit && trk.alive().length === 0, [likes().length, trk.alive()]);
    } else {
      const hit = await wait(() => sw.hits.length >= 1 && trk.alive().length === 1 && likes().length === 0, 90000, 20);      // the page is still loading, nothing is clicked yet
      for (const id of trk.alive()) { try { ctx.closeTab(id); } catch (_) { /* gone */ } }
      check('R69a the tab disappeared in the middle of the step (before any click)', !!hit && trk.alive().length === 0 && likes().length === 0, [sw.hits.length, trk.alive(), likes().length]);
    }
    if (process.env.R69DBG) { for (const dl of [60000, 60000, 60000]) { await sleep(dl); try { console.log('  [R69 advance]', await js(pw, "(async () => { try { const k0 = advance.key; await advance(); return 'ok key=' + (advance.key === k0) + ' ' + String(advance.key).slice(0, 80) + ' lgc=' + (typeof lastGoneCheck !== 'undefined' ? Date.now() - lastGoneCheck : '?') + ' own=' + JSON.stringify([own.id, own.last && own.last.id, own.last && own.last.state, own.cleared, own.stopped]); } catch (e) { return 'ERR ' + (e && e.stack); } })()")); console.log('  [R69 dbg]', await js(pw, "JSON.stringify({ now: Date.now(), mem: Object.entries(mem).map(([k, m]) => [k.slice(-3), m.lastSeenAt && Date.now() - m.lastSeenAt, m.graceUntil && m.graceUntil - Date.now(), m.openedAt && Date.now() - m.openedAt, m.cut && Date.now() - m.cut, m.short, m.heard, m.pingSaves]), live: 1 })")); const x = await batchOf(pw); console.log('  [R69 dbg rec]', JSON.stringify({ upd: Date.now() - x.updated, nextAt: x.nextAt && x.nextAt - Date.now(), grace: x.graceUntil && x.graceUntil - Date.now(), g: x.groups.map((g) => [g.status, g.tab, g.recycle, g.openedAt && Date.now() - g.openedAt]), it: x.items.map((i) => [i.status, i.hb, i.prog, i.at])})); } catch (e) { console.log('dbg fail', String(e)); } } }
    if (process.env.R69SAMP) (async () => { const T0 = Date.now(); for (let k = 0; k < 12; k++) { await sleep(45000); try { const x = await batchOf(pw); console.log('  [R69 samp +' + Math.round((Date.now() - T0) / 1000) + ']', await js(pw, "JSON.stringify({ own: [own.cleared, own.last && own.last.state, myTabs.size], adv: advancing, mem: Object.entries(mem).map(([k, m]) => [k.slice(-3), m.lastSeenAt && Date.now() - m.lastSeenAt, m.graceUntil && m.graceUntil - Date.now(), m.heard, m.rc]) })"), JSON.stringify(x && { st: x.state, pr: x.pauseReq, upd: Date.now() - x.updated, g: x.groups.map((g) => [g.status, g.tab, g.recycle, g.reopens]), it: x.items.map((i) => [i.status, i.code]), ev: (x.events || []).slice(-3).map((e) => String(e[1]).slice(0, 70)) })); } catch (e) { console.log('samp fail', String(e)); } } })();
    const tF0 = Date.now(); const b = await finished(pw, +process.env.R69T || 600000); if (process.env.R69T) console.log('  [R69 finished after ' + Math.round((Date.now() - tF0) / 1000) + ' s]'); if (dbgT) clearInterval(dbgT); slow(); if (!b) await dbg(b);
    const keys = likes().map((c) => c.vid + c.id + c.acct + c.chan);
    check((afterLike ? 'R69b' : 'R69a') + ' the run is not interrupted and not stuck: it carries on in a fresh tab (a new tab was opened)', !!b && b.state === 'done' && !b.items.some((i) => i.code === 'interrupted') && trk.total > t0, b && [b.state, codes(b), trk.total - t0]);
    if (afterLike) check('R69b NEVER a second like for something already sent: each (account/channel/comment) liked at most once, the item whose like was sent is confirmed by the fresh tab (or reported "Like sent - not confirmed" / "not repeated"), all 4 done with exactly 4 clicks', !!b && new Set(keys).size === keys.length && keys.length <= 4 && b.items.filter((i) => i.status === 'liked' || i.code === 'click-sent-before').length === 4 && likes().length === 4, b && [codes(b), keys.length]);
    else check('R69a all 4 liked, exactly once each (the item that was open when the tab vanished was tried again in the fresh tab)', !!b && codes(b).join() === 'liked,liked,liked,liked' && keys.length === 4 && new Set(keys).size === 4, b && [codes(b), keys.length]);
    check((afterLike ? 'R69b' : 'R69a') + ' the log says a tab disappeared and the run continued in a fresh tab', !!b && (b.events || []).some((e) => /tab disappeared|opened again in a fresh tab/.test(e[1])) , b && b.events);
    await noTabs(); check((afterLike ? 'R69b' : 'R69a') + ' no Bean tab left open', trk.alive().length === 0, trk.alive());
  };
  if (want('R69')) await tabGoneRun('R69a. A Bean tab DISAPPEARS mid-step (closed / expired) before any click: handled like a closed tab, a fresh tab finishes the run, nothing repeated', 'TABGONE0001', false);
  if (want('R69')) await tabGoneRun('R69b. A Bean tab DISAPPEARS right after a like was sent: that like is never sent again ("Like sent - not confirmed"), the rest finishes in a fresh tab', 'TABGONE0002', true);
  // ---------------------------------------------------------------------------------------------------------------- 1.1.7 "container tab stopped answering": reopen instead of fail, tab-seen marker, Google check, grace
  const resetHang = () => { sw.hangSeen = {}; sw.hangLog = []; sw.hangClosed = 0; sw.googleHits = []; };
  const noMarkers = async (bid, cids) => { for (const c of cids) for (const p of ['p9bn.tabseen.', 'p9bn.gcheck.']) { const v = await store(pw, p + bid + '.' + c); if (v) return false; } return true; };
  if (want('R70')) {
    await resetChan(); resetHang(); console.log('\n== R70. The FIRST page load of each container never answers: the tab is closed after the grace and the container is REOPENED in a fresh tab (not failed); nothing is liked twice ==');
    sw.liked.clear(); slow(); const t0 = Date.now();
    await startRun(twoLinks('HANGFIRST01'), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    if (process.env.R70DBG) (async () => { for (let k = 0; k < 5; k++) { await sleep(45000); try { const x = await batchOf(pw); console.log('  [R70 dbg +' + Math.round((Date.now() - t0) / 1000) + ']', await js(pw, "JSON.stringify({ rr: (() => { try { const q = performance.now(); renderResults(); return 'ok ' + Math.round(performance.now() - q) + 'ms'; } catch (e) { return String(e.stack).slice(0, 400); } })(), own: [own.id, own.cleared, own.last && own.last.state, own.stopped, myTabs.size], advancing, hidden: document.hidden, mem: Object.entries(mem).map(([k, m]) => [k.slice(-3), m.lastSeenAt && Date.now() - m.lastSeenAt, m.graceUntil && m.graceUntil - Date.now(), m.heard, m.pingSaves]) })"), JSON.stringify({ upd: Date.now() - x.updated, grace: x.graceUntil && x.graceUntil - Date.now(), g: x.groups.map((g) => [g.status, g.tab, g.recycle, g.reopens]), ev: (x.events || []).slice(-3).map((e) => String(e[1]).slice(0, 80)) })); } catch (e) { console.log('dbg fail', String(e)); } } })();
    const bid = runId; const b = await finished(pw, 600000); slow(); if (!b) await dbg(b);
    const keys = likes().map((c) => c.vid + c.id + c.acct + c.chan);
    check('R70 all 4 liked, exactly once each: the silent container was reopened and finished (no "not started", no "interrupted")', !!b && codes(b).join() === 'liked,liked,liked,liked' && keys.length === 4 && new Set(keys).size === 4, b && [codes(b), keys.length, b.items.map((i) => i.msg)]);
    check('R70 each container was loaded twice (the first never answered, the fresh tab did), the silent tab was closed', Object.values(sw.hangSeen).length === 2 && Object.values(sw.hangSeen).every((n) => n >= 2) && sw.hangClosed >= 2, [sw.hangSeen, sw.hangClosed]);
    check('R70 the record says reopens=1 for both containers, recycle+1; the log says "fresh tab"; it took longer than the open grace (75 s)', !!b && b.groups.every((g) => g.reopens === 1 && g.recycle >= 1) && (b.events || []).some((x) => /never answered/.test(x[1]) && /fresh tab/.test(x[1])) && Date.now() - t0 > 70000, b && [b.groups.map((g) => [g.reopens, g.recycle]), b.events, Date.now() - t0]);
    check('R70 the log says it was tried again in a fresh tab (the item log when an item was open, else the run log: an item that never started has nothing of its own to say)', !!b && (b.items.some((i) => (i.lg || []).some((l) => /fresh tab/.test(String(l[2])))) || (b.events || []).some((x) => /fresh tab/.test(String(x[1])))), b && [b.events]);
    await noTabs(); check('R70 no Bean tab left open; the tab-seen markers are removed with the run', trk.alive().length === 0 && await wait(() => noMarkers(bid, [cA.id, cB.id]), 15000), trk.alive());
  }
  if (want('R71')) {
    await resetChan(); resetHang(); console.log('\n== R71. A container whose tab NEVER answers, even in 2 fresh tabs: its items end with a plain "never answered" message (max 2 reopens), no like, no tab left ==');
    sw.liked.clear(); slow(); await startRun(twoLinks('HANGALL0001'), { [cA.id]: ['main'] }, 'fast');
    const b = await finished(pw, 1200000); slow(); if (!b) await dbg(b);
    const hang = b ? b.items.filter((i) => i.vid === 'HANGALL0001') : [];
    check('R71 the items of the silent video end with a clear message ("never answered") and a code of "not started / interrupted", nothing liked', !!b && hang.length === 2 && hang.every((i) => i.status === 'failed' && /^(not-started|interrupted)$/.test(i.code) && /never answered/.test(i.msg)) && !likes().some((c) => c.vid === 'HANGALL0001'), b && [hang.map((i) => [i.status, i.code, i.msg]), likes().length]);
    check('R71 each container was loaded exactly 2 times (1.1.7.2: the first + ONE reopen), all closed again', Object.values(sw.hangSeen).length >= 1 && Object.values(sw.hangSeen).every((n) => n <= 2) && Math.max(...Object.values(sw.hangSeen)) === 2 && sw.hangClosed >= 2, [sw.hangSeen, sw.hangClosed]);
    check('R71 the log says the container never answered and 2 fresh tabs did not help; the record keeps reopens=2', !!b && (b.events || []).some((x) => /never answered and 1 fresh tabs did not help/.test(x[1])) && b.groups.some((g) => g.reopens === 2), b && [b.events, b.groups.map((g) => g.reopens)]);
    await noTabs(); check('R71 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  const googleRun = async (title, vid) => {
    await resetChan(); resetHang(); console.log('\n== ' + title + ' ==');
    sw.liked.clear(); slow(); const t0 = Date.now(); await startRun(twoLinks(vid), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    const bid = runId; const b = await finished(pw, 300000); slow(); if (!b) await dbg(b);
    const nm = (cid) => (cid === cA.id ? 'Channel A' : 'Channel B');
    check('R72 ' + vid + ': both containers are skipped right away (code google-check), far sooner than the open grace; nothing liked', !!b && b.items.length === 4 && b.items.every((i) => i.status === 'skipped' && i.code === 'google-check') && likes().length === 0 && Date.now() - t0 < 70000, b && [codes(b), Date.now() - t0]);
    check('R72 ' + vid + ': the message is in plain words, with the container name', !!b && b.items.every((i) => i.msg === 'Google asked container ' + (i.cname || '') + ' to sign in or verify; open it once and complete it.') && b.items.some((i) => i.cname), b && b.items.map((i) => [i.cname, i.msg]));
    check('R72 ' + vid + ': no reopen, no retry (Bean does not try to solve the challenge): Google was hit by the tabs only, each container loaded once', !!b && b.groups.every((g) => !g.reopens) && sw.hits.length <= 2 && (sw.googleHits || []).length >= 1, [b && b.groups.map((g) => g.reopens), sw.hits.length, (sw.googleHits || []).length]);
    check('R72 ' + vid + ': the log names the Google check', !!b && (b.events || []).some((x) => /Google asked container/.test(x[1])), b && b.events);
    await noTabs(); check('R72 ' + vid + ': no Bean tab left open (the Google tabs were closed), markers removed', trk.alive().length === 0 && await wait(() => noMarkers(bid, [cA.id, cB.id]), 15000), trk.alive());
  };
  if (want('R72')) { await googleRun('R72a. A container lands on Google sign-in (accounts.google.com, Bean\'s address kept in "continue"): skipped at once with a plain message', 'GOOGLECHK01'); await googleRun('R72b. A container lands on a Google consent page without any address (consent.youtube.com): recognised while the run is opening it, skipped at once', 'GOOGLECHK02'); }
  if (want('R89')) {          // 1.1.7.2 (Oluchi's run i7de3vi7mw1sir2y #1): a Google sign-in on ONE container skips only its items; the run goes on to the next container with no pause
    await resetChan(); resetHang(); console.log('\n== R89. A Google sign-in page on container A only: A\'s items are skipped (google-check), container B is opened right after and liked, the run never pauses ==');
    sw.liked.clear(); slow(); const t0 = Date.now(); await startRun(link('GOOGLEONE01', ID.top1), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    const b = await finished(pw, 240000); slow(); if (!b) await dbg(b);
    const byC = (cid) => (b ? b.items.filter((i) => i.cid === cid).map((i) => i.code) : []);
    check('R89 container A skipped (google-check), container B liked once, the run is done', !!b && b.state === 'done' && byC(cA.id).every((c) => c === 'google-check') && byC(cB.id).join() === 'liked' && likes().length === 1, b && [b.state, codes(b), likes().length]);
    check('R89 the run never paused (no pause event, no pause request) and finished in under 3 minutes', !!b && !b.pauseReq && !(b.events || []).some((x) => /paused|pause requested/.test(x[1])) && Date.now() - t0 < 180000, b && [b.pauseReq, (b.events || []).map((x) => x[1]), Date.now() - t0]);
    await noTabs(); check('R89 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R90')) {          // 1.1.7.2 (Oluchi's run i7de3vi7mw1sir2y #5): the like was made, but every report of the tab after the click is lost: the item must not stay "liking"
    await resetChan(); console.log('\n== R90. The like is SENT, then every report of the tab is lost (deleted as it lands): within ~35-90 s the item ends "Like sent - not confirmed" (or liked), ONE click, the run moves on ==');
    sw.liked.clear(); slow({ watch: 1500 }); await startRun(twoLinks('LOSTREP0001'), { [cA.id]: ['main'] }, 'fast');
    const hit = await wait(() => likes().length >= 1, 120000, 50); const tc = Date.now(); const stop = { v: false }; let wiped = 0;
    const eat = (async () => { while (!stop.v && Date.now() - tc < 150000) { try { wiped += await js(pw, "chrome.storage.local.get(null).then((v) => { const ks = Object.keys(v).filter((k) => k.indexOf('p9bn.rep.') === 0); return ks.length ? chrome.storage.local.remove(ks).then(() => ks.length) : 0; })"); } catch (_) { /* busy */ } await sleep(200); } })();
    const first = await wait(async () => { const x = await batchOf(pw); return x && x.items[0] && x.items[0].status !== 'running' && x.items[0].status !== 'queued' ? x : false; }, 150000, 500); const dt = Date.now() - tc; stop.v = true; await eat;
    const b = await finished(pw, 300000); slow(); if (!b) await dbg(b);
    console.log('   [R90] first item final after ' + Math.round(dt / 1000) + ' s; reports wiped ' + wiped + '; codes ' + (b ? codes(b).join() : '-'));
    check('R90 the like was sent and the reports were really lost', !!hit && wiped >= 1, [!!hit, wiped]);
    check('R90 the first item is final within 100 s of the click ("liked" / "Like sent - not confirmed"), not stuck "liking"', !!first && /^(liked|liked-unverified)$/.test(first.items[0].code) && dt < 100000, first && [first.items[0].status, first.items[0].code, dt]);
    check('R90 ONE click per item, never a second click on the sent like; the run finishes', !!b && b.state === 'done' && new Set(likes().map((c) => c.vid + c.id + c.acct + c.chan)).size === likes().length && likes().length <= 2, b && [b.state, codes(b), likes().length]);
    await noTabs(); check('R90 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R91')) {          // 1.1.7.2 (Oluchi's run 0b8p7pfomw1tx4af): the open-tab call after the VPN step never answers: within ~45 s the container is handed back and opened in a fresh tab
    await resetChan(); console.log('\n== R91. The call that opens the tab NEVER answers (test hook, once): the run is not stuck: the container is handed back within ~45 s and opened again, both liked, one click each ==');
    sw.liked.clear(); slow(); await js(pw, 'self.P9T = { hangOpen: 1 }'); const t0 = Date.now(); await startRun(twoLinks('OPENHANG001'), { [cA.id]: ['main'] }, 'fast');
    const ev = await wait(async () => { const x = await batchOf(pw); return x && (x.events || []).some((e) => /opening the tab did not answer/.test(e[1])) ? x : false; }, 90000, 500); const dt = Date.now() - t0;
    const b = await finished(pw, 240000); slow(); if (!b) await dbg(b);
    check('R91 the hung open was noticed and handed back within 45 s (not stuck "queued")', !!ev && dt < 45000, [!!ev, dt]);
    check('R91 the container was opened again and both items liked, one click each', !!b && codes(b).join() === 'liked,liked' && likes().length === 2 && new Set(likes().map((c) => c.vid + c.id + c.acct + c.chan)).size === 2, b && [codes(b), likes().length]);
    await noTabs(); check('R91 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R92')) {          // 1.1.7.2: a deleted comment ends at once (comment-gone) and is not tried on the other container; a SLOW comment list is never taken for a deleted one
    await resetChan(); console.log('\n== R92a. The comment was DELETED (the list loads, the linked comment is not in it): comment-gone only after a second container confirmed it, nothing clicked ==');
    sw.liked.clear(); slow(); const h0 = sw.hits.length; await startRun(link('NORMAL0GONE', 'UgxGONE_deleted_dddddddddddddddd'), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    const b = await finished(pw, 240000); slow(); if (!b) await dbg(b);
    check('R92a both items end comment-gone, nothing liked', !!b && b.items.every((i) => i.code === 'comment-gone') && likes().length === 0, b && [codes(b), likes().length]);
    { const n = sw.hits.filter((h) => /NORMAL0GONE/.test(h)).length; check('R92a SURE before ending: the comment was re-checked on the OTHER container (2 page loads, one per container), then ended', n === 2, n); }
    await noTabs();
    console.log('\n== R92b. Control: the comments load SLOWLY (3.5 s): never taken for a deleted comment, liked normally ==');
    sw.liked.clear(); slow(); await startRun(link('SLOWLOAD_92', ID.top1), { [cA.id]: ['main'] }, 'fast');
    const b2 = await finished(pw, 240000); slow(); if (!b2) await dbg(b2);
    check('R92b a slow comment list is liked, never comment-gone', !!b2 && codes(b2).join() === 'liked' && likes().length === 1, b2 && [codes(b2), likes().length]);
    await noTabs(); check('R92 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R94')) {          // 1.1.7.2 (real job__7oLkcMhLbq6It4O): every item is final but the container's channel restore never finishes and the record keeps being touched: the run still ends within ~30 s, a Pause never waits on it
    await resetChan(); console.log('\n== R94. All items final, the channel restore "pending" for ever while the record keeps being refreshed: the run ends within 30 s; a Pause pressed meanwhile does not hang ==');
    sw.liked.clear(); slow(); await startRun(link('RESTHANG001', ID.top1), { [cA.id]: ['main'] }, 'fast'); const bid = runId;
    await wait(() => likes().length >= 1, 120000, 100);
    const fin = await wait(async () => { const x = await batchOf(pw); return x && x.items.every((i) => i.status !== 'queued' && i.status !== 'running') ? x : false; }, 120000, 100);
    const stop = { v: false }; const pump = (async () => { while (!stop.v) { try { await js(pw, "chrome.storage.local.get('p9bn.batch').then((v) => { const b = v['p9bn.batch']; if (!b || b.id !== " + JSON.stringify(bid) + " || b.state !== 'running') return; b.groups.forEach((g) => { if (g.status === 'done') g.status = 'running'; g.restore = 'pending'; }); b.updated = Date.now(); return chrome.storage.local.set({ 'p9bn.batch': b }); })"); } catch (_) { /* busy */ } await sleep(1000); } })();
    const t0 = Date.now(); await sleep(3000); await js(pw, "document.getElementById('pause').click()").catch(() => {});
    const end = await wait(async () => { const x = await batchOf(pw); return x && x.id === bid && x.state !== 'running' ? x : false; }, 60000, 300); const dt = Date.now() - t0; stop.v = true; await pump;
    console.log('   [R94] run ended ' + Math.round(dt / 1000) + ' s after the restore hang started: ' + (end && end.state));
    check('R94 the run ended (done) within 30 s although the restore never finished; the result is kept (liked)', !!fin && !!end && end.state === 'done' && dt < 30000 && codes(end).join() === 'liked', [!!fin, end && end.state, dt, end && codes(end)]);
    await noTabs(); check('R94 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R73')) {
    await resetChan(); resetHang(); console.log('\n== R73. The content script writes the tab-seen marker (p9bn.tabseen.<run>.<container> = {url, at}) at document_start, and it is removed with the run ==');
    sw.liked.clear(); slow({ watch: 1500 }); await startRun(twoLinks('SEENMARK001'), { [cA.id]: ['main'] }, 'normal');
    const bid = runId, key = 'p9bn.tabseen.' + bid + '.' + cA.id;
    const mk0 = await wait(async () => { const v = await store(pw, key); return v && v.at ? v : false; }, 60000, 200);
    check('R73 the marker exists while the tab works: {url without Bean parameters, at}', !!mk0 && /^\/watch\?v=SEENMARK001/.test(mk0.url) && !/p9b/.test(mk0.url) && Date.now() - mk0.at < 60000, mk0);
    const b = await finished(pw, 300000); slow(); if (!b) await dbg(b);
    const gone = !!b && await wait(async () => !(await store(pw, key)), 15000); if (!gone) console.log('   [debug R73] keys', JSON.stringify(await js(pw, "chrome.storage.local.get(null).then((v) => Object.keys(v).filter((k) => /tabseen|gcheck/.test(k)).map((k) => [k, v[k]]))")), 'bid', bid, 'cA', cA.id, 'state', b && b.state, 'owner', b && b.owner);
    check('R73 the run finished and the marker is gone afterwards', gone, b && codes(b));
    await noTabs();
  }
  // R74: Panel 9 mirrors chrome.storage between sessions by snapshot copy: OLDER versions of keys come back after newer ones (real job: 83 writes of the run record in ~70 s, 14 distinct versions). A page in the test
  // writes older snapshots of the run record and of the tabs' heartbeat / report keys back all the time. Nothing may be failed falsely, nothing may be clicked twice, no tab may be left open.
  const replayRun = async (title, vid, every, back) => {
    await resetChan(); resetHang(); console.log('\n== ' + title + ' ==');
    sw.liked.clear(); slow({ watch: 600 });
    const stop = { v: false }, hist = []; let replays = 0, rsn = 0;
    await startRun(twoLinks(vid), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    const bid = runId;
    const pump = (async () => { while (!stop.v) { try { const snap = await js(pw, "chrome.storage.local.get(null).then((v) => { const o = {}; for (const k of Object.keys(v)) if (/^p9bn\\.(batch|hb\\.|rep\\.)/.test(k)) o[k] = v[k]; return o; })"); hist.push(snap); if (hist.length > back + 4) hist.shift(); if (hist.length > back) { const old = hist[hist.length - 1 - back]; if (old['p9bn.batch'] && old['p9bn.batch'].id === bid) { await js(pw, 'chrome.storage.local.set(' + JSON.stringify(old) + ')'); replays++; } } } catch (_) { /* page busy */ } await sleep(every); } })();
    const dbgR = process.env.R74DBG ? setInterval(async () => { try { const x = await js(pw, "chrome.storage.local.get(null).then((v) => { const o = {}; for (const k of Object.keys(v)) { if (/^p9bn\\.hb\\./.test(k)) o[k.slice(5)] = [v[k].gen % 100000, v[k].seq, v[k].rseq, v[k].graceMs, v[k].idx]; else if (/^p9bn\\.rep\\./.test(k)) o[k.slice(5)] = [v[k].gen % 100000, v[k].seq, Object.keys(v[k].items || {}).map((i) => i + ':' + (v[k].items[i].status || '-')).join(',')]; else if (k === 'p9bn.batch') o.batch = [v[k].items.map((i) => i.status).join(','), v[k].groups.map((g) => g.status).join(','), Date.now() - v[k].updated]; } return o; })"); console.log('   [r74] ' + new Date().toTimeString().slice(0, 8), JSON.stringify(x)); } catch (_) { /* busy */ } }, 15000) : null;
    const b = await finished(pw, 420000); if (dbgR) clearInterval(dbgR); stop.v = true; await pump; slow(); if (!b) await dbg(b);
    const lk = likes(), keys = lk.map((c) => c.vid + c.id + c.acct + c.chan);
    console.log('   [R74] replays written: ' + replays + '; final codes ' + (b ? codes(b).join() : '-') + '; likes ' + lk.length);
    check('R74 the run finishes with all 4 items liked although old versions of the record kept coming back (' + replays + ' replays)', !!b && b.state === 'done' && codes(b).join() === 'liked,liked,liked,liked' && replays >= 5, b && [b.state, codes(b), b.items.map((i) => i.msg), replays]);
    check('R74 nothing is clicked twice: exactly 4 likes, each (account/channel/comment) once', lk.length === 4 && new Set(keys).size === 4, [lk.length, new Set(keys).size]);
    check('R74 no item was falsely failed / interrupted / not started, no tab reopened for nothing', !!b && !b.items.some((i) => i.status === 'failed' || i.status === 'skipped') && !(b.groups || []).some((g) => g.reopens) && !(b.events || []).some((x) => /heartbeat missed|never answered|went quiet/.test(x[1])), b && [b.events, b.groups.map((g) => g.reopens)]);
    await noTabs(); check('R74 no Bean tab left open', trk.alive().length === 0, trk.alive());
  };
  if (want('R74')) { await replayRun('R74a. The mirror keeps bringing back OLDER versions of the run record and of the tabs\' keys (about every second, 3 samples old): no item is falsely failed, nothing is clicked twice', 'REPLAY00001', 900, 3); await replayRun('R74b. The same, harder (every 0.4 s, 5 samples old)', 'REPLAY00002', 400, 5); }
  // R75: Oluchi's real cases #8 (the fresh tab after "reopen 1 of 2" never reported, the item ended not-started) and #16 (the page loaded twice, then silence, ended "interrupted" with no click)
  if (want('R75')) {
    await resetChan(); resetHang(); sw.froze = 0; sw.freezeSeen = {}; console.log('\n== R75a. (#16) the page loads twice, then its script goes silent (frozen renderer): the item is NOT failed "interrupted": it is tried again in a fresh tab (verified close), the like that was sent is never repeated ==');
    sw.liked.clear(); slow({ watch: 400 }); await startRun(twoLinks('FREEZE02001'), { [cA.id]: ['main'] }, 'fast');
    const b = await finished(pw, 480000); slow(); if (!b) await dbg(b);
    const lk = likes(), keys = lk.map((c) => c.vid + c.id + c.acct + c.chan);
    check('R75a the second page froze (the mock froze ' + sw.froze + ' page)', sw.froze >= 1, sw.froze);
    check('R75a both items end liked (none "interrupted" / "not started"), each liked exactly once', !!b && codes(b).join() === 'liked,liked' && lk.length === 2 && new Set(keys).size === 2, b && [codes(b), lk.length, b.items.map((i) => i.msg)]);
    check('R75a the log says it was tried again in a fresh tab and what Bean knew (VPN / runtime id / page started)', !!b && (b.events || []).some((x) => /tab disappeared|heartbeat missed/.test(x[1])) && (b.events || []).some((x) => /runtime id/.test(x[1])), b && b.events);
    await noTabs(); check('R75a no Bean tab left open (the frozen one was closed, verified)', trk.alive().length === 0, trk.alive());
  }
  if (want('R75')) {
    await resetChan(); resetHang(); console.log('\n== R75b. (#8) the first fresh tab never reports either, and a stale copy of the run record keeps taking the reopen away: the container is still opened in a fresh tab (confirmed by its tab-seen marker), nothing fails ==');
    sw.liked.clear(); slow(); const stop = { v: false }, hist = []; let replays = 0;
    await startRun(twoLinks('HANGFIRST02'), { [cA.id]: ['main'] }, 'fast'); const bid = runId;
    const pump = (async () => { while (!stop.v) { try { const snap = await js(pw, "chrome.storage.local.get(null).then((v) => { const o = {}; for (const k of Object.keys(v)) if (/^p9bn\\.(batch|hb\\.|rep\\.)/.test(k)) o[k] = v[k]; return o; })"); hist.push(snap); if (hist.length > 9) hist.shift(); if (hist.length > 5 && hist[hist.length - 6]['p9bn.batch'] && hist[hist.length - 6]['p9bn.batch'].id === bid) { await js(pw, 'chrome.storage.local.set(' + JSON.stringify(hist[hist.length - 6]) + ')'); replays++; } } catch (_) { /* busy */ } await sleep(500); } })();
    const b = await finished(pw, 480000); stop.v = true; await pump; slow(); if (!b) await dbg(b);
    const lk = likes(), keys = lk.map((c) => c.vid + c.id + c.acct + c.chan);
    console.log('   [R75b] replays ' + replays + '; codes ' + (b ? codes(b).join() : '-') + '; hang loads ' + JSON.stringify(sw.hangSeen));
    check('R75b both items liked exactly once (the container was reopened in a fresh tab although old versions of the record kept coming back)', !!b && codes(b).join() === 'liked,liked' && lk.length === 2 && new Set(keys).size === 2, b && [codes(b), lk.length, b.items.map((i) => i.msg)]);
    check('R75b the silent first tab was replaced: the container was loaded twice and the fresh one reported (tab-seen marker)', Object.values(sw.hangSeen).length >= 1 && Object.values(sw.hangSeen).every((n) => n >= 2) && sw.hangClosed >= 1, [sw.hangSeen, sw.hangClosed]);       // the page loads and the closed hung tab prove the reopen; the record's own reopens counter can be rolled back by the replays after the run ended
    await noTabs(); check('R75b no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  // ---------------------------------------------------------------------------------------------------------------- 1.1.6.4 (Oluchi: Bean pulled focus to its running window)
  // Bean opens its tabs in the BACKGROUND (background:true on the Panel 9 bridge): not activated, not focused, not raised. These tests watch every focus/raise call of the main process while a
  // whole run is going and sample the Bean tabs (visibilityState / hasFocus), then check the likes still land. Needs a Panel 9 with the Bean no-focus patch; run with NOTHROTTLE=1 for the real thing.
  const focusRun = async (title, opts) => {
    console.log('\n== ' + title + ' ==');
    const { BaseWindow, app: eapp } = require('electron');
    const wcProto = Object.getPrototypeOf(ctx.tabs[0].view.webContents), winProto = Object.getPrototypeOf(ctx.win);
    if (!globalThis.__focusLog) {
      const L = globalThis.__focusLog = { on: false, calls: [] };
      const wrap = (proto, names, tag, isWc) => { for (const n of names) { const o = proto[n]; if (typeof o !== 'function') continue; proto[n] = function (...a) { if (L.on) { let u = ''; try { u = isWc ? this.getURL() : ''; } catch (_) { /* ignore */ } L.calls.push({ call: tag + '.' + n, url: String(u).slice(0, 80) }); } return o.apply(this, a); }; } };
      wrap(wcProto, ['focus'], 'webContents', true); wrap(winProto, ['focus', 'show', 'moveTop', 'restore', 'setAlwaysOnTop', 'flashFrame'], 'window', false);
      try { const o = eapp.focus; eapp.focus = function (...a) { if (L.on) L.calls.push({ call: 'app.focus', url: '' }); return o.apply(this, a); }; } catch (_) { /* ignore */ }
    }
    const L = globalThis.__focusLog; L.calls.length = 0;
    sw.liked.clear(); slow({ watch: 300, switcher: 300, signin: 300, hops: 1 });
    try { ctx.win.blur(); } catch (_) { /* ignore */ }
    const act0 = ctx.activeId, samples = []; let moved = 0, winFocused = 0, hiddenForced = 0;
    L.on = true;
    const iv = setInterval(async () => {
      try {
        if (ctx.activeId !== act0) moved++;
        if (ctx.win.isFocused()) winFocused++;
        for (const id of trk.alive()) { const t = ctx.tabs.find((x) => x.id === id); if (!t) continue; const wc = t.view.webContents;
                    const r = await Promise.race([wc.executeJavaScript('[document.visibilityState, document.hasFocus(), !!document.querySelector("ytd-comments, #comments"), innerWidth, innerHeight, document.querySelectorAll("[data-cid]").length]'), sleep(1500).then(() => null)]).catch(() => null);
          if (r) samples.push({ vis: r[0], focus: r[1], comments: r[2], w: r[3], h: r[4], n: r[5], wcFocused: wc.isFocused(), b: JSON.stringify(t.view.getBounds()) }); }
      } catch (_) { /* ignore */ }
    }, 250);
    const t0 = Date.now();
    await startRun(link(opts.vid, ID.top1) + '\n' + link(opts.vid, ID.top3), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, 300000); L.on = false; clearInterval(iv); slow();
    const secs = Math.round((Date.now() - t0) / 1000);
    if (process.env.DEBUGF) console.log('[focus-samples]', JSON.stringify(samples.filter((_, i) => i % 25 === 0)));
    console.log(`[focus-run] ${opts.vid} ${b ? b.items.length : 0} items in ${secs} s; tab samples ${samples.length}; focus/raise calls ${L.calls.length}`);
    if (!b || codes(b).join() !== 'liked,liked,liked,liked') await dbg(b);
    return { b, samples, L, moved, winFocused, secs, hiddenForced };
  };
  if (want('R63')) {
    await js(pw, "chrome.storage.local.set({ 'p9bn.bgTabs': true })");      // 1.1.7: the background flag is opt-in (p9bn.bgTabs === true); R63 tests the opt-in path
    const r = await focusRun('R63. no focus, no raise: a whole run (2 comments x 2 channels incl. a channel switch) with the Panel 9 window unfocused: the tab you are in stays the active one, nothing calls focus/raise, and every like still lands', { vid: 'NOFOCUSRUN1' });
    check('R63 all 4 liked, each (account/channel/comment) once: clicks, hydration, identity and verify all worked in a background, unfocused tab', !!r.b && r.b.state === 'done' && codes(r.b).join() === 'liked,liked,liked,liked' && likes().length === 4 && new Set(likes().map((c) => c.vid + c.id + c.acct + c.chan)).size === 4, r.b && [r.b.state, codes(r.b), likes().length]);
    check('R63 NO focus/raise call in the whole run (no webContents.focus on a YouTube tab, no window focus/show/moveTop/restore, no app.focus)', r.L.calls.length === 0, r.L.calls.slice(0, 6));
    check('R63 the tab the user is in stayed the ACTIVE one for the whole run (Bean never switched the visible tab) and the window never got focus', r.moved === 0 && r.winFocused === 0, [r.moved, r.winFocused]);
    check('R63 the Bean tabs were never document-focused (hasFocus false) but WERE rendering (visibilityState visible) and showed the comments', r.samples.length >= 3 && r.samples.every((x) => x.focus === false && x.wcFocused === false) && r.samples.every((x) => x.vis === 'visible') && r.samples.some((x) => x.comments), r.samples.slice(0, 4));
    await js(pw, "chrome.storage.local.remove('p9bn.bgTabs')");
    await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- 1.1.6.5 (Panel 9 2.3.23 hides a background view; YouTube comments never load in it)
  // R68: the DEFAULT sends no background flag (the tab is a normal, activated tab: Panel 9's beanBg is false/absent), p9bn.bgTabs === true sends it (beanBg true), anything else than the boolean true does not.
  // The harness is the Panel 9 copy with the Bean no-focus patch: a tab opened with background:true carries tab.beanBg === true (the patch sets it only for a.background === true).
  if (want('R68')) {
    console.log('\n== R68. background tabs are OFF by default: no background flag is sent unless p9bn.bgTabs === true ==');
    const mode = async (title, setting, vid) => {
      if (setting === undefined) await js(pw, "chrome.storage.local.remove('p9bn.bgTabs')"); else await js(pw, 'sset("p9bn.bgTabs", ' + JSON.stringify(setting) + ')');
      sw.liked.clear(); slow({ watch: 300, switcher: 300, signin: 300, hops: 1 }); const seen = [];
      const iv = setInterval(() => { try { for (const id of trk.alive()) { const t = ctx.tabs.find((x) => x.id === id); if (t) seen.push(!!t.beanBg); } } catch (_) { /* ignore */ } }, 120);
      await startRun(link(vid, ID.top1), { [cA.id]: ['main'] }, 'fast');
      const b = await finished(pw, 150000); clearInterval(iv); slow();
      const logTxt = await js(pw, "sget(K.batch).then((bb) => L.logText(L.runBrief(bb)))");
      console.log(`[R68] ${title}: setting ${JSON.stringify(setting)}; tab samples ${seen.length}; beanBg true in ${seen.filter(Boolean).length}; codes ${b ? codes(b).join() : '?'}`);
      await js(pw, "chrome.storage.local.remove('p9bn.bgTabs')"); await noTabs();
      return { b, seen, logTxt };
    };
    const d = await mode('default', undefined, 'BGTABSDEF01');
    check('R68 default (setting unset): the run works (liked) and Bean sent NO background flag (the tab is a normal tab, never a beanBg tab)', !!d.b && codes(d.b).join() === 'liked' && d.seen.length >= 1 && d.seen.every((x) => x === false), [d.b && codes(d.b), d.seen.slice(0, 8)]);
    check('R68 default: the run log says "open mode: tabs open normally" (header) and has the run event', !!d.b && d.b.openMode === 'tabs open normally' && /open mode: tabs open normally/.test(d.logTxt) && /open mode — tabs open normally/.test(d.logTxt), [d.b && d.b.openMode, String(d.logTxt).slice(0, 200)]);
    const o = await mode('bgTabs=true', true, 'BGTABSON001');
    check('R68 p9bn.bgTabs = true: Bean sent background:true (every Bean tab is a beanBg tab)', !!o.b && o.seen.length >= 1 && o.seen.every((x) => x === true), [o.b && codes(o.b), o.seen.slice(0, 8)]);
    check('R68 p9bn.bgTabs = true: the run log says "open mode: background tabs requested"', !!o.b && o.b.openMode === 'background tabs requested' && /open mode: background tabs requested/.test(o.logTxt) && /open mode — background tabs requested/.test(o.logTxt), [o.b && o.b.openMode, String(o.logTxt).slice(0, 200)]);
    for (const [label, v] of [['the string "true"', 'true'], ['false', false], ['1', 1]]) {
      const x = await mode('bgTabs=' + label, v, 'BGTABSX' + (label.length + 1000));
      check('R68 p9bn.bgTabs = ' + label + ' is NOT the boolean true: no background flag is sent, tabs open normally', !!x.b && x.seen.length >= 1 && x.seen.every((y) => y === false) && x.b.openMode === 'tabs open normally', [x.b && x.b.openMode, x.seen.slice(0, 6)]);
    }
    // 1.1.7: the settings switch drives the same key; it applies to the next run at once (read fresh before every tab open)
    { await js(pw, "chrome.storage.local.remove('p9bn.bgTabs')"); pw = await popup(); await sleep(400);
      const st0 = await js(pw, "document.getElementById('bgTabs').checked");
      await js(pw, "document.getElementById('bgTabs').click()"); await sleep(500);
      const st1 = await store(pw, 'p9bn.bgTabs');
      await js(pw, "document.getElementById('bgTabs').click()"); await sleep(500);
      const st2 = await store(pw, 'p9bn.bgTabs');
      check('R68 the settings switch "Background tabs": default OFF (key unset); ticking it writes p9bn.bgTabs = true, unticking removes the key (never false)', st0 === false && st1 === true && st2 === undefined, [st0, st1, st2]); }
  }
  // ---------------------------------------------------------------------------------------------------------------- R82 (1.1.7.1): Pause UI is steady (no flicker) and Pause never waits for a stuck step
  if (want('R82')) {
    await resetChan();
    console.log('\n== R82. Pause while a step is STUCK (HANGPRE_ page: a step never settles, the heartbeat keeps beating): the buttons/text go "Pausing…" -> "Paused" once, never back (even when the mirror brings back an older record without the pause); the stuck item is cancelled (nothing clicked), the tab closed; Resume carries on and likes it once ==');
    sw.liked.clear(); slow({ watch: 300 });
    await startRun(link('HANGPRE_002', ID.top1), { [cA.id]: ['main'] }, 'fast');
    await wait(async () => { const b = await batchOf(pw); return b && b.items[0] && (b.items[0].lg || []).some((l) => /this step never settles/.test(String(l[2]))) ? b : false; }, 90000, 200);
    const sample = () => js(pw, "JSON.stringify([document.getElementById('pause').hidden, document.getElementById('resume').hidden, document.getElementById('resume').textContent, document.getElementById('pnow').textContent])");
    const seq = []; let stop = false; const sampler = (async () => { while (!stop) { try { seq.push([Date.now(), JSON.parse(await sample())]); } catch (_) { /* ignore */ } await sleep(120); } })();
    const t0 = Date.now(); await js(pw, "document.getElementById('pause').click()");
    // an OLDER record (no pause request) comes back from the mirror a few times while pausing: the buttons must not flip back
    for (let k = 0; k < 6; k++) { await sleep(700); await js(pw, "chrome.storage.local.get('p9bn.batch').then((o) => { const b = o['p9bn.batch']; if (b && b.pauseReq && !(b.pause && b.pause.since)) { b.pauseReq = 0; return chrome.storage.local.set({ 'p9bn.batch': b }); } })").catch(() => {}); }
    for (const dly of [4000, 10000, 12000]) { await sleep(dly); try { const x = await batchOf(pw); const it = x && x.items[0]; console.log('  [R82 dbg +' + (Date.now() - t0) + ']', JSON.stringify({ st: it && it.status, prog: it && it.prog && Date.now() - it.prog, hb: it && it.hb && Date.now() - it.hb, step: it && it.step, pauseReq: x && x.pauseReq && Date.now() - x.pauseReq, pause: x && x.pause, grace: x && x.graceUntil && x.graceUntil - Date.now(), upd: x && Date.now() - x.updated, g: x && x.groups.map((g) => g.status) })); } catch (_) { /* ignore */ } }
    const bp = await wait(async () => { const b = await batchOf(pw); return b && b.pauseReq && b.pause && b.pause.since ? b : false; }, 90000, 250); const dtp = Date.now() - t0;
    await sleep(2500); stop = true; await sampler;
    const pausedIdx = seq.findIndex((x) => x[1][1] === false && x[1][0] === true && /Paused/i.test(x[1][3])), firstP = seq.findIndex((x) => x[1][0] === true);
    const flipped = firstP >= 0 && seq.slice(firstP).some((x) => x[1][0] === false);
    console.log(`[R82] paused after ${Math.round(dtp / 1000)} s; samples ${seq.length}; first hidden-Pause at #${firstP}; flip back ${flipped}`);
    const dtPz = bp && bp.pause && bp.pauseReq ? bp.pause.since - bp.pauseReq : -1; console.log(`[R82] Pause pressed -> Paused (run record): ${Math.round(dtPz / 100) / 10} s`);
    check('R82 pause was NOT left waiting on the stuck item: PAUSED within 3 s of the press (1.1.7.2), the stuck item is queued again, nothing was clicked, the Bean tab is closed', !!bp && dtPz >= 0 && dtPz < 3500 && bp.items[0].status === 'queued' && likes().length === 0 && sw.unlikes.length === 0 && (bp.items[0].lg || []).some((l) => /Pause was requested while this step was stuck/.test(String(l[2]))), bp && [dtp, bp.items.map((i) => i.status), likes().length]);
    check('R82 the Pause button stays hidden from the first press on (no flicker, even though older records came back): "Pausing…" -> "Paused"', firstP >= 0 && !flipped && pausedIdx > firstP, { firstP, flipped, pausedIdx, n: seq.length });
    await noTabs(); check('R82 the stuck tab was closed (no Bean tab left while paused)', trk.alive().length === 0, trk.alive());
    await js(pw, "document.getElementById('resume').click()");
    const b = await finished(pw, +process.env.FIN || 200000); if (!b || codes(b).join() !== 'liked') await dbg(b);
    check('R82 Resume: a fresh tab carries on, the like is made exactly once', !!b && codes(b).join() === 'liked' && likes().length === 1, b && [codes(b), likes().length]);
    slow(); await noTabs();
  }

  // ---------------------------------------------------------------------------------------------------------------- R83 (1.1.7.1): popup layout while a run is going: the "Working…" notice, the progress/likes counters and the buttons never overlap, every button is visible and clickable
  if (want('R83')) {
    await resetChan();
    console.log('\n== R83. popup layout while running (380 px, and narrower): no overlap between the notice, the progress area, the counters and the buttons; every visible button is on screen and the topmost element at its centre ==');
    sw.liked.clear(); slow({ watch: 4000 });
    await startRun(twoLinks(), { [cA.id]: ['main'], [cB.id]: ['main'] }, 'fast');
    await itemRunning(0); await sleep(1500);
    const probe = (w) => js(pw, `(() => { const html = document.documentElement; const prev = html.style.width; html.style.width = document.body.style.width = '${w}px';
      const vis = (e) => { if (!e || e.hidden) return null; const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none' ? r : null; };
      const ids = ['msg', 'progress', 'pcount', 'pbar', 'pnow', 'actions', 'results', 'orders', 'plan']; const R = {}; for (const i of ids) { const r = vis(document.getElementById(i)); if (r) R[i] = [Math.round(r.left), Math.round(r.top), Math.round(r.right), Math.round(r.bottom)]; }
      const top = ['msg', 'progress', 'actions', 'results', 'plan']; const over = [];
      for (let i = 0; i < top.length; i++) for (let j = i + 1; j < top.length; j++) { const a = R[top[i]], b = R[top[j]]; if (!a || !b) continue; const ox = Math.min(a[2], b[2]) - Math.max(a[0], b[0]), oy = Math.min(a[3], b[3]) - Math.max(a[1], b[1]); if (ox > 1 && oy > 1) over.push([top[i], top[j], ox, oy]); }
      const btnBad = []; for (const b of document.querySelectorAll('#actions button, #results button')) { const r = vis(b); if (!r) continue; window.scrollTo(0, 0); b.scrollIntoView({ block: 'center' }); const q = b.getBoundingClientRect(); const x = Math.min(innerWidth - 1, Math.max(0, q.left + q.width / 2)), y = Math.min(innerHeight - 1, Math.max(0, q.top + q.height / 2)); const t = document.elementFromPoint(x, y); if (!(t === b || b.contains(t))) btnBad.push([b.id || b.textContent.slice(0, 12), t && (t.id || t.className || t.tagName)]); if (q.right > innerWidth + 1 || q.left < -1) btnBad.push([b.id || b.textContent.slice(0, 12), 'off screen', Math.round(q.left), Math.round(q.right), innerWidth]); }
      html.style.width = document.body.style.width = prev; window.scrollTo(0, 0); return JSON.stringify({ R, over, btnBad, msg: (document.getElementById('msg') || {}).textContent }); })()`).then((x) => JSON.parse(x));
    for (const w of [380, 340, 300]) { const r = await probe(w); console.log(`[R83 ${w}px]`, JSON.stringify(r).slice(0, 700)); check(`R83 at ${w} px: no overlap between the notice, the progress/likes area, the buttons and the results; every visible button is topmost at its centre and on screen`, r.over.length === 0 && r.btnBad.length === 0 && /Working/.test(r.msg || ''), r); }
    await js(pw, "document.getElementById('stop').click()"); await finished(pw, 60000).catch(() => null); slow(); await noTabs();
  }

  // ---------------------------------------------------------------------------------------------------------------- R81 (1.1.7.1, background tabs): the tab is REALLY hidden and its timers are throttled (Chromium: one timer check per second once a page is hidden; once a minute after 5 minutes)
  // ---------------------------------------------------------------------------------------------------------------- R84 / R85 (1.1.7.1: PREFER ACTIVE CHANNEL)
  const actOf = (c) => store(pw, 'p9bn.act.' + c.id);
  if (want('R84')) {
    console.log('\n== R84. PREFER ACTIVE CHANNEL: run 1 leaves the containers on p111 / p222; run 2 (2 likes, all 4 channels ticked, the channel list still says "main") takes the channels that are ACTIVE (p111, p222): ZERO switches ==');
    await fresh17(); await saveSel({ [cA.id]: ['p111'], [cB.id]: ['p222'] }); await setLinks(pw, link('ACTFIRST001', ID.top1), 'fast'); slow({ watch: 1500, switcher: 4000, signin: 2000, hops: 2 }); sw.switches.length = 0;
    const h0 = await histN(); const t1 = Date.now(); await clickGo(); const d1 = await waitHist(h0 + 1, 300000); const s1 = sw.switches.length, T1 = Math.round((Date.now() - t1) / 1000);
    check('R84 run 1 (explicit p111 / p222) is done and left the containers there', !!d1 && d1.hist[0].state === 'done' && likes().length === 2, d1 && [d1.hist[0].state, likes().length]);
    await sleep(800); const a1 = await actOf(cA), b1 = await actOf(cB);
    check('R84 the last confirmed active channel is stored per container, keyed by the stable channel id (p111 / p222)', !!a1 && !!b1 && a1.id === 'p111' && b1.id === 'p222', [a1 && a1.id, b1 && b1.id]);
    await saveSel(SELALL()); await setLinks(pw, link('ACTSECOND01', ID.top1), 'fast'); await setQty(2); await sleep(500);
    sw.switches.length = 0; const lk0 = likes().length; const t2 = Date.now(); await clickGo(); const d2 = await waitHist(h0 + 2, 300000); const s2 = sw.switches.length, T2 = Math.round((Date.now() - t2) / 1000); slow();
    const l2 = likes().slice(lk0);
    console.log(`[R84] run 1 (2 switches needed): ${s1} switches, ${T1} s; run 2 (2 active channels, all 4 ticked): ${s2} switches, ${T2} s; liked from ${l2.map((c) => c.chan).join(',')}`);
    check('R84 run 2 is done: 2 likes, on the ACTIVE channels p111 and p222 (not "main"), and ZERO switches', !!d2 && d2.hist[0].state === 'done' && l2.length === 2 && l2.map((c) => c.chan).sort().join() === 'p111,p222' && s2 === 0, d2 && [d2.hist[0].state, l2.map((c) => c.chan), s2]);
    check('R84 never two Bean tabs, nothing un-liked, no tab left', trk.max <= 1 && sw.unlikes.length === 0 && trk.alive().length === 0, [trk.max, sw.unlikes.length, trk.alive()]);
    await setQty(''); await noTabs();
  }
  if (want('R85')) {
    console.log('\n== R85. the STORED active channel is WRONG at open time (the container really is on "main" but the record says p111): Bean falls back to the normal switch path (identity checked, fresh tab), likes from p111 and from nothing else, and the record is corrected ==');
    await fresh17(); await saveSel(SELALL()); await setLinks(pw, link('ACTWRONG001', ID.top1), 'fast'); await setQty(2);
    await js(pw, `chrome.storage.local.set({ ['p9bn.act.' + ${JSON.stringify(cA.id)}]: { id: 'p111', name: 'p111', at: Date.now() + 5000, src: 'identity' } })`); await sleep(500);
    slow({ watch: 800, switcher: 800, signin: 800, hops: 1 }); sw.switches.length = 0; const h0 = await histN(); await clickGo(); const d = await waitHist(h0 + 1, 300000); slow();
    check('R85 the order is done with 2 likes: container A from p111 (reached by the normal switch), container B from main; exactly one switch; nothing liked from the wrong channel', !!d && d.hist[0].state === 'done' && likes().length === 2 && likes().filter((c) => c.chan === 'p111').length === 1 && likes().filter((c) => c.chan === 'main').length === 1 && sw.switches.length === 1 && sw.unlikes.length === 0, d && [d.hist[0].state, likes().map((c) => [c.acct, c.chan]), sw.switches.length]);
    await sleep(800); const aa = await actOf(cA);
    check('R85 the stored record for A now says p111 (confirmed after the switch), written by identity, not by the stale guess', !!aa && aa.id === 'p111' && aa.at < Date.now(), aa);
    await setQty(''); await noTabs();
  }
  // ---------------------------------------------------------------------------------------------------------------- R86 (1.1.7.1: a like the page shows but YouTube never registered)
  if (want('R86')) {
    await resetChan();
    console.log('\n== R86. Bean clicks, the page shows aria-pressed true for good, but a FRESH page shows the comment NOT liked (the like never registered on YouTube): result "not-registered" (never "liked", never re-clicked from that channel, nothing un-liked) ==');
    sw.liked.clear(); slow({ watch: 600 }); sw.switches.length = 0;
    await startRun(link('NOREGIST_01', ID.top1), { [cA.id]: ['main'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 240000); slow(); if (!b || codes(b).join() !== 'not-registered') await dbg(b);
    check('R86 the item ends "not-registered" (not "liked"), the run is done', !!b && b.state === 'done' && codes(b).join() === 'not-registered', b && [b.state, codes(b), b.items.map((i) => i.msg)]);
    check('R86 exactly ONE click (never re-clicked from this channel), nothing un-liked', likes().length === 1 && sw.unlikes.length === 0, [likes().length, sw.unlikes.length]);
    check('R86 the item log says the fresh page showed the comment NOT liked', !!b && (b.items[0].lg || []).some((l) => /fresh page shows the comment NOT liked/.test(String(l[2]))), b && (b.items[0].lg || []).map((l) => l[1] + ' ' + l[2]).slice(-6));
    check('R86 the like count seen before the click is recorded for the cross-check (cnt0)', !!b && typeof b.items[0].cnt0 === 'number', b && b.items[0].cnt0);
    await noTabs(); check('R86 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R87')) {
    await resetChan();
    console.log('\n== R87. the VERIFY page after the click goes silent for good (test hook: the 2nd load of the video never settles): a fresh tab only VERIFIES (no click): "liked", one click, no 4-minute wait ==');
    sw.liked.clear(); slow({ watch: 600 });
    const t0 = Date.now(); await startRun(link('HANGVER_001', ID.top1), { [cA.id]: ['main'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 300000); const dt = Date.now() - t0; slow(); if (!b || codes(b).join() !== 'liked') await dbg(b);
    console.log(`[R87] ${Math.round(dt / 1000)} s; codes ${b ? codes(b).join() : '?'}; hook seen in log: ${!!b && JSON.stringify(b.items[0].lg || []).indexOf('never settles') >= 0}`);
    check('R87 the item ends "liked" (not liked-unverified, not already), ONE click, in under 3 minutes', !!b && codes(b).join() === 'liked' && likes().length === 1 && dt < 180000, b && [codes(b), likes().length, dt]);
    check('R87 the silent verify page really hung (hook) and was recycled by the watchdog, then a fresh tab verified', !!b && /never settles/.test(JSON.stringify(b.items[0].lg || [])) && /no progress for \d+ s|only VERIFIES|verifying only, no click/.test(JSON.stringify(b.items[0].lg || []) + JSON.stringify(b.events || [])), b && (b.items[0].lg || []).map((l) => l[1] + ' ' + l[2]).slice(-10));
    await noTabs(); check('R87 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }
  if (want('R88')) {
    await resetChan();
    console.log('\n== R88. ONE active run, no flapping: while run B is shown, the storage mirror brings back the record of an OLDER (just finished) run several times: the popup never shows it (the view stays on B), and the run still ends normally ==');
    sw.liked.clear(); slow({ watch: 1200, switcher: 3000, signin: 1500, hops: 2 });
    await startRun(link('FLAP0000001', ID.top1), { [cA.id]: ['p111'], [cB.id]: ['p222'] }, 'fast');
    const run = await wait(async () => { const b = await batchOf(pw); return b && b.state === 'running' && b.items.length >= 2 ? b : false; }, 60000, 200);
    const seen = []; let flips = 0;
    for (let k = 0; k < 5 && run; k++) {
      await js(pw, `chrome.storage.local.get('p9bn.batch').then((o) => { const b = o['p9bn.batch']; if (!b) return; const old = JSON.parse(JSON.stringify(b)); old.id = 'oldrun' + ${k}; old.created = (b.created || Date.now()) - 60000; old.state = 'done'; old.order = ''; old.items.forEach((i) => { i.status = 'liked'; i.code = 'liked'; i.vid = 'STALEOLD001'; }); return chrome.storage.local.set({ 'p9bn.batch': old }); })`).catch(() => {});
      for (let j = 0; j < 6; j++) { await sleep(150); try { const sh = JSON.parse(await js(pw, "JSON.stringify([batch && batch.id, document.getElementById('progress') && document.getElementById('progress').textContent])")); seen.push(sh); if (sh[0] && /^oldrun/.test(sh[0])) flips++; } catch (_) { /* ignore */ } }
    }
    const stale = await js(pw, 'staleSeen').catch(() => -1);
    const b = await finished(pw, +process.env.FIN || 300000); slow(); if (!b || codes(b).join() !== 'liked,liked') await dbg(b);
    console.log(`[R88] samples ${seen.length}; times the older run was shown: ${flips}; stale records ignored by the view: ${stale}`);
    check('R88 the popup never showed the older run (0 flips) although its record came back 5 times, and the view ignored them', !!run && flips === 0 && seen.length > 10 && stale >= 1, { flips, n: seen.length, stale });
    check('R88 the run still ended normally: 2 likes, once each', !!b && codes(b).join() === 'liked,liked' && likes().length === 2, b && [codes(b), likes().length]);
    await noTabs();
  }
  if (want('R81')) {
    await resetChan();
    console.log('\n== R81. background tabs (p9bn.bgTabs = true) that are really hidden and timer-throttled (test-only P9_BG_HIDDEN): the run degrades SAFELY (bounded, no wrong/double like, tabs replaced and closed) ==');
    sw.liked.clear(); slow({ watch: 300, switcher: 300, signin: 300, hops: 1 }); sw.switches.length = 0;
    process.env.P9_BG_HIDDEN = '1'; await js(pw, 'sset("p9bn.bgTabs", true)');
    const vis = []; const iv = setInterval(() => { try { for (const id of trk.alive()) { const t = ctx.tabs.find((x) => x.id === id); if (t && t.view && t.view.webContents) t.view.webContents.executeJavaScript('document.hidden').then((h) => vis.push(!!h)).catch(() => {}); } } catch (_) { /* ignore */ } }, 500);
    const t0 = Date.now(); await startRun(link('HIDDENTAB01', ID.top1), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, +process.env.FIN || 300000); const dt = Date.now() - t0; clearInterval(iv);
    delete process.env.P9_BG_HIDDEN; await js(pw, "chrome.storage.local.remove('p9bn.bgTabs')"); slow();
    if (!b || codes(b).join() !== 'liked,liked') await dbg(b);
    console.log(`[R81] hidden samples ${vis.length} (hidden ${vis.filter(Boolean).length}); ${Math.round(dt / 1000)} s; codes ${b ? codes(b).join() : '?'}`);
    check('R81 the tabs were really hidden (document.hidden) while Bean worked in them', vis.length >= 3 && vis.filter(Boolean).length >= Math.ceil(vis.length / 2), [vis.length, vis.filter(Boolean).length]);
    // A REALLY hidden, timer-throttled tab starves both YouTube's own page code (the comments render late or never: the problem Panel 9's unthrottled background tabs exist to avoid) and Bean's timer-driven polling, so a run may be slow or not finish in this
    // harsh setup (MEASURED, informational: the numbers are printed above). What must hold is SAFETY: never a wrong or double like, nothing un-liked, and Stop closes every tab. (Liked normally in the unthrottled harness: R68 / R76 / R77.)
    if (!b) { await js(pw, "document.getElementById('stop').click()").catch(() => {}); await finished(pw, 90000).catch(() => null); }
    check('R81 hidden + throttled tabs: never a wrong or double like: at most one click per channel (main, p111), nothing un-liked', likes().length <= 2 && new Set(likes().map((c) => c.chan)).size === likes().length && sw.unlikes.length === 0, { likes: likes().map((c) => c.chan), unlikes: sw.unlikes.length, finished: !!b, codes: b && codes(b) });
    await noTabs(); check('R81 no Bean tab left open', trk.alive().length === 0, trk.alive());
  }

  // ---------------------------------------------------------------------------------------------------------------- R17 (measurement)
  if (want('R17')) {
    console.log('\n== R17. speed: 2 comments x 2 channels of one container with realistic delays (/watch 12 s, channel switcher read 14 s, sign-in switch 2 hops x 4 s), pace "fast" ==');
    sw.liked.clear(); slow({ watch: 12000, switcher: 14000, signin: 4000, hops: 2 }); const sh0 = sw.switcherHits;
    const t0 = Date.now(); await startRun(link('SPEEDTEST01', ID.top1) + '\n' + link('SPEEDTEST01', ID.top3), { [cA.id]: ['main', 'p111'] }, 'fast');
    const b = await finished(pw, 1200000); slow(); const secs = Math.round((Date.now() - t0) / 1000);
    check('R17 all 4 liked', !!b && b.state === 'done' && codes(b).join() === 'liked,liked,liked,liked', b && [b.state, codes(b)]);
    if (!b || codes(b).join() !== 'liked,liked,liked,liked') await dbg(b);
    console.log(`[speed] ${b ? b.items.length : 0} items in ${secs} s = ${b ? (secs / b.items.length).toFixed(1) : '?'} s per item; page loads: ${sw.hits.length}; switcher reads: ${sw.switcherHits - sh0}; switches: ${sw.switches.length}`);
    await noTabs();
  }

  console.log(`\n${passes} passed, ${failures} failed`);
  process.exit(failures ? 1 : 0);
})().catch((e) => { console.log('FATAL', e && e.stack || e); process.exit(2); });
