'use strict';
// Bean 1.1.7 simulated world: a fake clock, a fake storage, a fake ledger, and a fake "tab pool" that processes a run record the way content.js / popup.js advance() do
// (one tab at a time, one item at a time, recycle, stall, crash, click markers). Used by unit17.js and soak17.js. The Dispatcher / watchdog / endItems / housekeeping it drives are the REAL modules.
const L = require('../lib/links.js'), O = require('../lib/orders.js'), E = require('../lib/errors.js');
function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const clone = (x) => (x === undefined ? undefined : JSON.parse(JSON.stringify(x)));

class World {
  constructor(o) {
    o = o || {}; this.r = rng(o.seed || 1); this.t = Date.UTC(2026, 10, 1, 8, 0, 0); this.kv = new Map(); this.ledger = new Set(); this.markers = new Set(); this.clicks = new Map();
    this.violations = []; this.batch = null; this.tab = null; this.tabsOpen = 0; this.tabsMax = 0; this.itemMs = o.itemMs || 20000; this.p = Object.assign({ liked: 0.78, already: 0.05, notFound: 0.06, vpnFailed: 0.03, switchFailed: 0.03, unknown: 0.02, clickFailed: 0.02, stall: 0.01, crash: 0.006, crashAfterClick: 0.004 }, o.p || {});
    this.focusOff = false; this.vpnDown = false; this.vpnOn = !!o.vpn; this.paused = false; this.finals = []; this.stats = { clicks: 0, recycles: 0, stalls: 0, crashes: 0, batches: 0, retryRounds: 0 }; this.recorded = new Set();
    this.targets = o.targets || [{ id: 'A', name: 'A', channels: [{ id: 'a1', name: 'A1', handle: '@a1' }, { id: 'a2', name: 'A2', handle: '@a2' }, { id: 'a3', name: 'A3', handle: '@a3' }] }, { id: 'B', name: 'B', channels: [{ id: 'b1', name: 'B1', handle: '@b1' }, { id: 'b2', name: 'B2', handle: '@b2' }] }, { id: 'C', name: 'C' }];
    this.reservedWatch = [];
  }
  now() { return this.t; }
  get clock() { return { now: () => this.t }; }
  store() { return { get: async (k) => (this.kv.has(k) ? clone(this.kv.get(k)) : null), set: async (k, v) => { this.kv.set(k, clone(v)); } }; }
  raw() { return { all: async () => { const o = {}; for (const [k, v] of this.kv) o[k] = clone(v); return o; }, set: async (o) => { for (const k of Object.keys(o)) this.kv.set(k, clone(o[k])); }, remove: async (ks) => { for (const k of ks) this.kv.delete(k); }, bytes: async () => this.bytes() }; }
  bytes() { let n = 0; for (const [k, v] of this.kv) n += k.length + JSON.stringify(v).length; return n; }
  // ---- ports ----
  ports(extra) {
    const w = this;
    return Object.assign({
      ledgerUsed: (v, l, ck) => w.ledger.has(v + '|' + l + '|' + ck),
      preflight: async () => (w.focusOff ? { ok: false, code: 'focus_off', msg: E.message('focus_off') } : w.vpnOn && w.vpnDown ? { ok: false, code: 'vpn_unavailable', msg: E.message('vpn_unavailable') } : { ok: true }),
      flatFor: async (o) => O.flatChannels(o.targets),
      startBatch: async (o, { chosen, flat }) => {
        if (w.batch && w.batch.state === 'running') throw new Error('two runs at once');
        const items = [], groups = [], id = 'b' + (++w.stats.batches);
        for (const c of w.targets) {
          const g = { cid: c.id, name: c.name, status: 'queued', openedAt: 0, doneAt: 0, recycle: 0 }; const first = items.length;
          for (const f of flat) { if (f.cid !== c.id) continue; for (const l of o.links) { if (!(chosen[O.lkey(l.vid, l.lc)] || []).includes(f.ck)) continue; items.push({ n: items.length + 1, jn: l.n, vid: l.vid, lc: l.lc, cid: c.id, cname: c.name, chid: f.chid, chname: f.chname, ck: f.ck, status: 'queued', code: '', msg: '', hb: 0, tries: 0 }); } }
          if (items.length > first) groups.push(g);
        }
        if (!items.length) return { ok: false, code: 'no_capacity' };
        w.batch = { id, state: 'running', pace: 'fast', created: w.t, updated: w.t, nextAt: 0, groups, items, owner: 'sim' }; w.tab = null; w.dead = false;
        return { ok: true, batchId: id };
      },
      batchOf: async (o) => (w.batch && w.batch.id === o.batchId ? clone(w.batch) : null),
      stale: (rec) => rec.state === 'running' && w.t > L.staleAt(rec) + 20000,
      endStale: async (o, rec) => { const b = w.batch; if (!b || b.id !== rec.id) return rec; O.endItems(b.items, w.t); b.groups.forEach((g) => { g.status = 'done'; }); b.state = 'stopped'; w.closeTab(); w.recordFinals(); return clone(b); },
      abortBatch: async (o) => { const b = w.batch; if (!b || b.id !== o.batchId) return; b.state = 'stopped'; b.items.forEach((it) => { if (it.status === 'queued') { it.status = 'skipped'; it.code = 'stopped'; } else if (it.status === 'running' && !(it.sent || it.verify)) { it.status = 'stopped'; it.code = 'stopped'; } }); b.items.forEach((it) => { if (it.status === 'running') { it.status = 'liked'; it.code = 'liked-unverified'; } }); b.groups.forEach((g) => { g.status = 'done'; }); w.closeTab(); w.recordFinals(); },
      markerExists: async (v, l, ck) => w.markers.has(v + '|' + l + '|' + ck),
      onFinal: async (o) => { w.finals.push(clone(o)); },
      vpnCheck: async () => (w.vpnOn ? { ok: !w.vpnDown, msg: w.vpnDown ? 'ExpressVPN is not connected' : '' } : null),
      pauseBatch: async (o, on) => { w.paused = !!on; if (w.batch) { w.batch.pauseReq = on ? w.t : 0; w.batch.pause = on ? { since: w.t } : null; } },
      housekeeping: async () => O.housekeeping(w.raw(), w.t)
    }, extra || {});
  }
  closeTab() { if (this.tabsOpen) this.tabsOpen = 0; this.tab = null; }
  openTab(cid) { if (this.tabsOpen) this.violations.push('two tabs open at once'); this.tabsOpen++; this.tabsMax = Math.max(this.tabsMax, this.tabsOpen); this.tab = { cid, cur: null, since: this.t }; }
  recordFinals() {       // ext11 recordFinal: liked / already items -> ledger
    const b = this.batch; if (!b) return;
    b.items.forEach((it, i) => { if (it.status !== 'liked' && it.status !== 'already') return; const k = b.id + ':' + i; if (this.recorded.has(k)) return; this.recorded.add(k); this.ledger.add(it.vid + '|' + it.lc + '|' + it.ck); });
  }
  // ---- the tab pool + popup advance, one step of dt ms ----
  step(dt) {
    this.t += dt; const b = this.batch; if (!b || b.state !== 'running') { this.recordFinals(); return; }
    const now = this.t;
    // popup advance
    const gl = b.groups; const act = gl.find((g) => g.status === 'opening' || g.status === 'running');
    if (act) {
      const its = b.items.filter((it) => it.cid === act.cid);
      if (its.every((it) => it.status !== 'queued' && it.status !== 'running')) { act.status = 'done'; act.doneAt = now; b.nextAt = now + 2000; this.closeTab(); }
      else if (now > L.staleAt(b)) { O.endItems(its, now); act.status = 'done'; b.nextAt = now + 2000; this.closeTab(); this.stats.crashes++; }
    }
    const wd = O.watchdog(b, now, { paused: this.paused }); if (wd.changed) { this.stats.stalls += wd.stalled; this.stats.recycles++; this.closeTab(); }
    if (!gl.some((g) => g.status === 'opening' || g.status === 'running')) {
      const next = gl.find((g) => g.status === 'queued');
      if (!next) { if (!b.items.some((it) => it.status === 'queued' || it.status === 'running')) b.state = 'done'; else { O.endItems(b.items, now); b.state = 'done'; } b.updated = now; }
      else if (!b.pauseReq && now >= (b.nextAt || 0)) { next.status = 'running'; next.openedAt = now; this.openTab(next.cid); this.dead = false; b.updated = now; }
    }
    // the tab
    if (this.tab && !this.dead && !this.paused) this.tabStep();
    this.recordFinals();
    if (b.state === 'running' && b.groups.every((g) => g.status === 'done') ) { /* wait for next advance */ }
  }
  tabStep() {
    const b = this.batch, tab = this.tab, now = this.t, p = this.p, r = this.r; b.updated = now;
    if (!tab.cur) {
      const it = b.items.find((x) => x.cid === tab.cid && x.status === 'queued'); if (!it) return;
      it.status = 'running'; it.at = now; it.hb = now; it.sent = false; tab.cur = { it, end: now + this.itemMs * (0.7 + 0.6 * r()) };
      if (r() < p.stall) { tab.cur.stall = true; this.stallSeen = true; }
      return;
    }
    const c = tab.cur, it = c.it; it.hb = now; if (c.stall) return;                      // heartbeat keeps beating, nothing progresses
    if (now < c.end) return;
    const key = it.vid + '|' + it.lc + '|' + it.ck, mk = key;
    const fin = (status, code, msg) => { it.status = status; it.code = code; it.msg = msg || ''; it.at = now; it.hb = 0; it.verify = 0; tab.cur = null; this.afterItem(); };
    const x = r(); let acc = 0; const pick = (pr) => { acc += pr; return x < acc; };
    if (pick(p.crash)) { this.dead = true; this.stats.crashes++; return; }                  // tab dies: nothing more is written
    if (this.ledger.has(key)) { fin('skipped', 'ledger-used'); return; }
    if (this.markers.has(mk)) { fin('liked', 'liked-unverified'); return; }               // verify-only path: a like was sent before
    if (this.signedOut && this.signedOut.has(it.cid)) return fin('failed', 'not-signed-in');
    if (this.failCks && this.failCks.has(it.ck)) { this.markers.add(mk); it.sent = true; this.stats.clicks++; const n0 = (this.clicks.get(key) || 0) + 1; this.clicks.set(key, n0); if (n0 > 1) this.violations.push('double click ' + key); return fin('failed', 'click-failed'); }
    if (pick(p.notFound)) return fin('failed', 'not-found');
    if (pick(p.vpnFailed)) return fin('failed', 'vpn-failed');
    if (pick(p.switchFailed)) return fin('failed', 'switch-failed');
    if (pick(p.unknown)) return fin('failed', 'unknown-state');
    if (pick(p.already)) return fin('already', '');
    // click: marker first, then the click, then verify
    this.markers.add(mk); it.sent = true; this.stats.clicks++; const n = (this.clicks.get(key) || 0) + 1; this.clicks.set(key, n); if (n > 1 || this.ledger.has(key)) this.violations.push('double like ' + key);
    if (r() < p.crashAfterClick) { this.dead = true; this.stats.crashes++; return; }
    if (r() < p.clickFailed / (p.clickFailed + p.liked)) return fin('failed', 'click-failed');
    fin('liked', '');
  }
  afterItem() {
    const b = this.batch, tab = this.tab, g = b.groups.find((x) => x.cid === tab.cid); const left = b.items.some((it) => it.cid === tab.cid && it.status === 'queued');
    if (left && O.shouldRecycle(g, b.items, this.t)) { g.status = 'queued'; g.recycle = (g.recycle || 0) + 1; b.nextAt = this.t + 3000; this.stats.recycles++; this.closeTab(); }
  }
  // invariant helper: reservations of open orders are pairwise disjoint per link
  checkReservations(d) {
    const seen = new Map();
    for (const o of d.queue) { if (!O.isOpen(o)) continue; for (const key of Object.keys(o.res || {})) for (const ck of o.res[key]) { const k = key + '|' + ck; if (seen.has(k) && seen.get(k) !== o.id) this.violations.push('reservation overlap ' + k); seen.set(k, o.id); } }
  }
}
module.exports = { World, rng, clone };
