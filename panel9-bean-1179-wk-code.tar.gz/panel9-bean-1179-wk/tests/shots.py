#!/usr/bin/env python3
"""Screenshot the Bean popup with mock data (no Panel 9, no YouTube, no account): the popup files are copied, a tiny in-memory chrome.storage / panel9ext stub is injected
and headless Chrome renders it. usage: shots.py <extension dir> <out png> [dark|light] [state: main|log|nobox]"""
import sys, os, shutil, subprocess, tempfile, json
src, out = sys.argv[1], sys.argv[2]
scheme = sys.argv[3] if len(sys.argv) > 3 else 'dark'
state = sys.argv[4] if len(sys.argv) > 4 else 'main'
d = tempfile.mkdtemp(prefix='beanshot-')
shutil.copytree(src, d + '/x', ignore=shutil.ignore_patterns('tests', 'shots', '*.md', '*.patch', '.git'))
now = 1793455000000
ch = lambda i, n, h: {'id': i, 'name': n, 'handle': h, 'avatar': ''}
seed = {
  'p9bn.settings': {'pace': 'normal', 'sel': {'0': ['c1', 'c2']}, 'chs': {'0': {'c1': ['main', 'p111'], 'c2': ['main']}}, 'vpn': {'locs': [{'id': 'USA - New York', 'name': 'USA - New York'}, {'id': 'UK - London', 'name': 'UK - London'}]}},
  'p9bn.ch.0.c1': {'at': now, 'ok': True, 'channels': [ch('main', 'Alice', '@alice'), ch('p111', 'Alice Cooking', '@alicecooks')], 'active': 'main'},
  'p9bn.ch.0.c2': {'at': now, 'ok': True, 'channels': [ch('main', 'Bob', '@bob'), ch('p222', 'Bob Gaming', '@bobgames')], 'active': 'main'},
  'p9bn.ytf': {'installed': True, 'commentsOnly': True, 'seen': 9999999999999},
}
L = lambda *a: [[now, a[0], a[1]]]
items = [
  dict(vid='dQw4w9WgXcQ', lc='UgxTOP1_unliked_aaaaaaaaaaaaaaaa', status='liked', code='liked', cname='Alice', chname='Alice Cooking', at=now, ck='p:p111', cid='c1', vpn={'location': 'USA - New York'}, lg=L('verify', 'fresh page shows the comment as liked')),
  dict(vid='dQw4w9WgXcQ', lc='UgxTOP1_unliked_aaaaaaaaaaaaaaaa', status='liked', code='liked', cname='Alice', chname='Alice', at=now, ck='h:@alice', cid='c1', vpn={'location': 'UK - London'}),
  dict(vid='dQw4w9WgXcQ', lc='UgxTOP1_unliked_aaaaaaaaaaaaaaaa', status='failed', code='like-not-kept', cname='Bob', chname='Bob', at=now, ck='h:@bob', cid='c2', lg=L('after', 'aria-pressed turned false again 2600ms after the click')),
  dict(vid='dQw4w9WgXcQ', lc='UgxTOP1_unliked_aaaaaaaaaaaaaaaa', status='failed', code='switch-failed', cname='Bob', chname='Bob Gaming', msg="YouTube still shows 'Bob'", at=now, ck='p:p222', cid='c2'),
  dict(vid='aBcDeFgHiJk', lc='UgxTOP2_alreadyliked_bbbbbbbbbbbb', status='failed', code='wrong-channel', cname='Alice', chname='Alice Cooking', msg="active is 'Alice', selected is 'Alice Cooking'", at=now, ck='p:p111', cid='c1'),
  dict(vid='aBcDeFgHiJk', lc='UgxTOP2_alreadyliked_bbbbbbbbbbbb', status='failed', code='vpn-failed', cname='Bob', chname='Bob', msg='ExpressVPN did not connect to UK - London in time', at=now, ck='h:@bob', cid='c2'),
  dict(vid='aBcDeFgHiJk', lc='UgxTOP2_alreadyliked_bbbbbbbbbbbb', status='running', code='', cname='Bob', chname='Bob Gaming', at=now, ck='p:p222', cid='c2', hb=now),
]
if state in ('picker', 'idle'): seed['p9bn.links'] = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&lc=UgxTOP1_unliked_aaaaaaaaaaaaaaaa\nhttps://www.youtube.com/watch?v=aBcDeFgHiJk&lc=UgxTOP2_alreadyliked_bbbbbbbbbbbb'
if state not in ('nobox', 'picker', 'idle'):
  seed['p9bn.batch'] = {'id': 'shot1', 'state': 'running', 'pace': 'normal', 'created': now - 90000, 'updated': now, 'owner': 'popup', 'groups': [{'cid': 'c1', 'name': 'Alice', 'status': 'done'}, {'cid': 'c2', 'name': 'Bob', 'status': 'running'}], 'items': items}
  seed['p9bn.links'] = 'x'
  if state == 'paused': seed['p9bn.batch'].update(pauseReq=now + 4000, pause={'since': now + 4000}); items[-1]['status'] = 'queued'
  if state == 'done':
    seed['p9bn.batch'].update(state='done'); items[-1].update(status='liked', code='liked')
    for g in seed['p9bn.batch']['groups']: g['status'] = 'done'
stub = """(() => { const S = %s; const ls = [];
 const get = (k) => { if (k == null) return Promise.resolve(JSON.parse(JSON.stringify(S))); if (typeof k === 'string') k = [k]; const o = Array.isArray(k) ? {} : Object.assign({}, k); for (const x of (Array.isArray(k) ? k : Object.keys(k))) if (x in S) o[x] = JSON.parse(JSON.stringify(S[x])); return Promise.resolve(o); };
 window.chrome = { storage: { local: { get, set: (o) => { Object.assign(S, JSON.parse(JSON.stringify(o))); return Promise.resolve(); }, remove: (k) => { [].concat(k).forEach((x) => delete S[x]); return Promise.resolve(); } }, onChanged: { addListener() {} } }, runtime: { getManifest: () => ({ version: '1.1.1' }), sendMessage: () => Promise.resolve() } };
 window.panel9ext = { containers: async () => ({ profile: { id: '0' }, containers: [{ id: 'c1', name: 'Alice', color: '#e5484d', current: true }, { id: 'c2', name: 'Bob', color: '#3e63dd' }, { id: 'c3', name: 'Dora', color: '#f5a524' }] }), openTabInContainer: async () => ({ tabId: 1 }), closeTab: async () => true, vpn: async () => ({ ok: false }) };
 Date.now = ((n) => () => n)(%d + 5000);
})();""" % (json.dumps(seed), now)
open(d + '/x/stub.js', 'w').write(stub)
h = open(d + '/x/popup.html').read().replace('<link rel="stylesheet" href="theme.css">', '<script src="stub.js"></script><link rel="stylesheet" href="theme.css">', 1)
# screenshots show the WHOLE popup (the real window scrolls inside 640 px)
h = h.replace('</head>', '<style>body{max-height:none!important;overflow:visible!important}#app{max-height:none!important}.body{overflow:visible!important}</style></head>', 1)
if state == 'log': h = h.replace('<details id="sec-log" class="runlog">', '<details id="sec-log" class="runlog" open>', 1)
if state == 'picker': h = h.replace('<details', '<details open').replace('</head>', '<style>#cbox,#cbox *{max-height:none!important;overflow:visible!important}</style></head>', 1)
if state in ('picker', 'idle'): h = h.replace('</body>', '<script>setTimeout(() => { const t = document.getElementById("links"); t.value = "https://www.youtube.com/watch?v=dQw4w9WgXcQ&lc=UgxTOP1_unliked_aaaaaaaaaaaaaaaa\\nhttps://www.youtube.com/watch?v=aBcDeFgHiJk&lc=UgxTOP2_alreadyliked_bbbbbbbbbbbb"; t.dispatchEvent(new Event("input", { bubbles: true })); }, 600);</script></body>', 1)
if state in ('ledger', 'ledgerclear'):
    h = h.replace('<details id="sec-led">', '<details id="sec-led" open>', 1)
    h = h.replace('</body>', """<script>(async () => { const LG = self.P9BEAN_LEDGER; await new Promise((r) => setTimeout(r, 300)); if (!B11.S.ledReady) { B11.S.led = new LG.Ledger(LG.chromeStore(chrome.storage.local)); await B11.S.led.load(); B11.S.ledReady = true; } const l = B11.S.led, t0 = %d, D = 86400000;
 l.add('dQw4w9WgXcQ', 'UgxTOP1_unliked_aaaaaaaaaaaaaaaa', 'p:p111', 'l', t0 - 2 * D); l.add('dQw4w9WgXcQ', 'UgxTOP1_unliked_aaaaaaaaaaaaaaaa', 'h:@alice', 'l', t0 - D); l.add('dQw4w9WgXcQ', 'UgxTOP1_unliked_aaaaaaaaaaaaaaaa', 'h:@bob', 'a', t0);
 l.add('aBcDeFgHiJk', 'UgxTOP2_alreadyliked_bbbbbbbbbbbb', 'p:p222', 'l', t0 - 3 * D); B11.renderLedger();
 if (%s) { for (const k of ['p:p111', 'h:@alice', 'h:@bob', 'h:@carol']) l.add('DEMOvideo01', 'UgzDEMOcomment_aaaaaaaaaaaaaaaa', k, k === 'p:p111' ? 'l' : 'a', t0 - 60000); B11.renderLedger(); const i = document.querySelector('#ledbody input[type=search]'); i.value = 'DEMOvideo01'; i.dispatchEvent(new Event('input', { bubbles: true })); } })();</script></body>""" % (now, 'true' if state == 'ledgerclear' else 'false'), 1)
if state in ('vpn', 'api', 'ledger', 'ledgerclear', 'log'): h = h.replace('</head>', '<style>.body>*:not(#sections):not(#sec-log):not(#actions){display:none!important}#sec-log summary{display:flex}</style></head>', 1)
WID = sys.argv[6] if len(sys.argv) > 6 else '420'
if len(sys.argv) > 6: h = h.replace('</head>', '<style>html,body{width:%spx!important}</style></head>' % WID, 1)
if state in ('vpn', 'api', 'ledger', 'ledgerclear'): h = h.replace('<div id="sections" class="sections" hidden>', '<div id="sections" class="sections">', 1).replace('<details id="sec-%s">' % ('led' if state == 'ledgerclear' else state), '<details id="sec-%s" open>' % state, 1)
if state == 'vpn': h = h.replace('</body>', '<script>setTimeout(() => { try { B11.S.vpnOn = true; B11.renderVpn(); } catch (e) { document.title = String(e); } }, 900);</script></body>', 1)
if state == 'api': h = h.replace('</body>', '<script>setTimeout(() => { try { B11.S.api = { token: "bean_x", enabled: true, name: "Studio PC", base: "" }; B11.S.key = ""; B11.renderApi(); } catch (e) { document.title = String(e); } }, 900);</script></body>', 1)
if scheme == 'light': h = h.replace('<body>', '<body class="forcelight">', 1)
open(d + '/x/popup.html', 'w').write(h)
if scheme == 'light':      # headless Chrome does not honour prefers-color-scheme here: force the light token blocks on
    for f in ('theme.css', 'popup.css'):
        t = open(d + '/x/' + f).read().replace('@media (prefers-color-scheme: light)', '@media all'); open(d + '/x/' + f, 'w').write(t)
args = ['google-chrome', '--headless=new', '--no-sandbox', '--disable-gpu', '--hide-scrollbars', '--force-device-scale-factor=2', '--window-size=%s,%s' % (sys.argv[6] if len(sys.argv) > 6 else '420', sys.argv[5] if len(sys.argv) > 5 else '980'), '--virtual-time-budget=8000',
        '--force-dark-mode' if scheme == 'dark' else '--blink-settings=preferredColorScheme=0', '--screenshot=' + out, 'file://' + d + '/x/popup.html']
r = subprocess.run(args, capture_output=True, text=True, timeout=90)
print('shot', out, 'rc', r.returncode)
