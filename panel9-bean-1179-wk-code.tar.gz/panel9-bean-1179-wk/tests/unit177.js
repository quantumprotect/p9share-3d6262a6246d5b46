// Bean 1.1.7.9: wave-shared VPN wiring
const fs = require('fs'), path = require('path'); let p = 0, f = 0;
const ok = (n, c) => { if (c) p++; else { f++; console.log('FAIL ' + n); } };
const root = path.join(__dirname, '..');
const pj = fs.readFileSync(path.join(root, 'popup.js'), 'utf8');
const cj = fs.readFileSync(path.join(root, 'content.js'), 'utf8');
const sj = fs.readFileSync(path.join(root, 'lib/steps.js'), 'utf8');
ok('manifest 1.1.7.9', JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8')).version === '1.1.7.9');
ok('steps.js documents WAVE-SHARED VPN', /WAVE-SHARED VPN/.test(sj) && /wave\.loc/.test(sj));
ok('pickOpen no longer gates on vpnOpen', !/vpnOpen && usesVpn/.test(sj) && !/the VPN is in use by an open container/.test(sj));
ok('popup vpnBeforeOpen stamps wave.loc', /WAVE-SHARED VPN/.test(pj) && /w\.loc = loc/.test(pj) && /shared wave location/.test(pj));
ok('content.js skips per-item rotate when wave.loc / item.vpn set', /WAVE-SHARED VPN/.test(cj) && /inherited wave/.test(cj) && /haveLoc/.test(cj));
ok('no mid-wave rotate in pace gap when location known', /kept shared\/wave location/.test(cj));
ok('mid-page fallback adopts wave.loc before rotating', /adopted wave .* shared location/.test(cj));
console.log('unit177: ' + p + ' passed, ' + f + ' failed');
process.exit(f ? 1 : 0);
