'use strict';
// A tiny stand-in for www.youtube.com's watch page, good enough to exercise Bean AND the real YouTube Focus extension against it.
// It reproduces the element names/ids the extensions depend on (ytd-app > ytd-masthead, ytd-watch-flexy #primary #below ytd-comments#comments,
// ytd-comment-thread-renderer > ytd-comment-view-model #published-time-text a[href*=lc=] / #like-button button[aria-pressed], replies behind
// ytd-comment-replies-renderer #more-replies, "linked comment" badge, sign-in dialog) — reproduced from public markup, NOT captured from a signed-in session.
// Every click on a like/dislike button is reported to the server (/__click) so tests can assert exactly what was pressed.
// Video-id prefixes pick a scenario (see SCENARIOS). Nothing here talks to the real YouTube; no real account or comment is ever touched.
const https = require('https');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');

const SCENARIOS = {
  // id: { comments: [...], flags }  -- liked = initial aria-pressed
  NORMAL: {},                // normal video
  LATEPRESS: { latePressed: true },  // like button first renders un-pressed, the "already liked" state arrives ~500 ms later
  FLAKYLIKE: { flaky: true },        // the like click does nothing (UI never toggles)
  NOCOMMENT: { commentsOff: true },  // comments turned off
  NOMASTHEA: { noMasthead: true },   // no masthead at all (sign-in state unknowable); like click opens the sign-in dialog when signed out
  SLOWLOAD_: { slow: 3500 },         // comments take 3.5 s to appear
  // --- 1.1.1 real-world conditions (the aria-pressed state of the account's OWN likes arrives late / the UI is slow to toggle / the page reloads)
  LATEHYD: { hydrateMs: 3200 },      // every like button renders un-pressed; a comment this account already liked turns "pressed" only 3.2 s later (late hydration)
  SLOWTOG: { toggleMs: 1400 },       // a click is only reflected in aria-pressed 1.4 s later (slow server round trip)
  HANGPRE_: {},               // 1.1.7.1 test: the FIRST load of this video in a container hangs forever right after the VPN confirmation (a step that never settles; the heartbeat keeps beating): the runner must recycle the tab
  LOSEONE_: {},               // 1.1.7.1 test: the reply of ONE storage call right before the click is lost once (bounded + retried inside the tab: no stall, no reopen)
  LOSEALL_: {},               // 1.1.7.1 test: the replies of one storage call are lost 3 times (the call fails as step-timeout: nothing clicked, fresh tab)
  HANGVER_: {},               // 1.1.7.1 test: the SECOND load of this video in a container (the verify page after the click) goes silent for good: the runner recycles it and a fresh tab only VERIFIES (liked, not liked-unverified, never a second click)
  NOREGIST_: {},              // 1.1.7.1 test: the click is shown by the page (aria-pressed true) but the server never registers the like: a fresh page shows it un-liked
  HANGREC_: {},               // 1.1.7.1 test: the FIRST load hangs inside the pre-click identity re-check (bounded by the tab itself: step-timeout -> fresh tab)
  DUPINST: { toggleMs: 1400 },       // duplicate injection test: slow toggle + a second copy of the tab logic is started at DOMContentLoaded
  REJECTLK: { rejectMs: 2600 },      // YouTube silently REJECTS the like: aria-pressed turns true at once (optimistic UI) and reverts 2.6 s later; the server never records it
  FLIPCHAN: { flipMs: 1800 },        // the account's active channel flips back to 'main' 1.8 s after load (stale switch / another tab / YouTube) — a click then lands on the wrong channel
  RELOADAF: { hydrateMs: 3200, reloadAfterClick: 700 }   // like clicked -> the page reloads itself 0.7 s later; the reloaded page hydrates late again
};


// 1.1.6.2: the account menu of the real page, in many interface languages. Structure like YouTube's (first section: Google Account <a href>, the switcher row (an in-menu action: NO address), Sign out <a href>; second section: more
// rows without address). The labels are the ONLY thing that changes between languages (Bean must not read them). Clicking Sign out is recorded (/__signout): it must never happen.
const MENU_LABELS = {
  en: ['Google Account', 'Switch account', 'Sign out', 'Appearance', 'Language'], ru: ['Аккаунт Google', 'Сменить аккаунт', 'Выйти', 'Тема', 'Язык'],
  ar: ['حساب Google', 'تبديل الحساب', 'تسجيل الخروج', 'المظهر', 'اللغة'], ja: ['Google アカウント', 'アカウントを切り替える', 'ログアウト', 'デザイン', '言語'],
  de: ['Google-Konto', 'Konto wechseln', 'Abmelden', 'Darstellung', 'Sprache'], pt: ['Conta do Google', 'Alternar conta', 'Sair', 'Aparência', 'Idioma'],
  fr: ['Compte Google', 'Changer de compte', 'Se déconnecter', 'Apparence', 'Langue'], hi: ['Google खाता', 'खाता बदलें', 'साइन आउट करें', 'दिखावट', 'भाषा'],
  sw: ['Akaunti ya Google', 'Badilisha akaunti', 'Ondoka', 'Mwonekano', 'Lugha'], zz: ['\u2060', '\u2060', '\u2060', '\u2060', '\u2060']
};
function menuScript(state) {
  const loc = MENU_LABELS[state.menuLocale || 'en'] || MENU_LABELS.en, rtl = state.menuLocale === 'ar';
  const data = { chans: state.__menu.map((c) => ({ id: c.id, name: c.name })), L: loc, rtl, noSw: !!state.menuNoSwitcher, swFirst: !!state.menuSwitcherFirst };
  return '<script>window.__mm=' + JSON.stringify(data) + ';' + `document.addEventListener('DOMContentLoaded',function(){var av=document.getElementById('avatar-btn');if(!av)return;av.addEventListener('click',function(){if(document.querySelector('ytd-multi-page-menu-renderer'))return;var M=window.__mm,m=document.createElement('ytd-multi-page-menu-renderer');if(M.rtl){m.setAttribute('dir','rtl');}
function row(label,href,id){var r=document.createElement('ytd-compact-link-renderer'),a=document.createElement('a');a.id=id||'endpoint';if(href)a.setAttribute('href',href);else a.setAttribute('tabindex','0');a.textContent=label;r.appendChild(a);return r;}
var s1=document.createElement('ytd-multi-page-menu-section-renderer'),s2=document.createElement('ytd-multi-page-menu-section-renderer');
s1.appendChild(row(M.L[0],'https://myaccount.google.com/?authuser=0'));var sw=null;if(!M.noSw){sw=row(M.L[1],'','sw');s1.appendChild(sw);}
var so=row(M.L[2],'https://accounts.google.com/Logout?service=youtube','so');so.addEventListener('click',function(){fetch('/__signout');});s1.appendChild(so);
s2.appendChild(row(M.L[3],'','ap'));s2.appendChild(row(M.L[4],'','lg'));m.appendChild(s1);m.appendChild(s2);document.getElementById('popups').appendChild(m);
function chooser(){m.innerHTML='';M.chans.forEach(function(c){var r=document.createElement('ytd-account-item-renderer');r.innerHTML='<tp-yt-paper-icon-item><span id="channel-title"></span></tp-yt-paper-icon-item>';r.querySelector('#channel-title').textContent=c.name;r.querySelector('tp-yt-paper-icon-item').addEventListener('click',function(){location.href='/signin?action_handle_signin=true&authuser=0'+(c.id==='main'?'':'&pageid='+c.id)+'&next='+encodeURIComponent(location.pathname+location.search)+'&feature=masthead_switcher&skip_identity_prompt=true&ui=1';});m.appendChild(r);});}
if(sw)sw.addEventListener('click',chooser);[].forEach.call(m.querySelectorAll('#ap,#lg'),function(x){x.addEventListener('click',function(){m.dataset.sub='1';});});});});</script>`;
}
function pageFor(vid, lc, state, acct, signedIn, chan) {
  const sc0 = SCENARIOS[Object.keys(SCENARIOS).find((k) => vid.startsWith(k))] || SCENARIOS.NORMAL;
  const sc = state.__blank === 'off' ? Object.assign({}, sc0, { commentsOff: true }) : state.__blank === 'empty' ? Object.assign({}, sc0, { commentsEmpty: true }) : sc0;          // 1.1.6.3 verifyBlank: the fresh page after a like shows no comments (off message / empty section)
  const isLiked = (id) => state.__stale ? true : state.liked.has((acct || '_') + (chan ? '#' + chan : '') + '|' + vid + '|' + id);
  const serverLiked = (id) => isLiked(id);
  const data = {
    vid, lc, signedIn, sc, acct, chan,
    comments: [
      { id: 'UgxTOP1_unliked_aaaaaaaaaaaaaaaa', text: 'top comment one', liked: isLiked('UgxTOP1_unliked_aaaaaaaaaaaaaaaa') },
      { id: 'UgxTOP2_alreadyliked_bbbbbbbbbbbb', text: 'top comment two (already liked)', liked: true },
      { id: 'UgxTOP3_withreplies_cccccccccccc', text: 'top comment three', liked: isLiked('UgxTOP3_withreplies_cccccccccccc'), replies: [{ id: 'UgxTOP3_withreplies_cccccccccccc.REPLYr1xxxxx', text: 'reply one', liked: isLiked('UgxTOP3_withreplies_cccccccccccc.REPLYr1xxxxx') }, { id: 'UgxTOP3_withreplies_cccccccccccc.REPLYr2yyyyy', text: 'reply two (already liked)', liked: true }] }
    ]
  };
  const masthead = sc.noMasthead ? '' : signedIn
    ? '<ytd-masthead><div id="buttons"><button id="avatar-btn" aria-label="Account menu"><img id="img" width="24" height="24" alt="" src="https://yt3.ggpht.com/mock/' + (state.mastAvatar || chan || 'main') + '=s24"></button></div></ytd-masthead>'
    : '<ytd-masthead><div id="buttons"><ytd-button-renderer class="style-suggestive"><a href="https://accounts.google.com/ServiceLogin?service=youtube" aria-label="Sign in">Sign in</a></ytd-button-renderer></div></ytd-masthead>';
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>mock watch ${vid}</title>
${(() => { const cfg = 'ytcfg.set({"DELEGATED_SESSION_ID":"' + (chan && chan !== 'main' ? chan : '') + '","DATASYNC_ID":"' + (chan && chan !== 'main' ? chan + '||9999999999' : '9999999999||') + '","SESSION_INDEX":"0","LOGGED_IN":' + (signedIn ? 'true' : 'false') + '});'; return state.ytcfgDelay ? '<script>setTimeout(function(){var s=document.createElement("script");s.textContent=' + JSON.stringify(cfg) + ';document.head.appendChild(s);},' + (+state.ytcfgDelay) + ');</script>' : '<script>' + cfg + '</script>'; })()}
<style>
 ytd-app,ytd-masthead,ytd-page-manager,ytd-watch-flexy,ytd-comments,ytd-comment-thread-renderer,ytd-comment-view-model,ytd-comment-replies-renderer,ytd-comment-engagement-bar,ytd-popup-container,tp-yt-paper-dialog,ytd-message-renderer,ytd-watch-metadata{display:block}
 body{margin:0;font:14px sans-serif;background:#fff;color:#111} ytd-masthead{height:56px;background:#eee} #player{height:900px;background:#222}
 ytd-comment-view-model{padding:10px;border-bottom:1px solid #ddd} #like-button,#dislike-button{display:inline-block} button{margin-right:6px}
 #linked-comment-badge{font-size:11px;background:#ddd;display:inline-block;padding:1px 6px}
 tp-yt-paper-dialog{position:fixed;left:30%;top:30%;background:#fff;border:2px solid #333;padding:20px;z-index:99999}
</style></head><body>
<ytd-app>${masthead}
<ytd-page-manager><ytd-watch-flexy><div id="columns"><div id="primary"><div id="primary-inner">
  <div id="player"><ytd-player><div id="movie_player"><video></video></div></ytd-player></div>
  <ytd-watch-metadata>metadata for ${vid}</ytd-watch-metadata>
  <div id="below"><ytd-comments id="comments"></ytd-comments></div>
</div></div><div id="secondary">related stuff</div></div></ytd-watch-flexy></ytd-page-manager>
<ytd-popup-container id="popups"></ytd-popup-container></ytd-app>${state.__menu && signedIn ? menuScript(state) : ''}
<script>
const D = ${JSON.stringify(data)};
// 1.1.3: real YouTube rewrites the watch URL after load (history.replaceState) and keeps only the params it knows (v, lc, t, list, index): unknown params (Bean's p9bn/p9bc/p9bh) disappear, so location.reload() reloads a token-less URL
const RELOAD_ONCE = ${JSON.stringify(!!state.__ro)};
if (RELOAD_ONCE) setTimeout(() => location.replace('/watch?v=' + D.vid + '&lc=' + encodeURIComponent(D.lc)), 1200);
const STRIP = ${JSON.stringify(state.strip || 0)};
if (STRIP) { const strip = () => { try { const u = new URL(location.href); for (const k of [...u.searchParams.keys()]) if (!['v', 'lc', 't', 'list', 'index'].includes(k)) u.searchParams.delete(k); history.replaceState(history.state, '', u.pathname + u.search + u.hash); } catch (e) {} }; setTimeout(strip, STRIP); document.addEventListener('DOMContentLoaded', () => setTimeout(strip, STRIP)); }
// test hook (1.1.1): ask a second copy of Bean's content script logic to run in this page at once (a duplicate injection)
if (D.vid.startsWith('HANGVER_')) { try { const n = +(localStorage.getItem('p9bn-hv-' + D.vid) || 0); localStorage.setItem('p9bn-hv-' + D.vid, String(n + 1)); if (n === 1) document.documentElement.setAttribute('data-p9bn-test', 'hangver'); } catch (e) {} }
for (const [pf, nm] of [['HANGPRE_', 'hangpre'], ['HANGREC_', 'hangrec'], ['LOSEONE_', 'loseone'], ['LOSEALL_', 'loseall']]) { if (D.vid.startsWith(pf)) { try { if (!localStorage.getItem('p9bn-hp-' + D.vid)) { localStorage.setItem('p9bn-hp-' + D.vid, '1'); document.documentElement.setAttribute('data-p9bn-test', nm); } } catch (e) {} } }          // 1.1.7.1 test hooks (one-shot per container session)
if (D.vid.startsWith('DUPINST')) { document.documentElement.setAttribute('data-p9bn-test', 'dup'); document.addEventListener('DOMContentLoaded', () => document.dispatchEvent(new Event('p9bn-test-dup'))); }
const beacon = (kind, id, pressed, extra) => { try { navigator.sendBeacon('/__click?kind=' + kind + '&id=' + encodeURIComponent(id) + '&vid=' + D.vid + '&pressed=' + pressed + '&signedIn=' + D.signedIn + '&acct=' + encodeURIComponent(D.acct || '') + '&chan=' + encodeURIComponent(D.chan || '') + (extra || '')); } catch (e) {} };
function commentHtml(c, isReply) {
  return '<ytd-comment-view-model' + (isReply ? ' is-reply' : '') + ' id="comment" data-cid="' + c.id + '">' +
    '<div id="header"><a id="author-text" href="/@someone">someone</a><span id="published-time-text"><a href="/watch?v=' + D.vid + '&lc=' + c.id + '">1 day ago</a></span></div>' +
    (D.lc === c.id ? '<div id="linked-comment-badge">Highlighted comment</div>' : '') +
    '<div id="content-text">' + c.text + '</div>' +
    '<ytd-comment-engagement-bar><div id="toolbar"><div id="like-button"><button data-kind="like" aria-pressed="' + ((D.sc.latePressed || D.sc.hydrateMs) ? 'false' : c.liked) + '" aria-label="Like this comment along with 4 other people">like</button></div>' +
    '<div id="dislike-button"><button data-kind="dislike" aria-pressed="false" aria-label="Dislike this comment">dislike</button></div></div></ytd-comment-engagement-bar></ytd-comment-view-model>';
}
function bind(el, c) {
  for (const b of el.querySelectorAll('button[data-kind]')) b.addEventListener('click', () => {
    const kind = b.dataset.kind, before = b.getAttribute('aria-pressed') === 'true';
    beacon(kind, c.id, before ? 'was-liked' : 'was-unliked', ((kind === 'like' && D.signedIn && !D.sc.flaky && !before) ? '&ok=1' : '') + (D.sc.rejectMs ? '&rej=1' : ''));
    if (kind === 'like' && !D.signedIn) { document.getElementById('popups').innerHTML = '<tp-yt-paper-dialog><div>Sign in to like this comment</div><a href="https://accounts.google.com/ServiceLogin">Sign in</a></tp-yt-paper-dialog>'; return; }
    if (D.sc.flaky) return;
    if (D.sc.reloadAfterClick && kind === 'like') setTimeout(() => location.reload(), D.sc.reloadAfterClick);
    setTimeout(() => b.setAttribute('aria-pressed', String(!before)), D.sc.toggleMs || 120);
    if (D.sc.rejectMs && kind === 'like') setTimeout(() => b.setAttribute('aria-pressed', String(before)), D.sc.rejectMs);
  });
}
function render() {
  const host = document.getElementById('comments');
  if (D.sc.commentsEmpty) { host.innerHTML = ''; return; }
  if (D.sc.commentsOff) { host.innerHTML = '<ytd-message-renderer>Comments are turned off.</ytd-message-renderer>'; return; }
  const list = D.comments.slice();
  // YouTube puts the linked comment's thread first
  const lcTop = D.lc.split('.')[0];
  list.sort((a, b) => (b.id === lcTop) - (a.id === lcTop));
  for (const c of list) {
    const th = document.createElement('ytd-comment-thread-renderer'); th.innerHTML = commentHtml(c, false);
    bind(th, c);
    if (c.replies) {
      const rep = document.createElement('ytd-comment-replies-renderer');
      rep.innerHTML = '<div id="expander"><div id="more-replies"><button>' + c.replies.length + ' replies</button></div></div><div id="loaded-replies"></div>';
      rep.querySelector('#more-replies button').addEventListener('click', () => setTimeout(() => {
        const lr = rep.querySelector('#loaded-replies');
        for (const r of c.replies) { const w = document.createElement('div'); w.innerHTML = commentHtml(r, true); lr.appendChild(w); bind(w, r); }
        rep.querySelector('#more-replies').hidden = true;
      }, 500));
      th.appendChild(rep);
    }
    host.appendChild(th);
  }
  if (D.sc.hydrateMs) setTimeout(() => { for (const c of D.comments) { const b = document.querySelector('[data-cid="' + c.id + '"] #like-button button'); if (b && c.liked && b.getAttribute('aria-pressed') !== 'true') b.setAttribute('aria-pressed', 'true'); } }, D.sc.hydrateMs);
  if (D.sc.latePressed) setTimeout(() => { for (const c of D.comments) { const b = document.querySelector('[data-cid="' + c.id + '"] #like-button button'); if (b) b.setAttribute('aria-pressed', String(true)); } }, 500);
}
// lazy like YouTube: the section only fills once it is on screen (comment-only layout stretches it over the viewport; the normal layout pushes it below the 900px player)
if (D.sc.flipMs && D.chan && D.chan !== 'main') setTimeout(() => { fetch('/__flip?to=main', { credentials: 'include' }).catch(() => {}); }, D.sc.flipMs);
let started = false;
const io = new IntersectionObserver((es) => { if (!started && es.some((e) => e.isIntersecting)) { started = true; setTimeout(render, D.sc.slow || 900); } });
function arm() { const h = document.getElementById('comments'); if (h) io.observe(h); }
arm(); setInterval(arm, 500);
</script></body></html>`;
}

async function start(opts = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'p9bn-cert-'));
  execFileSync('openssl', ['req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-days', '2', '-subj', '/CN=www.youtube.com', '-addext', 'subjectAltName=DNS:www.youtube.com', '-keyout', path.join(dir, 'k.pem'), '-out', path.join(dir, 'c.pem')], { stdio: 'ignore' });
  const state = { unlikes: [], signedIn: opts.signedIn !== false, clicks: [], hits: [], liked: new Set(), cookies: [], hitLog: [], accounts: {}, failSwitch: new Set(), switches: [], switcherHits: 0, delay: { watch: 0, switcher: 0, signin: 0, hops: 0 } };   // 1.1.2: real-world slowness: /watch takes 10-35 s, the switcher read ~14 s, a sign-in redirect chain of `hops` slow hops
  // 1.1.4: YouTube's own switch address carries authuser + feature + skip_identity_prompt (the list's accountSigninToken.signinUrl). A hand-made address without them does NOT switch (it only redirects to next).
  const realSwitch = (q) => state.requireReal === false || (q.get('authuser') !== null && /switcher/.test(q.get('feature') || '') && q.get('skip_identity_prompt') === 'true');
  // after a successful switch: the active channel changes; optionally YouTube RELOADS the landing page once by itself (the page dies, a token-less one replaces it) and/or the next switcher reads hang
  // 1.1.6 ghostSwitch (the REAL 1.1.5 finding): the switcher fetch reports the NEW channel as active (cookie chan), but the page's own session (ytcfg DELEGATED_SESSION_ID) and the like request stay on the PREVIOUS channel (cookie ident).
  // state.ghostSwitch = true: never catches up; = N: the identity follows only at the Nth switch attempt towards that channel (state.ghostTry); state.identNever (Set): channels it never follows to.
  // 1.1.6.1 uiOnly: the sign-in ADDRESS changes the menu's channel (cookie chan) but NOT the page identity (cookie ident); only YouTube's own account-menu click (the address with ui=1) does.
  // 1.1.6.1 staleDoc = N: a page NAVIGATION (sec-fetch-dest: document) to the same watch page (same v + lc, any other parameters) gets the old copy N times (a worker/cache answering); a fetch() and later loads get the fresh page.
  const swCookies = (to, prev, cur, via) => {
    const gh = [];
    if (state.navLag) gh.push('ident=' + encodeURIComponent(cur || prev || 'main') + '; Path=/');          // 1.1.6.2 navLag: the page identity of navigations INSIDE a tab stays on the previous channel
    if (state.uiOnly) gh.push('ident=' + encodeURIComponent(via ? to : (cur || prev || 'main')) + '; Path=/');
    if (state.ghostSwitch) { state.ghostN = (state.ghostN || 0) + 1; state.ghostTry = state.ghostTry || {}; const n = state.ghostTry[to] = (state.ghostTry[to] || 0) + 1; const follow = state.ghostSwitch !== true && !(state.identNever && state.identNever.has(to)) && n >= state.ghostSwitch; gh.push('ident=' + encodeURIComponent(follow ? to : (cur || prev || 'main')) + '; Path=/'); }      // per TARGET: the identity follows at that channel's Nth switch attempt (N=1: no lag); identNever: targets the page identity never reaches
    return swCookies0(to).concat(gh);
  };
  const swCookies0 = (to) => { if (state.hangAfterSwitch) state.hangNext = 3; return ['chan=' + encodeURIComponent(to) + '; Path=/'].concat(state.postSwitchReload ? ['jsw=1; Path=/'] : [], state.staleLikeAfterSwitch ? ['stl=1; Path=/'] : []); };
  const sanitizeNext = (n) => { if (!state.stripSignin) return n; try { const x = new URL(n, 'https://www.youtube.com'); for (const k of [...x.searchParams.keys()]) if (!['v', 'lc', 't', 'list', 'index'].includes(k)) x.searchParams.delete(k); return x.pathname + x.search; } catch (e) { return n; } };
  const handler = (req, res) => {
    const u = new URL(req.url, 'https://www.youtube.com');
    // 1.1.7: Google's own pages (a container whose Google session needs a sign-in / verification / consent): same server, other host names
    { const host = String(req.headers.host || '').split(':')[0].toLowerCase();
      if (host === 'accounts.google.com' || host === 'consent.youtube.com') { (state.googleHits = state.googleHits || []).push({ t: Date.now(), host, url: req.url }); res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' }); return res.end('<!doctype html><title>Sign in - Google Accounts</title><body><h1>Verify it\'s you</h1><input type="email" id="identifierId"></body>'); } }
    if (u.pathname === '/__signout') { state.signouts = (state.signouts || 0) + 1; res.writeHead(204); return res.end(); }
    if (u.pathname === '/__flip') { res.writeHead(204, { 'set-cookie': 'chan=' + encodeURIComponent(u.searchParams.get('to') || 'main') + '; Path=/' }); return res.end(); }
    if (u.pathname === '/__click') {
      const q = Object.fromEntries(u.searchParams); q.t = Date.now();
      { const ck = (n) => { const m = new RegExp('(?:^|;\\s*)' + n + '=([^;]*)').exec(req.headers.cookie || ''); return m ? decodeURIComponent(m[1]) : ''; }; const l = state.accounts[q.acct]; if (l) { const c = ck('chan'); q.pageChan = q.chan; q.chan = (l.find((x) => x.id === c) || l[0]).id; } }   // the channel the SERVER sees at click time (cookie), not the one the page was rendered for
      state.clicks.push(q); if (state.driftAfterClick && !state.driftNow) state.driftNow = true;
      // the SERVER decides what a click on "like" does: on a comment this account already liked it is an UN-LIKE (whatever the page showed when it was clicked)
      const key = (q.acct || '_') + (q.chan ? '#' + q.chan : '') + '|' + q.vid + '|' + q.id;
      if (q.kind === 'like' && key && q.signedIn === 'true') { if (state.liked.has(key)) { state.liked.delete(key); (state.unlikes = state.unlikes || []).push(Object.assign({ key }, q)); } else if (q.ok === '1' && q.rej !== '1' && !String(q.vid).startsWith('NOREGIST_')) state.liked.add(key); }          // NOREGIST_ (1.1.7.1 test): the page shows the like, the server never registers it
      res.writeHead(204); return res.end();
    }
    const cookie = (n) => { const m = new RegExp('(?:^|;\\s*)' + n + '=([^;]*)').exec(req.headers.cookie || ''); return m ? decodeURIComponent(m[1]) : ''; };
    // channels of an account (tests fill state.accounts = { alice: [{id,name,handle}, …] }); the first one is the one that is active until a switch happens
    const chansOf = (acct) => state.accounts[acct] || null;
    const activeOf = (acct) => { const l = chansOf(acct); if (!l) return ''; const c = cookie('chan'); return (l.find((x) => x.id === c) || l[0]).id; };
    // the account switcher list the page itself loads (shape reproduced from public markup, NOT captured from a signed-in session)
    if (u.pathname === '/getAccountSwitcherEndpoint') {
      state.switcherHits++;
      if (state.hangNext > 0) { state.hangNext--; state.hung = (state.hung || 0) + 1; setTimeout(() => { try { res.destroy(); } catch (e) {} }, 150000); return; }
      const acct = cookie('acct'), l = chansOf(acct);
      if (process.env.MOCKDBG) console.log('[mock switcher]', acct, 'chan=' + cookie('chan'), 'list=' + (l ? l.map((x) => x.id).join(',') : 'none'));
      res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
      if (!acct || acct === 'signedout' || !l) return res.end(")]}'\n" + JSON.stringify({ responseContext: {}, data: { actions: [] } }));
      const act = activeOf(acct);
      // 1.1.4: the REAL shape (public sources: yt-dlp#682, namida#726): accountItem.serviceEndpoint.selectActiveIdentityEndpoint.supportedTokens = [accountStateToken, offlineCacheKeyToken,
      // accountSigninToken{signinUrl}, datasyncIdToken, and pageIdToken{pageId} for a brand channel only]. The signinUrl carries authuser + feature + skip_identity_prompt (+ pageid for a brand channel).
      const item = (c) => ({ accountItem: { accountName: { simpleText: c.name }, accountByline: { simpleText: c.handle || (acct + '@example.invalid') }, isSelected: c.id === act, hasChannel: true, isDisabled: false, accountPhoto: { thumbnails: [{ url: 'https://yt3.ggpht.com/mock/' + c.id + '=s88' }] },
        serviceEndpoint: { selectActiveIdentityEndpoint: { supportedTokens: [{ accountStateToken: { hasChannel: true, isMerged: true, obfuscatedGaiaId: '103947969592461616663' } }, { offlineCacheKeyToken: { clientCacheKey: '' } },
          { accountSigninToken: { signinUrl: '/signin?action_handle_signin=true&authuser=0&next=%2F&feature=masthead_switcher&skip_identity_prompt=true' + (c.id === 'main' ? '' : '&pageid=' + c.id) } }, { datasyncIdToken: { datasyncIdToken: '103947969592461616663||' } }].concat(c.id === 'main' ? [] : [{ pageIdToken: { pageId: c.id } }]) } } } });
      const other = { accountItem: { accountName: { simpleText: 'Somebody Else' }, accountByline: { simpleText: 'other@example.invalid' }, isSelected: false, serviceEndpoint: { selectActiveIdentityEndpoint: { supportedTokens: [{ accountSigninToken: { signinUrl: '/signin?action_handle_signin=true&authuser=1&next=%2F&feature=masthead_switcher&skip_identity_prompt=true' } }] } } } };
      return res.end(")]}'\n" + JSON.stringify({ data: { actions: [{ getMultiPageMenuAction: { menu: { multiPageMenuRenderer: { sections: [
        { accountSectionListRenderer: { contents: [{ accountItemSectionRenderer: { contents: l.map(item) } }, { accountItemSectionRenderer: { contents: [other] } }] } }] } } } }] } }));
    }
    // YouTube's own switch: a GET that changes the active channel and goes back to next=
    if (u.pathname === '/signin') {
      if (state.hangSignin > 0) { state.hangSignin--; state.signinHung = (state.signinHung || 0) + 1; setTimeout(() => { try { res.destroy(); } catch (e) {} }, 150000); return; }          // 1.1.7.1: the switch address never comes back (real run q0uqbz21mw0h3rku #6)
      const acct = cookie('acct'), to = u.searchParams.get('pageid') || 'main', next = u.searchParams.get('next') || '/';
      const l = chansOf(acct), ok = !!l && l.some((x) => x.id === to) && !state.failSwitch.has(to) && realSwitch(u.searchParams);
      state.switches.push({ t: Date.now(), acct, to, ok });
      if (ok && state.settleMs) { state.settleUntil = Date.now() + state.settleMs; state.settlePrev = activeOf(acct); }          // 1.1.6.2 settleMs: the sign-in's cookies are not final yet: every page / fetch answers as the PREVIOUS channel for this long
      const h = { location: sanitizeNext(next), 'cache-control': 'no-store' };
      if (ok) h['set-cookie'] = swCookies(to, activeOf(acct), cookie('ident'), u.searchParams.get('ui') === '1').concat(state.staleDoc ? ['swn=' + state.staleDoc + '; Path=/'] : []);
      if (state.delay.hops > 0) { const q = new URLSearchParams(u.search); q.set('hop', '1'); h.location = '/signin-hop?' + q.toString(); delete h['set-cookie']; res.writeHead(302, h); return res.end(); }      // the chain: /signin -> /signin-hop (n times) -> next, the channel changes at the LAST hop
      res.writeHead(302, h); return res.end();
    }
    if (u.pathname === '/signin-hop') {
      const hop = +(u.searchParams.get('hop') || 1), acct = cookie('acct'), to = u.searchParams.get('pageid') || 'main', next = u.searchParams.get('next') || '/';
      const l = chansOf(acct), ok = !!l && l.some((x) => x.id === to) && !state.failSwitch.has(to) && realSwitch(u.searchParams);
      if (hop < state.delay.hops) { const q = new URLSearchParams(u.search); q.set('hop', String(hop + 1)); res.writeHead(302, { location: '/signin-hop?' + q.toString(), 'cache-control': 'no-store' }); return res.end(); }
      const h = { location: sanitizeNext(next), 'cache-control': 'no-store' }; if (ok) h['set-cookie'] = swCookies(to, activeOf(acct), cookie('ident'));
      res.writeHead(302, h); return res.end();
    }
    if (u.pathname === '/watch') {
      // per-container Google account: tests put a cookie  acct=<name>  into each container's session ('signedout' = not signed in). Without it the global switch applies.
      const m = /(?:^|;\s*)acct=([^;]*)/.exec(req.headers.cookie || ''), acct = m ? decodeURIComponent(m[1]) : '';
      const signedIn = acct ? acct !== 'signedout' : state.signedIn;
      let chan = state.driftNow ? state.driftTo : (state.ghostSwitch || state.uiOnly) && cookie('ident') ? cookie('ident') : activeOf(acct);        // driftNow: identity drift mid-run (after the first like every page is another channel)        // ghostSwitch: the page renders (and likes) as the PREVIOUS identity
      let navFresh = false;
      if (state.navLag) {                                                  // 1.1.6.2: the REAL 1.1.6.1 failure. A fetch() of the page renders the TARGET (cookie chan); a navigation inside a tab renders the OLD identity (cookie ident) until a tab is OPENED anew (sec-fetch-site: none)
        const doc = req.headers['sec-fetch-dest'] === 'document', id = cookie('ident');
        navFresh = doc && req.headers['sec-fetch-site'] === 'none';
        chan = doc && !navFresh && id ? id : activeOf(acct); state.navServed = (state.navServed || 0) + (doc && !navFresh && id && id !== activeOf(acct) ? 1 : 0); if (navFresh) state.navFreshOpens = (state.navFreshOpens || 0) + 1;
      }
      if (state.settleMs && Date.now() < (state.settleUntil || 0) && state.settlePrev) chan = state.settlePrev;
      if (process.env.MOCKDBG) console.log('[mock /watch]', 'ghost=' + state.ghostSwitch, 'ident=' + cookie('ident'), 'chan=' + cookie('chan'), 'page=' + chan);
      state.hits.push(u.search); state.cookies.push(acct); state.hitLog.push({ t: Date.now(), acct, chan, search: u.search });
      { const v0 = u.searchParams.get('v') || '', dk = acct + '|' + v0;
        // 1.1.7 silent / blocked containers. HANGFIRST*: the FIRST page load of each (container, video) never answers (a dead proxy / a stuck connection); HANGALL*: every load does. The socket stays open until the tab is closed.
        if (v0.startsWith('HANGONE') && acct === 'alice') { state.hangSeen = state.hangSeen || {}; state.hangSeen[dk] = (state.hangSeen[dk] || 0) + 1; req.on('close', () => { state.hangClosed = (state.hangClosed || 0) + 1; }); return; }          // 1.1.7.2: only container A hangs, on every load
        if (v0.startsWith('HANGFIRST') || v0.startsWith('HANGALL')) { state.hangSeen = state.hangSeen || {}; const n = state.hangSeen[dk] = (state.hangSeen[dk] || 0) + 1; state.hangLog = (state.hangLog || []).concat([{ t: Date.now(), acct, v: v0, n }]); if (v0.startsWith('HANGALL') || n === 1) { req.on('close', () => { state.hangClosed = (state.hangClosed || 0) + 1; }); return; } }
        // GOOGLECHK01: Google sends the tab to its sign-in page and keeps the original address in "continue" (as the real one does); GOOGLECHK02: to its consent page, without any address
        if (v0.startsWith('GOOGLECHK01')) { res.writeHead(302, { location: 'https://accounts.google.com/v3/signin/identifier?hl=en&continue=' + encodeURIComponent('https://www.youtube.com' + req.url) + '&service=youtube', 'cache-control': 'no-store' }); return res.end(); }
        if (v0.startsWith('GOOGLEONE') && acct === 'alice') { res.writeHead(302, { location: 'https://accounts.google.com/v3/signin/identifier?hl=en&continue=' + encodeURIComponent('https://www.youtube.com' + req.url) + '&service=youtube', 'cache-control': 'no-store' }); return res.end(); }          // 1.1.7.2: only container A needs a sign-in
        if (v0.startsWith('GOOGLECHK02')) { res.writeHead(302, { location: 'https://consent.youtube.com/m?hl=en&pc=yt', 'cache-control': 'no-store' }); return res.end(); } }
      const skey = acct + '|' + u.searchParams.get('v') + '|' + u.searchParams.get('lc'), swn = +cookie('swn') || 0;
      const staleBody = state.staleDoc && req.headers['sec-fetch-dest'] === 'document' && swn > 0 && state.docCache && state.docCache.get(skey) || null;       // staleDoc: the first N page loads AFTER a sign-in come from the copy shown before it
      if (staleBody) { state.staleServed = (state.staleServed || 0) + 1; res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'set-cookie': 'swn=' + (swn - 1) + '; Path=/' }); return res.end(staleBody); }
      const jsw = cookie('jsw') === '1'; state.__ro = jsw; const stl = cookie('stl') === '1'; state.__stale = stl;
      { const sc = [].concat(jsw ? ['jsw=; Path=/; Max-Age=0'] : [], stl && state.staleLikeAfterSwitch !== 'persist' ? ['stl=; Path=/; Max-Age=0'] : [], navFresh ? ['ident=' + encodeURIComponent(activeOf(acct) || 'main') + '; Path=/'] : []); res.writeHead(200, Object.assign({ 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' }, sc.length ? { 'set-cookie': sc } : {})); }
      state.__blank = false; if (state.verifyBlank && state.verifyBlank.n > 0) { const vv = u.searchParams.get('v') || '', pre = (acct || '_') + (chan ? '#' + chan : '') + '|' + vv + '|'; if ([...state.liked].some((k) => k.startsWith(pre))) { state.verifyBlank.n--; state.__blank = state.verifyBlank.mode || 'off'; state.blankServed = (state.blankServed || 0) + 1; } }          // 1.1.6.3: the first N page loads after a like show no comments
      state.__menu = (state.uiMenu || state.uiOnly || state.navLag) && state.uiMenu !== false ? chansOf(acct) : null;
      const body = pageFor(u.searchParams.get('v') || 'XXXXXXXXXXX', u.searchParams.get('lc') || '', state, acct, signedIn, chan);
      if (state.staleDoc && req.headers['sec-fetch-dest'] === 'document') { state.docCache = state.docCache || new Map(); if (!staleBody) state.docCache.set(skey, body); }
      let out = body;
      { // 1.1.7 FREEZE01*: the 1st page load of each (container, video) freezes its renderer 2.5 s after it started (Bean's script runs, then goes silent); FREEZE02*: the 2nd load does (the page loaded twice, then silence)
        const v1 = u.searchParams.get('v') || '';
        if (v1.startsWith('FREEZE0')) { state.freezeSeen = state.freezeSeen || {}; const fk = acct + '|' + v1, n = state.freezeSeen[fk] = (state.freezeSeen[fk] || 0) + 1; if (n === (v1.startsWith('FREEZE02') ? 2 : 1)) { state.froze = (state.froze || 0) + 1; out = body + '<script>setTimeout(function(){var t=Date.now();while(Date.now()-t<900000);},2500)</script>'; } } }
      return res.end(out);
    }
    res.writeHead(200, { 'content-type': 'text/html' }); res.end('<!doctype html><title>mock youtube</title>mock home');
  };
  const ms = (v) => (typeof v === 'function' ? v() : v) || 0;
  const srv = https.createServer({ key: fs.readFileSync(path.join(dir, 'k.pem')), cert: fs.readFileSync(path.join(dir, 'c.pem')) }, (req, res) => {
    const t0 = Date.now(); res.on('close', () => { (state.reqLog = state.reqLog || []).push({ p: new URL(req.url, 'https://www.youtube.com').pathname, t0, t1: Date.now() }); if (state.reqLog.length > 2000) state.reqLog.shift(); });
    const p = new URL(req.url, 'https://www.youtube.com').pathname, d = p === '/watch' ? ms(state.delay.watch) : p === '/getAccountSwitcherEndpoint' ? ms(state.delay.switcher) : p === '/signin' || p === '/signin-hop' ? ms(state.delay.signin) : 0;
    if (d) setTimeout(() => handler(req, res), d); else handler(req, res);
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  return { port: srv.address().port, state, close: () => new Promise((r) => srv.close(r)) };
}
module.exports = { start, SCENARIOS };
