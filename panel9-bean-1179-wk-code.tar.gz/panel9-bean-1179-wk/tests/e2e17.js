'use strict';
// Bean 1.1.7 order-queue end-to-end tests (R50-R55: quantity per link, queue + reservation, cancel, persistence, spares, shortfall).
// They live in e2e-safety.js (same real Panel 9 + Bean + YouTube Focus harness and mock) so the whole matrix can be run in one go; this file runs just those sections.
// Run: cd /tmp/p9-bean2310 && P9_DIR=/tmp/p9-bean2310 xvfb-run -a -s "-screen 0 1440x1000x24" npx electron --no-sandbox /workspace/panel9-bean-117/tests/e2e17.js
process.env.ONLY = process.env.ONLY || 'R50,R51,R52,R53,R54,R55';
require('./e2e-safety.js');
