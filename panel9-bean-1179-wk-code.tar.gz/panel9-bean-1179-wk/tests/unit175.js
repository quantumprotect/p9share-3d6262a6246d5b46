// Bean 1.1.7.9 unit checks: parallel containers (+ Parallel/Single toggle capacity) (waves of 4, WAVE-SHARED VPN = up to 4 VPN containers at once, never a stall) and the step table
const S = require('../lib/steps.js'), O = require('../lib/orders.js'), fs = require('fs'), path = require('path'); let p = 0, f = 0;
const ok = (n, c) => { if (c) p++; else { f++; console.log('FAIL ' + n); } };
const mk = (n, o) => { o = o || {}; const groups = [], items = []; for (let i = 0; i < n; i++) { groups.push({ cid: 'c' + i, status: 'queued' }); for (let k = 0; k < 2; k++) items.push({ cid: 'c' + i, status: 'queued', vpnSkip: !!(o.skip && o.skip(i)) }); } return { id: 'r', groups, items, vpn: { on: !!o.vpn } }; };
const open = (b) => b.groups.filter((g) => g.status === 'opening' || g.status === 'running');
// drive pickOpen like advance(): one open per pass, stagger respected via time
function drive(b, o) {
  o = o || {}; let wave = null, t = 1e6, last = 0, maxOpen = 0, maxVpn = 0, waveViol = 0, passes = 0, rnd = o.seed || 7; const r = () => { rnd = (rnd * 1103515245 + 12345) % 2147483648; return rnd / 2147483648; };
  const waveOfCid = {};
  while (b.groups.some((g) => g.status !== 'done') && passes < 20000) {
    passes++; t += 1000;
    for (const g of open(b)) if (r() < (o.pDone || 0.08)) { g.status = 'done'; b.items.forEach((it) => { if (it.cid === g.cid) it.status = 'liked'; }); }
      else if (r() < (o.pBack || 0.01)) g.status = 'queued';          // handed back (fresh tab)
    const pl = S.pickOpen(b, { now: t, wave, lastOpenAt: last, cap: o.cap });
    if (pl.wave) wave = pl.wave;
    if (pl.cid != null) { const g = b.groups.find((x) => x.cid === pl.cid); g.status = 'opening'; last = t; if (waveOfCid[g.cid] != null && waveOfCid[g.cid] !== wave.n) waveViol++; waveOfCid[g.cid] = wave.n;
      for (const x of open(b)) if (x !== g && waveOfCid[x.cid] !== wave.n) waveViol++; }
    maxOpen = Math.max(maxOpen, open(b).length); maxVpn = Math.max(maxVpn, open(b).filter((g) => S.usesVpn(b, g)).length);
  }
  return { finished: b.groups.every((g) => g.status === 'done'), maxOpen, maxVpn, waveViol, passes, waves: wave ? wave.n : 0 };
}
ok('PARALLEL_CONTAINERS is 4, wave mode on', S.PARALLEL_CONTAINERS === 4 && S.WAVE_MODE === true);
{ const r = drive(mk(10), { pDone: 0.01, pBack: 0 }); ok('VPN off: 10 containers finish, never more than 4 open, reaches 4', r.finished && r.maxOpen === 4); ok('waves: no container of the next wave opens while one of the current wave is open', r.waveViol === 0); ok('10 containers = 3 waves (4+4+2)', r.waves === 3); }
{ const r = drive(mk(10, { vpn: true }), { pDone: 0.01, pBack: 0 }); ok('VPN on (wave-shared): up to 4 VPN containers open at once, all finish', r.finished && r.maxVpn === 4 && r.maxOpen === 4); }
{ const r = drive(mk(9, { vpn: true, skip: (i) => i % 3 !== 0 }), { pDone: 0.01, pBack: 0 }); ok('VPN on, 6 of 9 bypassed: up to 4 open (VPN + bypass fill the wave)', r.finished && r.maxOpen === 4 && r.maxVpn >= 1 && r.maxVpn <= 4); }
for (let s = 1; s <= 40; s++) { const r = drive(mk(7, { vpn: s % 2 === 0, skip: (i) => i % 2 === 1 }), { seed: s * 7919, pBack: 0.05 }); if (!(r.finished && r.maxOpen <= 4 && r.maxVpn <= 4 && r.waveViol === 0)) { ok('random run ' + s + ' ' + JSON.stringify(r), false); break; } if (s === 40) ok('40 random runs with hand-backs: always finish, <=4 open, <=4 VPN (wave-shared), waves intact', true); }
{ const b = mk(5); const a = S.pickOpen(b, { now: 1000 }); ok('first pick starts wave 1 with c0', a.cid === 'c0' && a.wave && a.wave.n === 1 && a.wave.cids[0] === 'c0'); b.groups[0].status = 'opening';
  ok('stagger: the second member waits STAGGER_MS', S.pickOpen(b, { now: 1000 + 100, wave: a.wave, lastOpenAt: 1000 }).cid === null && S.pickOpen(b, { now: 1000 + S.STAGGER_MS + 1, wave: a.wave, lastOpenAt: 1000 }).cid === 'c1'); }
{ const b = mk(5); b.groups.slice(0, 4).forEach((g) => { g.status = 'running'; }); ok('5th container never opens while 4 are open', S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0', 'c1', 'c2', 'c3'] } }).cid === null); }
{ const b = mk(5); b.groups[0].status = 'done'; b.groups[1].status = 'running'; b.groups[2].status = 'running'; b.groups[3].status = 'running'; ok('wave mode: one of four finished -> the 5th still waits for the whole wave', S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0', 'c1', 'c2', 'c3'] } }).cid === null); }
{ const b = mk(5); b.groups[0].status = 'queued'; b.groups[1].status = 'running'; b.groups[2].status = 'done'; b.groups[3].status = 'done'; ok('a member handed back is reopened inside its wave', S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0', 'c1', 'c2', 'c3'] } }).cid === 'c0'); }
{ const b = mk(5); b.groups.slice(0, 4).forEach((g) => { g.status = 'done'; }); const r = S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0', 'c1', 'c2', 'c3'] } }); ok('wave over -> wave 2 starts with c4', r.cid === 'c4' && r.wave.n === 2); }
{ const b = mk(3); ok('cap 1 (p9bn.parallel=1) = the old one-at-a-time behaviour', drive(b, { cap: 1 }).maxOpen === 1); }

{ const b = mk(4, { vpn: true }); b.groups[0].status = 'running'; const r = S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0'] }, lastOpenAt: 0 }); ok('1.1.7.9: second VPN container may open while first VPN is open (wave-shared)', r.cid === 'c1'); }
{ const b = mk(3, { vpn: true }); b.groups[0].status = 'opening';
  const r2 = S.pickOpen(b, { now: 9e9, wave: { n: 1, cids: ['c0'], loc: { location: 'NY', ipChanged: true } }, lastOpenAt: 0 });
  ok('wave.loc kept when a new member is added to the wave', r2.cid === 'c1' && r2.wave && r2.wave.loc && r2.wave.loc.location === 'NY' && r2.wave.cids.indexOf('c1') >= 0); }
// steps
ok('every step has a name, a positive limit and an outcome', Object.keys(S.STEPS).length >= 12 && Object.entries(S.STEPS).every(([n, v]) => n && v[0] > 0 && v[0] <= 320000 && v[2]));
for (const n of ['vpn-rotate', 'vpn-up', 'open-tab', 'first-heartbeat', 'channel-switch', 'find-comment', 'identity-check', 'like-verify', 'next-item', 'group-done']) ok('step ' + n + ' is in the table', !!S.STEPS[n]);
(async () => {
  let e = null; const t0 = Date.now(); try { await S.step('open-tab', new Promise(() => {}), 60); } catch (x) { e = x; }
  ok('a step that never answers rejects { bound, step } at its limit', e && e.bound === true && e.step === 'open-tab' && Date.now() - t0 < 1000 && /open-tab/.test(e.message));
  ok('a step that answers resolves its value', (await S.step('open-tab', Promise.resolve(42), 1000)) === 42);
  let thr = false; try { S.stepMs('nope'); } catch (_) { thr = true; } ok('unknown step name throws (no silent default)', thr);
  // tabGone touches only the container named
  { const b = { state: 'running', groups: [{ cid: 'a', status: 'running' }, { cid: 'b', status: 'running' }], items: [{ cid: 'a', status: 'running' }, { cid: 'b', status: 'running' }] }; O.tabGone(b, Date.now(), { cid: 'a' }); ok('tabGone({cid}) only re-queues that container', b.items[0].status === 'queued' && b.items[1].status === 'running' && !b.groups[1].gone); }
  // static wiring
  const pj = fs.readFileSync(path.join(__dirname, '..', 'popup.js'), 'utf8'), cj = fs.readFileSync(path.join(__dirname, '..', 'content.js'), 'utf8'), ph = fs.readFileSync(path.join(__dirname, '..', 'popup.html'), 'utf8');
  ok('popup.html loads lib/steps.js before popup.js', ph.indexOf('lib/steps.js') > 0 && ph.indexOf('lib/steps.js') < ph.indexOf('popup.js'));
  ok('advance() opens through ST.pickOpen (no more "one open group = wait")', /ST\.pickOpen\(b, \{ now, cap: parCap/.test(pj) && !/a tab is working: wait/.test(pj));
  ok('before an open only THIS container\'s tab is closed (siblings kept via keepOthers/mem/tabOf/wave)', /ST\.step\('close-previous', closeExcept\(b, toOpen\.cid\)\)/.test(pj) && /keepSiblings/.test(pj) && /Never close another parallel container/.test(pj));
  ok('VPN-drop reopen and lost-tab reopen close only that container', (pj.match(/closeOneGroup\(/g) || []).length >= 3 && /tabGone\(b, Date\.now\(\), \{ cid: g0\.cid/.test(pj));
  ok('alive ping is per container', /tabAnswers\(cur, g0\.cid/.test(pj) && /tabAnswers\(cur, c\)/.test(pj) && /K\.alive \+ '\.' \+ myCid\(\)/.test(cj));
  ok('click lock is per container', /const lockKey = \(\) => \(myCid\(\) \? K\.lock \+ '\.' \+ myCid\(\) : K\.lock\)/.test(cj) && !/sget\(K\.lock\)|sset\(K\.lock,/.test(cj));
  ok('vpn-up wait is bounded by the step table', /ST\.step\('vpn-up', vpnUpBeforeOpen\(toOpen\)\)/.test(pj));
  ok('parallel only with Background tabs on (else 1, the old behaviour)', /async function parallelCap\(\) \{ if \(!\(await bgTabsNow\(\)\)\) return 1;/.test(pj));
  ok('manifest 1.1.7.9', JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'manifest.json'), 'utf8')).version === '1.1.7.9');
  console.log(`unit175: ${p} passed, ${f} failed`); process.exit(f ? 1 : 0);
})();
