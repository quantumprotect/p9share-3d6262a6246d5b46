// test helper: a worker thread that notices when the main thread stops heartbeating and prints the main thread's JS stack (via the inspector)
const { Worker, isMainThread, workerData } = require('worker_threads');
if (isMainThread) {
  module.exports = () => {
    const sab = new SharedArrayBuffer(8), a = new Int32Array(sab);
    setInterval(() => { Atomics.store(a, 0, (Date.now() / 1000) | 0); }, 500).unref();
    const w = new Worker(__filename, { workerData: { sab } }); w.unref(); w.on('message', (m) => console.log(m)); return w;
  };
} else {
  const { parentPort } = require('worker_threads'); const inspector = require('inspector'); const a = new Int32Array(workerData.sab);
  const s = new inspector.Session(); s.connectToMainThread(); let busy = false, last = 0;
  s.on('Debugger.paused', (m) => { const f = (m.params.callFrames || []).slice(0, 10).map((c) => `${c.functionName || '(anon)'} ${String(c.url).split('/').slice(-3).join('/')}:${c.location.lineNumber + 1}`); parentPort.postMessage(`   [stack] main thread blocked in: ${f.join(' <- ')}`); s.post('Debugger.resume', () => { busy = false; }); });
  s.post('Debugger.enable');
  setInterval(() => { const now = (Date.now() / 1000) | 0, hb = Atomics.load(a, 0); if (hb && now - hb > 6 && !busy && now - last > 30) { busy = true; last = now; s.post('Debugger.pause'); } }, 1000);
}
