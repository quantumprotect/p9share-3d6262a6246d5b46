'use strict';
// Bean 1.1.0 end-to-end: the REAL Bean (+ the REAL, unmodified YouTube Focus) inside the REAL Panel 9 WITH the Bean VPN bridge patch, against
//   · a LOCAL mock of youtube.com (tests/mock-youtube.js)           — no real YouTube, account or comment is touched
//   · a MOCK expressvpnctl + a local "geo" server                    — no real VPN is controlled
//   · the REAL bean_api Flask blueprint on a throw-away sqlite file  — no real server, no real key
// Covers: the permanent channel ledger, VPN location rotation (success / stuck / CLI unavailable / bypassed container), the named API (create, capacity, quantity clamp,
// headless job run, cancel, regenerate, revoke, key↔install binding, popup-as-executor) and restore of the ledger from the server.
// Run:  cd /tmp/p9-bean11 && P9_DIR=/tmp/p9-bean11 xvfb-run -a -s "-screen 0 1440x1000x24" npx electron --no-sandbox /workspace/panel9-bean/tests/e2e11.js
const fs = require('fs'); const os = require('os'); const path = require('path'); const http = require('http'); const net = require('net');
const { spawn, execFileSync } = require('child_process');
const { app } = require('electron');
// xvfb has no real window visibility: keep hidden test windows' timers running like a visible popup would (a throttled timer only delays Bean's 1 s tick)
app.commandLine.appendSwitch('disable-background-timer-throttling'); app.commandLine.appendSwitch('disable-renderer-backgrounding'); app.commandLine.appendSwitch('disable-backgrounding-occluded-windows'); app.commandLine.appendSwitch('disable-features', 'IntensiveWakeUpThrottling,CalculateNativeWinOcclusion');
const P9 = process.env.P9_DIR || '/tmp/p9-bean11';
const YTF = process.env.P9_YTF_DIR || '/workspace/yt-focus-extension';
const PY = process.env.BEAN_PY || '/workspace/appstore/venv/bin/python';
const SRC = path.join(__dirname, '..');
const mock = require('./mock-youtube.js');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let failures = 0, passes = 0;
const check = (name, ok, detail) => { if (ok) passes++; else failures++; console.log(`  ${ok ? 'PASS' : 'FAIL'}  ${name}${!ok && detail !== undefined ? '  -> ' + JSON.stringify(detail).slice(0, 400) : ''}`); };
const js = (wc, code) => wc.executeJavaScript(code).catch((e) => { console.log('  [js error] ' + String(code).slice(0, 160).replace(/\s+/g, ' ') + ' -> ' + String(e).slice(0, 200)); throw e; });

(async () => {
  const srv = await mock.start({ signedIn: true }); const sw = srv.state;
  app.commandLine.appendSwitch('host-resolver-rules', `MAP www.youtube.com 127.0.0.1:${srv.port}`);
  app.commandLine.appendSwitch('ignore-certificate-errors');
  process.env.P9_TEST = '1'; process.env.P9_USER_DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'p9-bean11-'));
  process.env.P9_LEGACY_DIR = path.join(process.env.P9_USER_DATA, '..', 'p9-no-legacy-dir'); process.env.P9_NO_UPDATE_CHECK = '1';
  const { ready, api } = require(path.join(P9, 'src/main.js'));
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'bean11-'));
  // ---- the Bean API server (real code, throw-away data)
  const free = () => new Promise((r) => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => r(p)); }); });
  const SPORT = await free();
  const py = spawn(PY, [path.join(__dirname, 'run_bean_server.py'), path.join(tmp, 'server'), String(SPORT)], { stdio: ['ignore', 'ignore', 'pipe'], env: Object.assign({}, process.env, { BEAN_TEST_FAST: '1' }) });
  let pyErr = ''; py.stderr.on('data', (d) => { pyErr += d; }); process.on('exit', () => { try { py.kill(); } catch (_) { /* gone */ } });
  const BASE = `http://127.0.0.1:${SPORT}`;
  const req = (method, p, key, body, extra) => new Promise((res, rej) => { const d = body === undefined ? null : JSON.stringify(body); const r = http.request({ host: '127.0.0.1', port: SPORT, path: p, method, headers: Object.assign({ 'Content-Type': 'application/json' }, key ? { Authorization: 'Bearer ' + key } : {}, d ? { 'Content-Length': Buffer.byteLength(d) } : {}, extra || {}) }, (x) => { let b = ''; x.on('data', (c) => { b += c; }); x.on('end', () => { let j = null; try { j = JSON.parse(b); } catch (_) { /* not json */ } res({ status: x.statusCode, json: j }); }); }); r.on('error', rej); if (d) r.write(d); r.end(); });
  for (let i = 0; i < 60; i++) { try { if ((await req('GET', '/api/bean/v1/health')).status === 200) break; } catch (_) { /* starting */ } await sleep(250); }
  check('the real Bean API server is up (local, throw-away database)', (await req('GET', '/api/bean/v1/health')).status === 200, pyErr.slice(0, 300));
  // ---- mock expressvpnctl + geo
  const stateFile = path.join(tmp, 'evpn-state.json'), wrapper = path.join(tmp, 'expressvpnctl');
  fs.writeFileSync(wrapper, `#!/bin/sh\nexec "${execFileSync('which', ['node']).toString().trim()}" "${path.join(P9, 'test/mock-expressvpnctl.js')}" "$@"\n`, { mode: 0o755 });
  process.env.P9_MOCK_EVPN_STATE = stateFile; process.env.P9_EXPRESSVPN_CLI = wrapper; process.env.P9_MOCK_MORE_REGIONS = '5';
  const REAL = '203.0.113.5', ipOf = (region) => { let n = 7; for (const ch of region) n = (n * 31 + ch.charCodeAt(0)) % 200; return '198.51.100.' + (10 + n); };
  const geoLog = [];
  const geo = http.createServer((q, r) => { let st = {}; try { st = JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch (_) { /* none */ } geoLog.push({ t: Date.now(), region: st.state === 'Connected' ? st.region : '' }); r.writeHead(200, { 'content-type': 'application/json' }); r.end(JSON.stringify({ success: true, ip: st.state === 'Connected' ? ipOf(st.region) : REAL, country_code: 'XX' })); });
  await new Promise((r) => geo.listen(0, '127.0.0.1', r)); process.env.P9_VERIFY_URL_PLAIN = `http://127.0.0.1:${geo.address().port}/geo`;
  const ctlCalls = () => { try { return fs.readFileSync(stateFile + '.calls', 'utf8').split('\n').filter(Boolean); } catch (_) { return []; } };
  const connects = () => ctlCalls().filter((c) => /^connect /.test(c)).map((c) => c.replace(/^connect /, ''));
  const connT = []; { let seen = 0; setInterval(() => { const n = ctlCalls().filter((c) => /^connect /.test(c)).length; while (seen < n) { connT.push(Date.now()); seen++; } }, 30); }      // 1.1.2: when did each VPN connect happen?

  await ready;
  const ctx = api.ctx, mgr = api.extensions;
  const trk = require('./tabtrack.js')(ctx);        // tab rule: at most ONE Bean tab open at any time, all closed at the end
  const wait = async (cond, ms = 20000, step = 150) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { try { const v = await cond(); if (v) return v; } catch (_) { /* retry */ } await sleep(step); } return false; };
  const copyExt = (name) => { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'p9bn-copy-')); fs.cpSync(SRC, d, { recursive: true, filter: (p) => !/[\\/](tests|shots)([\\/]|$)/.test(p) }); const m = JSON.parse(fs.readFileSync(path.join(d, 'manifest.json'), 'utf8')); m.name = name; m.host_permissions = (m.host_permissions || []).concat(['http://127.0.0.1/*']);   /* test copy only: the local Bean API server */ fs.writeFileSync(path.join(d, 'manifest.json'), JSON.stringify(m, null, 2)); return d; };
  console.log('\n== setup ==');
  const ytf = await mgr.loadUnpacked(YTF), bean = await mgr.loadUnpacked(copyExt('Panel9 Bean'));
  const home = ctx.createTab('about:blank', 'desktop'); await home.ready; ctx.win.setSize(1300, 900); await sleep(400);
  await wait(() => mgr.pageUrl(bean.id, 'popup'), 8000);
  check('YouTube Focus (unmodified) and Bean 1.1.6 loaded; Bean has the patched bridge (api.bean present)', !!ytf && !!bean && bean.id === 'local-panel9-bean' && !!api.bean, [ytf && ytf.id, bean && bean.id]);
  const closePopups = () => { for (const w of api.extPopups.values()) { try { w.close(); } catch (_) { /* ignore */ } } };
  const popup = async (id, settle = 1400) => { closePopups(); await sleep(150); await api.openExtensionPopup(ctx, id || bean.id, 'popup'); const w = await wait(() => api.extPopups.get(`${ctx.id}:${id || bean.id}:popup`), 5000); const wc = w.contentView.children[0].webContents; await wait(() => js(wc, "document.readyState === 'complete' && !!window.B11 && B11.S.ledReady"), 8000); await sleep(settle); return wc; };
  const ytfToggle = async (key, on) => { const wc = await popup(ytf.id, 300); await js(wc, `(() => { const c = document.getElementById('${key}'); if (c.checked !== ${on}) c.click(); })()`); await sleep(700); closePopups(); };
  const batchOf = (wc) => js(wc, "chrome.storage.local.get('p9bn.batch').then((v) => v['p9bn.batch'])");
  const store = (wc, k) => js(wc, `chrome.storage.local.get(${JSON.stringify(k)}).then((v) => v[${JSON.stringify(k)}])`);
  const ui = (wc, sel) => js(wc, `(document.querySelector(${JSON.stringify(sel)}) || {}).textContent`);
  const click = (wc, sel) => js(wc, `(() => { const e = document.querySelector(${JSON.stringify(sel)}); if (!e) return false; e.click(); return true; })()`);
  const click2 = async (wc, sel) => { await click(wc, sel); await sleep(150); await click(wc, sel); };       // two-step confirm buttons
  const ID = { top1: 'UgxTOP1_unliked_aaaaaaaaaaaaaaaa', top3: 'UgxTOP3_withreplies_cccccccccccc', r1: 'UgxTOP3_withreplies_cccccccccccc.REPLYr1xxxxx' };
  const link = (vid, lc) => `https://www.youtube.com/watch?v=${vid}&lc=${lc}`;
  let runId = null;
  const setLinks = async (wc, text, pace = 'fast') => { await js(wc, `(() => { const t = document.getElementById('links'); t.value = ${JSON.stringify(text)}; t.dispatchEvent(new Event('input', { bubbles: true })); document.getElementById('pace').value = '${pace}'; })()`); await sleep(250); };
  const press = async (wc) => { const before = await batchOf(wc); await js(wc, "document.getElementById('go').click()"); const nb = await wait(async () => { const x = await batchOf(wc); return x && (!before || x.id !== before.id) ? x : false; }, 15000, 100); runId = nb ? nb.id : null; return nb; };
  const finished = (wc, ms = 200000) => wait(async () => { const b = await batchOf(wc); return b && b.id === runId && b.state !== 'running' ? b : false; }, ms, 400);
  const dumpB = async (tag, wc) => { try { const w = wc || pw; const x = await batchOf(w), oo = await store(w, 'p9bn.orders'); console.log('  [dumpB ' + tag + ']', JSON.stringify(x && { id: x.id, state: x.state, owner: x.owner, upd: Math.round((Date.now() - (x.updated || 0)) / 1000) + 's ago', pause: x.pause, pauseReq: x.pauseReq, ev: (x.events || []).slice(-6).map((e) => String(e[1]).slice(0, 100)), groups: (x.groups || []).map((g) => [g.cid, g.status, g.restore, g.reopens, g.recycle]), items: (x.items || []).map((i) => [i.status, i.code, i.hb && Math.round((Date.now() - i.hb) / 1000), (i.lg || []).slice(-1).map((l) => l[1] + ':' + String(l[2]).slice(0, 60))]) }), 'orders', JSON.stringify(oo && (oo.queue || []).concat(oo.hist || []).slice(0, 3).map((o) => [o.id, o.src, o.state, o.jobId && o.jobId.slice(-4), o.apiDone]))); } catch (e) { console.log('  [dumpB failed]', String(e).slice(0, 100)); } };
  const codes = (b) => b.items.map((i) => (i.status === 'failed' || i.status === 'skipped' ? i.code : i.status));
  const likes = () => sw.clicks.filter((c) => c.kind === 'like');
  const reset = () => { sw.clicks.length = 0; sw.hits.length = 0; sw.hitLog.length = 0; sw.switches.length = 0; };
  const results = (wc) => ui(wc, '#results');
  const waitingOrder = (re, vid) => wait(async () => { const o = await store(pw, 'p9bn.orders'); const h = o && (o.queue || []).find((x) => x.state === 'waiting' && re.test(x.waitWhy || '') && (!vid || (x.links || []).some((l) => l.vid === vid))); return h || false; }, 150000, 500);
  const cancelOrder = async (o) => { const oo0 = await store(pw, 'p9bn.orders'); const open = ((oo0 && oo0.queue) || []); console.log('  [debug cancel] open orders:', JSON.stringify(open.map((x) => [x.id, x.state, x.src, (x.links || []).map((l) => l.vid), x.created]))); for (const x of open) await js(pw, `B17.request({ op: 'cancel', oid: ${JSON.stringify(x.id)} }, 8000)`).catch(() => {}); await sleep(1500); };

  // gate on, three containers: A (alice: 2 channels), B (bob: 1 channel), D (dora: no channel list)
  await ytfToggle('commentsOnly', true);
  const mk = async (name, color, acct) => { const c = await api.call('containers.create', { name, color }, ctx); await ctx.sessionFor(c.id).cookies.set({ url: 'https://www.youtube.com/', name: 'acct', value: acct, secure: true }); return c; };
  const cA = await mk('Channel A', '#e5484d', 'alice'), cB = await mk('Channel B', '#3e63dd', 'bob'), cD = await mk('Channel D', '#f5a524', 'dora');
  sw.accounts = { alice: [{ id: 'main', name: 'Alice', handle: '@alice' }, { id: 'p111', name: 'Alice Cooking', handle: '@alicecooks' }], bob: [{ id: 'main', name: 'Bob', handle: '@bob' }] };
  const saveSel = async (wc, map) => { await js(wc, `(async () => { await loadChannelCache(); sel = new Set(${JSON.stringify(Object.keys(map))}); chSel = {}; const m = ${JSON.stringify(map)}; for (const cid of Object.keys(m)) if (m[cid]) chSel[cid] = new Set(m[cid]); normalizeSel(); saveSel(); renderContainers(); })()`); await sleep(1800); };
  let pw = await popup();
  await saveSel(pw, { [cA.id]: null, [cB.id]: null, [cD.id]: null });
  await js(pw, "document.getElementById('crefresh').click()");
  const gotCh = await wait(async () => { const a = await store(pw, 'p9bn.ch.' + (await js(pw, 'pid()')) + '.' + cA.id), b = await store(pw, 'p9bn.ch.' + (await js(pw, 'pid()')) + '.' + cB.id); return a && a.ok && b && b.ok; }, 120000, 600);
  check('"Refresh channels" read A (2 channels) and B (1 channel)', !!gotCh);
  await wait(async () => !(await js(pw, '!!discovering')) && ((await store(pw, 'p9bn.disc')) || {}).state !== 'running', 240000, 400);      // 1.1.7: an order waits (up to 90 s) for a running channel reading: the test lets the reading of the last container end first
  await sleep(2500);
  pw = await popup();
  const SEL_ALL = { [cA.id]: ['main', 'p111'], [cB.id]: ['main'], [cD.id]: null };
  await saveSel(pw, SEL_ALL);
  const CKS = { aMain: 'h:@alice', aCook: 'p:p111', bMain: 'h:@bob', d: 'c:' + cD.id };

  // ================================================================================================================ LEDGER
  let b, st, sv; const L1 = link('NORMAL00101', ID.top1);
  const SKIP12 = !!process.env.E2E_SKIP12;      // debugging aid: jump straight to the API part
  s12: {
  if (SKIP12) { await js(pw, `(async () => { settings.vpn = Object.assign({}, settings.vpn || {}, { locs: [] }); await sset(K.settings, settings); })()`); sv = { vpn: { locs: [{ id: 'USA - New York', name: 'USA - New York' }, { id: 'UK - London', name: 'UK - London' }, { id: 'Japan - Tokyo', name: 'Japan - Tokyo' }] } }; break s12; }
  console.log('\n== 1. ledger: a channel is never used twice on the same comment ==');
  reset();
  await setLinks(pw, L1);
  check('plan: 1 link × 4 channels (A main, A cooking, B, D) = 4 likes', /1 link × 3 containers \(4 channels\) = 4 likes/.test(await ui(pw, '#plan')) || /4 likes/.test(await ui(pw, '#go')), [await ui(pw, '#plan'), await ui(pw, '#go')]);
  const mkS1 = trk.mark(); trk.resetMax();
  await press(pw); b = await finished(pw);
  if (!b) console.log('  [debug first run]', JSON.stringify(await js(pw, "({ msg: document.getElementById('msg').textContent, go: document.getElementById('go').disabled, orders: (document.getElementById('orders') || {}).textContent.slice(0, 400) })")), String(JSON.stringify(await store(pw, 'p9bn.orders'))).slice(0, 900), 'runId', runId, 'BATCH', String(JSON.stringify(await batchOf(pw))).slice(0, 700),
      '\n  [debug first run items]', JSON.stringify(((await batchOf(pw)) || { items: [] }).items.map((i) => [i.status, i.code, i.chid, i.tries, (i.lg || []).slice(-8).map((l) => String(l[2] || '').slice(0, 110))])).slice(0, 3500), 'events', JSON.stringify(((await batchOf(pw)) || {}).events || []).slice(0, 800), 'DISC', JSON.stringify(await store(pw, 'p9bn.disc')));
  check('first run: 4 × liked (A: two channels, B, D), one click each', !!b && b.state === 'done' && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'liked', 'liked', 'liked']) && likes().length === 4, b && [b.state, codes(b), likes().length]);
  check('TAB RULE 1.1.7.5 (UI run over 3 containers): 3 tabs, at most 3 at once (parallel wave), never 2 of one container, all closed when done', (trk.total - mkS1.total === 3 || SKIP12) && trk.max <= 3 && trk.maxPerCid <= 1 && !!(await wait(() => trk.alive().length === 0, 8000)), { total: trk.total, max: trk.max, over: trk.over, alive: trk.alive() });
  check('every item carries its canonical channel key (h:@alice, p:p111, h:@bob, c:<container>)', !!b && b.items.map((i) => i.ck).join() === [CKS.aMain, CKS.aCook, CKS.bMain, CKS.d].join(), b && b.items.map((i) => i.ck));
  await sleep(2500);
  st = await js(pw, 'B11.S.led.stats()');
  check('ledger recorded 1 comment × 4 channels (and the section header says "1 comment")', st.comments === 1 && st.pairs === 4 && /1 comment/.test(await ui(pw, '#ledsum')), st);
  const shards = await js(pw, "chrome.storage.local.get(null).then((a) => Object.keys(a).filter((k) => /^p9bn\\.led\\./.test(k)).length)");
  check('ledger lives under p9bn.led.* in chrome.storage.local (a few small shards)', shards >= 3 && shards <= 12, shards);
  reset(); sw.liked.clear();                              // the mock would let every account like again: only the ledger can stop it
  const tabsBefore = ctx.tabs.length;
  await setLinks(pw, L1); await press(pw); { const sawMsg = await wait(async () => /No unused channel is left/.test(await ui(pw, '#msg')), 60000, 400); await sleep(1500); b = sawMsg; }
  check('same link again (1.1.7: skipped WITHOUT visiting): the 4 used channels are not even planned — no click, no page load, no new tab, no batch started', !!b && sw.clicks.length === 0 && sw.hits.length === 0 && ctx.tabs.length === tabsBefore, b && [sw.clicks.length, sw.hits.length, ctx.tabs.length, tabsBefore]);
  check('the screen says "No unused channel is left for these comments." and it is not shown as a failure', /No unused channel is left for these comments/.test(await ui(pw, '#msg')) && !/failed/.test(await ui(pw, '#msg')), [await ui(pw, '#msg')]);
  // partial: another comment liked by A main only; then the same comment with all channels -> only the unused ones act
  const L2 = link('NORMAL00101', ID.top3);
  await saveSel(pw, { [cA.id]: ['main'] }); reset(); await setLinks(pw, L2); await press(pw); b = await finished(pw);
  check('comment 2 liked by A main only', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked']) && likes().length === 1, b && codes(b));
  await sleep(1500); await saveSel(pw, SEL_ALL); sw.liked.clear(); reset(); await setLinks(pw, L2); await press(pw); b = await finished(pw);
  check('comment 2 with all channels: A main is not planned (used, skipped without visiting), the other 3 like — each channel at most once per comment', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'liked', 'liked']) && likes().length === 3 && !likes().some((c) => c.chan === 'main' && c.acct === 'alice'), b && [codes(b), likes().map((c) => c.acct + '/' + c.chan)]);
  // reply ids: a reply is its own comment, any link form of it maps to the same ledger key
  await sleep(1500); await saveSel(pw, { [cA.id]: ['main'] }); sw.liked.clear(); reset();
  await setLinks(pw, link('NORMAL00101', ID.r1)); await press(pw); b = await finished(pw);
  check('reply id (PARENT.REPLY): liked once by A main (the parent comment\'s earlier like does not count for the reply)', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked']) && likes().length === 1, b && codes(b));
  await sleep(1500); sw.liked.clear(); reset();
  await setLinks(pw, `https://youtu.be/NORMAL00101?lc=${ID.r1}&si=abc123`); await press(pw); b = await wait(async () => /No unused channel is left/.test(await ui(pw, '#msg')), 60000, 400); await sleep(1000);
  check('the same reply pasted as a youtu.be link with extra parameters: recognised as the same reply -> nothing left to do, no click', !!b && sw.clicks.length === 0 && sw.hits.length === 0, [b, sw.clicks.length, sw.hits.length]);
  // ledger view / export / import / clear
  await js(pw, "document.getElementById('sec-led').open = true"); await sleep(300);
  await js(pw, `(() => { const i = document.querySelector('#ledbody input[type=search]'); i.value = 'REPLYr1'; i.dispatchEvent(new Event('input', { bubbles: true })); })()`); await sleep(300);
  check('ledger view: searching a comment id lists its entry with the channel and "liked <date>"', /reply/.test(await ui(pw, '#ledrows')) && /liked 20\d\d-\d\d-\d\d/.test(await ui(pw, '#ledrows')) && /Alice/.test(await ui(pw, '#ledrows')), await ui(pw, '#ledrows'));
  const exp = JSON.parse(await js(pw, 'B11.S.led.exportJson()'));
  check('export JSON: bean ledger v1 with every [video, comment, channelKey, kind, time]', exp.bean === 'ledger' && exp.entries.length === 4 + 1 + 3 + 1 + 0 && exp.entries.every((e) => e.length === 5), [exp.entries.length]);
  { // 1.1.6: ONE comment shown -> "Clear all N marks for this comment" removes that comment's marks (and its "like sent" markers), nothing else
    const n0 = await js(pw, 'B11.S.led.stats().comments'), cnt0 = await js(pw, `B11.S.led.count('NORMAL00101', ${JSON.stringify(ID.r1)})`);
    const hasBtn = await js(pw, "!!document.getElementById('ledclearcomment')"), lbl = await js(pw, "(document.getElementById('ledclearcomment') || {}).textContent || ''");
    await click2(pw, '#ledclearcomment'); await sleep(900);
    const n1 = await js(pw, 'B11.S.led.stats().comments'), cnt1 = await js(pw, `B11.S.led.count('NORMAL00101', ${JSON.stringify(ID.r1)})`);
    check('1.1.6 ledger: with one comment shown the button "Clear all N marks for this comment" is offered; two clicks remove exactly that comment (others stay)', hasBtn && /Clear all \d+ mark/.test(lbl) && cnt0 >= 1 && cnt1 === 0 && n1 === n0 - 1, [hasBtn, lbl, cnt0, cnt1, n0, n1]);
  }
  await click2(pw, '#ledclear'); await sleep(800);
  check('"Clear ledger" (two clicks) empties it', (await js(pw, 'B11.S.led.stats().comments')) === 0, await js(pw, 'B11.S.led.stats()'));
  await click(pw, '#ledimp'); // (the import toggle is the 2nd button; use JS)
  await js(pw, `(() => { for (const x of document.querySelectorAll('#ledbody .btn')) if (x.textContent === 'Import…') x.click(); document.getElementById('ledimp').value = ${JSON.stringify(JSON.stringify(exp))}; })()`); await click(pw, '#ledimpgo'); await sleep(1000);
  st = await js(pw, 'B11.S.led.stats()');
  check('import of the export restores every entry (a channel is again never reused)', st.comments === 3 && st.pairs === 9, st);
  check('bad import is refused with a message', await (async () => { await js(pw, `(() => { for (const x of document.querySelectorAll('#ledbody .btn')) if (x.textContent === 'Import…') x.click(); document.getElementById('ledimp').value = '{"nope":1}'; })()`); await click(pw, '#ledimpgo'); await sleep(300); return /not a Bean ledger export/.test(await ui(pw, '#ledbody')); })());

  // ================================================================================================================ VPN
  console.log('\n== 2. VPN rotation: next saved location before every like ==');
  check('no locations saved: nothing so far touched ExpressVPN (1.0.0 behaviour)', connects().length === 0, connects());
  await js(pw, "document.getElementById('sec-vpn').open = true"); await sleep(1200);
  check('VPN section: ExpressVPN ready (mock) and the locations are listed', /ExpressVPN is ready/.test(await ui(pw, '#vpnbody')) && (await js(pw, "document.querySelectorAll('#vlist .vrow').length")) >= 10, await ui(pw, '#vpnbody'));
  await js(pw, `(() => { const i = document.querySelector('#vpnbody input[type=search]'); i.value = 'Germany'; i.dispatchEvent(new Event('input', { bubbles: true })); })()`); await sleep(250);
  check('filter narrows the list', (await js(pw, "document.querySelectorAll('#vlist .vrow').length")) === 1, await ui(pw, '#vlist'));
  await js(pw, `(() => { const i = document.querySelector('#vpnbody input[type=search]'); i.value = ''; i.dispatchEvent(new Event('input', { bubbles: true })); })()`); await sleep(250);
  const LOCS = ['USA - New York', 'UK - London', 'Japan - Tokyo'];
  await js(pw, `(() => { for (const r of document.querySelectorAll('#vlist .vrow')) if (${JSON.stringify(LOCS)}.includes(r.textContent.trim())) r.querySelector('input').click(); })()`); await sleep(300);
  await click(pw, '#vsave'); await sleep(1200);
  sv = await store(pw, 'p9bn.settings');
  check('Save locations: 3 locations stored in order of the list; the header shows "3 saved"', sv.vpn && sv.vpn.locs.length === 3 && /3 saved/.test(await ui(pw, '#vpnsum')), sv.vpn);
  // test-only fast timeouts (a real ExpressVPN reconnect takes seconds; these keep the e2e short)
  await js(pw, `(async () => { settings.vpn = Object.assign({}, settings.vpn, { t: { connectMs: 6000, ipMs: 4000, pollMs: 250, settleMs: 0, attempts: 2 } }); await sset(K.settings, settings); S = null; })().catch(() => {})`).catch(() => {}); await sleep(800);
  await saveSel(pw, { [cB.id]: ['main'] });
  process.env.P9_MOCK_DELAY_MS = '1200';
  reset(); const regions0 = locsOrder(sv.vpn.locs);
  const V1 = [link('NORMAL00201', ID.top1), link('NORMAL00202', ID.top1), link('NORMAL00203', ID.top1), link('NORMAL00204', ID.top1)].slice(0, process.env.E11_FAST ? 1 : 4);
  sw.delay.watch = 5000; sw.reqLog = []; connT.length = 0;        // 1.1.2: every /watch takes 5 s: a VPN switch during a load would be caught
  await setLinks(pw, V1.join('\n')); await press(pw); b = await finished(pw, 300000); sw.delay.watch = 0; if (!b) await dumpB('V1');
  if (process.env.E11_BENCH) {      // 1.1.7.1 speed measurement: per-item time of the 4-like VPN run (the same flow on any tree), the item log with times, the waits the run itself logged
    const t0 = b ? b.created : 0; let prev = t0; const per = [];
    for (const it of (b ? b.items : [])) { per.push(Math.round(((it.at || prev) - prev) / 100) / 10); prev = it.at || prev; }
    console.log('BENCH per-item seconds', JSON.stringify(per), 'total', b ? Math.round(((b.items[b.items.length - 1].at || t0) - t0) / 100) / 10 : null, 'codes', b && codes(b).join());
    for (const [i, it] of (b ? b.items : []).entries()) console.log('BENCH item ' + (i + 1) + ' log', (it.lg || []).map((l) => ((l[0] - t0) / 1000).toFixed(1) + ' ' + l[1] + ' ' + String(l[2]).slice(0, 70)).join(' | '));
    console.log('BENCH events', JSON.stringify((b ? b.events || [] : []).map((e) => ((e[0] - t0) / 1000).toFixed(1) + ' ' + String(e[1]).slice(0, 90))));
    try { py.kill(); } catch (_) { /* gone */ } geo.close(); await srv.close(); console.log('RESULT(bench)'); process.exit(0);
  }
  const exp3 = [regions0[0], regions0[1], regions0[2], regions0[0]];
  check('4 likes, 4 rotations: the locations are used in order and wrap around (a ctl "connect" before each like)', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'liked', 'liked', 'liked']) && JSON.stringify(connects()) === JSON.stringify(exp3), b && [codes(b), connects()]);
  check('each item records the location it liked through, with a verified address change', !!b && b.items.map((i) => i.vpn && i.vpn.location).join() === exp3.join() && b.items.every((i) => i.vpn && i.vpn.ipChanged === true), b && b.items.map((i) => i.vpn));
  { const win = (sw.reqLog || []).filter((w) => w.p === '/watch' || /^\/signin/.test(w.p) || w.p === '/getAccountSwitcherEndpoint');
    const bad = connT.filter((ct) => win.some((w) => w.t0 + 200 < ct && ct < w.t1 - 200));
    check('1.1.2: the VPN is NEVER switched while a page / redirect / switcher request is in flight (' + connT.length + ' switches, ' + win.length + ' YouTube requests)', connT.length >= 4 && bad.length === 0, { connects: connT.length, mid: bad.map((ct) => ct % 100000), windows: win.slice(0, 6).map((w) => [w.p, w.t0 % 100000, w.t1 % 100000]) }); }
  const lk = likes();
  check('every like happened while the exit address was the new location\'s (the last lookup before each click names the item\'s location)', lk.length === 4 && lk.every((c, i) => { const g = geoLog.filter((x) => x.t < c.t).pop(); return g && g.region === exp3[i]; }), lk.map((c, i) => [i, (geoLog.filter((x) => x.t < c.t).pop() || {}).region]));
  check('result rows say "via <location>"', exp3.every((l) => new RegExp('via ' + l).test(''))  || /via USA - New York/.test(await results(pw)), await results(pw));
  // 1.1.5: the in-tab VPN request was not answered at first (simulated: Bean's window ignores every request for 26 s) -> the tab asks again, the switch happens, the like is NOT skipped as vpn-failed (1.1.4 gave up after 15 s)
  if (!process.env.E11_HANGONLY) { reset(); connT.length = 0; sw.reqLog = []; sw.delay.watch = 0; const V2 = [link('NORMAL00211', ID.top1), link('NORMAL00212', ID.top1), link('NORMAL00213', ID.top1)];
    await setLinks(pw, V2.join('\n')); await js(pw, 'B11.S.dropVreqUntil = Date.now() + 26000'); await press(pw); b = await finished(pw, 300000); await js(pw, 'B11.S.dropVreqUntil = 0').catch(() => {});
    if (!b || JSON.stringify(codes(b)) !== JSON.stringify(['liked', 'liked', 'liked'])) console.log('  [debug vpn26]', JSON.stringify({ state: b && b.state, ev: b && b.events, items: b && b.items.map((i) => [i.status, i.code, i.msg, (i.lg || []).slice(-8)]), groups: b && b.groups }).slice(0, 3500));
    check('1.1.5: VPN request unanswered for 26 s: re-sent, answered late, all 3 likes done (no vpn-failed), every item through a location', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'liked', 'liked']) && b.items.every((i) => i.vpn && i.vpn.location), b && [codes(b), b.items.map((i) => i.vpn)]);
    if (b && !/asking again/.test(JSON.stringify(b.events || []) + JSON.stringify(b.items.map((i) => i.lg || [])))) console.log('  [asked-again dbg]', JSON.stringify(b.items.map((i) => (i.lg || []).map((l) => l[1] + ':' + String(l[2]).slice(0, 90)))).slice(0, 2500));
    check('1.1.5: the run log says the tab asked again', !!b && /asking again/.test(JSON.stringify(b.events || []) + JSON.stringify(b.items.map((i) => i.lg || []))), b && b.events); }

  // 1.1.7 (Oluchi's job_7JCK / run 7ln17k8fmvzclqr2): ExpressVPN drops by itself right after a tab was opened / while a page loads, and the first reads of the run record bring back the PREVIOUS run
  const dbgRun = async (tag) => { try { const x = await batchOf(pw); console.log('  [debug run ' + tag + ']', JSON.stringify(x && { state: x.state, ev: x.events, groups: x.groups, items: x.items.map((i) => [i.status, i.code, i.msg, (i.lg || []).slice(-6)]), upd: Date.now() - x.updated }).slice(0, 4000), 'hits', sw.hitLog.map((h) => [h.t % 100000, h.search && h.search.slice(0, 40)]).slice(0, 6)); } catch (e) { console.log('dbgRun failed', String(e)); } };
  const dropVpn = (ms) => { try { const st = JSON.parse(fs.readFileSync(stateFile, 'utf8')); st.pending = st.region || st.pending || 'USA - New York'; st.state = 'Connecting'; st.until = Date.now() + ms; fs.writeFileSync(stateFile, JSON.stringify(st)); return Date.now() + ms; } catch (_) { return 0; } };
  const vlastAt = () => js(pw, 'B11.S.vlast && B11.S.vlast.at || 0').catch(() => 0);
  // 1.1.7.1 (real run q8ojt7phmw0iecjy #4/#8): the messaging between a tab and Bean's window is a lossy channel (Panel 9 mirrors storage between sessions). (1) the pre-click VPN confirmation comes from the owner page's live sample (no request, nothing to lose);
  // (2) with no sample AND the check never answered the tab asks 3 times, then hands the container back (fresh tab, same location, nothing clicked); (3) a step that never settles after the confirmation is recycled by the runner (45 s of no progress while the heartbeat beats);
  // (4) a step inside the pre-click sequence that hangs is bounded by the tab itself.
  if (!process.env.E11_HANGONLY) { reset(); connT.length = 0; sw.reqLog = []; sw.delay.watch = 0; const t0 = Date.now();
    await setLinks(pw, [link('NORMAL00261', ID.top1), link('NORMAL00262', ID.top1)].join('\n')); await press(pw); b = await finished(pw, 300000);
    const lg = b ? JSON.stringify(b.items.map((i) => i.lg || [])) : '';
    check('1.1.7.1 (1): normal run: the pre-click confirmation comes from the live sample (no request/answer round trip), both liked, one click each', !!b && codes(b).join() === 'liked,liked' && likes().length === 2 && /confirmed right before the click from the live sample/.test(lg), b && [codes(b), likes().length, lg.slice(0, 300)]); }
  if (!process.env.E11_HANGONLY) { reset(); connT.length = 0; sw.reqLog = []; sw.delay.watch = 0;
    await setLinks(pw, [link('NORMAL00263', ID.top1), link('NORMAL00264', ID.top1), link('NORMAL00265', ID.top1)].join('\n')); await js(pw, 'B11.S.noVok = true; B11.S.dropCheckUntil = Date.now() + 30000'); await press(pw); b = await finished(pw, 420000); await js(pw, 'B11.S.noVok = false; B11.S.dropCheckUntil = 0').catch(() => {});
    const lg = b ? JSON.stringify(b.items.map((i) => i.lg || [])) + JSON.stringify(b.events || []) : '';
    if (!b || codes(b).join() !== 'liked,liked,liked') await dbgRun('lostcheck');
    check('1.1.7.1 (2): the pre-click VPN check is never answered for 30 s (no live sample either): 3 tries, then a fresh tab, nothing clicked without it: all 3 liked, ONE click each', !!b && codes(b).join() === 'liked,liked,liked' && likes().length === 3 && /got no answer \(try 3 of 3\)/.test(lg) && /reopen \d of 2/.test(lg), b && [codes(b), likes().length, lg.slice(0, 400)]);
    check('1.1.7.1 (2): the fresh tab kept the item\'s VPN location: one connection per like, none extra', connT.length <= 4, connT.length); }
  if (!process.env.E11_HANGONLY) { reset(); connT.length = 0; sw.reqLog = []; sw.delay.watch = 0; const t0 = Date.now();
    await setLinks(pw, [link('HANGPRE_001', ID.top1), link('NORMAL00266', ID.top1)].join('\n')); await press(pw); b = await finished(pw, 420000); const dt = Date.now() - t0;
    const lg = b ? JSON.stringify(b.items.map((i) => i.lg || [])) : '';
    if (!b || codes(b).join() !== 'liked,liked') await dbgRun('hangpre');
    check('1.1.7.1 (3): a step that never settles right after the VPN confirmation (heartbeat still beating): the runner recycles the tab after ~45 s (not 4 min), the like is made once in the fresh tab', !!b && codes(b).join() === 'liked,liked' && likes().length === 2 && dt < 200000 && /no progress for \d+ s/.test(lg), b && [codes(b), likes().length, dt, lg.slice(0, 500)]); }
  { reset(); connT.length = 0; sw.reqLog = []; sw.delay.watch = 0; const t0 = Date.now();
    await setLinks(pw, [link('HANGREC_001', ID.top1)].join('\n')); await press(pw); b = await finished(pw, 420000); const dt = Date.now() - t0;
    const lg = b ? JSON.stringify(b.items.map((i) => i.lg || [])) : '';
    if (!b || codes(b).join() !== 'liked') await dbgRun('hangrec');
    if (b) console.log('  [4 hangrec log]', JSON.stringify(b.items.map((i) => (i.lg || []).map((l) => ((l[0] - b.created) / 1000).toFixed(1) + ' ' + l[1] + ':' + String(l[2]).slice(0, 110)))), JSON.stringify((b.events || []).map((e) => ((e[0] - b.created) / 1000).toFixed(1) + ' ' + String(e[1]).slice(0, 110))));
    check('1.1.7.1 (4): the identity re-check right before the click hangs: bounded (the runner 30 s no-progress watchdog, or the own 40 s bound of the tab, whichever is first), the container is handed back, the like is made once in the fresh tab', !!b && codes(b).join() === 'liked' && likes().length === 1 && /did not finish in 40 s|no progress for \d+ s/.test(lg) && /kept the location|nothing was clicked/.test(lg) && dt < 150000, b && [codes(b), likes().length, dt, lg.slice(0, 500)]); }

  // 1.1.7.1 (real run zo8n4jxzmw0n9e3l): (a) the owner did the VPN step but its final answer never reached the tab: never "vpn-failed" for a lost answer; (f) a storage reply lost inside the tab must not stall the item flow;
  // (e) a verify page that goes silent after the click: a fresh tab only VERIFIES within ~1-2 minutes (liked, not liked-unverified, never a second click)
  if (!process.env.E11_HANGONLY) { reset(); connT.length = 0; sw.reqLog = []; sw.delay.watch = 0; const t0 = Date.now();
    await setLinks(pw, [link('NORMAL00271', ID.top1), link('NORMAL00272', ID.top1)].join('\n')); await js(pw, 'B11.S.dropDoneUntil = Date.now() + 600000'); await press(pw); b = await finished(pw, 420000); await js(pw, 'B11.S.dropDoneUntil = 0').catch(() => {}); const dt = Date.now() - t0;
    const lg = b ? JSON.stringify(b.items.map((i) => i.lg || [])) : '';
    if (!b || codes(b).join() !== 'liked,liked') await dbgRun('nodone');
    check('1.1.7.1 (a): the owner\'s final VPN answer is LOST (the rotation itself worked): no "vpn-failed" - the live sample shows it connected after the request, taken as done; both liked, one click each, far under 4 minutes', !!b && codes(b).join() === 'liked,liked' && likes().length === 2 && !/vpn-failed|longer than 4 minutes/.test(lg + JSON.stringify(b.events || [])) && /final answer did not arrive/.test(lg) && dt < 240000, b && [codes(b), likes().length, dt, lg.slice(0, 400)]); }
  if (!process.env.E11_HANGONLY) { reset(); connT.length = 0; sw.reqLog = []; sw.delay.watch = 0; const t0 = Date.now();
    await setLinks(pw, [link('LOSEONE_001', ID.top1), link('NORMAL00273', ID.top1)].join('\n')); await press(pw); b = await finished(pw, 420000); const dt = Date.now() - t0;
    const lg = b ? JSON.stringify(b.items.map((i) => i.lg || [])) : '';
    if (!b || codes(b).join() !== 'liked,liked') await dbgRun('loseone');
    check('1.1.7.1 (f): the reply of ONE storage call is lost inside the tab: bounded (7 s) and repeated, the item goes on in the same tab - both liked, one click each, no reopen', !!b && codes(b).join() === 'liked,liked' && likes().length === 2 && /reply of the next storage call is lost once/.test(lg) && !/reopen \d of 2/.test(lg) && dt < 200000, b && [codes(b), likes().length, dt, lg.slice(0, 400)]); }
  if (!process.env.E11_HANGONLY) { reset(); connT.length = 0; sw.reqLog = []; sw.delay.watch = 0; const t0 = Date.now();
    await setLinks(pw, [link('LOSEALL_001', ID.top1), link('NORMAL00274', ID.top1)].join('\n')); await press(pw); b = await finished(pw, 420000); const dt = Date.now() - t0;
    const lg = b ? JSON.stringify(b.items.map((i) => i.lg || [])) : '';
    if (!b || codes(b).join() !== 'liked,liked') await dbgRun('loseall');
    check('1.1.7.1 (f): a storage call that gets NO reply 3 times fails as a step-timeout instead of waiting for ever (callers that tolerate it carry on, the others hand the container back): both liked, one click each, no 4-minute stall', !!b && codes(b).join() === 'liked,liked' && likes().length === 2 && /replies of the next storage call are lost 3 times/.test(lg) && dt < 240000, b && [codes(b), likes().length, dt, lg.slice(0, 500)]); }
  { reset(); connT.length = 0; sw.reqLog = []; sw.delay.watch = 0; const t0 = Date.now();
    await setLinks(pw, [link('HANGVER_001', ID.top1)].join('\n')); await press(pw); b = await finished(pw, 420000); const dt = Date.now() - t0;
    const lg = b ? JSON.stringify(b.items.map((i) => i.lg || [])) : '';
    console.log('  [e] watch-page loads of HANGVER_001:', sw.hitLog.filter((h) => /HANGVER/.test(h.search || '')).map((h) => [h.t % 100000, (h.search || '').slice(0, 60)]), 'log:', (b ? b.items.map((i) => (i.lg || []).map((l) => l[1] + ':' + String(l[2]).slice(0, 50))) : ''));
    if (!b || codes(b).join() !== 'liked') await dbgRun('hangver');
    check('1.1.7.1 (e): the verify page after the click goes silent: a fresh tab only VERIFIES it - result "liked" (not liked-unverified, not already), ONE click, within 3 minutes', !!b && codes(b).join() === 'liked' && likes().length === 1 && /never settles/.test(lg) && /stalled after the click|no progress for \d+ s|only VERIFIES|Like sent - not confirmed|not confirmed: no report from the tab/.test(lg) && dt < 180000, b && [codes(b), likes().length, dt, lg.slice(-1500)]); }

  if (process.env.E11_STOP_AFTER_NEW) { closePopups(); try { py.kill(); } catch (_) {} console.log(`\nRESULT (partial new): ${passes} passed, ${failures} failed`); process.exit(failures ? 1 : 0); }
  { // (a) a drop right after Bean's rotation finished and BEFORE the container's tab is opened: the tab is not opened until ExpressVPN is connected again + a ~3 s settle
    await cancelOrder(); reset(); sw.hitLog.length = 0; const l0 = await vlastAt();
    await setLinks(pw, [link('NORMAL00231', ID.top1), link('NORMAL00232', ID.top1)].join('\n')); await press(pw);
    const t1 = await wait(async () => (await vlastAt()) > l0, 60000, 30); const endAt = t1 ? dropVpn(14000) : 0; const hitsAtDrop = sw.hitLog.length;
    b = await finished(pw, 300000); if (!b) await dbgRun('A');
    const firstHit = (sw.hitLog[0] || {}).t || 0;
    check('1.1.7 VPN drop right after the rotation, before the tab opens: no page was requested while ExpressVPN was down (first request came after it was back + settle)', !!t1 && !!b && hitsAtDrop === 0 && firstHit >= endAt + 2300, [t1, hitsAtDrop, firstHit - endAt]);
    check('1.1.7 …the container is served promptly once the VPN is back (the first page was requested within 60 s of it, not after an open grace of minutes)', firstHit > 0 && firstHit < endAt + 60000, [firstHit - endAt]);
    check('1.1.7 …and the run still finishes: both liked, nothing skipped, the log says it waited for ExpressVPN', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'liked']) && /waited \d+ s for ExpressVPN/.test(JSON.stringify(b.events || []) + JSON.stringify(b.items.map((i) => i.lg || []))), b && [codes(b), b.events]); }
  { // (b) a drop right after the rotation for the NEXT item (the tab sits idle in the pace gap): the tab does not navigate until ExpressVPN is back + settle
    await cancelOrder(); reset(); sw.hitLog.length = 0; let l0 = await vlastAt();
    await setLinks(pw, [link('NORMAL00233', ID.top1), link('NORMAL00234', ID.top1)].join('\n')); await press(pw);
    const t1 = await wait(async () => (await vlastAt()) > l0, 60000, 30); l0 = await vlastAt();                 // rotation before the first tab
    const t2 = await wait(async () => (await vlastAt()) > l0 && sw.hitLog.length >= 1, 120000, 30); const endAt = t2 ? dropVpn(12000) : 0; const hitsAtDrop = sw.hitLog.length;      // rotation for the 2nd item (in the pace gap of the open tab)
    b = await finished(pw, 300000); if (!b) await dbgRun('B');
    const second = (sw.hitLog.find((h, i) => i >= 1 && /NORMAL00234/.test(h.search)) || {}).t || 0;
    check('1.1.7 VPN drop right after the in-tab rotation for the next item: the tab does not navigate while ExpressVPN is down (the next page was requested only after it was back + settle)', !!t1 && !!t2 && !!b && second >= endAt + 2300, [t1, t2, second - endAt, hitsAtDrop]);
    check('1.1.7 …both liked, the second after the VPN came back', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'liked']), b && [codes(b), b.events]); }
  { // (c) the first reads of the run record (rotation, open) return the PREVIOUS run's record, state "done": it must not read as "the run is over" (it skipped item 1 two seconds after the start before)
    await cancelOrder(); reset(); connT.length = 0;
    await setLinks(pw, [link('NORMAL00235', ID.top1), link('NORMAL00236', ID.top1)].join('\n'));
    await js(pw, `(() => { window.__stale = 10; const o = chrome.storage.local.get.bind(chrome.storage.local); chrome.storage.local.get = function (k, cb) { const kk = typeof k === 'string' ? k : (k && typeof k === 'object' && !Array.isArray(k) ? Object.keys(k)[0] : null); if (window.__stale > 0 && kk === 'p9bn.batch' && /popup\.js|ext11\.js|ext17\.js/.test(new Error().stack)) { window.__stale--; const r = { 'p9bn.batch': { id: 'OLDRUN0000000000', state: 'done', owner: 'popup', created: 1, updated: 2, items: [], groups: [], rev: 99 } }; return cb ? (cb(r), undefined) : Promise.resolve(r); } return o(k, cb); }; })()`);
    await press(pw); b = await finished(pw, 300000); if (!b) await dumpB('stale'); const left = await js(pw, 'window.__stale'); await js(pw, 'window.__stale = 0');
    check('1.1.7 stale PREVIOUS-run record on the first reads (' + (10 - left) + ' served): nothing is skipped as "stopped" / "the run is over", both liked, each through a location', !!b && left < 10 && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'liked']) && b.items.every((i) => i.vpn && i.vpn.location), b && [left, codes(b), b.items.map((i) => [i.code, i.msg])]); }
  if (process.env.E11_STOP_AFTER_STALE) { closePopups(); try { py.kill(); } catch (_) {} console.log(`\nRESULT (partial): ${passes} passed, ${failures} failed`); process.exit(failures ? 1 : 0); }
  // stuck: nothing is liked, no wrong address
  process.env.P9_MOCK_STUCK = 'all'; delete process.env.P9_MOCK_DELAY_MS; reset(); const c0 = connects().length;
  await setLinks(pw, [link('NORMAL00205', ID.top1), link('NORMAL00206', ID.top1)].join('\n')); await press(pw); b = await finished(pw, 240000);
  check('stuck on "connecting": each like is skipped as "vpn-stuck", NOTHING is clicked, the run goes on to the next item', !!b && b.state === 'done' && JSON.stringify(codes(b)) === JSON.stringify(['vpn-stuck', 'vpn-stuck']) && sw.clicks.length === 0, b && [b.state, codes(b), sw.clicks.length]);
  check('retries are bounded: at most 2 connects per like', connects().length - c0 <= 4 && connects().length - c0 >= 2, connects().length - c0);
  check('popup says it clearly', /VPN stayed on “connecting”/.test(await results(pw)), await results(pw)); delete process.env.P9_MOCK_STUCK;
  // CLI unavailable: the run does not start
  await cancelOrder();      // 1.1.7: the "vpn-stuck" order above waits in the queue for a retry: take every open order out before the next test
  process.env.P9_MOCK_MODE = 'admin'; reset(); const before = await batchOf(pw);
  await setLinks(pw, link('NORMAL00207', ID.top1)); await js(pw, "document.getElementById('go').click()");
  const wo1 = await waitingOrder(/administrator/i, 'NORMAL00207');
  const after = await batchOf(pw);
  check('ExpressVPN needs admin (1.1.7: the order WAITS in the queue and says why): no run starts, nothing is clicked, the order reads "administrator"', !!wo1 && (!after || !before || after.id === before.id) && sw.clicks.length === 0, [wo1 && wo1.waitWhy, await ui(pw, '#msg'), sw.clicks.length]);
  await cancelOrder(wo1);      // a waiting order holds the queue and would run once ExpressVPN works again: take it out
  process.env.P9_MOCK_MODE = ''; delete process.env.P9_MOCK_MODE;
  // bypassed container: warned and recorded
  ctx.data.updateContainer(cB.id, { bypass: true }); await sleep(600);
  await js(pw, 'S_reset = 0; B11.S.vp = null;'); pw = await popup(); await js(pw, "document.getElementById('sec-vpn').open = true"); await sleep(1500);
  check('VPN section warns about a ticked container that bypasses the VPN', /do not follow ExpressVPN/.test(await ui(pw, '#vpnbody')) && /Channel B \(Outside VPN\)/.test(await ui(pw, '#vpnbody')), await ui(pw, '#vpnbody'));
  reset(); const c1 = connects().length;
  await setLinks(pw, link('NORMAL00208', ID.top1)); const tB0 = Date.now(); await press(pw); b = await finished(pw, 600000); console.log('  [debug bypass elapsed s]', Math.round((Date.now() - tB0) / 1000)); if (!b || Date.now() - tB0 > 300000) await dbgRun('bypass');      // 1.1.7: the page cannot load here, so its tab never answers: Bean replaces it in a fresh tab up to 3 times before it gives up ("tab-lost")
  check('bypassed container: NO location switch, flagged (batch.vpn.warn + item.vpnSkip), and the summary repeats the warning (the test build has no Direct helper, so the page itself cannot load here)', !!b && ['liked', 'interrupted', 'load-failed', 'not-started', 'tab-lost'].includes(codes(b)[0]) && connects().length === c1 && b.items[0].vpnSkip === true && b.vpn.warn.length === 1 && /Outside VPN/.test(b.vpn.warn[0]) && /Outside VPN/.test(await ui(pw, '#msg')), b && [codes(b), b.vpn, connects().length - c1]);
  await cancelOrder();      // the order of the unloadable page may still be retried by the dispatcher: take it out of the queue
  await js(pw, "document.getElementById('sec-vpn').open = true"); await js(pw, "(() => { const c = document.getElementById('vskip'); c.click(); })()"); await sleep(1000);
  reset();
  await setLinks(pw, link('NORMAL00209', ID.top1)); await press(pw); b = await finished(pw, 60000);
  check('"Skip containers that bypass the VPN": the item is skipped as vpn-bypass, nothing clicked', !!b && JSON.stringify(codes(b)) === JSON.stringify(['vpn-bypass']) && sw.clicks.length === 0, b && codes(b));
  ctx.data.updateContainer(cB.id, { bypass: false });
  try { await ctx.sessionFor(cB.id).setProxy({ mode: 'direct' }); } catch (e) {}      // the test build has no Direct helper: the bypass setting left this container's session on a dead proxy; put it back like a real un-bypass would
  await sleep(500);
  // ---- 2b. exact-id rule (Panel 9 2.3.10): locations stored in a non-exact form are migrated to exact ids or dropped (with a note); Bean never sends anything else to connect
  console.log('\n== 2b. saved locations in a non-exact form (old labels, case/space variants, smart-location) ==');
  await js(pw, "(async () => { settings.vpn = Object.assign({}, settings.vpn, { skipBypass: false, note: '', locs: [{ id: 'smart-location', name: 'Smart Location' }, { id: 'japan - tokyo', name: 'Japan - Tokyo' }, 'UK - London ', { id: 'Atlantis', name: 'Atlantis' }] }); await sset(K.settings, settings); await sset('p9bn.vpnptr', 0); })()"); await sleep(600);
  reset(); const c2 = connects().length;
  await setLinks(pw, link('NORMAL00210', ID.top1)); await press(pw); b = await finished(pw, 120000);
  const sv2 = await store(pw, 'p9bn.settings'), cons2 = connects().slice(c2);
  check('non-exact saved values: migrated to the exact ids (Japan - Tokyo, UK - London), smart-location and Atlantis dropped', !!sv2.vpn && JSON.stringify(sv2.vpn.locs.map((x) => x.id)) === JSON.stringify(['Japan - Tokyo', 'UK - London']), sv2.vpn);
  check('the run used the migrated location and Panel 9 accepted it (exact id sent, nothing else)', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked']) && JSON.stringify(cons2) === JSON.stringify(['Japan - Tokyo']) && cons2.every((l) => !/smart/i.test(l)), b && [codes(b), cons2]);
  check('a clear note says what changed (updated to exact ids; removed locations named) and is shown in the VPN section', /updated to ExpressVPN's exact location id/.test((sv2.vpn || {}).note || '') && /Atlantis/.test((sv2.vpn || {}).note || '') && /removed/.test((sv2.vpn || {}).note || ''), (sv2.vpn || {}).note);
  pw = await popup(); await js(pw, "document.getElementById('sec-vpn').open = true"); await sleep(1500);
  check('the VPN section shows that note', /exact location id/.test(await ui(pw, '#vnote')), await ui(pw, '#vpnbody'));
  // every saved location unusable: the run refuses to start (never a silent run from the user's own connection)
  await js(pw, "(async () => { settings.vpn = Object.assign({}, settings.vpn, { note: '', locs: [{ id: 'smart-location', name: 'Smart Location' }, { id: 'smart', name: 'Smart' }] }); await sset(K.settings, settings); })()"); await sleep(500);
  reset(); const c3 = connects().length, before3 = await batchOf(pw);
  await setLinks(pw, link('NORMAL00241', ID.top1)); await js(pw, "document.getElementById('go').click()");
  const wo3 = await waitingOrder(/none of the saved locations/, 'NORMAL00241');
  const after3 = await batchOf(pw);
  check('only smart / non-listed locations saved: the order WAITS in the queue (no run, no connect, no click) and the reason is shown', !!wo3 && (!after3 || !before3 || after3.id === before3.id) && connects().length === c3 && sw.clicks.length === 0, [wo3 && wo3.waitWhy, connects().length - c3, sw.clicks.length]);
  await cancelOrder(wo3);
  check('the Panel 9 mock CLI was never asked to connect to anything but an exact listed location (no smart…, no label variants)', connects().every((l) => /^(USA - New York|UK - London|Japan - Tokyo|Germany - Frankfurt - 1|Country \d+ - City \d+|Hong Kong|Nigeria|South Africa|USA - Los Angeles|The Netherlands - Amsterdam)$/.test(l)), connects());
  await js(pw, `(async () => { settings.vpn = Object.assign({}, settings.vpn, { note: '', locs: ${JSON.stringify(sv.vpn.locs)} }); await sset(K.settings, settings); await sset('p9bn.vpnptr', 0); })()`); await sleep(500);
  // keep VPN saved for the API part later; skip-bypass off again
  await js(pw, "(() => { const c = document.getElementById('vskip'); if (c && c.checked) c.click(); })()"); await sleep(800);

  }
  // ================================================================================================================ 1.1.1 per-container refresh
  console.log('\n== 2c. per-container refresh (↻ on a container row): reads ONLY that container, ticked or not ==');
  {
    pw = await popup(); await saveSel(pw, { [cA.id]: ['main'] });                 // A: main only; B and D are NOT ticked
    const PID = await js(pw, 'pid()'), rec = (cid) => store(pw, 'p9bn.ch.' + PID + '.' + cid);
    const atOf = async () => ({ a: ((await rec(cA.id)) || {}).at || 0, b: ((await rec(cB.id)) || {}).at || 0, d: ((await rec(cD.id)) || {}).at || 0 });
    const selOf = async () => JSON.parse(await js(pw, "JSON.stringify({ sel: [...sel], chSel: Object.fromEntries(Object.entries(chSel).map(([k, v]) => [k, [...v]])) })"));
    const done = () => wait(async () => !(await js(pw, '!!discovering')) , 150000, 300);
    const discTabs = new Set(); let sampling = true; const sampler = (async () => { while (sampling) { try { const d = await store(pw, 'p9bn.disc'); if (d && d.tab != null) discTabs.add(d.tab); } catch (_) { /* popup gone */ } await sleep(120); } })();
    check('every container row has a ↻ button (and "Refresh channels" is still there)', (await js(pw, "document.querySelectorAll('#clist .crow .rf').length")) >= 3 && !!(await js(pw, "!!document.getElementById('crefresh')")), await js(pw, "document.querySelectorAll('#clist .crow .rf').length"));
    const t0at = await atOf(), mk0 = trk.mark(); trk.resetMax(); const sel0 = await selOf();
    check('before: A is ticked (main only), B and D are not ticked', JSON.stringify(sel0.sel) === JSON.stringify([cA.id]) && JSON.stringify(sel0.chSel[cA.id]) === '["main"]', sel0);
    await click(pw, `.rf[data-cid="${cB.id}"]`);                                   // B is NOT ticked
    const midState = await wait(async () => { const r = await js(pw, `(() => ({ busy: !!discovering, off: [...document.querySelectorAll('#clist .rf')].every((b) => b.disabled), refOff: document.getElementById('crefresh').disabled, st: (document.querySelector('.crow[data-cid="${cB.id}"] .ct') || {}).textContent, spin: !!document.querySelector('.crow[data-cid="${cB.id}"] .rf.spin'), note: (document.getElementById('cnote') || {}).textContent }))()`); return r.busy ? r : false; }, 8000, 60);
    check('while reading: ALL ↻ buttons and "Refresh channels" are disabled, B\'s row says "reading…" and spins, the note names B', !!midState && midState.off && midState.refOff && /reading/.test(midState.st) && midState.spin && /Channel B/.test(midState.note), midState);
    await js(pw, `refreshOne(${JSON.stringify(cA.id)})`); await sleep(300);
    check('a second reading cannot start while one runs (refused, with a message)', /already being read/.test(await ui(pw, '#msg')) || /Channels are already/.test(await ui(pw, '#msg')), await ui(pw, '#msg'));
    check('single refresh finished', !!(await done()));
    const t1at = await atOf(), sel1 = await selOf();
    check('ONLY B\'s channel list was re-read (A and D records untouched)', t1at.b > t0at.b && t1at.a === t0at.a && t1at.d === t0at.d, [t0at, t1at]);
    check('ONE Bean tab for it, never two at once, all closed; its tab id was recorded in p9bn.disc', trk.total - mk0.total === 1 && trk.max <= 1 && trk.alive().length === 0 && discTabs.size >= 1, { total: trk.total - mk0.total, max: trk.max, alive: trk.alive(), disc: [...discTabs] });
    check('p9bn.disc ends as "done"', ((await store(pw, 'p9bn.disc')) || {}).state === 'done', await store(pw, 'p9bn.disc'));
    check('selections preserved: A still ticked with main only; B (not ticked) stays not ticked although its list is now known', JSON.stringify(sel1.sel) === JSON.stringify(sel0.sel) && JSON.stringify(sel1.chSel[cA.id]) === '["main"]' && !sel1.sel.includes(cB.id), sel1);
    check('B\'s row shows "Updated · 1 channel"', /Updated · 1 channel/.test(await ui(pw, `.rnote[data-cid="${cB.id}"]`)), await ui(pw, `.rnote[data-cid="${cB.id}"]`));
    check('controls are enabled again', await js(pw, "[...document.querySelectorAll('#clist .rf')].every((b) => !b.disabled) && !document.getElementById('crefresh').disabled"));

    // a channel that is truly gone is dropped from the selection; the others stay; other containers untouched
    await saveSel(pw, { [cA.id]: ['main', 'p111'], [cB.id]: ['main'] });
    sw.accounts.alice = [{ id: 'main', name: 'Alice', handle: '@alice' }];        // "Alice Cooking" is gone from Alice's account
    const t2at = await atOf(), mk2 = trk.mark(); trk.resetMax();
    await click(pw, `.rf[data-cid="${cA.id}"]`); await sleep(500); check('single refresh of A finished', !!(await done()));
    const t3at = await atOf(), sel3 = await selOf(), recA = await rec(cA.id);
    check('A: only the vanished channel is dropped from the saved selection (main kept, B untouched); the list now has 1 channel', JSON.stringify(sel3.chSel[cA.id]) === '["main"]' && recA.channels.length === 1 && JSON.stringify(sel3.chSel[cB.id]) === '["main"]' && t3at.a > t2at.a && t3at.b === t2at.b && t3at.d === t2at.d, [sel3, recA.channels.length, t2at, t3at]);
    check('one tab, never two', trk.total - mk2.total === 1 && trk.max <= 1 && trk.alive().length === 0, { total: trk.total - mk2.total, max: trk.max });
    sw.accounts.alice = [{ id: 'main', name: 'Alice', handle: '@alice' }, { id: 'p111', name: 'Alice Cooking', handle: '@alicecooks' }];
    await click(pw, `.rf[data-cid="${cA.id}"]`); await sleep(500); await done();
    const sel4 = await selOf(); check('the channel is back in the list but NOT auto-ticked (selection is the user\'s)', JSON.stringify(sel4.chSel[cA.id]) === '["main"]' && (await rec(cA.id)).channels.length === 2, sel4);

    // a failed single refresh keeps the previous good list and shows the error on that row
    const goodB = await rec(cB.id); delete sw.accounts.bob;                        // Bob's switcher cannot be read any more
    const t5at = await atOf(), mk5 = trk.mark(); trk.resetMax();
    await click(pw, `.rf[data-cid="${cB.id}"]`); await sleep(500); check('failed single refresh finished', !!(await done()));
    const recB = await rec(cB.id), t6at = await atOf();
    check('failed read: B keeps its previous list (1 channel, ok) and records the error; A and D untouched', !!recB && recB.ok === true && recB.channels.length === goodB.channels.length && /No channel list/.test(recB.err) && t6at.a === t5at.a && t6at.d === t5at.d, recB);
    check('the error is shown on B\'s row (and says the previous list is kept)', /Could not refresh/.test(await ui(pw, `.rnote[data-cid="${cB.id}"]`)) && /previous list/.test(await ui(pw, `.rnote[data-cid="${cB.id}"]`)), await ui(pw, `.rnote[data-cid="${cB.id}"]`));
    check('the failed read still used one tab, closed; selections unchanged', trk.total - mk5.total === 1 && trk.max <= 1 && trk.alive().length === 0 && JSON.stringify((await selOf()).chSel[cB.id]) === '["main"]', { total: trk.total - mk5.total, max: trk.max });
    sw.accounts.bob = [{ id: 'main', name: 'Bob', handle: '@bob' }];
    await click(pw, `.rf[data-cid="${cB.id}"]`); await sleep(500); await done();
    check('after Bob\'s switcher works again the error is gone from the row', !(await js(pw, `!!document.querySelector('.rnote.warn[data-cid="${cB.id}"]')`)) && !((await rec(cB.id)) || {}).err, await ui(pw, `.rnote[data-cid="${cB.id}"]`));

    // refused during a run: nothing is opened, the buttons are disabled
    await saveSel(pw, { [cA.id]: ['main'] }); reset();
    const mk7 = trk.mark(); trk.resetMax();
    await setLinks(pw, [link('NORMAL00301', ID.top1), link('NORMAL00302', ID.top1), link('NORMAL00303', ID.top1)].join('\n'), 'slow'); const nb7 = await press(pw);
    const runState = await js(pw, `(() => ({ off: [...document.querySelectorAll('#clist .rf')].every((b) => b.disabled), refOff: document.getElementById('crefresh').disabled, title: document.querySelector('#clist .rf').title }))()`);
    check('during a run: every ↻ and "Refresh channels" are disabled with a reason', runState.off && runState.refOff && /run is in progress/.test(runState.title), runState);
    const discBefore = await store(pw, 'p9bn.disc'), atRun = await atOf(); await js(pw, `refreshOne(${JSON.stringify(cB.id)})`); await sleep(1200);
    check('refreshOne() during a run is refused with a clear message, nothing is read', /run is in progress/.test(await ui(pw, '#msg')) && JSON.stringify(await store(pw, 'p9bn.disc')) === JSON.stringify(discBefore) && (await atOf()).b === atRun.b, [await ui(pw, '#msg'), discBefore]);
    await js(pw, "document.getElementById('stop').click()"); b = await finished(pw, 120000);
    check('the run was stopped cleanly; one Bean tab at a time throughout (run + refused refresh)', !!b && trk.max <= 1 && !!(await wait(() => trk.alive().length === 0, 15000)), { max: trk.max, alive: trk.alive() });
    sampling = false; await sampler;

    // "Refresh channels" still reads exactly the ticked containers
    pw = await popup(); await saveSel(pw, { [cA.id]: ['main'], [cB.id]: ['main'] });
    const t8 = await atOf(), mk8 = trk.mark(); trk.resetMax();
    await js(pw, "document.getElementById('crefresh').click()"); await sleep(800); await done();
    const t9 = await atOf();
    check('"Refresh channels" (all ticked) still reads A and B only — D (not ticked) untouched, two tabs one after the other', t9.a > t8.a && t9.b > t8.b && t9.d === t8.d && trk.total - mk8.total === 2 && trk.max <= 1 && trk.alive().length === 0, [t8, t9, trk.total - mk8.total, trk.max]);
    reset(); sw.liked.clear();
  }
  // 1.1.7 (the real 1.1.6.2 run): ONE VPN rotation per like attempt. A channel switch that ends in a FRESH TAB (reopen) keeps the location the item already has: before, the popup rotated again for the reopened tab.
  { reset(); connT.length = 0; sw.reqLog = []; sw.delay.watch = 0; sw.switches.length = 0; sw.navLag = true; sw.navFreshOpens = 0; const cn0 = connects().length;
    await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'chan', value: 'main', secure: true }); await ctx.sessionFor(cA.id).cookies.remove('https://www.youtube.com/', 'ident').catch(() => {});
    pw = await popup(); await saveSel(pw, { [cA.id]: ['main', 'p111'] }); await setLinks(pw, link('NAVLAGVPN01', ID.top1)); await press(pw); b = await finished(pw, 300000); sw.navLag = false;
    const cn = connects().slice(cn0), reo = !!b && b.items.some((i) => (i.ro || 0) >= 1), kept = !!b && b.items.some((i) => (i.lg || []).some((l) => l[1] === 'vpn' && /kept the location/.test(String(l[2]))));
    check('1.1.7 channel switch + fresh tab with VPN rotation: both liked, the p111 item was reopened in a fresh tab (the lag model forced it), ONE sign-in', !!b && JSON.stringify(codes(b)) === JSON.stringify(['liked', 'liked']) && reo && sw.switches.filter((x) => x.to === 'p111').length === 1 && likes().length === 2, b && [codes(b), reo, sw.switches.length, likes().length]);
    check('1.1.7 ONE rotation per like: 2 likes = 2 connects (the reopened tab kept the location; before: 3), and the log says it kept it', cn.length === 2 && kept, [cn, kept]);
    if (process.env.E11_STOP_AFTER_ROT) { closePopups(); try { py.kill(); } catch (_) {} console.log(`\nRESULT (partial rot): ${passes} passed, ${failures} failed`); process.exit(failures ? 1 : 0); }
    check('1.1.7 each like sits on the location its item recorded (the reopened one did not change it)', !!b && b.items.every((i) => i.vpn && i.vpn.location) && b.items[0].vpn.location !== b.items[1].vpn.location, b && b.items.map((i) => i.vpn));
    await ctx.sessionFor(cA.id).cookies.set({ url: 'https://www.youtube.com/', name: 'chan', value: 'main', secure: true }); await ctx.sessionFor(cA.id).cookies.remove('https://www.youtube.com/', 'ident').catch(() => {}); reset(); sw.liked.clear();
  }
  // ================================================================================================================ API
  if (process.env.E2E_STOP2C) { closePopups(); try { py.kill(); } catch (_) { /* gone */ } geo.close(); await srv.close(); console.log(`\nRESULT(partial 2c): ${passes} passed, ${failures} failed`); process.exit(failures ? 1 : 0); }
  console.log('\n== 3. the named API: create ==');
  await ytfToggle('commentsOnly', true);
  pw = await popup(); await saveSel(pw, SEL_ALL); await js(pw, "document.getElementById('sec-api').open = true"); await sleep(300);   // (the VPN part left only B ticked: the install reports 4 saved channels only with SEL_ALL)
  check('API section: off, name tag field, Create API button', /off/.test(await ui(pw, '#apisum')) && !!(await js(pw, "!!document.getElementById('apicreate') && !!document.getElementById('apiname')")));
  await js(pw, `(() => { const n = document.getElementById('apiname'); n.value = 'e2e-studio pc'; n.dispatchEvent(new Event('input', { bubbles: true })); const bs = document.getElementById('apibase'); bs.value = ${JSON.stringify(BASE)}; bs.dispatchEvent(new Event('input', { bubbles: true })); })()`);
  await click(pw, '#apicreate'); await wait(() => js(pw, "!!document.getElementById('apikey')"), 15000, 200);
  const KEY = (await ui(pw, '#apikey')) || ''; if (!KEY) console.log('  (create failed: ' + (await ui(pw, '#apimsg')) + ')');
  check('Create API: a key "bean_…" is shown ONCE with Copy / hide buttons', /^bean_[A-Za-z0-9_-]{43}$/.test(KEY) && !!(await js(pw, "!!document.getElementById('apicopy') && !!document.getElementById('apihide')")), KEY.slice(0, 9));
  const apiRec = await store(pw, 'p9bn.api');
  check('Bean stores the install identity + token + masked hint — never the key itself', !!apiRec && apiRec.enabled === true && /^bi_/.test(apiRec.installId) && /^bit_/.test(apiRec.token) && apiRec.name === 'e2e-studio pc' && !JSON.stringify(await js(pw, 'chrome.storage.local.get(null)')).includes(KEY), apiRec && [apiRec.installId, apiRec.name]);
  await click(pw, '#apihide'); await sleep(400);
  check('after "hide" only the masked key remains (first 9 chars … last 4), with Regenerate and Revoke buttons; Create is gone', /^bean_.{4}….{4}$/.test(await ui(pw, '#apihint')) && !(await js(pw, "!!document.getElementById('apikey') || !!document.getElementById('apicreate')")) && !!(await js(pw, "!!document.getElementById('apiregen') && !!document.getElementById('apirevoke')")), await ui(pw, '#apihint'));
  check('the server has only a HASH of the key and token (no plaintext in its database)', await (async () => { const db = path.join(tmp, 'server', 'bean.sqlite'); const out = execFileSync(PY, ['-c', 'import sqlite3,sys; c=sqlite3.connect(sys.argv[1]); print(open(sys.argv[1],"rb").read().decode("latin1").count(sys.argv[2]), open(sys.argv[1]+"-wal","rb").read().decode("latin1").count(sys.argv[2]) if __import__("os").path.exists(sys.argv[1]+"-wal") else 0)', db, KEY]).toString().trim(); return out === '0 0'; })());
  const instOf = async () => (await req('GET', '/api/bean/v1/install', KEY)).json;
  const online = await wait(async () => { const j = await instOf(); return j && j.online && j.saved_channels === 4 ? j : false; }, 40000, 500) || await instOf();
  check('GET /install: the install name, online status, saved channels (3 = A main, A cooking... see below), version', !!online && online.name === 'e2e-studio pc' && online.bean_version === '1.1.7.4' && online.saved_channels === 4, online);
  // ---- 1.1.1 "Possible likes": the popup's numbers equal the server's /capacity for the same links and the same ticked channels
  {
    const PL = [link('NORMAL00101', ID.top1), link('NORMAL00998', ID.top1)];
    await setLinks(pw, PL.join('\n')); await sleep(600);
    const cap = async (links) => (await req('GET', '/api/bean/v1/capacity?' + links.map((l) => 'link=' + encodeURIComponent(l)).join('&'), KEY)).json;
    const capOk = await wait(async () => { const c = await cap(PL); return c && c.capacity && c.capacity[0].channels_saved === 4 ? c : false; }, 30000, 500) || await cap(PL);
    const txt = (sel2) => ui(pw, sel2);
    check('"Possible likes: 4 per comment" is shown for the 4 ticked channels (A main, A cooking, B, D)', /^Possible likes: 4 per comment/.test(await txt('#possibleHead')), await txt('#possible'));
    const parse = async (n) => { const m = /^(\d+) of (\d+) possible(?: \((\d+) already used\))?/.exec(await txt(`#possibleLinks .lr[data-n="${n}"] .lv`) || ''); return m ? { avail: +m[1], total: +m[2], used: +(m[3] || 0) } : null; };
    const p1 = await parse(1), p2 = await parse(2), c1 = capOk.capacity[0], c2 = capOk.capacity[1];
    check('link 1: popup "X of Y possible (Z already used)" == API /capacity (max_likes, channels_saved, channels_used)', !!p1 && p1.avail === c1.max_likes && p1.total === c1.channels_saved && p1.used === c1.channels_used, [p1, c1]);
    check('link 2 (a fresh comment): all 4 possible, nothing used — same as /capacity', !!p2 && p2.avail === 4 && p2.used === 0 && p2.avail === c2.max_likes && c2.reserved_by_queued_jobs === 0, [p2, c2]);
    const tt = /^(\d+) of (\d+) possible(?: \((\d+) already used\))?/.exec(await txt('#possibleTotal .lv') || '');
    check('total = sum of the links (available / all / used)', !!tt && +tt[1] === c1.max_likes + c2.max_likes && +tt[2] === 8 && +(tt[3] || 0) === c1.channels_used + c2.channels_used, [await txt('#possibleTotal'), c1, c2]);
    check('the panel says how it counts (1.1.7: the ledger is applied and channels reserved by orders in the queue - popup and API orders alike - are left out)', /channels reserved by orders in the queue are left out/.test(await txt('#possible')), await txt('#possible'));
    // live: the selection changes -> the numbers follow at once
    await saveSel(pw, { [cA.id]: ['main'], [cB.id]: ['main'], [cD.id]: null }); await sleep(300);
    const pa = await parse(2); check('live: untick one channel -> "3 per comment" and link 2 "3 of 3 possible"', /^Possible likes: 3 per comment/.test(await txt('#possibleHead')) && !!pa && pa.avail === 3 && pa.total === 3, [await txt('#possibleHead'), pa]);
    const capB = await wait(async () => { const c = await cap(PL); return c && c.capacity && c.capacity[1].channels_saved === 3 ? c : false; }, 30000, 500);
    if (!capB) { const ii = (await req('GET', '/api/bean/v1/install', KEY)).json; const cc2 = await cap(PL); console.log('  [debug] capacity-follows: install.saved_channels=' + (ii && ii.saved_channels) + ' online=' + (ii && ii.online) + ' capacity=' + JSON.stringify(cc2 && cc2.capacity && cc2.capacity.map((x) => [x.channels_saved, x.max_likes])) + ' popup-sel=' + JSON.stringify(await js(pw, 'JSON.stringify([...sel])')) + ' savedKeys=' + JSON.stringify(await js(pw, 'JSON.stringify(B11.savedKeys())')) + ' executor=' + (await js(pw, 'B11.executor()')) + ' runnerAlive=' + (await js(pw, 'B11.runnerAlive()')) + ' settings=' + JSON.stringify(await store(pw, 'p9bn.settings')).slice(0, 400) + ' apistat=' + JSON.stringify(await store(pw, 'p9bn.apistat.runner')).slice(0, 300)); }
    check('...and the API\'s /capacity follows to the same 3', !!capB && capB.capacity[1].max_likes === pa.avail, capB && capB.capacity);
    // live: the links change
    await setLinks(pw, PL[1]); await sleep(300);
    check('live: one link left -> one "Link 1" line, total = that line', (await js(pw, "document.querySelectorAll('#possibleLinks .lr').length")) === 1 && /^3 of 3 possible/.test(await txt('#possibleTotal .lv')), await txt('#possible'));
    await setLinks(pw, ''); await sleep(300);
    check('no links: only "Possible likes: 3 per comment" (no per-link lines, no total)', /^Possible likes: 3 per comment/.test(await txt('#possibleHead')) && !(await js(pw, "!!document.getElementById('possibleLinks') || !!document.getElementById('possibleTotal')")), await txt('#possible'));
    // estimate: a signed-out container is listed as likely skipped; the API-style numbers stay
    await saveSel(pw, SEL_ALL); await setLinks(pw, PL[1]);
    await js(pw, `(() => { for (const c of ctrs.containers) { c.checked = true; c.signedIn = c.id !== ${JSON.stringify(cD.id)}; } renderContainers(); })()`); await sleep(300);
    check('a signed-out ticked container is named as "Likely skipped (estimate)"; per comment still 4 (API counting), "about 3 expected"', /Likely skipped \(estimate\).*Channel D — signed out/.test(await txt('#possible')) && /^Possible likes: 4 per comment/.test(await txt('#possibleHead')) && /about 3 expected/.test(await txt('#possibleTotal .lv')), await txt('#possible'));
    await js(pw, "loadContainers().then(renderContainers)"); await sleep(600);
    check('after the container list is reloaded the estimate follows Panel 9\'s own data again (the in-page edit is gone: every container of this test Panel 9 is signed out)', /Likely skipped \(estimate\).*Channel A.*Channel B/.test(await txt('#possible')), await txt('#possible'));
    await setLinks(pw, ''); await saveSel(pw, SEL_ALL);
  }
  const savedNow = online ? online.saved_channels : -1;
  check('the runner (hidden page) is up: the API works without a Bean window', !!(await wait(() => api.bean.runner.view && !api.bean.runner.view.webContents.isDestroyed(), 20000, 300)));
  // ledger mirrored to the server after create (full push)
  const tok = apiRec.token;
  const srvLedger = async () => (await req('GET', '/api/bean/agent/ledger?after=0&limit=2000', tok)).json;
  const ledLocal = await js(pw, 'B11.S.led.stats()');
  const gotLed = await wait(async () => { const l = await srvLedger(); return l && l.total === ledLocal.pairs ? l : false; }, 30000, 600);
  check('the existing ledger was pushed to the server (' + ledLocal.pairs + ' channel uses)', !!gotLed, [gotLed && gotLed.total, ledLocal.pairs]);
  { // 1.1.6: /capacity is the live number of possible likes: it follows channel selection, flagged channels and ledger clearing within seconds
    const capOf = async (vid, lc) => { const r = (await req('GET', '/api/bean/v1/capacity?link=' + encodeURIComponent(link(vid, lc)), KEY)).json; return r && r.capacity && r.capacity[0]; };
    await setLinks(pw, link('NORMAL00998', ID.top1)); await sleep(400);
    const base = await wait(async () => { const c = await capOf('NORMAL00998', ID.top1); return c && c.channels_saved === 4 ? c : false; }, 30000, 500);
    check('1.1.6 /capacity (before): 4 saved channels, 4 possible for a fresh comment', !!base && base.max_likes === 4, base);
    // (a) a channel the last run flagged (not found in the account menu / could not be switched to) is left out
    await js(pw, `chrome.storage.local.set({ ['p9bn.chstale.' + ${JSON.stringify(cA.id)}]: { at: Date.now(), ids: ['main'], why: 'test' } })`);
    const fl = await wait(async () => { const c = await capOf('NORMAL00998', ID.top1); return c && c.channels_saved === 3 ? c : false; }, 30000, 500);
    await sleep(500); const pk = /^(\d+) of (\d+) possible/.exec(await ui(pw, '#possibleLinks .lr .lv') || '');
    check('1.1.6 /capacity: a flagged (stale / missing / switch-failed) channel is NOT counted: 3 saved, 3 possible (and the panel\'s own "possible" line says the same)', !!fl && fl.max_likes === 3 && !!pk && +pk[1] === 3 && +pk[2] === 3, [fl, pk && pk[0], await js(pw, 'B11.savedKeys()')]);
    await js(pw, `chrome.storage.local.remove('p9bn.chstale.' + ${JSON.stringify(cA.id)})`);
    const back = await wait(async () => { const c = await capOf('NORMAL00998', ID.top1); return c && c.channels_saved === 4 ? c : false; }, 30000, 500);
    check('1.1.6 /capacity: after the flag is cleared (refresh or a like) the channel counts again: 4 possible', !!back && back.max_likes === 4, back);
    // (b) false marks on the server copy are removed when the owner clears them in Bean
    const keys = await js(pw, 'B11.savedKeys()'), VC = 'CAPCLEAR001', LC = 'UgxCAPCLEAR_aaaaaaaaaaaa';
    await req('POST', '/api/bean/agent/ledger', tok, { entries: [[VC, LC, keys[0], 'a', Date.now()], [VC, LC, keys[1], 'l', Date.now()]] });
    const marked = await wait(async () => { const c = await capOf(VC, LC); return c && c.channels_used === 2 ? c : false; }, 15000, 400);
    check('1.1.6 /capacity: two false marks on the server -> 2 used, 2 possible', !!marked && marked.max_likes === 2, marked);
    await js(pw, `chrome.storage.local.set({ 'p9bn.cmd': { id: 'cap' + Date.now(), op: 'remove-comment', arg: { vid: ${JSON.stringify(VC)}, lc: ${JSON.stringify(LC)} }, at: Date.now() } })`);
    const cleared = await wait(async () => { const c = await capOf(VC, LC); return c && c.channels_used === 0 ? c : false; }, 30000, 500);
    check('1.1.6 /capacity: after "Clear all marks for this comment" the cleared marks are gone from the server and /capacity: 0 used, 4 possible', !!cleared && cleared.max_likes === 4, cleared);
    await setLinks(pw, '');
  }
  await sleep(21000);       // a long poll that the popup started before the runner existed ends; from now on only the runner polls

  console.log('\n== 4. capacity, quantity, headless job (popup closed) ==');
  closePopups(); await sleep(500);
  const VPNOFF = async () => { pw = await popup(); await saveVpn(pw, []); closePopups(); };
  async function saveVpn(wc, locs) { await js(wc, `(async () => { settings.vpn = Object.assign({}, settings.vpn || {}, { locs: ${JSON.stringify(locs)} }); await sset(K.settings, settings); })()`); await sleep(1500); }
  await VPNOFF();
  // saved channels = every ticked channel: A main, A cooking, B main, D = 4 after we restore the selection
  pw = await popup(); await saveSel(pw, SEL_ALL); closePopups(); await sleep(3000);
  const cap = async (links, extra) => (await req('POST', '/api/bean/v1/capacity', KEY, { links })).json;
  const NL = link('NORMAL00301', ID.top1);
  let c = await cap([NL]);
  check('capacity for a fresh comment = saved channels (4) minus ledger uses (0)', c.capacity && c.capacity[0].max_likes === 4 && c.capacity[0].channels_saved === 4 && c.capacity[0].channels_used === 0, c);
  const old = await cap([L1]);
  check('capacity for a comment the ledger knows: 0 (all 4 channels used) — and it says why', (SKIP12 || (old.capacity[0].max_likes === 0 && old.capacity[0].channels_used === 4)), old.capacity && old.capacity[0]);
  let r = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: NL, quantity: 9 }] });
  check('quantity above capacity is REJECTED by default: 422 quantity_exceeds_capacity with the maximum', r.status === 422 && r.json.error.code === 'quantity_exceeds_capacity' && r.json.error.details.problems[0].max_likes === 4, r.json);
  r = SKIP12 ? { status: 422, json: { error: { code: 'no_capacity' } } } : await req('POST', '/api/bean/v1/jobs', KEY, { links: [L1] });
  check('a comment with no capacity left: 422 no_capacity', SKIP12 || (r.status === 422 && r.json.error.code === 'no_capacity'), r.json);
  let J1 = null;          // used again by section 8
  const ONLY4D = !!process.env.E11_ONLY4D;          // debugging aid: skip the job 1-3 / 4a / 4c parts and run only 4d
  const jobWait = (id, ms = 200000) => wait(async () => { const j = (await req('GET', '/api/bean/v1/jobs/' + id, KEY)).json; return j && !['queued', 'running'].includes(j.status) ? j : false; }, ms, 1000);
  if (!ONLY4D) {
  reset();
  r = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: NL, quantity: 2 }], note: 'e2e' });
  J1 = r.json && r.json.job_id;
  if (process.env.E2E_DEBUG) (async () => { const t0 = Date.now(); while (Date.now() - t0 < 70000) { await sleep(3000); try { const rv = api.bean.runner.view; const bb = await rv.webContents.executeJavaScript("chrome.storage.local.get('p9bn.batch').then((v) => { const b = v['p9bn.batch']; return b && { id: b.id.slice(0,5), st: b.state, owner: b.owner, job: b.job && b.job.slice(-4), n: b.items.length, it: b.items.map((i) => i.status[0]).join('') }; })"); console.log('  [dbg]', Math.round((Date.now() - t0) / 1000), JSON.stringify(bb), 'clicks', sw.clicks.filter((c) => c.kind === 'like').map((c) => c.acct + '/' + c.chan + '@' + (c.t % 100000)).join(' ')); } catch (e) { console.log('  [dbg] err', String(e).slice(0, 80)); } } })();
  check('job with quantity 2 accepted (202) and queued/running, no window open', r.status === 202 && !!J1 && r.json.links[0].accepted === 2, r.json);
  let j1 = await jobWait(J1);
  if (!j1 || j1.status !== 'completed') { console.log('  [debug] job1', JSON.stringify({ s: j1 && j1.status, e: j1 && j1.error, res: j1 && j1.results && j1.results.map((x) => [x.status, x.code, x.channel]), clicks: likes().length })); pw = await popup(); console.log('  [debug] batch', JSON.stringify(await js(pw, "chrome.storage.local.get('p9bn.batch').then((v) => { const b = v['p9bn.batch']; return b && { id: b.id, st: b.state, owner: b.owner, job: b.job, n: b.items.length, it: b.items.map((i) => [i.ck, i.status, i.code]) }; })"))); closePopups(); }
  check('job completed: 2 liked, each by a different channel, per-like results with container + channel + time', !!j1 && j1.status === 'completed' && j1.progress.liked === 2 && j1.results.length === 2 && new Set(j1.results.map((x) => x.channel)).size === 2 && j1.results.every((x) => x.status === 'liked' && x.container && x.at), j1);
  check('exactly 2 like clicks reached the page, by two different accounts/channels', likes().length === 2, likes().map((x) => x.acct + '/' + x.chan));
  check('TAB RULE 1.1.7.5 (API job over 3 containers, headless): at most 3 Bean tabs at once, never 2 of one container, none left open afterwards', trk.maxAll <= 3 && trk.maxPerCid <= 1 && !!(await wait(() => trk.alive().length === 0, 8000)), { max: trk.maxAll, over: trk.over, alive: trk.alive() });
  pw = await popup(); const bj = await batchOf(pw);
  check('the batch was run by the runner (owner "runner", job id recorded), not by a popup', !!bj && bj.owner === 'runner' && bj.job === J1, bj && [bj.owner, bj.job]);
  await sleep(2000);
  c = await cap([NL]);
  check('capacity afterwards = 2 (4 saved − 2 used); the ledger (local) has the 2 new entries and the server copy matches', c.capacity[0].max_likes === 2 && (await js(pw, 'B11.S.led.has("NORMAL00301", "' + ID.top1 + '", B11.S.led.used("NORMAL00301", "' + ID.top1 + '")[0])')) === true && (await srvLedger()).total === (await js(pw, 'B11.S.led.stats().pairs')), [c.capacity[0], (await srvLedger()).total]);
  closePopups();
  reset();
  r = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: NL }] });          // no quantity = all available
  const J2 = r.json.job_id; check('no quantity = all available (2)', r.status === 202 && r.json.links[0].accepted === 2 && r.json.links[0].requested === null, r.json);
  let j2 = await jobWait(J2);
  if (!j2 || j2.status !== 'completed') console.log('  [debug] job2', JSON.stringify({ s: j2 && j2.status, e: j2 && j2.error }));
  const capZero = await wait(async () => (await cap([NL])).capacity[0].max_likes === 0, 15000, 700);
  if (!capZero) { const rv = api.bean.runner.view; console.log('  [debug] ledger local(NL)', JSON.stringify(await rv.webContents.executeJavaScript('B11.S.led.used("NORMAL00301", "' + ID.top1 + '")')), 'server', JSON.stringify(((await srvLedger()).entries || []).filter((x) => x[0] === 'NORMAL00301'))); }
  check('job 2 completed with the 2 remaining channels; across both jobs all 4 saved channels liked the comment once', !!j2 && j2.status === 'completed' && likes().length === 2 && capZero, j2 && [j2.status, likes().length]);
  r = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00302', ID.top1), quantity: 3 }, { link: link('NORMAL00302', ID.top3), quantity: 1 }], over_quantity: 'clamp' });
  const J3 = r.json.job_id; reset();
  check('two links in one job (quantities 3 and 1)', r.status === 202 && r.json.links.map((l) => l.accepted).join() === '3,1', r.json && r.json.links);
  let j3 = await jobWait(J3);
  if (!j3 || j3.status !== 'completed') console.log('  [debug] job3', JSON.stringify({ s: j3 && j3.status, e: j3 && j3.error, w: j3 && j3.warnings }));
  check('multi-link job: 3 + 1 likes, each result tied to its link number', !!j3 && j3.status === 'completed' && j3.results.filter((x) => x.n === 1).length === 3 && j3.results.filter((x) => x.n === 2).length === 1 && likes().length === 4, j3 && [j3.status, j3.progress]);

  }
  // ---- 1.1.7.1 MUST-FIX (real job_V4Drrn4Psg2ovX5T, 16:04 WAT): the server handed job B over 4 s after job A finished; Bean never started it, and kept it 'running' (claimed-idle) until it was closed by hand at 16:22.
  // Bean now keeps every claimed job until it is started (retried every 3 s) and, after 30 s with no local run, hands it back with a finish report; a job the server calls running that Bean knows nothing about is handed back too.
  console.log('\n== 4a. claimed job hand-off: job A finishes, job B is handed over at once (the first hand-over attempts fail like a teardown race) ==');
  if (!ONLY4D) { const rq = (code) => api.bean.runner.view.webContents.executeJavaScript(code);
    const sj = async (id) => (await req('GET', '/api/bean/v1/jobs/' + id, KEY)).json;
    // (1) a RACE: B's first 3 hand-over attempts find the dispatcher not ready; the retry must start it (nothing claimed-idle)
    reset(); let rA = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00321', ID.top1), quantity: 1 }] }); const JA = rA.json && rA.json.job_id;
    let rB = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00322', ID.top1), quantity: 1 }] }); const JB = rB.json && rB.json.job_id;
    await rq("(self.B17.testBlock = { id: " + JSON.stringify(JB) + ", n: 3 }, 1)");
    const jA = await jobWait(JA, 200000); const tAend = Date.now();
    const jB = await jobWait(JB, 200000);
    if (!jB || jB.status !== 'completed') { const rv = api.bean.runner.view; await dumpB('4a1', rv.webContents).catch(() => {}); }
    const tl = await rq("JSON.stringify(self.B17.testBlock || null)");
    check('4a job A finished, job B (handed over right after, first 3 attempts failed) STARTED by the retry and finished: 1 like each, never claimed-idle', !!jA && jA.status === 'completed' && !!jB && jB.status === 'completed' && jB.results.length === 1 && jB.results[0].status === 'liked' && likes().length === 2, [jA && jA.status, jB && jB.status, jB && jB.error, likes().length, tl]);
    check('4a the hand-over attempts really failed first (the hook was used up)', /"n":0/.test(String(tl)), tl);
    // (2) B can NEVER be started (every attempt fails): it is handed back to the server with a finish report within ~45 s of the claim, not kept 'running' for ever
    reset(); rA = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00323', ID.top1), quantity: 1 }] }); const JA2 = rA.json && rA.json.job_id;
    rB = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00324', ID.top1), quantity: 1 }] }); const JB2 = rB.json && rB.json.job_id;
    await rq("(self.B17.testBlock = { id: " + JSON.stringify(JB2) + ", n: 100000 }, 1)");
    const jA2 = await jobWait(JA2, 200000); const tA2 = Date.now(); const clm = await wait(async () => { const j = await sj(JB2); return j && j.status === 'running' ? j : false; }, 60000, 500); const tClaim = Date.now();
    const jB2 = await jobWait(JB2, 180000); const dt = Math.round((Date.now() - tClaim) / 1000);
    console.log(`  [4a] B claimed ${Math.round((tClaim - tA2) / 1000)} s after A ended; handed back after ${dt} s; B: ${jB2 && jB2.status} ${JSON.stringify(jB2 && jB2.error)}`);
    check('4a a claimed job that cannot be started is HANDED BACK within 110 s (1.1.7.2: 90 s of retries first) (finished with an error report, nothing clicked), not kept running', !!jA2 && jA2.status === 'completed' && !!clm && !!jB2 && jB2.status !== 'running' && dt <= 110 && !!(jB2.error && jB2.error.code) && likes().length === 1, [jA2 && jA2.status, !!clm, jB2 && jB2.status, jB2 && jB2.error, dt, likes().length]);
    await rq("(self.B17.testBlock = null, 1)");
    // (3) a job the server calls running that Bean never heard of (the claim answer was lost) and that has NO results yet: 1.1.7.2 RE-ADOPTS it from the server's own job list (the old 1.1.7.1 rule handed it back 'interrupted' after ~45 s, so the caller had to order it again). It must complete with exactly one like (ledger: never a double like).
    { const db = path.join(tmp, 'server', 'bean.sqlite'), n0 = likes().length;
      execFileSync(PY, ['-c', 'import sqlite3,sys,time; c=sqlite3.connect(sys.argv[1], timeout=15); c.execute("INSERT INTO jobs (job_id, install_id, status, created, started, finished, expires, items, results, options, warnings, error, lease_until, attempts, cancel, idem, note) SELECT ?, install_id, \'running\', created, ?, NULL, expires, items, \'[]\', options, \'[]\', NULL, ?, 1, 0, NULL, \'lost claim e2e\' FROM jobs WHERE job_id=?", (sys.argv[3], time.time(), time.time()+600, sys.argv[2])); c.commit()', db, JB2, 'job_lostclaime2e000001']);
      const t0 = Date.now(); const lost = await wait(async () => { const j = (await req('GET', '/api/bean/v1/jobs/job_lostclaime2e000001', KEY)).json; return j && j.status !== 'running' ? j : false; }, 200000, 1000);
      console.log('  [4a] lost-claim job ' + (lost && lost.status) + ' after ' + Math.round((Date.now() - t0) / 1000) + ' s ' + JSON.stringify(lost && lost.error) + ' likes ' + (likes().length - n0));
      check('4a (1.1.7.2) a job the server calls running but Bean never received (lost claim answer, no results yet) is RE-ADOPTED from the server list: it completes with exactly ONE like, never handed back, never liked twice', !!lost && lost.status === 'completed' && likes().length === n0 + 1 && (lost.results || []).filter((x) => x.status === 'liked').length === 1, lost && [lost.status, lost.error, Math.round((Date.now() - t0) / 1000), likes().length - n0]); } }

  if (!ONLY4D) { // 1.1.7.2 (real job_IpAePu05dKstEVYT / job_y0Q44wtVF1P-kXRY on 1.1.7.1: handed back "not_started" 30 s after the claim while the first tab was slow): a job whose FIRST tab never answers
    // (the container is reopened after the open grace, ~75-120 s) is NEVER handed back: it completes, 1 like, no not_started
    console.log('\n== 4c. a slow first tab (the first page load never answers, reopened after the grace): the job is not handed back, it completes ==');
    reset(); const rS = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('HANGFIRST41', ID.top1), quantity: 1 }] }); const JS = rS.json && rS.json.job_id;
    const jS = await jobWait(JS, 420000);
    console.log('  [4c] job ' + (jS && jS.status) + ' ' + JSON.stringify(jS && jS.error));
    check('4c the slow-first-tab job completed with 1 like, never handed back as not_started', !!jS && jS.status === 'completed' && !(jS.error && jS.error.code === 'not_started') && (jS.results || []).filter((r) => r.status === 'liked').length === 1, [jS && jS.status, jS && jS.error, jS && jS.results]);
  }
  { // 1.1.7.2 (Oluchi's rule): ONE container that hangs for ever never fails the whole job: it is recycled once, given up, and the job completes with the other containers' likes; the server never calls it agent_lost
    console.log('\n== 4d. one container (Alice) hangs on EVERY load: the job still completes with likes from the other containers ==');
    reset(); const rH = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('HANGONE0041', ID.top1), quantity: 2 }] }); const JH = rH.json && rH.json.job_id;
    // the lease (server side: lease_until, 120 s) must be renewed all through the hang, whatever the tabs do: sample its remaining time every 8 s
    let minLease = 1e9, nLease = 0; const dbL = path.join(tmp, 'server', 'bean.sqlite'); const leaseT = setInterval(() => { try { const o = execFileSync(PY, ['-c', 'import sqlite3,sys,time; c=sqlite3.connect(sys.argv[1], timeout=5); r=c.execute("SELECT lease_until FROM jobs WHERE job_id=? AND status=\'running\'", (sys.argv[2],)).fetchone(); print(round(r[0]-time.time()) if r and r[0] else "none")', dbL, JH]).toString().trim(); if (o !== 'none') { nLease++; minLease = Math.min(minLease, Number(o)); } } catch (_) { /* sampling only */ } }, 8000);
    const jH = await jobWait(JH, 600000); clearInterval(leaseT); const lk = (jH && jH.results || []).filter((r) => r.status === 'liked');
    console.log('  [4d] lease samples: ' + nLease + ', lowest remaining lease ' + minLease + ' s (of 120)');
    console.log('  [4d] job ' + (jH && jH.status) + ' ' + JSON.stringify(jH && jH.error) + ' liked ' + lk.length);
    if (!jH || jH.status !== 'completed' || lk.length !== 2) { try { const rv4 = api.bean.runner.view; const dmp = await rv4.webContents.executeJavaScript("(async()=>{const g=(k)=>new Promise((r)=>chrome.storage.local.get(k,(o)=>r(o[k])));const bb=await g('p9bn.batch'), oo=await g('p9bn.orders');return JSON.stringify({b:bb&&{id:bb.id,st:bb.state,job:bb.job,groups:(bb.groups||[]).map((q)=>[q.cid,q.status,q.reopens,q.recycle]),items:(bb.items||[]).map((i)=>[i.cid,i.ck,i.status,i.code,(i.lg||[]).slice(-2).map((l)=>l[1]+':'+String(l[2]).slice(0,70))]),ev:(bb.events||[]).slice(-8).map((e)=>String(e[1]).slice(0,110))},o:oo&&(oo.queue||[]).concat(oo.hist||[]).slice(0,3).map((o)=>[o.id,o.jobId,o.state,o.round,o.tries,o.apiSent,(o.apiRes||[]).length,o.apiDone,o.err&&o.err.code]),api:await g('p9bn.apistat.runner')})})()"); console.log('  [debug 4d]', String(dmp).slice(0, 3500)); } catch (e) { console.log('  [debug 4d failed]', String(e).slice(0, 200)); } }
    check('4d the job completed with 2 likes from the containers that work (the hanging one was given up), never agent_lost / not_started', !!jH && jH.status === 'completed' && lk.length === 2 && !(jH.error && /agent_lost|not_started/.test(jH.error.code || '')), [jH && jH.status, jH && jH.error, lk.length]);
    check('4d the lease heartbeat kept going all through the hang: the server job never ran below 45 s of lease (renewed every <= 15 s, independent of the tabs)', nLease >= 5 && minLease >= 45, [nLease, minLease]);
  }
  if (process.env.E11_STOP_AFTER_4A) { closePopups(); try { py.kill(); } catch (_) { /* gone */ } geo.close(); await srv.close(); console.log(`\nRESULT(partial 4a): ${passes} passed, ${failures} failed`); process.exit(failures ? 1 : 0); }
  // ---- 1.1.7.1: an API job that is PAUSED while Bean is reloaded (Panel 9 restarted / Bean updated) must keep reporting after Resume: every result, then the finish
  console.log('\n== 4b. API job + Bean reload while paused: after Resume the server still gets every result and the finish ==');
  const sjob = async (id) => (await req('GET', '/api/bean/v1/jobs/' + id, KEY)).json;
  reset(); r = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00311', ID.top1), quantity: 4 }] }); const JR = r.json && r.json.job_id;
  check('4b job accepted (4 likes)', r.status === 202 && !!JR, r.json);
  const got1 = await wait(async () => { const j = await sjob(JR); return j && j.results && j.results.length >= 1 && j.results.length < 4 ? j : false; }, 120000, 200);
  pw = await popup(); await click(pw, '#pause');
  const bp5 = await wait(async () => { const bb = await batchOf(pw); return bb && bb.pauseReq ? bb : false; }, 30000, 300);
  await sleep(2500); const nPaused = (await sjob(JR)).results.length, lPaused = likes().length;
  check('4b before the reload: the job is running, paused after at least 1 and before 4 results', !!got1 && !!bp5 && nPaused >= 1 && nPaused < 4, [got1 && got1.results.length, nPaused, bp5 && bp5.pause]);
  { const r5 = await mgr.reloadUnpacked(bean.id); await sleep(3000); pw = await popup((r5 && r5.id) || bean.id); }
  const bk5 = await wait(async () => { const bb = await batchOf(pw); return bb && bb.state === 'running' && bb.pause ? bb : false; }, 30000, 300);
  check('4b after the reload: the local run is kept paused, the order still names the job, and the server still says running', !!bk5 && bk5.job === JR && (await sjob(JR)).status === 'running', bk5 && [bk5.state, bk5.job, bk5.pause]);
  await sleep(1500); await click(pw, '#resume');
  const jr = await jobWait(JR, 240000);
  if (!jr || jr.status !== 'completed') { const oo5 = await store(pw, 'p9bn.orders'); console.log('  [debug 4b]', JSON.stringify({ s: jr && jr.status, n: jr && jr.results && jr.results.length, likes: likes().length, api: await store(pw, 'p9bn.apistat.runner'), orders: oo5 && [(oo5.queue || []).concat(oo5.hist || []).slice(0, 2).map((o) => [o.src, o.state, o.jobId, o.apiSent, (o.apiRes || []).length, o.apiDone, o.batchId])], lease: await store(pw, 'p9bn.ordlease') }).slice(0, 1800)); }
  check('4b after Resume the server gets ALL 4 results and the finish (status completed, 4 distinct results), each like clicked once', !!jr && jr.status === 'completed' && jr.results.length === 4 && new Set(jr.results.map((x) => x.seq)).size === 4 && jr.results.every((x) => x.status === 'liked') && likes().length === 4 && new Set(likes().map((c) => c.acct + c.chan)).size === 4, jr && [jr.status, jr.results.length, likes().length, lPaused]);
  // reconciliation: the local run is over, the server still says "running" (a finish that never arrived): Bean sends the finish on its own, never clicks again
  { const db = path.join(tmp, 'server', 'bean.sqlite'); const n0 = likes().length;
    execFileSync(PY, ['-c', 'import sqlite3,sys; c=sqlite3.connect(sys.argv[1], timeout=15); c.execute("UPDATE jobs SET status=\'running\', finished=NULL, lease_until=? WHERE job_id=?", (__import__("time").time()+600, sys.argv[2])); c.commit()', db, JR]);
    const rec = await wait(async () => { const j = await sjob(JR); return j && j.status !== 'running' ? j : false; }, 90000, 1000);
    check('4b reconciliation: the server says running although Bean finished it: Bean re-sends the finish (job completed again), no new click', !!rec && rec.status === 'completed' && likes().length === n0, rec && [rec.status, rec.results.length, likes().length - n0]); }
  // a job the server calls running although Bean has no order for it (Bean restarted / its run was cleared). 1.1.7.2: (i) no results yet -> Bean tries to RE-ADOPT it; when it cannot (here: every channel already liked this comment, no capacity) it reports the job finished with the reason, nothing is clicked, the queue is free;
  // (ii) it already has results (partly done) -> never re-run: reported finished 'interrupted' after two sightings, the results it has stay
  { const db = path.join(tmp, 'server', 'bean.sqlite'), n0 = likes().length;
    execFileSync(PY, ['-c', 'import sqlite3,sys,time; c=sqlite3.connect(sys.argv[1], timeout=15); c.execute("INSERT INTO jobs (job_id, install_id, status, created, started, finished, expires, items, results, options, warnings, error, lease_until, attempts, cancel, idem, note) SELECT ?, install_id, \'running\', created, ?, NULL, expires, items, \'[]\', options, \'[]\', NULL, ?, 1, 0, NULL, \'orphan e2e\' FROM jobs WHERE job_id=?", (sys.argv[3], time.time()-900, time.time()+600, sys.argv[2])); c.commit()', db, JR, 'job_orphane2e0000001']);
    const orp = await wait(async () => { const j = (await req('GET', '/api/bean/v1/jobs/job_orphane2e0000001', KEY)).json; return j && j.status !== 'running' ? j : false; }, 200000, 1500);
    check('4b orphan (no results, nothing left to like): Bean tries to re-adopt it, cannot (no capacity), and reports it finished with the reason so the queue is not blocked; nothing clicked', !!orp && ['failed', 'partial'].includes(orp.status) && !!(orp.error && orp.error.code) && likes().length === n0, orp && [orp.status, orp.error, likes().length - n0]);
    execFileSync(PY, ['-c', 'import sqlite3,sys,time,json; c=sqlite3.connect(sys.argv[1], timeout=15); res=json.dumps([{"n":1,"seq":0,"status":"liked","container":"x","channel":"y","at":"2026-11-04T10:00:00Z"}]); c.execute("INSERT INTO jobs (job_id, install_id, status, created, started, finished, expires, items, results, options, warnings, error, lease_until, attempts, cancel, idem, note) SELECT ?, install_id, \'running\', created, ?, NULL, expires, items, ?, options, \'[]\', NULL, ?, 1, 0, NULL, \'orphan2 e2e\' FROM jobs WHERE job_id=?", (sys.argv[3], time.time()-900, res, time.time()+600, sys.argv[2])); c.commit()', db, JR, 'job_orphane2e0000002']);
    const orp2 = await wait(async () => { const j = (await req('GET', '/api/bean/v1/jobs/job_orphane2e0000002', KEY)).json; return j && j.status !== 'running' ? j : false; }, 200000, 1500);
    check('4b orphan (already has a result): never re-run; Bean reports it finished "interrupted" (the result it has stays), nothing clicked, so the queue is not blocked', !!orp2 && ['failed', 'partial'].includes(orp2.status) && !!(orp2.error && orp2.error.code === 'interrupted') && likes().length === n0, orp2 && [orp2.status, orp2.error, likes().length - n0]); }
  closePopups(); if (process.env.E11_STOP_AFTER_4B) { try { py.kill(); } catch (_) { /* gone */ } geo.close(); await srv.close(); console.log(`\nRESULT(partial 4b): ${passes} passed, ${failures} failed`); process.exit(failures ? 1 : 0); }

  // the reload above leaves the test harness with a runner page of the OLD extension instance (dead: "Extension context invalidated"); a real Panel 9 restart builds a new one. Do the same here before the next sections.
  process.env.P9_NO_BEAN_RUNNER = '1'; await wait(() => !api.bean.runner.view, 40000, 500); await sleep(3000); delete process.env.P9_NO_BEAN_RUNNER;
  check('after the 4b reload a NEW runner page is built (harness restart of the Bean runner)', !!(await wait(() => api.bean.runner.view, 60000, 500)));
  await sleep(20000);

  console.log('\n== 5. job + VPN rotation (results carry the location) ==');
  pw = await popup(); await saveVpn(pw, sv.vpn.locs); await js(pw, "settings.vpn = Object.assign({}, settings.vpn, { t: { connectMs: 6000, ipMs: 4000, pollMs: 250, settleMs: 0, attempts: 2 } }); sset(K.settings, settings)"); closePopups(); await sleep(2500);
  const c2 = connects().length; reset();
  r = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00303', ID.top1), quantity: 2 }] }); const J4 = r.json.job_id;
  let j4 = await jobWait(J4, 240000);
  console.log('  [debug] job4 connects', connects().slice(c2), 'clicks', likes().length);
  if (!j4 || j4.status !== 'completed') { try { const rv = api.bean.runner.view; console.log('  [debug job4 state]', JSON.stringify(await rv.webContents.executeJavaScript("JSON.stringify({ err: B11.S.err, code: B11.S.errCode, job: B11.S.job, online: B11.S.online, held: self.B17 && B17.held(), orders: (self.B17 && B17.state() ? B17.state().queue.concat(B17.state().hist).map((o) => [o.id, o.src, o.state, o.waitWhy, o.err && o.err.code, o.jobId]) : null) })")), 'job', JSON.stringify(j4 && { s: j4.status, e: j4.error })); } catch (e) { console.log('  [debug job4 state failed]', String(e)); } }
  if (process.env.E11_STOP_AFTER5 && (!j4 || j4.status !== 'completed')) { try { const rv5 = api.bean.runner.view; const dump = await rv5.webContents.executeJavaScript("(async()=>{const g=(k)=>new Promise((r)=>chrome.storage.local.get(k,(o)=>r(o[k])));const bb=await g('p9bn.batch');const o={vreq:await g('p9bn.vpnreq'),vpn:await g('p9bn.vpn'),vok:await g('p9bn.vpnok'),role:self.B11&&B11.S&&B11.S.role,vrot:self.B11&&B11.S&&B11.S.vrot};o.b=bb&&{id:bb.id,st:bb.state,own:bb.owner,order:bb.order,vpn:bb.vpn,nextAt:bb.nextAt,idx:bb.idx,pause:bb.pause,groups:(bb.groups||[]).map((q)=>[q.cid,q.status,q.recycle,q.loc]),items:(bb.items||[]).map((i)=>[i.status,i.code,i.hb,(i.lg||[]).slice(-2)]),ev:(bb.events||[]).slice(-8)};return JSON.stringify(o);})()"); console.log('  [debug job4 runner storage]', String(dump).slice(0, 3500)); } catch (e) { console.log('  [debug batch failed]', String(e)); } }
  if (process.env.E11_STOP_AFTER5 && (!j4 || j4.status !== 'completed')) { closePopups(); try { py.kill(); } catch (_) {} console.log('RESULT (stopped after section 5 failure)'); process.exit(1); }
  check('job through the VPN: completed, every result names its location and "ip_changed": true', !!j4 && j4.status === 'completed' && j4.results.every((x) => x.vpn && x.vpn.location && (x.vpn.ip_changed === true || x.vpn.ip_changed === null) && x.vpn.bypassed === false) && connects().length - c2 === 2, j4 && [j4.status, j4.results.map((x) => x.vpn), connects().length - c2]);
  process.env.P9_MOCK_MODE = 'admin'; reset();
  r = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00304', ID.top1), quantity: 1 }] });
  const J5 = r.json.job_id; pw = await popup(); const wo5 = await waitingOrder(/administrator/i, 'NORMAL00304'); const jj5 = (await req('GET', '/api/bean/v1/jobs/' + J5, KEY)).json; closePopups();
  check('ExpressVPN unavailable (1.1.7: the order WAITS and retries, the job is not failed at once): the local order says "administrator", the job is still open, nothing is liked', !!wo5 && !!jj5 && ['queued', 'running'].includes(jj5.status) && sw.clicks.length === 0, [wo5 && wo5.waitWhy, jj5 && jj5.status, sw.clicks.length]);
  delete process.env.P9_MOCK_MODE; await req('POST', '/api/bean/v1/jobs/' + J5 + '/cancel', KEY); const j5 = await jobWait(J5, 90000);
  check('...and cancelling the job ends it "cancelled" (the waiting order is gone, nothing was ever clicked)', !!j5 && j5.status === 'cancelled' && sw.clicks.length === 0, j5 && [j5.status, j5.error, sw.clicks.length]);
  pw = await popup(); await saveVpn(pw, []); closePopups(); await sleep(2000);

  console.log('\n== 6. the YouTube Focus gate: jobs only run while Comments-only is on ==');
  await ytfToggle('commentsOnly', false); reset();
  r = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00305', ID.top1), quantity: 1 }] });
  const J6 = r.json.job_id; pw = await popup(); const wo6 = await waitingOrder(/Comments only/, 'NORMAL00305'); const jj6 = (await req('GET', '/api/bean/v1/jobs/' + J6, KEY)).json;       // (the popup stays open until the Queue panel check below)
  // 1.1.7: the popup's Queue panel also lists the API server's jobs: the running one (J6, the order is waiting for the gate) and the one queued behind it, with place in line, WAT time and the caller's note
  r = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00306', ID.top1), quantity: 1 }], note: 'YT Panel retry e2e' }); const J6b = r.json.job_id;
  const srvTxt = await wait(async () => { const t = await js(pw, "document.getElementById('orders') ? document.getElementById('orders').innerText : ''"); return /API server/.test(t) && /running now/.test(t) && /#1 in line/.test(t) && /YT Panel retry e2e/.test(t) ? t : false; }, 30000, 1000);
  if (!srvTxt) console.log('  [debug queue panel]', JSON.stringify(await js(pw, "[document.getElementById('orders') ? document.getElementById('orders').innerText : 'NO #orders', typeof pullApiJobs, document.getElementById('orders') && document.getElementById('orders').hidden]").catch((e) => String(e))).slice(0, 800));
  check('the popup Queue panel lists the API server jobs: the running one and the queued one with place in line, created time (WAT) and the note', !!srvTxt && /WAT/.test(srvTxt) && /youtu\.be\/NORMAL00306/.test(srvTxt), String(srvTxt || '').slice(0, 300));
  closePopups();
  check('gate off (1.1.7: the order WAITS until YouTube Focus is on, the job is not failed at once): the local order names "Comments only", the job is still open, nothing clicked', !!wo6 && !!jj6 && ['queued', 'running'].includes(jj6.status) && sw.clicks.length === 0, [wo6 && wo6.waitWhy, jj6 && jj6.status, sw.clicks.length]);
  await req('POST', '/api/bean/v1/jobs/' + J6b + '/cancel', KEY);
  await req('POST', '/api/bean/v1/jobs/' + J6 + '/cancel', KEY); const j6 = await jobWait(J6, 90000);
  check('...cancelling the job ends it "cancelled"; still nothing clicked', !!j6 && j6.status === 'cancelled' && sw.clicks.length === 0, j6 && [j6.status, j6.error, sw.clicks.length]);
  await ytfToggle('commentsOnly', true);

  console.log('\n== 7. cancel a running job ==');
  pw = await popup(); await js(pw, "settings.pace = 'slow'; sset(K.settings, settings); sset(K.pace, { pace: 'slow', at: Date.now() })"); closePopups(); await sleep(2500); reset();
  r = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00306', ID.top1), quantity: 2 }, { link: link('NORMAL00306', ID.top3), quantity: 2 }] }); const J7 = r.json.job_id;
  await wait(async () => { const j = (await req('GET', '/api/bean/v1/jobs/' + J7, KEY)).json; return j && j.progress && j.progress.liked >= 1; }, 240000, 800);     // 1.1.1: a like counts only after it was verified on a fresh page
  { pw = await popup(); const bp = await js(pw, "sget(K.batch).then((b) => b && [b.pace, b.job ? 1 : 0, b.items.some((i) => (i.lg || []).some((l) => l[1] === 'pace' && /Slow \\(9–20 s\\)/.test(l[2])))])"); closePopups();
    check('1.1.6.3 the API job runs at the ONE saved pace (slow): the run record says so and the item log names it', Array.isArray(bp) && bp[0] === 'slow' && bp[1] === 1 && bp[2] === true, bp); }
  const cc = await req('POST', '/api/bean/v1/jobs/' + J7 + '/cancel', KEY);
  const j7 = await jobWait(J7, 120000);
  if (!j7 || j7.status !== 'cancelled') console.log('  [debug] job7', JSON.stringify({ s: j7 && j7.status, e: j7 && j7.error, res: j7 && j7.results && j7.results.map((x) => [x.status, x.code]) }));
  check('cancel: job ends "cancelled" quickly; likes already made stay; the rest never happen', cc.status === 200 && !!j7 && j7.status === 'cancelled' && likes().length <= 2 && j7.progress.liked >= 1, j7 && [cc.json.status, j7.status, likes().length, j7.progress]);
  await sleep(25000);
  check('no further clicks after the cancel', likes().length <= 2, likes().length);
  pw = await popup(); await js(pw, "settings.pace = 'fast'; sset(K.settings, settings); sset(K.pace, { pace: 'fast', at: Date.now() })"); closePopups(); await sleep(1500);

  console.log('\n== 8. key ↔ install binding ==');
  const idB = { installId: 'bi_' + 'B'.repeat(24), token: 'bit_' + 'b'.repeat(43) };
  const regB = await req('POST', '/api/bean/agent/register', '', { install_id: idB.installId, install_token: idB.token, name: 'other-install', version: '1.1.0' });
  const KEYB = regB.json.api_key;
  await req('PUT', '/api/bean/agent/config', idB.token, { channels: ['p:zzz', 'p:yyy'], gate: 'on', vpn: { on: false, n: 0 }, name: 'other-install' });
  const jb = await req('POST', '/api/bean/v1/jobs', KEYB, { links: [link('NORMAL00399', ID.top1)] });
  check('install B (a second, fake Bean) can queue its own job', jb.status === 202, jb.json);
  const lookA = await req('GET', '/api/bean/v1/jobs/' + jb.json.job_id, KEY);
  check('key A cannot read or cancel install B\'s job (404 job_not_found), and B\'s job is not in A\'s list', lookA.status === 404 && lookA.json.error.code === 'job_not_found' && (await req('POST', '/api/bean/v1/jobs/' + jb.json.job_id + '/cancel', KEY)).status === 404 && !(await req('GET', '/api/bean/v1/jobs?limit=100', KEY)).json.jobs.some((x) => x.job_id === jb.json.job_id), lookA.status);
  check('each key sees only its own install (name, saved channels)', (await instOf()).name === 'e2e-studio pc' && (await req('GET', '/api/bean/v1/install', KEYB)).json.name === 'other-install' && (await req('GET', '/api/bean/v1/install', KEYB)).json.saved_channels === 2);
  check('install B\'s token cannot drive install A (agent routes are token-bound) and a key is not accepted as an install token', (await req('POST', '/api/bean/agent/jobs/' + J1 + '/report', idB.token, { state: 'running', results: [] })).status === 404 && (await req('GET', '/api/bean/agent/poll?wait=0', KEY)).status === 401);
  check('A\'s capacity is not affected by B\'s data', (await cap([link('NORMAL00399', ID.top1)])).capacity[0].max_likes === 4);

  console.log('\n== 9. popup as executor (Panel 9 without the runner): jobs run while Bean\'s window is open ==');
  process.env.P9_NO_BEAN_RUNNER = '1';
  check('runner switched off (test seam P9_NO_BEAN_RUNNER)', !!(await wait(() => !api.bean.runner.view, 40000, 500)));
  await sleep(16000);      // the runner's heartbeat must go stale (12 s) before a popup takes over
  pw = await popup(null, 600); await js(pw, "document.getElementById('sec-api').open = true"); await sleep(500);
  check('API section says jobs run "while this Bean window is open"', /while this Bean window is open/.test(await ui(pw, '#apibody')), await ui(pw, '#apibody'));
  reset();
  r = await req('POST', '/api/bean/v1/jobs', KEY, { links: [{ link: link('NORMAL00310', ID.top1), quantity: 1 }] });
  let j8 = await jobWait(r.json.job_id, 150000);
  check('the popup claimed and ran the job (completed, 1 click)', !!j8 && j8.status === 'completed' && likes().length === 1, j8 && [j8.status, j8.error]);
  const b8 = await batchOf(pw); check('batch owner is "popup" in this mode', !!b8 && b8.owner === 'popup' && b8.job === r.json.job_id, b8 && b8.owner);
  delete process.env.P9_NO_BEAN_RUNNER; closePopups();
  check('runner returns when the seam is removed', !!(await wait(() => api.bean.runner.view, 40000, 500)));
  await sleep(22000);

  console.log('\n== 10. regenerate, revoke, create again, restore ==');
  pw = await popup(); await js(pw, "document.getElementById('sec-api').open = true"); await sleep(300);
  await click2(pw, '#apiregen'); await wait(() => js(pw, "!!document.getElementById('apikey')"), 15000, 200);
  const KEY2 = await ui(pw, '#apikey');
  check('Regenerate: a NEW key is shown once; the old key stops working at once, the new one drives the same install', /^bean_/.test(KEY2) && KEY2 !== KEY && (await req('GET', '/api/bean/v1/install', KEY)).status === 401 && (await req('GET', '/api/bean/v1/install', KEY2)).json.install_id === apiRec.installId, [KEY2.slice(0, 9)]);
  await click(pw, '#apihide'); await sleep(300);
  const preRev = await js(pw, 'B11.S.led.stats().pairs');
  await click2(pw, '#apirevoke'); await sleep(2500);
  check('Revoke: the key is dead (401), the header says "revoked", the runner stops, queued jobs are cancelled', (await req('GET', '/api/bean/v1/install', KEY2)).status === 401 && /revoked/.test(await ui(pw, '#apisum')) && !!(await wait(() => !api.bean.runner.view, 40000, 500)), await ui(pw, '#apisum'));
  closePopups(); pw = await popup(); await js(pw, "document.getElementById('sec-api').open = true"); await sleep(300);
  await js(pw, `(() => { const n = document.getElementById('apiname'); n.value = 'e2e-studio pc'; n.dispatchEvent(new Event('input', { bubbles: true })); const bs = document.getElementById('apibase'); bs.value = ${JSON.stringify(BASE)}; bs.dispatchEvent(new Event('input', { bubbles: true })); })()`);
  await click(pw, '#apicreate'); await wait(() => js(pw, "!!document.getElementById('apikey')"), 15000, 200); const KEY3 = await ui(pw, '#apikey');
  const inst3 = (await req('GET', '/api/bean/v1/install', KEY3)).json;
  check('after a revoke the API can be created again for the SAME install (same id, ledger kept on the server)', /^bean_/.test(KEY3) && inst3.install_id === apiRec.installId && inst3.ledger_entries === preRev, [inst3 && inst3.ledger_entries, preRev]);
  await click(pw, '#apihide');
  // restore after "reinstall": wipe the local ledger AND the local API record, link with the key
  await js(pw, "chrome.storage.local.set({ 'p9bn.api': null })"); await sleep(800);
  await js(pw, "B11.S.led.clear().then(() => B11.renderLedger())"); await sleep(600);
  check('simulated reinstall: local ledger empty, no API', (await js(pw, 'B11.S.led.stats().comments')) === 0, await js(pw, 'B11.S.led.stats()'));
  closePopups(); pw = await popup(); await js(pw, "document.getElementById('sec-api').open = true"); await sleep(300);
  await click(pw, '#apilinkbtn'); await sleep(300);
  await js(pw, `(() => { const k = document.getElementById('apilinkkey'); k.value = 'bean_${'x'.repeat(43)}'; const bs = document.getElementById('apibase'); bs.value = ${JSON.stringify(BASE)}; bs.dispatchEvent(new Event('input', { bubbles: true })); })()`); await click(pw, '#apilink'); await sleep(1800);
  check('a wrong key is refused when linking (and nothing is stored)', /Unknown, revoked or replaced/.test(await ui(pw, '#apimsg')) && !(await store(pw, 'p9bn.api')), await ui(pw, '#apimsg'));
  await js(pw, `(() => { const k = document.getElementById('apilinkkey'); if (!k) { document.getElementById('apilinkbtn').click(); } })()`); await sleep(300);
  await js(pw, `(() => { const k = document.getElementById('apilinkkey'); k.value = ${JSON.stringify(KEY3)}; const bs = document.getElementById('apibase'); bs.value = ${JSON.stringify(BASE)}; bs.dispatchEvent(new Event('input', { bubbles: true })); })()`);
  await click(pw, '#apilink'); await wait(async () => (await js(pw, 'B11.S.led.stats().pairs')) > 0, 30000, 300); await sleep(1500);
  const afterLink = await js(pw, 'B11.S.led.stats()');
  check('Link with the saved key: the install is back (same id) and the ledger is RESTORED from the server', afterLink.pairs === preRev && (await store(pw, 'p9bn.api')).installId === apiRec.installId && /Ledger restored/.test(await ui(pw, '#apimsg')), [afterLink.pairs, preRev, await ui(pw, '#apimsg')]);
  console.log('  [debug] after restore: local NL', JSON.stringify(await js(pw, 'B11.S.led.used("NORMAL00301", "' + ID.top1 + '")')), 'server NL', JSON.stringify(((await srvLedger()).entries || []).filter((x) => x[0] === 'NORMAL00301').map((x) => x[2])));
  reset(); await saveSel(pw, SEL_ALL); await setLinks(pw, NL); await js(pw, "document.getElementById('go').click()"); await wait(async () => /No unused channel is left/.test(await ui(pw, '#msg')), 60000, 400); await sleep(1500);
  check('and the restored ledger blocks reuse (1.1.7: skipped WITHOUT visiting): the 4 channels of NL are not planned at all - "No unused channel is left", no click, no page load', /No unused channel is left/.test(await ui(pw, '#msg')) && sw.clicks.length === 0 && sw.hits.length === 0, [await ui(pw, '#msg'), sw.clicks.length, sw.hits.length]);
  check('TAB RULE (whole suite, UI + API + discovery + popup-executor): '+trk.total+' Bean tabs seen, never more than 3 at once (1.1.7.5), never 2 of one container, none left open', trk.maxAll <= 3 && trk.maxPerCid <= 1 && !!(await wait(() => trk.alive().length === 0, 8000)), { maxAll: trk.maxAll, over: trk.over, alive: trk.alive() }); trk.stop();
  closePopups(); try { py.kill(); } catch (_) { /* gone */ } geo.close(); await srv.close();
  console.log(`\nRESULT: ${passes} passed, ${failures} failed`);
  process.exit(failures ? 1 : 0);

  function locsOrder(locs) { return locs.map((l) => l.id); }
})().catch((e) => { console.error(e); process.exit(2); });
