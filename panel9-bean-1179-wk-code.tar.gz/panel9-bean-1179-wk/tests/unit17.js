'use strict';
// Bean 1.1.7 unit tests (node): orders model, reservation, dispatcher transitions, retries, watchdog, recycle, race repair, housekeeping, error catalogue.
// Run: node tests/unit17.js
const L = require('../lib/links.js'), O = require('../lib/orders.js'), E = require('../lib/errors.js');
const { World } = require('./sim17.js');
let pass = 0, fail = 0;
const ok = (name, c, detail) => { if (c) pass++; else { fail++; console.log('  FAIL ' + name + (detail !== undefined ? '  -> ' + JSON.stringify(detail).slice(0, 300) : '')); } };
const V1 = 'dQw4w9WgXcQ', V2 = 'abcdefghijk', LC1 = 'UgxAAAAAAAAAAAAAAAAAAAAAAAAA', LC2 = 'UgxBBBBBBBBBBBBBBBBBBBBBBBBB';
const link = (n, vid, lc, q) => ({ n, vid: vid || V1, lc: lc || LC1, quantity: q == null ? null : q, url: '' });
const mk = (opts) => { const w = new World(opts); const d = new O.Dispatcher({ store: w.store(), clock: w.clock, ports: w.ports((opts && opts.ports) || {}) }); return { w, d }; };
const run = async (w, d, ms, dt) => { dt = dt || 1000; for (let t = 0; t < ms; t += dt) { w.step(dt); await d.tick(); w.checkReservations(d.d); } };

(async () => {
  // ---------------- errors catalogue
  for (const c of Object.keys(L.CODES)) ok('catalogue has ' + c, !!E.T[c]);
  for (const c of E.codes()) { const i = E.info(c); ok('afterClick => never retried: ' + c, !(i.afterClick && i.retry !== 'none')); ok('message is plain: ' + c, !!i.message && !/[A-Za-z0-9_-]{25,}|undefined|\bat \w+\.js/.test(i.message), i.message); }
  for (const c of ['click-failed', 'like-not-kept', 'not-registered', 'click-unconfirmed', 'liked-unverified', 'click-sent-before']) ok('click outcome never retried: ' + c, E.info(c).retry === 'none' && E.info(c).afterClick);
  ok('safeToRetry not-found', E.safeToRetry({ status: 'failed', code: 'not-found' }));
  ok('safeToRetry refuses a sent item', !E.safeToRetry({ status: 'failed', code: 'not-found', sent: true }));
  ok('safeToRetry refuses when marker exists', !E.safeToRetry({ status: 'failed', code: 'not-found' }, { marker: true }));
  ok('safeToRetry refuses when ledgered', !E.safeToRetry({ status: 'failed', code: 'not-found' }, { inLedger: true }));
  ok('safeToRetry caps at 2', !E.safeToRetry({ status: 'failed', code: 'not-found', retries: 2 }));
  ok('unknown code gets a fallback', E.info('zzz').retry === 'none');

  // ---------------- reservation
  { const { w, d } = mk(); const t = w.targets; // flat = a1 a2 a3 b1 b2 c  (6)
    const r1 = await d.submit({ src: 'api', jobId: 'j1', links: [link(1, V1, LC1, 4)], targets: t });
    ok('api order reserves 4', r1.ok && r1.order.res[O.lkey(V1, LC1)].length === 4, r1);
    const r2 = await d.submit({ src: 'popup', links: [link(1, V1, LC1)], targets: t });
    ok('popup order for the same link gets only the other 2', r2.ok && r2.order.res[O.lkey(V1, LC1)].length === 2, r2.order && r2.order.res);
    const a = new Set(r1.order.res[O.lkey(V1, LC1)]), b = r2.order.res[O.lkey(V1, LC1)]; ok('no overlap', b.every((x) => !a.has(x)));
    const r3 = await d.submit({ src: 'popup', links: [link(1, V1, LC1)], targets: t });
    ok('third order: refused, says reserved', !r3.ok && r3.code === 'no_capacity' && /reserved/.test(r3.message), r3);
    const r4 = await d.submit({ src: 'popup', links: [link(1, V2, LC2)], targets: t });
    ok('another link is unaffected: all 6', r4.ok && r4.order.res[O.lkey(V2, LC2)].length === 6);
    ok('api dup job id is idempotent', (await d.submit({ src: 'api', jobId: 'j1', links: [link(1, V1, LC1, 4)], targets: t })).dup === true);
    ok('api shortfall noted', (await d.submit({ src: 'api', jobId: 'j2', links: [link(1, V2, LC2, 9)], targets: t })).short[0].missing === 9);
    await d.cancel(r1.order.id); // release
    const r5 = await d.submit({ src: 'popup', links: [link(1, V1, LC1)], targets: t });
    ok('cancel releases the reservation', r5.ok && r5.order.res[O.lkey(V1, LC1)].length === 4, r5.order && r5.order.res); }
  { const { w, d } = mk(); w.ledger.add(V1 + '|' + LC1 + '|p:a1'); w.ledger.add(V1 + '|' + LC1 + '|p:a2');
    const r = await d.submit({ src: 'popup', links: [link(1)], targets: w.targets }); ok('ledger-used channels are never reserved', r.ok && r.order.res[O.lkey(V1, LC1)].length === 4 && !r.order.res[O.lkey(V1, LC1)].includes('p:a1'), r.order && r.order.res); }
  { const { w, d } = mk(); for (let i = 0; i < 50; i++) await d.submit({ src: 'popup', links: [link(1, V1, 'Ugx' + String(i).padStart(25, 'Z'))], targets: w.targets }); const r = await d.submit({ src: 'popup', links: [link(1, V1, 'UgxQQQQQQQQQQQQQQQQQQQQQQQQQ')], targets: w.targets }); ok('queue_full at 50', !r.ok && r.code === 'queue_full'); }
  // move / cancel
  { const { w, d } = mk(); const a = (await d.submit({ src: 'popup', links: [link(1, V1, LC1)], targets: w.targets })).order, b = (await d.submit({ src: 'popup', links: [link(1, V2, LC2)], targets: w.targets })).order;
    ok('move down', (await d.move(a.id, 1)).ok && d.d.queue[0].id === b.id); ok('move up', (await d.move(a.id, -1)).ok && d.d.queue[0].id === a.id); ok('cannot move past the end', !(await d.move(b.id, 1)).ok);
    await d.tick(); ok('head started', d.d.queue[0].state === 'running'); ok('a running order cannot be moved', !(await d.move(a.id, 1)).ok && !(await d.move(b.id, -1)).ok);
    ok('cancel queued', (await d.cancel(b.id)).ok && d.find(b.id).state === 'cancelled' && d.d.queue.length === 1); }

  // ---------------- lifecycle: plain run, results, history
  { const { w, d } = mk({ seed: 5, p: { liked: 1, already: 0, notFound: 0, vpnFailed: 0, switchFailed: 0, unknown: 0, clickFailed: 0, stall: 0, crash: 0, crashAfterClick: 0 } });
    const o = (await d.submit({ src: 'popup', links: [link(1)], targets: w.targets })).order; await run(w, d, 400000);
    const h = d.find(o.id); ok('order done', h.state === 'done' && h.counts.liked === 6 && !d.d.queue.length, h && h.counts); ok('every channel liked once', w.ledger.size === 6 && !w.violations.length, w.violations);
    ok('history has rows', h.rows.length === 6); ok('finalised callback', w.finals.length === 1); ok('res released', Object.keys(h.res).length === 0); }
  // two orders on one link run one after the other, never the same channel twice
  { const { w, d } = mk({ seed: 6, p: { liked: 1, already: 0, notFound: 0, vpnFailed: 0, switchFailed: 0, unknown: 0, clickFailed: 0, stall: 0, crash: 0, crashAfterClick: 0 } });
    await d.submit({ src: 'api', jobId: 'jj', links: [link(1, V1, LC1, 3)], targets: w.targets }); await d.submit({ src: 'popup', links: [link(1)], targets: w.targets }); await d.submit({ src: 'popup', links: [link(1)], targets: w.targets });
    await run(w, d, 900000); ok('3 orders: first two done, third refused at submit', d.d.hist.length === 2 && w.ledger.size === 6 && !w.violations.length, { h: d.d.hist.length, l: w.ledger.size, v: w.violations }); }
  // API order tops up when its reservation shrank (a channel became used elsewhere)
  { const { w, d } = mk({ seed: 7, p: { liked: 1, already: 0, notFound: 0, vpnFailed: 0, switchFailed: 0, unknown: 0, clickFailed: 0, stall: 0, crash: 0, crashAfterClick: 0 } });
    const o = (await d.submit({ src: 'api', jobId: 'jt', links: [link(1, V1, LC1, 3)], targets: w.targets })).order; const first = o.res[O.lkey(V1, LC1)][0]; w.ledger.add(V1 + '|' + LC1 + '|' + first);
    await run(w, d, 400000); const h = d.find(o.id); ok('api order topped up to its quantity (3)', h.state === 'done' && h.counts.liked === 3 && w.ledger.size === 4, { st: h.state, c: h.counts, l: w.ledger.size }); }

  // ---------------- retries: safe vs never
  { const { w, d } = mk({ seed: 8, p: { liked: 0, already: 0, notFound: 1, vpnFailed: 0, switchFailed: 0, unknown: 0, clickFailed: 0, stall: 0, crash: 0, crashAfterClick: 0 } });
    const o = (await d.submit({ src: 'popup', links: [link(1)], targets: [w.targets[2]] })).order; let rounds = 0; let last = ''; for (let t = 0; t < 900000; t += 1000) { w.step(1000); await d.tick(); if (o.round !== rounds) rounds = o.round; }
    const h = d.find(o.id); ok('not-found is retried twice then fails typed', h.state === 'failed' && (h.err || {}).code === 'not-found' && rounds === 2 && w.stats.batches === 3, { st: h.state, e: h.err, rounds, b: w.stats.batches }); }
  { const { w, d } = mk({ seed: 9, p: { liked: 0, already: 0, notFound: 0, vpnFailed: 0, switchFailed: 0, unknown: 0, clickFailed: 1, stall: 0, crash: 0, crashAfterClick: 0 } });
    const o = (await d.submit({ src: 'popup', links: [link(1)], targets: [w.targets[2]] })).order; await run(w, d, 400000); const h = d.find(o.id);
    ok('click-failed is NEVER retried (exactly one batch, one click)', h.state === 'failed' && w.stats.batches === 1 && w.stats.clicks === 1 && h.err.code === 'click-failed', { b: w.stats.batches, c: w.stats.clicks, e: h.err }); }
  { const { w, d } = mk({ seed: 10, ports: { markerExists: async () => true }, p: { liked: 0, already: 0, notFound: 1, vpnFailed: 0, switchFailed: 0, unknown: 0, clickFailed: 0, stall: 0, crash: 0, crashAfterClick: 0 } });
    const o = (await d.submit({ src: 'popup', links: [link(1)], targets: [w.targets[2]] })).order; await run(w, d, 300000);
    ok('a like marker blocks the retry', d.find(o.id).state === 'failed' && w.stats.batches === 1, { b: w.stats.batches }); }
  // machine-wide wait: Focus off at start -> waiting with back-off, starts when back on, queue held meanwhile
  { const { w, d } = mk({ seed: 11, p: { liked: 1, already: 0, notFound: 0, vpnFailed: 0, switchFailed: 0, unknown: 0, clickFailed: 0, stall: 0, crash: 0, crashAfterClick: 0 } }); w.focusOff = true;
    const o = (await d.submit({ src: 'api', jobId: 'jf', links: [link(1, V1, LC1, 2)], targets: w.targets })).order; const o2 = (await d.submit({ src: 'popup', links: [link(1, V2, LC2)], targets: w.targets })).order;
    await run(w, d, 5000); ok('waiting, with a plain reason', d.find(o.id).state === 'waiting' && /Focus/.test(d.find(o.id).waitWhy), d.find(o.id).waitWhy); ok('queue held behind it', d.find(o2.id).state === 'queued');
    w.focusOff = false; await run(w, d, 100000); ok('still waiting until the back-off is over', d.find(o.id).state === 'waiting' || d.find(o.id).state === 'running'); await run(w, d, 900000);
    ok('both finish after Focus is back', d.find(o.id).state === 'done' && d.find(o2.id).state === 'done', [d.find(o.id).state, d.find(o2.id).state]); }
  { const { w, d } = mk({ seed: 12 }); w.focusOff = true; const o = (await d.submit({ src: 'api', jobId: 'jg', links: [link(1, V1, LC1, 2)], targets: w.targets })).order;
    await run(w, d, 5 * 3600000, 10000); const h = d.find(o.id); ok('Focus never back: fails typed after the waits', h.state === 'failed' && h.err.code === 'focus_off' && h.tries > O.C.MAX_WAITS - 1, { st: h.state, e: h.err, t: h.tries }); }
  // interruption: the tab dies every time -> retried, then tab-lost; likes sent before the crash are not repeated
  { const { w, d } = mk({ seed: 13, p: { liked: 1, already: 0, notFound: 0, vpnFailed: 0, switchFailed: 0, unknown: 0, clickFailed: 0, stall: 0, crash: 0.6, crashAfterClick: 0.2 } });
    const o = (await d.submit({ src: 'popup', links: [link(1), link(2, V2, LC2)], targets: w.targets })).order; await run(w, d, 6 * 3600000, 2000);
    const h = d.find(o.id); ok('order ends (never stuck)', !!h && !O.isOpen(h), h && h.state); ok('no double like under crashes', !w.violations.length, w.violations); }
  // the run record vanished (cleared / Panel 9 restart before the write)
  { const { w, d } = mk({ seed: 14 }); const o = (await d.submit({ src: 'popup', links: [link(1)], targets: w.targets })).order; await d.tick(); w.batch = null; await run(w, d, 30000);
    ok('a vanished run record ends the order typed', d.find(o.id).state === 'failed' && d.find(o.id).err.code === 'interrupted_order', d.find(o.id)); }
  // user cancel of the running order
  { const { w, d } = mk({ seed: 15, p: { liked: 1, already: 0, notFound: 0, vpnFailed: 0, switchFailed: 0, unknown: 0, clickFailed: 0, stall: 0, crash: 0, crashAfterClick: 0 } });
    const o = (await d.submit({ src: 'popup', links: [link(1)], targets: w.targets })).order; await run(w, d, 60000); await d.cancel(o.id); await run(w, d, 30000); ok('running order cancelled', d.find(o.id).state === 'cancelled' && !w.violations.length && w.stats.batches === 1, d.find(o.id).state); }
  // inbox
  { const { w, d } = mk(); const io = w.store(); await io.set(O.INBOX, [{ id: 'r1', op: 'submit', spec: { links: [link(1)], targets: w.targets } }, { id: 'r1', op: 'submit', spec: { links: [link(1, V2, LC2)], targets: w.targets } }]);
    let p = await O.pump(d, io, 'popup'); ok('pump takes the lease and consumes once', p.held && d.d.queue.length === 1); await O.pump(d, io, 'popup'); ok('same request id is never applied twice', d.d.queue.length === 1);
    const d2 = new O.Dispatcher({ store: io, clock: w.clock, ports: w.ports() }); ok('a second page does not run while the lease is fresh', !(await O.pump(d2, io, 'runner')).held);
    w.t += 11000; ok('lease taken over when stale', (await O.pump(d2, io, 'runner')).held && d2.d.queue.length === 1, d2.d.queue.length); }


  // ---------------- quantity (1.1.7): popup and API orders share one logic
  const CLEAN = { liked: 1, already: 0, notFound: 0, vpnFailed: 0, switchFailed: 0, unknown: 0, clickFailed: 0, stall: 0, crash: 0, crashAfterClick: 0 };
  { const t = [{ id: 'A', name: 'A', active: 'a1', channels: [{ id: 'a1', name: 'A1' }, { id: 'a2', name: 'A2' }, { id: 'a3', name: 'A3' }] }, { id: 'B', name: 'B', active: 'b1', channels: [{ id: 'b1', name: 'B1' }, { id: 'b2', name: 'B2' }] }, { id: 'C', name: 'C' }];
    const flat = O.flatChannels(t), ids = (l) => l.map((f) => f.chid || f.cid).join(',');
    ok('q=2: each container\'s ACTIVE channel (no switch at all: a switch now costs a sign-in and a fresh tab) beats a 2nd channel of one container', ids(O.pickChannels(flat, 2)) === 'a1,b1', ids(O.pickChannels(flat, 2)));
    ok('q=4: all three active channels first (A, B, C), then exactly one switch', (() => { const r = O.pickChannels(flat, 4); return r.length === 4 && ['a1', 'b1', 'C'].every((x) => ids(r).split(',').includes(x)); })(), ids(O.pickChannels(flat, 4)));
    ok('q=3: the three active channels, no switch', ids(O.pickChannels(flat, 3)) === 'a1,b1,C', ids(O.pickChannels(flat, 3)));
    ok('q>=all: everything', O.pickChannels(flat, 99).length === 6 && O.pickChannels(flat, null).length === 6);
    const t2 = [{ id: 'A', name: 'A', active: 'a2', channels: [{ id: 'a1', name: 'A1' }, { id: 'a2', name: 'A2' }] }, { id: 'B', name: 'B', active: 'b1', channels: [{ id: 'b1', name: 'B1' }] }];
    ok('prefers the channel the page is on (a2 before a1)', ids(O.pickChannels(O.flatChannels(t2), 1)) === 'a2', ids(O.pickChannels(O.flatChannels(t2), 1)));
    const t3 = [{ id: 'A', name: 'A', channels: [{ id: 'a1', name: 'A1' }] }, { id: 'B', name: 'B', channels: [{ id: 'b1', name: 'B1' }] }, { id: 'C', name: 'C', channels: [{ id: 'c1', name: 'C1' }] }];
    ok('single-channel containers: spreads across containers (nothing else to choose)', O.pickChannels(O.flatChannels(t3), 2).length === 2); }
  // ---- 1.1.7.1 PREFER ACTIVE CHANNEL: selection order
  { const ids = (l) => l.map((f) => f.chid || f.cid).join(',');
    const tB = [{ id: 'A', name: 'A', channels: [{ id: 'a1', name: 'A1' }, { id: 'a2', name: 'A2' }] }, { id: 'B', name: 'B', active: 'b2', channels: [{ id: 'b1', name: 'B1' }, { id: 'b2', name: 'B2' }] }];
    ok('1.1.7.1 q=1: the active channel of the LATER container (b2) is taken, not the first channel of the first container (a switch)', ids(O.pickChannels(O.flatChannels(tB), 1)) === 'b2', ids(O.pickChannels(O.flatChannels(tB), 1)));
    const tC = [{ id: 'A', name: 'A', active: 'a1', channels: [{ id: 'a1', name: 'A1' }, { id: 'a2', name: 'A2' }, { id: 'a3', name: 'A3' }] }, { id: 'B', name: 'B', active: 'b1', channels: [{ id: 'b1', name: 'B1' }, { id: 'b2', name: 'B2' }] }];
    ok('1.1.7.1 q=2 with two active channels: both active, zero switches', ids(O.pickChannels(O.flatChannels(tC), 2)) === 'a1,b1');
    const r3 = O.pickChannels(O.flatChannels(tC), 3); ok('1.1.7.1 q=3: both active channels FIRST, then exactly one switch-needing channel', r3.length === 3 && ids(r3).indexOf('a1') >= 0 && ids(r3).indexOf('b1') >= 0, ids(r3));
    ok('1.1.7.1 switch-needing channels only when the active ones are not enough (q=2 never takes a2/b2)', !/a2|a3|b2/.test(ids(O.pickChannels(O.flatChannels(tC), 2))));
    const tD = [{ id: 'A', name: 'A', channels: [{ id: 'a1', name: 'A1', }, { id: 'a2', name: 'A2' }] }, { id: 'B', name: 'B', channels: [{ id: 'b1', name: 'B1' }] }];
    const fD = O.flatChannels(tD).map((f) => Object.assign({}, f, { act: true }));      // a broken caller that marks two channels of one container active
    ok('1.1.7.1 never two active channels of one container: only the first one counts (q=2 over A(a1,a2 both flagged) + B -> a1,b1)', ids(O.pickChannels(fD, 2)) === 'a1,b1', ids(O.pickChannels(fD, 2)));
    ok('1.1.7.1 a container without a channel list counts as active (no switch is ever needed there)', ids(O.pickChannels(O.flatChannels([{ id: 'A', name: 'A', channels: [{ id: 'a1', name: 'A1' }, { id: 'a2', name: 'A2' }] }, { id: 'C', name: 'C' }]), 1)) === 'C');
    // spare fill after failures: the container's remaining channels are offered through the same order (the active one first)
    const sp = O.pickChannels(O.flatChannels(tC).filter((f) => f.chid !== 'a1'), 1); ok('1.1.7.1 spare fill: when A\'s active channel failed, B\'s active channel comes before any switch in A', ids(sp) === 'b1', ids(sp));
    // the stored "last confirmed active channel" beats an older channel-list read; an unknown id is ignored; the answer is one id
    const L1 = L, ce = { ok: true, at: 100, active: 'x1', channels: [{ id: 'x1' }, { id: 'x2' }] };
    ok('1.1.7.1 activeChannel: the newer record wins (stored x2 at 200 beats the list read x1 at 100)', L1.activeChannel(ce, { id: 'x2', at: 200 }) === 'x2');
    ok('1.1.7.1 activeChannel: an older stored record loses to a newer channel-list read', L1.activeChannel(ce, { id: 'x2', at: 50 }) === 'x1');
    ok('1.1.7.1 activeChannel: a stored id that is not in the list is ignored; nothing known = ""', L1.activeChannel(ce, { id: 'zz', at: 999 }) === 'x1' && L1.activeChannel(null, null) === '' && L1.activeChannel({ ok: true, channels: [{ id: 'x1' }] }, { id: 'x1', at: 5 }) === 'x1'); }
  { const { w, d } = mk({ seed: 21, p: CLEAN }); const r = await d.submit({ src: 'popup', links: [link(1, V1, LC1, 3)], targets: w.targets }); ok('popup quantity 3 reserves exactly 3', r.ok && r.order.res[O.lkey(V1, LC1)].length === 3, r.order && r.order.res);
    await run(w, d, 400000); const h = d.find(r.order.id); ok('popup order with quantity 3 stops at 3 likes', h.state === 'done' && h.counts.liked === 3 && w.ledger.size === 3, { s: h.state, c: h.counts, l: w.ledger.size }); }
  { const { w, d } = mk({ seed: 22, p: CLEAN }); w.failCks = new Set(['p:a1']); const r = await d.submit({ src: 'popup', links: [link(1, V1, LC1, 3)], targets: w.targets }); const first = r.order.res[O.lkey(V1, LC1)].slice();
    await run(w, d, 900000); const h = d.find(r.order.id); ok('a failed channel is replaced by a spare: target reached, failed one clicked exactly once', h.state === 'done' && h.counts.liked === 3 && w.clicks.get(V1 + '|' + LC1 + '|p:a1') === 1 && !w.violations.length, { s: h.state, c: h.counts, first, v: w.violations });
    ok('the replacement is a channel that was not in the first pick', [...w.ledger].every((k) => k.indexOf('p:a1') < 0) && w.ledger.size === 3); }
  { const { w, d } = mk({ seed: 23, p: CLEAN }); w.failCks = new Set(['p:a1', 'p:a2', 'p:a3', 'p:b1']); const r = await d.submit({ src: 'popup', links: [link(1, V1, LC1, 5)], targets: w.targets });
    await run(w, d, 2000000); const h = d.find(r.order.id); ok('shortfall: 2 liked of 5, reported clearly, nothing clicked twice', h.state === 'partial' && h.counts.liked === 2 && h.err.code === 'shortfall' && /2 of 5/.test(h.err.message) && !w.violations.length && h.shortfall[0].want === 5, { s: h.state, e: h.err, c: h.counts, v: w.violations }); }
  { const { w, d } = mk({ seed: 24, p: CLEAN }); const r = await d.submit({ src: 'popup', links: [link(1, V1, LC1, 99)], targets: w.targets }); ok('quantity above what exists: clamped to what exists, shortfall noted', r.ok && r.order.res[O.lkey(V1, LC1)].length === 6 && r.short[0].missing === 93, r.short); }
  { const { w, d } = mk({ seed: 25, p: CLEAN }); const o1 = (await d.submit({ src: 'popup', links: [link(1, V1, LC1, 2)], targets: w.targets })).order, o2 = (await d.submit({ src: 'api', jobId: 'q2', links: [link(1, V1, LC1, 2)], targets: w.targets })).order;
    const a = o1.res[O.lkey(V1, LC1)], b = o2.res[O.lkey(V1, LC1)]; ok('two quantity orders on one link reserve disjoint channels', a.length === 2 && b.length === 2 && a.every((x) => !b.includes(x)));
    w.failCks = new Set([a[0]]); await run(w, d, 1500000); ok('spare for order 1 never steals order 2\'s reservation, both reach their target', d.find(o1.id).counts.liked === 2 && d.find(o2.id).counts.liked === 2 && w.ledger.size === 4 && !w.violations.length, { s: [d.find(o1.id).state, d.find(o2.id).state], l: w.ledger.size, v: w.violations }); }
  { const { w, d } = mk({ seed: 26, p: CLEAN }); w.signedOut = new Set(['A']); const r = await d.submit({ src: 'popup', links: [link(1, V1, LC1, 3)], targets: w.targets }); await run(w, d, 1500000); const h = d.find(r.order.id);
    ok('a signed-out container is skipped for spares (no wasted attempts there)', h.counts.liked === 3 && w.ledger.size === 3 && [...w.ledger].every((k) => !/p:a/.test(k)), { c: h.counts, l: [...w.ledger] }); }
  { const { w, d } = mk({ seed: 27, p: CLEAN }); const r = await d.submit({ src: 'popup', links: [link(1, V1, LC1, 2), link(2, V2, LC2)], targets: w.targets }); const rs = r.order.res; ok('per-link quantity: link 1 = 2, link 2 = all', rs[O.lkey(V1, LC1)].length === 2 && rs[O.lkey(V2, LC2)].length === 6);
    await run(w, d, 900000); const h = d.find(r.order.id); ok('mixed order done', h.state === 'done' && h.counts.liked === 8, h.counts); }

  // ---------------- watchdog / recycle
  { const b = { id: 'x', state: 'running', groups: [{ cid: 'A', status: 'running', openedAt: 0 }], items: [{ cid: 'A', status: 'running', at: 1000, hb: 5e5 }, { cid: 'A', status: 'queued' }], updated: 5e5 };
    ok('no stall before the limit', !O.watchdog(b, 1000 + O.C.STALL_MS - 1).changed);
    const r = O.watchdog(b, 1000 + O.C.STALL_MS + 5); ok('stalled item goes back to queue, tab recycled', r.changed && b.items[0].status === 'queued' && b.groups[0].status === 'queued' && b.groups[0].recycle === 1);
    b.groups[0].status = 'running'; b.items[0].status = 'running'; b.items[0].at = 10; const r2 = O.watchdog(b, 10 + O.C.STALL_MS + 5); ok('second stall fails it as "stalled", nothing clicked', b.items[0].status === 'failed' && b.items[0].code === 'stalled');
    const b2 = { id: 'y', state: 'running', groups: [{ cid: 'A', status: 'running' }], items: [{ cid: 'A', status: 'running', at: 10, sent: true }], updated: 1 }; O.watchdog(b2, 10 + O.C.STALL_MS + 5); ok('a stalled item after the click is counted, never re-queued', b2.items[0].status === 'liked' && b2.items[0].code === 'liked-unverified');
    const b3 = { id: 'z', state: 'running', pauseReq: 1, pause: { since: 1 }, groups: [{ cid: 'A', status: 'running' }], items: [{ cid: 'A', status: 'running', at: 10 }], updated: 1 }; ok('paused runs are never stalled', !O.watchdog(b3, 1e9).changed); }
  // ---------------- a tab that disappears mid-step (closed / expired by Panel 9 after 20 min)
  { const mkb = () => ({ id: 't', state: 'running', groups: [{ cid: 'A', status: 'running', tab: 7 }, { cid: 'B', status: 'queued' }], items: [{ cid: 'A', status: 'running', at: 1000 }, { cid: 'A', status: 'queued' }, { cid: 'B', status: 'queued' }], updated: 1 });
    let b = mkb(); const r = O.tabGone(b, 5000); ok('tab gone: group back to the queue (fresh tab), open item queued again, others untouched', r.changed && b.groups[0].status === 'queued' && b.groups[0].recycle === 1 && b.groups[0].tab === undefined && b.items[0].status === 'queued' && b.items[0].tabGone === 1 && b.items[1].status === 'queued' && b.groups[1].status === 'queued');
    b = mkb(); b.items[0].sent = true; O.tabGone(b, 5000); ok('tab gone AFTER the like was sent: counted "like sent - not confirmed", never queued again', b.items[0].status === 'liked' && b.items[0].code === 'liked-unverified');
    b = mkb(); b.items[0].verify = 1; O.tabGone(b, 5000); ok('tab gone while verifying: counted, never queued again', b.items[0].status === 'liked' && b.items[0].code === 'liked-unverified');
    b = mkb(); for (let k = 0; k < O.C.MAX_TABLOST; k++) { b.groups[0].status = 'running'; b.items[0].status = b.items[0].status === 'failed' ? 'failed' : 'running'; O.tabGone(b, 5000 + k); }
    ok('tab gone again and again: the item ends "tab-lost" (nothing clicked), not endless', b.items[0].status === 'failed' && b.items[0].code === 'tab-lost');
    ok('tab-lost has a message', /lost its YouTube tab/.test(E.message('tab-lost')));
    b = mkb(); b.state = 'done'; ok('a finished run is never touched', !O.tabGone(b, 5000).changed); }
  { const items = Array.from({ length: 40 }, () => ({ cid: 'A', status: 'liked', at: 100 })).concat([{ cid: 'A', status: 'queued' }]); ok('recycle after 40 items', O.shouldRecycle({ cid: 'A', openedAt: 50 }, items, 200)); ok('no recycle after 5', !O.shouldRecycle({ cid: 'A', openedAt: 50 }, items.slice(0, 5), 200));
    ok('recycle after 15 min (Panel 9 2.3.23 expires a background tab at 20)', O.shouldRecycle({ cid: 'A', openedAt: 50 }, items.slice(0, 5), 50 + O.C.RECYCLE_MS + 1)); }
  { const its = [{ status: 'running', sent: true }, { status: 'running' }, { status: 'queued' }]; O.endItems(its, 5); ok('endItems: sent -> liked-unverified, running -> interrupted, queued -> not-started', its[0].code === 'liked-unverified' && its[1].code === 'interrupted' && its[2].code === 'not-started'); }

  // ---------------- race repair
  { const make = (lossy) => { let rec = { id: 'r', rev: 0, items: [{ status: 'running' }, { status: 'queued' }], state: 'running' }; let drop = lossy; const old = JSON.stringify(rec);
      return { get: async () => JSON.parse(JSON.stringify(rec)), set: async (v) => { if (drop > 0) { drop--; rec = JSON.parse(old); rec.rev = 99; return; } rec = JSON.parse(JSON.stringify(v)); }, sleep: async () => {}, peek: () => rec }; };
    const io = make(2); const r = await O.writeVerified(io, 'r', (rec) => { rec.items[0].status = 'liked'; return { items: { 0: { status: 'liked' } } }; });
    ok('a write lost twice to stale mirrors is re-applied and verified', r.ok && r.n === 3 && io.peek().items[0].status === 'liked', r);
    const io2 = make(5); const r2 = await O.writeVerified(io2, 'r', (rec) => { rec.items[0].status = 'liked'; return { items: { 0: { status: 'liked' } } }; }); ok('gives up after 3 tries and says so', !r2.ok && r2.why === 'lost');
    const io3 = make(0); ok('no loss: one write', (await O.writeVerified(io3, 'r', (rec) => { rec.state = 'done'; return { batch: { state: 'done' } }; })).n === 1); }

  // ---------------- housekeeping
  { const w = new World(); const now = w.t; for (let i = 0; i < 300; i++) w.kv.set('p9bn.clk.k' + i, { at: now - (i % 2 ? 70 : 10) * 86400000 }); w.kv.set('p9bn.chstale.A', { at: now - 2 * 86400000, ids: [] });
    w.kv.set('p9bn.runs', Array.from({ length: 9 }, (_, i) => ({ id: 'r' + i, big: 'x'.repeat(200000) }))); w.kv.set('p9bn.tabidx', Array.from({ length: 100 }, (_, i) => ({ id: i, at: now - (i < 50 ? 10 : 7 * 3600000) })));
    w.kv.set('p9bn.ledrm', new Array(25000).fill(['v', 'l', 'c'])); const s = await O.housekeeping(w.raw(), now);
    ok('markers older than 60 days pruned', s.markers === 150 && ![...w.kv.keys()].some((k) => /^p9bn\.clk\.k\d*[13579]$/.test(k)), s); ok('stale flags pruned', !w.kv.has('p9bn.chstale.A')); ok('runs capped', w.kv.get('p9bn.runs').length <= 5 && JSON.stringify(w.kv.get('p9bn.runs')).length <= O.C.RUNS_BYTES, w.kv.get('p9bn.runs').length);
    ok('tab registry pruned', w.kv.get('p9bn.tabidx').length === 50); ok('ledrm capped', w.kv.get('p9bn.ledrm').length === 20000); }


  // ---------------- CP2: wiring (static) + rev-based repair
  { const fs = require('fs'), rd = (f) => fs.readFileSync(require('path').join(__dirname, '..', f), 'utf8'), ct = rd('content.js'), pj = rd('popup.js'), ui = rd('ui17.js'), ph = rd('popup.html'), e17 = rd('ext17.js');
    ok('tab recycle: content.js numbers equal lib/orders.js C', new RegExp('RECYCLE_ITEMS = ' + O.C.RECYCLE_ITEMS + ', RECYCLE_MS = ' + (O.C.RECYCLE_MS / 60000) + ' \\* 60000').test(ct), [O.C.RECYCLE_ITEMS, O.C.RECYCLE_MS]);
    ok('tab recycle: sits before the next item and never after a like was sent (no click in the slice)', (() => { const a = ct.indexOf("await holdIfPaused('before the next item')"), b = ct.indexOf('clearInterval(poll); stripToken(); return;', a); return a > 0 && b > a && !/\.click\(/.test(ct.slice(a, b)); })());
    ok('popup advance: recycled tab is a new tab key; toOpen carries it', /next\.recycle \|\| 0/.test(pj) && /opened\.delete\(toOpen\.okey\)/.test(pj));
    ok('popup: go is never blocked by a running run (queue instead); stop cancels the order', !/A run is already in progress/.test(pj.slice(pj.indexOf('async function goInner'), pj.indexOf('async function goDirect') > 0 ? pj.indexOf('async function goInner') + 3500 : 0)) && /B17\.request\(\{ op: 'submit'/.test(pj) && /op: 'cancel', oid: b\.order/.test(pj));
    ok('popup: runner/popup adoption of a dead owner', /gone: this \$\{ROLE\} page continues/.test(pj) && /p9bn\.pbeat/.test(pj) && /p9bn\.pbeat/.test(e17));
    ok('popup: mutate bumps rev and verifies per field', /b\.rev = \(b\.rev \|\| 0\) \+ 1/.test(pj) && /verifyWrite\(before, b\)/.test(pj) && /NEVER writes the run record/.test(ct) && !/sset\(K\.batch/.test(ct.replace(/\/\/.*$/gm, '')));
    ok('ui17: no innerHTML / insertAdjacentHTML / eval, only textContent', !/innerHTML|insertAdjacentHTML|eval\(|new Function/.test(ui));
    ok('popup.html loads ui17 after ext17 and has #orders, #qall', ph.indexOf('ui17.js') > ph.indexOf('ext17.js') && /id="orders"/.test(ph) && /id="qall"/.test(ph)); }
  { const a = { id: 'b', rev: 3, state: 'running', x: 1, items: [{ status: 'queued', lg: [1] }, { status: 'queued' }], groups: [{ status: 'queued' }] };
    const b = JSON.parse(JSON.stringify(a)); b.rev = 4; b.items[1].status = 'running'; b.groups[0].status = 'opening'; b.x = 2;
    const w = O.diffWant(a, b); ok('diffWant: batch, items, groups', w.batch.x === 2 && w.items[1].status === 'running' && w.groups[0].status === 'opening' && !w.items[0]);
    const stale = JSON.parse(JSON.stringify(a)); // older copy came back
    const pl = O.repairPlan(stale, b, w); ok('older copy (lower rev) => repair', pl.act === 'repair' && pl.miss.length >= 3, pl);
    O.applyWant(stale, w); ok('applyWant puts back exactly the changed fields', stale.items[1].status === 'running' && stale.groups[0].status === 'opening' && stale.x === 2 && stale.items[0].status === 'queued');
    const newer = JSON.parse(JSON.stringify(b)); newer.rev = 5; newer.groups[0].status = 'running'; ok('record with a higher rev is never overwritten', O.repairPlan(newer, b, w).act === 'none');
    ok('intact record => nothing to do', O.repairPlan(JSON.parse(JSON.stringify(b)), b, w).act === 'none'); }

  // ---------------- 1.1.7 a tab that goes silent is REOPENED (max 2), not failed
  { const mkb = () => ({ id: 'r', state: 'running', graceUntil: 5, groups: [{ cid: 'A', name: 'Ann', status: 'running', tab: 7, openedAt: 100 }, { cid: 'B', status: 'queued' }], items: [{ cid: 'A', status: 'running', at: 1000, vpn: { location: 'Lagos' } }, { cid: 'A', status: 'queued' }, { cid: 'B', status: 'queued' }], updated: 1 });
    let b = mkb(); let r = O.reopenGroup(b, b.groups[0], 9000, { seen: false });
    ok('stale: the group goes back to the queue (recycle+1, tab dropped), nothing fails', r.reopened && b.groups[0].status === 'queued' && b.groups[0].recycle === 1 && !('tab' in b.groups[0]) && b.groups[0].reopens === 1 && b.items.every((it) => it.status === 'queued') && !b.items.some((it) => it.code));
    ok('stale: the item keeps its VPN location (no rotation) and records the reopen', b.items[0].vpn.location === 'Lagos' && b.items[0].reopened === 1 && b.graceUntil === 0 && /fresh tab/.test(b.items[0].lg.map((x) => x[2]).join(' ')));
    b = mkb(); b.items[0].sent = true; O.reopenGroup(b, b.groups[0], 9000, { seen: true }); ok('stale AFTER the like was sent (1.1.7.1): the item goes back to the queue to be only VERIFIED in a fresh tab (sent kept, never a click path), not given up at once', b.items[0].status === 'queued' && b.items[0].sent && b.items[0].verify && b.items[0].vrq === 1 && !b.items[0].code && b.groups[0].status === 'queued');
    b.items[0].status = 'running'; O.reopenGroup(b, b.groups[0], 9100, { seen: true }); b.items[0].status = 'running'; b.groups[0].reopens = 1; O.reopenGroup(b, b.groups[0], 9200, { seen: true }); ok('...after 2 verify-only reopens the silent like is counted "liked-unverified" (never queued again)', b.items[0].status === 'liked' && b.items[0].code === 'liked-unverified' && b.items[0].vrq >= 1);          // 1.1.7.2: MAX_REOPENS 1
    b = mkb(); b.items[0].verify = 1; O.reopenGroup(b, b.groups[0], 9000, {}); ok('stale while verifying (1.1.7.1): a fresh tab verifies again, never clicks', b.items[0].status === 'queued' && b.items[0].verify && !b.items[0].code);
    b = mkb(); const g = b.groups[0]; O.reopenGroup(b, g, 9000, {}); g.status = 'running'; b.items[0].status = 'running'; O.reopenGroup(b, g, 9100, {}); ok('1.1.7.2: ONE reopen only: the second silence ends the container (its items fail plainly, the run moves on)', g.reopens === 2 && g.status === 'done' && b.items[0].status === 'failed');
    g.status = 'running'; b.items[0].status = 'running'; r = O.reopenGroup(b, g, 9200, { seen: false });
    ok('after 2 reopens the third silence ends the items: "never answered" message, group done', r.ended && g.status === 'done' && b.items[0].status === 'failed' && b.items[0].code === 'interrupted' && /never answered/.test(b.items[0].msg) && b.items[1].code === 'not-started' && /never answered/.test(b.items[1].msg) && b.items[2].status === 'queued');
    b = mkb(); b.groups[0].reopens = 2; O.reopenGroup(b, b.groups[0], 9000, { seen: true }); ok('seen marker present => message says "went quiet after it started"', /went quiet after it started/.test(b.items[1].msg) && !/never answered/.test(b.items[1].msg));
    b = mkb(); b.groups[0].reopens = 2; b.items[0].sent = true; O.reopenGroup(b, b.groups[0], 9000, { seen: true }); ok('ended group: a sent like stays "liked-unverified" (counted once)', b.items[0].code === 'liked-unverified');
    ok('open grace (1.1.7.2): 45 s normally, 60 s when a VPN rotation finished <= 30 s ago', O.openGraceMs(0, 1e6) === 45000 && O.openGraceMs(1e6 - 40000, 1e6) === 45000 && O.openGraceMs(1e6 - 20000, 1e6) === 60000 && O.C.OPEN_GRACE_VPN_MS === 60000 && O.C.MAX_REOPENS === 1);
    ok('no container message still says "tab stopped answering"', !/tab stopped answering|tab went quiet before this item began/.test(require('fs').readFileSync(require('path').join(__dirname, '..', 'lib', 'orders.js'), 'utf8') + require('fs').readFileSync(require('path').join(__dirname, '..', 'popup.js'), 'utf8') + require('fs').readFileSync(require('path').join(__dirname, '..', 'lib', 'links.js'), 'utf8')));
    const Lk = require('../lib/links.js'), E = require('../lib/errors.js'), cs = require('../content.js'.replace('content.js','manifest.json')), gj = require('fs').readFileSync(require('path').join(__dirname, '..', 'google.js'), 'utf8');
    ok('google-check: plain words, known error code, hint', Lk.gcheckMsg('Ann') === 'Google asked container Ann to sign in or verify; open it once and complete it.' && E.info('google-check').type === 'account' && /Google/.test(Lk.label('google-check')) && Lk.googleHost('accounts.google.com') && Lk.googleHost('consent.youtube.com') && !Lk.googleHost('www.youtube.com') && !Lk.googleHost('evilaccounts.google.com'));
    const gm = cs.content_scripts.find((c) => c.js.indexOf('google.js') >= 0), ym = cs.content_scripts.find((c) => c.js.indexOf('content.js') >= 0);
    ok('manifest: google.js only on accounts.google.com + consent.youtube.com, YouTube script unchanged', gm && gm.matches.length === 2 && gm.matches.indexOf('https://accounts.google.com/*') >= 0 && gm.matches.indexOf('https://consent.youtube.com/*') >= 0 && ym.matches.length === 1 && ym.matches[0] === 'https://www.youtube.com/*' && cs.host_permissions.indexOf('https://accounts.google.com/*') >= 0 && cs.host_permissions.indexOf('https://consent.youtube.com/*') >= 0);
    ok('google.js never clicks or types (no click/submit/value/dispatchEvent)', !/\.click\(|\.submit\(|\.value\s*=|dispatchEvent|keydown|\.focus\(/.test(gj)); }
  // ---------------- 1.1.7 split writers (lib/reports.js)
  { const R = require('../lib/reports.js'), J = (o) => JSON.parse(JSON.stringify(o));
    const rec = () => ({ id: 'b', state: 'running', rev: 1, updated: 1, pace: 'fast', items: [{ cid: 'A', status: 'queued' }, { cid: 'A', status: 'queued' }, { cid: 'B', status: 'queued' }], groups: [{ cid: 'A', status: 'opening', tab: 5, openedAt: 100 }, { cid: 'B', status: 'queued' }], events: [] });
    // the tab: reads, changes, reports a delta (never the record)
    const a = rec(), t = J(a); t.items[0].status = 'running'; t.items[0].hb = 9; t.groups[0].status = 'running'; (t.events = t.events || []).push([5, 'x']); t.graceUntil = 5000 + 3000;
    const d = R.delta(a, t, 5000); ok('delta: only changed fields, appended events, a grace in ms (record age fields are never reported)', JSON.stringify(d.items) === '{"0":{"status":"running","hb":9}}' && JSON.stringify(d.groups) === '{"A":{"status":"running"}}' && d.events.length === 1 && d.graceMs === 3000 && !('updated' in d.top) && !('rev' in d.top), d);
    const rep = R.mergeInto(R.emptyRep(10), d); rep.seq = 1;
    // the runner merges: group fields the runner wrote (tab id, openedAt) are NOT lost, whatever the tab saw
    const r1 = rec(); const n = R.apply(r1, R.diffRep(null, rep)); ok('apply: the tab\'s changes arrive, the runner\'s own group fields (tab id, openedAt) stay', n > 0 && r1.items[0].status === 'running' && r1.groups[0].status === 'running' && r1.groups[0].tab === 5 && r1.groups[0].openedAt === 100 && r1.events.length === 1, r1);
    // a finished item is never touched (a failed / liked item stays; an OLD report cannot un-finish it)
    const r2 = rec(); r2.items[0] = { cid: 'A', status: 'failed', code: 'interrupted' }; R.apply(r2, R.diffRep(null, rep)); ok('apply: a finished item is never changed back to running', r2.items[0].status === 'failed' && r2.items[0].code === 'interrupted');
    const r3 = rec(); r3.groups[0].status = 'done'; R.apply(r3, R.diffRep(null, rep)); ok('apply: a finished group stays finished', r3.groups[0].status === 'done');
    const r4 = rec(); r4.state = 'stopped'; ok('apply: a run that is over takes nothing', R.apply(r4, R.diffRep(null, rep)) === 0 && r4.items[0].status === 'queued');
    // replaying the SAME report (stale mirror copy re-delivered) changes nothing the second time; an old cumulative value is not re-applied over a deliberate change
    const r5 = rec(), prev = J(rep); R.apply(r5, R.diffRep(null, rep)); ok('diffRep: the report applied twice (same content) adds nothing', R.apply(r5, R.diffRep(prev, rep)) === 0);
    r5.items[0].status = 'queued'; r5.items[0].hb = 0; const rep2 = J(rep); rep2.seq = 2; rep2.items[1] = { status: 'running' }; R.apply(r5, R.diffRep(prev, rep2)); ok('diffRep: the runner\'s deliberate requeue of item 0 is not undone by the old value still sitting in the cumulative report; the new field is applied', r5.items[0].status === 'queued' && r5.items[1].status === 'running');
    const rp = R.emptyRep(1); rp.top.pause = { since: 1 }; rp.top.pace = 'slow'; const r6 = rec(); R.apply(r6, R.diffRep(null, rp)); ok('a first full apply never takes the pause fields (the Pause key owns them)', !r6.pause && r6.pace === 'slow');
    // the tab\'s own view: record + own report, but a finished item of the runner is not overlaid
    const v = rec(); v.items[1].status = 'liked'; R.overlay(v, rep); ok('overlay: the tab sees its own changes on top of the record; the runner\'s finished item is kept', v.items[0].status === 'running' && v.items[1].status === 'liked' && v.groups[0].status === 'running');
    // heartbeats: new = seq grew or another gen; stale = older than the cut (a replaced tab)
    const hbs = { 0: { gen: 10, seq: 3, rseq: 1 }, 1: { gen: 5, seq: 9, rseq: 2 } }; const pl = R.plan(hbs, { 0: { gen: 10, seq: 2, rseq: 1 } }, 8); ok('plan: heartbeat seen (seq grew), no new report, the old tab\'s slot is stale', pl.seen && pl.needRep.length === 0 && pl.stale.join() === '1', pl);
    ok('plan: a new generation always needs its report', R.plan({ 2: { gen: 20, seq: 1, rseq: 1 } }, { 2: { gen: 10, seq: 5, rseq: 5 } }, 8).needRep.join() === '2');
    ok('keys: one slot key per tab (heartbeat + report), never the run record', R.keyHb('b', 'A', 2) === 'p9bn.hb.b.A.2' && R.keyRep('b', 'A', 2) === 'p9bn.rep.b.A.2'); }
  { const e17 = require('fs').readFileSync(require('path').join(__dirname, '..', 'ext17.js'), 'utf8'), pj = require('fs').readFileSync(require('path').join(__dirname, '..', 'popup.js'), 'utf8');
    ok('1.1.6.3: every order (popup, API, queued) starts its run at the ONE saved pace (p9bn.pace), the order\'s own pace is only a fallback', /pace = L\.pickPace\(await sget\(K\.pace\), o\.pace\)/.test(e17));
    ok('1.1.6.3: the select IS the saved pace: it is written when an order is submitted from the popup', /ps\.pace !== els\.pace\.value\) await sset\(K\.pace/.test(pj)); }

  // ---------------- 1.1.7: the API server's jobs in the Queue panel (lib/apijobs.js + ui17.js + the client call)
  { const AJ = require('../lib/apijobs.js'), A = require('../lib/apiclient.js'), fs = require('fs'), path = require('path'), vm = require('vm');
    const NOW = Date.parse('2026-11-02T14:30:00Z');
    const resp = { jobs: [
      { job_id: 'job_running0000001', status: 'running', place: 0, created_at: '2026-11-02T13:55:00+00:00', started_at: '2026-11-02T14:00:00+00:00', note: 'YT Panel batch 7', cancel_requested: false, progress: { total_likes: 3, done: 1 }, links: [{ n: 1, link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&lc=UgxAbCdEfGhIjKlMnOp', vid: 'dQw4w9WgXcQ', comment_id: 'UgxAbCdEfGhIjKlMnOp', requested: 3, accepted: 3 }] },
      { job_id: 'job_queued00000002', status: 'queued', place: 1, created_at: '2026-11-01T20:30:00+00:00', started_at: null, note: 'YT Panel retry 7.1', cancel_requested: false, progress: { total_likes: 3, done: 0 }, links: [{ n: 1, link: 'x', vid: 'abcdefghijk', comment_id: 'UgxZZZZZZZZZZ.9xYzAbCdEfGh', requested: 2, accepted: 2 }, { n: 2, link: 'y', vid: 'abcdefghijl', comment_id: 'UgxYYYYYYYYYY', requested: null, accepted: 1 }] },
      { job_id: 'job_done', status: 'completed', links: [] }] };
    const rows = AJ.view(resp, { now: NOW, mine: new Set(['job_running0000001']) });
    ok('apijobs: only running + queued jobs, running first, then the place in line', rows.length === 2 && rows[0].status === 'running' && rows[0].placeLabel === 'running now' && rows[1].placeLabel === '#1 in line' && rows[1].statusLabel === 'Waiting' && rows[0].statusLabel === 'Running', rows.map((r) => [r.id, r.placeLabel]));
    ok('apijobs: requested likes (sum of the accepted quantities), links, source note', rows[0].likes === 3 && rows[1].likes === 3 && rows[1].linkCount === 2 && rows[0].note === 'YT Panel batch 7' && rows[1].note === 'YT Panel retry 7.1', rows.map((r) => [r.likes, r.note]));
    ok('apijobs: created time is shown in WAT (UTC+1): same day = time only, other day = date + time', rows[0].created === '14:55 WAT' && rows[1].created === '1 Nov 21:30 WAT', rows.map((r) => r.created));
    ok('apijobs: WAT is fixed UTC+1 whatever the browser zone is; bad dates give ""', AJ.wat('2026-06-30T23:30:00Z', Date.parse('2026-07-01T10:00:00Z')) === '00:30 WAT' && AJ.wat('nope') === '' && AJ.wat('') === '');
    ok('apijobs: a job Bean already took into its own queue is marked', rows[0].picked === true && rows[1].picked === false);
    ok('apijobs: the link is rebuilt from the video id + comment id only (the server text is just a tooltip); a bad id gives no url', rows[0].links[0].url === 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&lc=UgxAbCdEfGhIjKlMnOp' && rows[1].links[0].label === 'youtu.be/abcdefghijk \u00b7 comment UgxZZZZZZZZZZ' && AJ.linkView({ vid: 'javascript:alert(1)', comment_id: '<b>', link: 'javascript:alert(1)', accepted: 1 }).url === '');
    ok('apijobs: a cancel in progress reads "Stopping"; control characters and long notes are cleaned', AJ.view({ jobs: [{ job_id: 'j1', status: 'running', cancel_requested: true, note: 'a\u0000b' + 'x'.repeat(300), links: [] }] })[0].statusLabel === 'Stopping' && AJ.view({ jobs: [{ job_id: 'j1', status: 'queued', note: 'a\u0000b' + 'x'.repeat(300), links: [] }] })[0].note.length <= 120);
    ok('apijobs: nothing / garbage answers give an empty list, never a crash', AJ.view(null).length === 0 && AJ.view({}).length === 0 && AJ.view({ jobs: [null, 5, {}] }).length === 0);
    ok('apijobs: refresh every 10 s', AJ.REFRESH_MS === 10000);
    ok('apijobs: the signature changes when a status / place / progress changes, not when nothing did', AJ.signature(rows) === AJ.signature(AJ.view(resp, { now: NOW + 5000, mine: new Set(['job_running0000001']) })) && AJ.signature(rows) !== AJ.signature(AJ.view({ jobs: resp.jobs.slice(1) }, { now: NOW })));
    // the client: GET /agent/jobs with the install token (existing auth), no body, no key
    { const seen = []; const c = new A.BeanApi({ base: 'https://api10.norhartpro.com', getToken: () => 'bit_TEST', fetch: async (u, o) => { seen.push([u, o]); return { ok: true, status: 200, headers: { get: () => null }, json: async () => resp }; } });
      const r = await c.jobs(); ok('client: jobs() = GET /api/bean/agent/jobs with the install token', seen.length === 1 && seen[0][0] === 'https://api10.norhartpro.com/api/bean/agent/jobs' && seen[0][1].method === 'GET' && seen[0][1].headers.Authorization === 'Bearer bit_TEST' && seen[0][1].body === undefined && r.jobs.length === 3);
      const old = new A.BeanApi({ base: 'https://api10.norhartpro.com', getToken: () => 'bit_TEST', fetch: async () => ({ ok: false, status: 404, headers: { get: () => null }, json: async () => ({ error: { code: 'not_found', message: 'Unknown route' } }) }) });
      let er = null; try { await old.jobs(); } catch (e) { er = e; } ok('client: an older server (404 not_found) is a clean ApiError the popup words in plain text', er && er.status === 404 && er.code === 'not_found'); }
    // ui17.js run against a tiny fake DOM: what the Queue panel shows
    { const mkEl = (tag) => { const e = { tag, className: '', children: [], dataset: {}, style: {}, _t: '', hidden: false, open: false, title: '', listeners: {}, append(...k) { k.forEach((x) => { x.parent = e; e.children.push(x); }); }, addEventListener(n, f) { e.listeners[n] = f; }, set textContent(v) { e._t = String(v); e.children = []; }, get textContent() { return e._t + e.children.map((c) => c.textContent).join(''); } }; return e; };
      const rootEl = mkEl('div'); const store = {}; let intervals = [], timeouts = [];
      const od = { queue: [{ id: 'o1', seq: 1, src: 'api', jobId: 'job_running0000001', state: 'running', links: [{ n: 1, vid: 'dQw4w9WgXcQ', lc: 'UgxAbCdEfGhIjKlMnOp', quantity: 3 }], carry: { liked: 1, already: 0, failed: 0 } }], hist: [] };
      let apiOn = true, calls = 0, fail = null; const ctx = { document: { getElementById: (id) => (id === 'orders' ? rootEl : null), createElement: mkEl, hidden: false }, ROLE: 'popup', P9BEAN_ORD: { KEY: 'p9bn.orders', UI: 'p9bn.ui' }, P9BEAN_APIJOBS: AJ, ordData: null,
        sget: async (k) => (k === 'p9bn.orders' ? od : null), setMsg() {}, B17: { request: async () => ({ ok: true }) }, B11: { apiOn: () => apiOn, apiJobs: async () => { calls++; if (fail) throw fail; return resp; } },
        chrome: { storage: { local: { set: async () => {} }, onChanged: { addListener() {} } } }, setInterval: (f, ms) => { intervals.push([f, ms]); return 1; }, setTimeout: (f, ms) => { timeouts.push([f, ms]); return 1; }, clearTimeout() {}, console };
      ctx.self = ctx; vm.createContext(ctx); vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'ui17.js'), 'utf8'), ctx);
      const flush = () => new Promise((r) => setImmediate(r)); await flush(); await flush(); await flush();
      const text = () => rootEl.textContent;
      const panel = (name) => { const find = (e) => { if (e.tag === 'details' && e.dataset.k === name) return e; for (const c of e.children) { const f = find(c); if (f) return f; } return null; }; return find(rootEl); };
      const qp = panel('queue');
      ok('ui: the server jobs show inside the Queue panel (running now + the one in line), with created time (WAT), note, likes and the video', !!qp && /API server/.test(qp.textContent) && /running now · Running/.test(qp.textContent) && /#1 in line · Waiting/.test(qp.textContent) && /created (\d+ \w+ )?14:55 WAT/.test(qp.textContent) && /YT Panel retry 7\.1/.test(qp.textContent) && /youtu\.be\/dQw4w9WgXcQ/.test(qp.textContent) && /3 likes/.test(qp.textContent), qp && qp.textContent.slice(0, 400));
      ok('ui: the Queue count includes the server jobs; a job Bean already has says so', /Queue.*2/.test(qp.children[0].textContent) && /Bean has it/.test(qp.textContent), qp && qp.children[0].textContent);
      ok('ui: refreshed every 10 s while the popup is open (and not while hidden)', intervals.some((i) => i[1] === 10000) && calls >= 1);
      const iv = intervals.find((i) => i[1] === 10000)[0]; const c0 = calls; ctx.document.hidden = true; iv(); await flush(); ok('ui: a hidden popup does not ask the server', calls === c0); ctx.document.hidden = false; iv(); await flush(); ok('ui: the refresh asks the server again', calls === c0 + 1);
      fail = { status: 0, code: 'network' }; iv(); await flush(); await flush(); ok('ui: an unreachable server keeps the last list and says so', /Could not reach the server/.test(text()) && /#1 in line/.test(text()));
      fail = { status: 404, code: 'not_found' }; iv(); await flush(); await flush(); ok('ui: a server without the list says so in plain words', /cannot list its jobs yet/.test(text()));
      fail = null; apiOn = false; iv(); await flush(); await flush(); ok('ui: API off = no server block at all', !/API server/.test(text()), text().slice(0, 200)); }
    const uj = fs.readFileSync(path.join(__dirname, '..', 'ui17.js'), 'utf8'), ph = fs.readFileSync(path.join(__dirname, '..', 'popup.html'), 'utf8'), e11 = fs.readFileSync(path.join(__dirname, '..', 'ext11.js'), 'utf8');
    ok('ui: server text only ever goes in through textContent (no innerHTML, no href from the server)', !/innerHTML|insertAdjacentHTML|\.href\s*=/.test(uj) && !/innerHTML/.test(fs.readFileSync(path.join(__dirname, '..', 'lib', 'apijobs.js'), 'utf8')));
    ok('wiring: popup.html loads lib/apijobs.js before ui17.js; ext11 exports apiJobs/apiOn; the call is read-only', ph.indexOf('lib/apijobs.js') > 0 && ph.indexOf('lib/apijobs.js') < ph.indexOf('ui17.js') && /apiJobs, apiOn/.test(e11) && /jobs\(\) \{ return this\.req\('GET', '\/agent\/jobs'/.test(fs.readFileSync(path.join(__dirname, '..', 'lib', 'apiclient.js'), 'utf8'))); }
  // ---- 1.1.7.1 (real run zo8n4jxzmw0n9e3l): every await of the item flow is bounded; a lost final VPN answer is never "vpn-failed"; a silent like is verified, not given up; no false auto-pause
  { const pjy = require('fs').readFileSync(require('path').join(__dirname, '..', 'popup.js'), 'utf8');
    ok('1.1.7.1 the popup\'s done count only goes up while the run is live (an older mirrored copy of the record cannot flicker it back)', /renderProgress\.hi/.test(pjy) && /p\.live && p\.done < hi\.n\) p\.done = hi\.n/.test(pjy)); }
  { const rdf = (f) => require('fs').readFileSync(require('path').join(__dirname, '..', f), 'utf8'), cj = rdf('content.js'), pjx = rdf('popup.js'), ej = rdf('ext11.js');
    ok('1.1.7.1 every storage call of the tab goes through the bounded wrapper (7 s, 3 tries): sget / sset / slot / report reads / marker removes / ledger reads', /const stor = \(fn, label\)/.test(cj) && /const sget = \(k\) => stor\(/.test(cj) && /const sset = \(k, v\) => stor\(/.test(cj) && !/[^(]chrome\.storage\.local\.(get|remove)\(/.test(cj.replace(/stor\(\(\) => chrome\.storage\.local\.(get|remove)\([^)]*\)[^)]*\)/g, '').replace(/\{ \[k\]: null \}/g, '')) , cj.match(/[^\n]{0,60}[^(]chrome\.storage\.local\.(get|remove)\([^\n]{0,40}/g));
    ok('1.1.7.1 a write that never settles cannot block the tab\'s write queue: each queued write is bounded (45 s)', /patchChain\.then\(\(\) => bound\(patchNow\(/.test(cj));
    ok('1.1.7.1 in-tab DEADMAN: no progress for 80 s on an item this page is working on -> the page hands it back itself (fresh tab; a SENT like is only verified)', /const GUARD_MS = 80000/.test(cj) && /const handBack = async/.test(cj) && /guardFired = true; handBack\(/.test(cj) && /ci\.status !== 'running'\) return/.test(cj) && /a like was sent: a fresh tab only VERIFIES it, never clicks again/.test(cj));
    ok('1.1.7.1 a page that was handed back / stopped never clicks even if a stuck step wakes up late (alive() is checked right before the marker and the click)', /if \(!alive\(\)\) return \{ code: 'stopped' \};[^\n]*\n\s*await sset\(X\.mkey, val\)/.test(cj));
    ok('1.1.7.1 VPN: the owner answered ("working") but the final answer was lost: the live sample (connected after the request) is taken as done; after 120 s it is "vpn-unanswered", NEVER "vpn-failed"', /final answer did not arrive, but its live sample/.test(cj) && /Date\.now\(\) - t0 > 120000\) return \{ ok: false, code: 'vpn-unanswered'/.test(cj) && /code: \(working && !v\.up\) \? 'vpn-unanswered' : 'vpn-failed'/.test(cj));
    ok('1.1.7.1 VPN owner writes its final answer again after 3, 8 and 15 s (the mirror can lose one write)', /for \(const ms of \[3000, 8000, 15000\]\)/.test(ej) && /stage === 'done'\) return sset\(KK\.vpn/.test(ej));
    ok('1.1.7.1 the click line of an earlier page of the item counts as "a like was sent" (item.lg click) even when `sent` and the marker never arrived: liked, never "already"', /loggedClick/.test(cj) && /\(mine\.sent \|\| mine\.verify \|\| loggedClick\)/.test(cj));
    ok('1.1.7.1 runner: answering a ping is not progress (no extra grace for a tab waiting on a switch page / 45 s without progress); a beating tab is never "orphaned" (no automatic Pause)', /const noSave = cur\.items\.some/.test(pjx) && /!noSave && seen/.test(pjx) && /it\.hb && nw - it\.hb < 8000\)\) return false/.test(pjx) && /Date\.now\(\) - t0 < 12000;/.test(pjx));
    // the deadman and the sent-verify requeue as behaviour of the pure parts
    { const b = { id: 'r', state: 'running', groups: [{ cid: 'A', status: 'running', openedAt: 1 }], items: [{ cid: 'A', status: 'running', sent: 5, at: 1 }, { cid: 'A', status: 'queued' }], updated: 1 };
      const r = O.reopenGroup(b, b.groups[0], 9000, { seen: true }); ok('1.1.7.1 silent after a sent like: queued for a verify-only fresh tab (sent kept, vrq 1)', r.reopened && b.items[0].status === 'queued' && b.items[0].sent === 5 && b.items[0].vrq === 1); } }
  { const cj = require('fs').readFileSync(require('path').join(__dirname, '..', 'content.js'), 'utf8');
    ok('1.1.7: a new page sees the reports of the earlier pages of its tab at once (R27/R35: tries/fresh after a switch), newer than the tab\'s open time only', /async function readB\(\)[\s\S]{0,1100}repCut[\s\S]{0,600}\(!rep \|\| r\.gen < rep\.gen\) && r\.gen >= cut/.test(cj)); }
  { const pj = require('fs').readFileSync(require('path').join(__dirname, '..', 'popup.js'), 'utf8');
  ok('1.1.7: a VPN drop while a fresh tab has not answered: the tab is closed and the container reopened as soon as the VPN is back (no open grace wait, bounded, not counted as a tab reopen)', /m1\.vpnDownAt/.test(pj) && /g\.vpnReopens = \(g\.vpnReopens \|\| 0\) \+ 1/.test(pj) && /\(g1\.vpnReopens \|\| 0\) < 6/.test(pj) && /m\.heard = true/.test(pj)); }
  { const e17 = require('fs').readFileSync(require('path').join(__dirname, '..', 'ext17.js'), 'utf8'), pj2 = require('fs').readFileSync(require('path').join(__dirname, '..', 'popup.js'), 'utf8');
    ok("1.1.7: a run whose items were all final when the backstop ends it is 'done', not 'stopped' (R69b)", /open0 \? 'stopped' : 'done'/.test(e17) && /b\.state = b\.items\.every\(finalIt\) \? 'done' : 'stopped'/.test(pj2));
    ok('1.1.7: the lost-run backstop gives the tabs 2 minutes after THIS page was frozen (computer asleep / starved window), it never ends a run for a silence it caused itself', /probeAt && t - probeAt > 30000\) freezeUntil = t \+ 120000/.test(e17) && /t >= freezeUntil/.test(e17)); }
  { const R = require('../lib/reports.js'), b = { state: 'running', items: [{ status: 'running', lg: [[1, 'a', 'tab line'], [3, 'vpn', 'runner line']] }], groups: [] };
    R.apply(b, { items: { 0: { lg: [[1, 'a', 'tab line'], [2, 'b', 'tab line 2']] } }, groups: {}, top: {}, events: [], orphans: [] });
    ok("1.1.7: merging a tab report keeps the runner's own item-log lines (e.g. 'kept the location') next to the tab's, in time order", JSON.stringify(b.items[0].lg.map((l) => l[2])) === JSON.stringify(['tab line', 'tab line 2', 'runner line'])); }
  { const rd = (f) => require('fs').readFileSync(require('path').join(__dirname, '..', f), 'utf8'), cj = rd('content.js'), e11 = rd('ext11.js'), e17 = rd('ext17.js'), pj = rd('popup.js'), oj = rd('lib/orders.js'), lj = require('../lib/links.js');
    ok("1.1.7.1: a page that does not find the 'like sent' marker but whose run record says sent/verify only VERIFIES (synthetic marker, no click, 'liked' never 'already'); the click page records the marker key (item.mk)", /!marker && \(mine\.sent \|\| mine\.verify \|\| loggedClick\)/.test(cj) && /recovered: true/.test(cj) && /onSent: \(\) => \{ sentLocal = Date\.now\(\); return patch\(b\.id, idx, \{ sent: sentLocal, mk: mkey/.test(cj));
    ok("1.1.7.1: the 3 s VPN settle follows a reconnect this page SAW, not Bean's own verified rotation", /stable = vs\.first \? 0 : vs\.at, wait = stable \+ VPN_SETTLE_MS/.test(e11) && !/S\.vlast && S\.vlast\.ok \? S\.vlast\.at : 0\), wait/.test(e11));
    ok('1.1.7.1: the owner page publishes p9bn.vpnok once a second and a tab that sees it fresh (< 3 s) and connected for 3+ s navigates at once (no request round trip)', /const VOK = 'p9bn\.vpnok'/.test(e11) && /vpnSample\(\)\.catch/.test(e11) && /sget\('p9bn\.vpnok'\)[\s\S]{0,260}Date\.now\(\) - v\.at <= 3000 && v\.at - v\.since >= 3000\) return true/.test(cj));
    ok('1.1.7.1: the VPN request is asked again only after 4 s (the mirror needs 2-8 s: an earlier repeat is a duplicate write), then every 4 s', /nextTry = t0 \+ 4000/.test(cj) && /nextTry = Date\.now\(\) \+ 4000/.test(cj));
    ok('1.1.7.1: switch-page watchdog: a switch navigation announces a SHORT grace (28 s, 45 s via the page\'s own menu) that is the whole allowance; the lost attempt is not counted and the other method is used next', lj.SWITCH_WATCH_MS === 28000 && lj.SWITCH_WATCH_UI_MS === 45000 && /swat: Date\.now\(\)[\s\S]{0,120}method === 'ui' \? L\.SWITCH_WATCH_UI_MS : L\.SWITCH_WATCH_MS/.test(cj) && /m\.short && m\.graceUntil \? 0 : m\.lastSeenAt \+ STALE_MS/.test(pj) && /it\.swlost = \(it\.swlost \|\| 0\) \+ 1; it\.swat = 0; it\.tries = Math\.max\(0, \(it\.tries \|\| 0\) - 1\)/.test(oj) && /switchMethod\(\(item\.tries \|\| 0\) \+ \(item\.swlost \|\| 0\)\)/.test(cj));
    ok("1.1.7.1: the lost switch really is a reopen of the container with the item requeued (pure rule): swlost 1, tries back to 0, nothing failed", (() => { const O = require('../lib/orders.js'); const b = { items: [{ cid: 'c1', status: 'running', tries: 1, swat: 5, chid: 'x' }], groups: [{ cid: 'c1', status: 'running' }], events: [] }; const r = O.reopenGroup(b, b.groups[0], 100, { seen: true }); const it = b.items[0]; return r.reopened && it.status === 'queued' && it.swlost === 1 && it.tries === 0 && it.swat === 0; })());
    ok('1.1.7.1: API reconciliation: every 15 s the server\'s job list is compared with the orders: an over order is finished again, a running job no order (and no pending claim) knows is reported finished after 30 s and two sightings (never a click)', /async function reconcile\(\)/.test(e17) && /t - \(S17\.recAt \|\| 0\) < 15000/.test(e17) && /t - first < 14000 \|\| t - startedAt < 30000/.test(e17) && /reconcile\(\)\.catch/.test(e17) && /S17\.accepting === j\.job_id \|\| S17\.claims\[j\.job_id\]/.test(e17));
    ok('1.1.7.1 CLAIMED JOB (job_V4Drrn4Psg2ovX5T): a claimed job is kept in S17.claims until it is queued locally; retryClaims retries every 3 s and after 30 s hands it back with a finish report (not_started); the silent returns of accept() keep the claim; the guard timer runs it even when the queue lease is elsewhere', /claims: \{\}/.test(e17) && /S17\.claims\[job\.job_id\] = \{ job, at: \(\(S17\.first = S17\.first \|\| \{\}\)\[job\.job_id\] = \(S17\.first\[job\.job_id\] \|\| now\(\)\)\), next: now\(\) \+ 3000 \}/.test(e17) && /async function retryClaims\(\)/.test(e17) && /CLAIM_GIVE_UP_MS = 90000/.test(e17) && /code: 'not_started'/.test(e17) && /async function apiGuard\(\) \{\s*retryClaims\(\)/.test(e17) && /delete S17\.claims\[job\.job_id\];\s*\/\/ the order exists locally/.test(e17)); }
    { const rdf = (f) => require("fs").readFileSync(require("path").join(__dirname, "..", f), "utf8"), pj2 = rdf("popup.js"), e17 = rdf("ext17.js"); ok('1.1.7.1 ONE ACTIVE RUN: the popup ignores the record of a different, older run (stale copy from the mirror); pause cut (1.1.7.2): 1 s, the step is not waited for, a sent like keeps verify; the run log has a timing line', /nv\.id !== batch\.id && \(nv\.created \|\| 0\) < \(batch\.created \|\| 0\)\) \{ staleSeen\+\+/.test(pj2) && /now - cur\.pauseReq < 1000/.test(pj2) && /if \(it\.sent\) it\.verify = it\.verify \|\| now/.test(pj2) && /timing — the order waited/.test(e17)); }
  { const e17b = require('fs').readFileSync(require('path').join(__dirname, '..', 'ext17.js'), 'utf8'), ojb = require('fs').readFileSync(require('path').join(__dirname, '..', 'lib', 'orders.js'), 'utf8');
    ok('1.1.7.1: reporting to the API server has its own timer (apiGuard: lease-aware, one pass at a time, bounded) and is no longer behind the dispatcher tick; one bad order cannot stop the others', /async function apiGuard\(\)/.test(e17b) && /S17\.apiTimer = setInterval\(\(\) => \{ apiGuard\(\)/.test(e17b) && !/\n\s+await apiTick\(\);\n/.test(e17b.replace(/async function apiGuard[\s\S]*?\n  }\n/, '')) && /Promise\.race\(\[apiTick\(\)/.test(e17b) && /\} catch \(e\) \{ S\.err = String\(\(e && e\.message\) \|\| e\)\.slice\(0, 120\); \}\n    \}\n    if \(B\.writeStat\)/.test(e17b));
    ok('1.1.7.1: a stuck pump / dispatcher tick (an IPC call that never answered) is given up after 1 / 2 minutes instead of blocking forever', /S17\.pumping && now\(\) - S17\.pumpAt < 60000/.test(e17b) && /this\.busy && this\.now\(\) - \(this\.busyAt \|\| 0\) < 120000/.test(ojb)); }
  // ---------------- 1.1.7.1: messaging between a tab and Bean's window cannot hang a step
  { const fs = require('fs'), pth = require('path'), rd = (f) => fs.readFileSync(pth.join(__dirname, '..', f), 'utf8'), ct = rd('content.js'), e11 = rd('ext11.js');
    // runner: a tab that still beats but whose progress stood still for 45 s is recycled (nothing clicked); a tab that is progressing, in grace or beating slowly is left alone
    const mkb = (over) => ({ state: 'running', groups: [{ cid: 'c1', status: 'running' }], items: [Object.assign({ cid: 'c1', status: 'running', at: 1000, hb: 100000, prog: 50000 }, over || {})], events: [] });
    { const b = mkb(); const r = O.watchdog(b, 100000); ok('1.1.7.1: beating tab with 50 s of no progress is recycled now (not after 4 min), nothing clicked', r.changed && b.items[0].status === 'queued' && b.groups[0].status === 'queued' && b.groups[0].recycle === 1 && /no progress for 50 s/.test(JSON.stringify(b.items[0].lg)), b.items[0]); }
    { const b = mkb({ prog: 70000 }); ok('1.1.7.1: 30 s of silence is not a stall', !O.watchdog(b, 100000).changed); }
    { const b = mkb({ hb: 70000 }); ok('1.1.7.1: a tab whose heartbeat is also old is left to the tab-gone / staleness rules, not this one', !O.watchdog(b, 100000).changed); }
    { const b = mkb({ hb: 0 }); b.graceUntil = 200000; ok('1.1.7.1: an announced navigation (the tab writes hb 0) is never called silent', !O.watchdog(b, 100000).changed); }
    { const b = mkb(); b.graceUntil = 200000; ok('1.1.7.1: the opener\'s grace on the run does not hide a beating tab that made no progress', O.watchdog(b, 100000).changed); }
    { const b = mkb({ sent: 99000, step: 'liking…' }); const r = O.watchdog(b, 100000); ok('1.1.7.1: silent AFTER a click: counted as liked-unverified, never clicked again', r.changed && b.items[0].status === 'liked' && b.items[0].code === 'liked-unverified'); }
    ok('1.1.7.1: the stall threshold for a silent step is 30 s (1.1.7.2)', O.C.SILENT_MS === 30000);
    // the tab: progress is tracked, every pre-click await is bounded, an unanswered / timed-out step is never a result
    ok('1.1.7.1: the heartbeat carries prog/step; sleep, log lines and status texts are progress', /prog: PROG\.at, step: PROG\.step/.test(ct) && /const sleep = \(ms\) => new Promise\(\(r\) => setTimeout\(\(\) => \{ PROG\.at = Date\.now\(\); r\(\); \}, ms\)\)/.test(ct) && /const ev = \(step, detail\) => \{ touch\(step\);/.test(ct));
    const co = ct.slice(ct.indexOf('async function clickOnce'), ct.indexOf('btn.click()'));
    ok('1.1.7.1: before the click the lock, the run record, the marker read and the identity re-check are each bounded (step-timeout)', /bound\(lockTake/.test(co) && /bound\(readB\(\)/.test(co) && /bound\(sget\(X\.mkey\)/.test(co) && (co.match(/bound\(rck\(\), 40000/g) || []).length === 2 && /step-timeout/.test(co));
    ok('1.1.7.1: vpn-unanswered / step-timeout hand the container back (reopenNow) while reopens are left; the click is never reached', /res\.code === 'vpn-unanswered' \|\| res\.code === 'step-timeout'\) && !stop && \(item\.ro \|\| 0\) < I\.MAX_REOPEN\) \{ await reopenNow/.test(ct));
    const pcv = ct.slice(ct.indexOf('if (vpnReq) {'), ct.indexOf('human-like beat'));
    ok('1.1.7.1: the pre-click VPN confirmation uses the live sample first (up, same location, younger than 5 s), then 3 bounded requests, else vpn-unanswered', /p9bn\.vpnok/.test(pcv) && /o\.locOk/.test(pcv) && /o\.at <= 5000/.test(pcv) && /k <= 3/.test(pcv) && /code: 'vpn-unanswered'/.test(pcv));
    ok('1.1.7.1: the wait for the owner\'s answer ends on the storage event (not only on a timer), and the status text names what is asked (check / connect / switch)', /const vwake = /.test(ct) && /await vwake\(400\)/.test(ct) && /checking the VPN connection…/.test(ct) && /waiting for ExpressVPN to be connected…/.test(ct));
    ok('1.1.7.1: the live sample carries locOk (the same test as the check) and the owner always writes an answer: a throw cannot leave the tab on "working"', /locOk/.test(e11) && /let out; try \{ out = rq\.up/.test(e11) && /kind: rq\.up \? 'up'/.test(e11));
    ok('1.1.7.1: test hooks exist only as page attributes / owner flags (HANGPRE_, HANGREC_, noVok, dropCheckUntil)', /data-p9bn-test'\) === 'hangpre'/.test(ct) && /S\.noVok/.test(e11) && /S\.dropCheckUntil/.test(e11));
    ok('1.1.7.1: plain-words messages exist for vpn-unanswered and step-timeout', !!E.info('vpn-unanswered').message && !!E.info('step-timeout').message && !!L.label('vpn-unanswered') && !!L.label('step-timeout')); }
  // ---------------- 1.1.7.1: Pause UI latch + pause never waits for a stuck step
  { const fs = require('fs'), pth = require('path'), pj = fs.readFileSync(pth.join(__dirname, '..', 'popup.js'), 'utf8');
    const src = pj.slice(pj.indexOf('let uiPause = null, uiResume = null;'), pj.indexOf('// 1.1.4 PAUSE') > 0 ? pj.indexOf('let lastSilentCheck') + 0 : 0);
    const fnSrc = pj.slice(pj.indexOf('let uiPause = null, uiResume = null;'), pj.indexOf('\n}\n', pj.indexOf('function pauseUi(b)')) + 3);
    let T = 1000; const mkUi = new Function('L', 'Date', fnSrc + '; return { pauseUi, set: (a, b) => { uiPause = a; uiResume = b; }, get: () => [uiPause, uiResume] };');
    const ui = mkUi(L, { now: () => T });
    const rec = (over) => Object.assign({ id: 'r1', state: 'running', pauseReq: 0, pause: null }, over || {});
    ok('1.1.7.1: no pause = running, nothing shown', ui.pauseUi(rec()) === '');
    ui.set({ bid: 'r1', st: 'pausing', at: T, seen: T }, null);
    ok('1.1.7.1: right after the press: "pausing" even though the record does not know yet (older record)', ui.pauseUi(rec()) === 'pausing');
    T += 2000; ok('1.1.7.1: the record says pausing: still pausing', ui.pauseUi(rec({ pauseReq: T })) === 'pausing');
    T += 2000; ok('1.1.7.1: the record says paused: paused', ui.pauseUi(rec({ pauseReq: T, pause: { since: T } })) === 'paused');
    T += 500; ok('1.1.7.1: an OLDER record (no pause / only a request) never takes "paused" back', ui.pauseUi(rec()) === 'paused' && ui.pauseUi(rec({ pauseReq: T })) === 'paused');
    T += 9000; ok('1.1.7.1: the latch is dropped after 8 s of silence (a pause cleared elsewhere)', ui.pauseUi(rec()) === '');
    ui.set({ bid: 'r1', st: 'paused', at: T, seen: T }, { bid: 'r1', at: T });
    T += 1000; ok('1.1.7.1: right after Resume an older "paused" record does not bring the pause state back (6 s)', ui.pauseUi(rec({ pauseReq: T, pause: { since: T - 5000 } })) === '');
    T += 6000; ok('1.1.7.1: a run that ended clears the latch', ui.pauseUi({ id: 'r1', state: 'done' }) === '' && ui.get()[0] === null);
    ok('1.1.7.1: Pause/Resume set the latch at once; the buttons, progress text and message all read the same pauseUi()', /uiPause = \{ bid: c0\.id, st: 'pausing'/.test(pj) && /uiPause = null; if \(c0\) uiResume/.test(pj) && (pj.match(/pauseUi\(b\)/g) || []).length >= 4 && !/L\.pauseState\(b\)/.test(pj.slice(pj.indexOf('function renderProgress'), pj.indexOf('function renderProgress') + 2500)));
    ok('1.1.7.1: a pause requested while an item is stuck cancels it (1.1.7.2: 1 s after the request, never waits for the step; a sent like is kept for a verify-only pass), closes the tab and pauses', /async function pauseStuckStep/.test(pj) && /now - cur\.pauseReq < 1000 \|\| now - lastStuckPause < 1500/.test(pj) && /if \(await pauseStuckStep\(cur\)/.test(pj) && /pausedBy\[cur\.id\] && pausedBy\[cur\.id\]\.since\) return false/.test(pj) && /sweepVerified\(null, 3\)/.test(pj.slice(pj.indexOf('async function pauseStuckStep'), pj.indexOf('async function recoverAfterReload')))); }
  { const ct = require('fs').readFileSync(require('path').join(__dirname, '..', 'content.js'), 'utf8');
    ok('1.1.7.1 speed: after a click on the page\'s own account menu the tab waits 6 s (not 15 s) for the navigation before it uses the switch address; the fresh-tab reopen after a switch is untouched', /r === 'clicked'\) \{ await sleep\(6000\)/.test(ct) && /const reopenNow = async/.test(ct) && /straight to a fresh tab/.test(ct)); }
  console.log(`unit17: ${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
})().catch((e) => { console.log('CRASH', e && e.stack || e); process.exit(2); });
