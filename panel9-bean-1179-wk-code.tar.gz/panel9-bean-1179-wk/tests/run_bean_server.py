#!/usr/bin/env python3
"""Local Bean API server for the e2e tests: the REAL bean_api blueprint on a throw-away sqlite file. usage: run_bean_server.py <dir> <port>"""
import os, sys
sys.path.insert(0, os.environ.get("BEAN_SERVER_DIR") or (os.path.join(os.path.dirname(os.path.abspath(__file__)), "server-patched") if not os.environ.get("BEAN_SERVER_LIVE") else "/workspace/appstore/server"))   # 1.1.6: default = the live server + the proposed ledger-remove endpoint (server-patch-ledger-remove.diff)
from flask import Flask
import bean_api
root, port = sys.argv[1], int(sys.argv[2])
os.makedirs(root, exist_ok=True)
from flask_cors import CORS
app = Flask(__name__)
CORS(app, origins="*", max_age=7200)       # same as the real store app.py
bean_api.init(app, root, os.path.join(root, "bean.sqlite"))
if os.environ.get("BEAN_TEST_FAST"):
    bean_api.CFG["online_s"] = 20
app.run("127.0.0.1", port, threaded=True, use_reloader=False)
