// Bean 1.1.7 - Google check detector. Runs ONLY on accounts.google.com and consent.youtube.com (a container whose Google session needs a sign-in, a verification or a consent click lands here instead of YouTube).
// It never clicks or types anything: it only tells the popup, in one storage key, that the tab of the running Bean run is stuck on a Google page, so the container is skipped right away with a plain message
// ("Google asked container X to sign in or verify; open it once and complete it") instead of waiting for the tab to time out. Bean does not try to solve the challenge.
(() => {
  'use strict';
  const L = self.P9BEAN; if (!L || !L.googleHost(location.hostname)) return;
  const sget = async (k) => { try { const v = await chrome.storage.local.get(k); return v[k]; } catch (_) { return undefined; } };
  const run = async () => {
    // which run / container is this page for? Bean's tokens ride inside the "continue" / "next" / "followup" address that Google keeps (decoded, up to 3 levels); without them the page is only Bean's when a run is
    // opening a container right now, no Bean page has started in it yet and it was opened less than 150 s ago (a tab of the user's own on a Google page is never taken for Bean's otherwise)
    let u; try { u = new URL(location.href); } catch (_) { return; }
    let tok = '', cid = '';
    const scan = (s, depth) => { if (!s || depth > 3 || tok) return; let v = s; for (let i = 0; i < depth + 1; i++) { try { v = decodeURIComponent(v); } catch (_) { break; } } const m = /[?&]p9bn=([^&#]+)/.exec(v), c = /[?&]p9bc=([^&#]+)/.exec(v); if (m) { tok = decodeURIComponent(m[1]); cid = c ? decodeURIComponent(c[1]) : ''; } };
    for (const k of ['continue', 'next', 'followup', 'url', 'dest', 'u']) scan(u.searchParams.get(k), 0), scan(u.searchParams.get(k), 1), scan(u.searchParams.get(k), 2);
    scan(location.href, 1);
    const b = await sget('p9bn.batch'); if (!b || b.state !== 'running') return;
    let g = null;
    if (tok) { if (tok !== b.id) return; g = (b.groups || []).find((x) => (x.cid || '') === cid && (x.status === 'opening' || x.status === 'running')) || (b.groups || []).find((x) => x.status === 'opening' || x.status === 'running'); }
    else { const cand = (b.groups || []).filter((x) => x.status === 'opening'); if (cand.length !== 1) return; g = cand[0]; if (Date.now() - (g.openedAt || 0) > 150000) return; const seen = await sget(L.TABSEEN + b.id + '.' + (g.cid || '')); if (seen && seen.at >= (g.openedAt || 0)) return; }
    if (!g) return;
    const key = L.GCHECK + b.id + '.' + (g.cid || '');
    try { await chrome.storage.local.set({ [key]: { host: location.hostname, kind: /consent/i.test(location.hostname) ? 'consent' : 'signin', at: Date.now() } }); } catch (_) { /* ignore */ }
  };
  const go = () => run().catch(() => {});
  go(); setTimeout(go, 2500); setTimeout(go, 8000);          // the page may redirect through several steps before it settles
})();
