// Bean — content script (isolated world, www.youtube.com, top frame, document_start).
// Two jobs:
//  1) DETECT YouTube Focus. yt-focus (content.js) mirrors its switches onto <html data-ytf-*> and fires a `ytf-state` DOM event; the DOM is shared
//     between extensions, so we can read those attributes (extensions cannot read each other's chrome.storage). We publish what we see in our own
//     chrome.storage.local ("p9bn.ytf") so the popup can show it, and answer the popup's "p9bn.ping".
//  2) RUN a batch. The popup opens …/watch?v=VID&lc=COMMENT&p9bn=BATCHID. Only a tab whose URL carries the id of the running batch does anything.
//     It checks that yt-focus comment-only view is ON, finds the linked comment, clicks its Like button ONCE (never when already liked), records the result,
//     waits a human-like pause and navigates the same tab to the next link.
(() => {
  'use strict';
  if (window.__p9bn) return;
  window.__p9bn = true;
  const L = self.P9BEAN;
  const I = self.BeanIdentity;       // 1.1.6 identity module (lib/identity.js)
  if (!L || !self.P9BEAN_REP) return;
  const K = { ytf: 'p9bn.ytf', batch: 'p9bn.batch', ping: 'p9bn.ping', disc: 'p9bn.disc', diag: 'p9bn.diag', bind: 'p9bn.bind', vreq: 'p9bn.vpnreq', vpn: 'p9bn.vpn', lock: 'p9bn.lock', clk: 'p9bn.clk.', pause: 'p9bn.pause', stale: 'p9bn.chstale.', pace: 'p9bn.pace', alive: 'p9bn.alive' };
  // 1.1.6: a channel this run could not reach (not in the account menu / the identity could not be reached) is flagged for the popup and for the API's /capacity: it is left out of "possible likes" until a refresh or a like proves it works again
  const markStale = async (cid, chid, why) => { try { const cur = (await sget(K.stale + (cid || ''))) || {}; const ids = Array.isArray(cur.ids) ? cur.ids.slice() : []; if (chid && ids.indexOf(chid) < 0) ids.push(chid); await sset(K.stale + (cid || ''), { at: Date.now(), ids, why: String(why || '').slice(0, 120) }); } catch (_) { /* best effort */ } };
  const LG = self.P9BEAN_LEDGER;
  const R = self.P9BEAN_REP;           // 1.1.7 split writers (lib/reports.js)
  let rep = null, repSlot = -1, hbSeq = 0;
  const root = document.documentElement;
  // 1.1.7.1: PROGRESS. A page that is stuck on one awaited promise (a storage read or an answer that never comes) stops ticking: every finished sleep, every log line and every status text is a sign of life. The heartbeat carries it
  // (prog/step), and the runner recycles a tab whose heartbeat is alive but whose progress stood still for 45 s (lib/orders.js watchdog), instead of waiting for the 4-minute item stall.
  const PROG = { at: Date.now(), step: '' };
  const touch = (step) => { PROG.at = Date.now(); if (step) PROG.step = String(step).slice(0, 60); };
  const sleep = (ms) => new Promise((r) => setTimeout(() => { PROG.at = Date.now(); r(); }, ms));
  // every awaited step before a click is bounded: a promise that does not settle in `ms` ends as { code:'step-timeout' } (nothing clicked, the container is handed back)
  const bound = (p, ms, label) => new Promise((res, rej) => { let done = false; const t = setTimeout(() => { if (!done) { done = true; rej(Object.assign(new Error(label + ' did not finish in ' + Math.round(ms / 1000) + ' s'), { stepTimeout: true, label })); } }, ms); Promise.resolve(p).then((v) => { if (!done) { done = true; clearTimeout(t); res(v); } }, (e) => { if (!done) { done = true; clearTimeout(t); rej(e); } }); });
  const RECYCLE_ITEMS = 40, RECYCLE_MS = 15 * 60000;           // 1.1.7: same numbers as lib/orders.js C.RECYCLE_ITEMS / C.RECYCLE_MS (a unit test keeps them equal)
  const VERIFY_TRIES = 3;                                        // 1.1.6.3: fresh pages read after a sent like before it is called 'unverified' (never not-found, never a second click)
  const SETTLE_POLLS = 3, SETTLE_MS = 3000;                                        // 1.1.6.2: fresh-copy polls (5 s apart) while a sign-in may still be settling
  const rnd = (a, b) => a + Math.random() * (b - a);
  const T0 = Date.now();
  // 1.1.7.1 ROOT CAUSE of the silent stalls ("heartbeat missed" while the page still answered pings): chrome.storage calls go through Panel 9 and a reply can be lost, so an awaited read/write NEVER settled; the tab's single
  // write queue (patch) then waited behind it for ever (no heartbeats, no results) while the ping answer (a plain write) still worked. Every storage call of this page is now bounded (7 s, up to 3 tries; a read or a whole-key write is
  // safe to repeat) and fails with a step-timeout instead of hanging.
  const TL = { n: 0 };          // test hook only (data-p9bn-test = loseone / loseall on LOSEONE_ / LOSEALL_ pages): the next storage call loses its reply 1 / 3 times
  const stor = (fn, label) => { let n = 0; const go = () => bound(Promise.resolve().then(() => (TL.n > 0 ? (TL.n--, new Promise(() => {})) : fn())), 7000, label).catch((e) => { if (e && e.stepTimeout && ++n < 3) return go(); throw e; }); return go(); };
  const sget = (k) => stor(() => chrome.storage.local.get({ [k]: null }), 'storage read').then((v) => v[k]);
  const sset = (k, v) => stor(() => chrome.storage.local.set({ [k]: v }), 'storage write');
  // 1.1.7.1 PREFER ACTIVE CHANNEL: the last channel Bean saw ACTIVE in a container (identity confirmed / account menu read), one record per container keyed by the stable channel id. Planning prefers it over channels that need a switch.
  const noteActive = (cid, id, name, src) => { if (!cid || !id) return Promise.resolve(); return sset(L.ACT_KEY + cid, { id: String(id), name: String(name || '').slice(0, 60), at: Date.now(), src: src || 'identity' }).catch(() => {}); };

  // ================================================================== 1. YouTube Focus detection
  let ytfEvent = false;
  document.addEventListener('ytf-state', () => { ytfEvent = true; report(false); }, true);
  const ytfAttrs = () => { for (const a of root.attributes) if (a.name.indexOf('data-ytf-') === 0) return true; return false; };
  const ytfPresent = () => ytfEvent || ytfAttrs() || !!document.getElementById('ytf-bar');
  const ytfComments = () => root.hasAttribute('data-ytf-comments');          // the "comments only" switch is ON (set by yt-focus content.js)
  const ytfFocus = () => root.hasAttribute('data-ytf-focus');                // …and this page is a watch page shown in comment-only layout
  const isWatch = () => location.pathname === '/watch';
  let lastRep = null, lastRepAt = 0;
  function report(force) {
    const installed = ytfPresent() ? true : (isWatch() && Date.now() - T0 > 6000 ? false : null);   // absence is only proof on a watch page, after yt-focus had time to run
    const st = { installed, commentsOnly: installed === true && ytfComments(), seen: Date.now() };
    if (installed === null) return;   // "cannot tell" (e.g. home page, no yt-focus marker yet) is never written: it would overwrite real knowledge from another tab
    const sig = JSON.stringify([st.installed, st.commentsOnly]);
    if (!force && sig === lastRep && Date.now() - lastRepAt < 30000) return;
    lastRep = sig; lastRepAt = Date.now();
    sset(K.ytf, st).catch(() => {});
  }
  try { new MutationObserver(() => report(false)).observe(root, { attributes: true }); } catch (_) { /* ignore */ }
  setInterval(() => { report(false); }, 15000);      // 1.1.6.3: was every 2 s on EVERY YouTube page forever; the mutation observer and the ytf-state event already report changes at once
  try { chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c[K.ping]) report(true); }); } catch (_) { /* ignore */ }
  report(false);

  // ================================================================== 2. batch runner
  let info = L.pageInfo(location.href);
  // 1.1.7: the TAB-SEEN marker, written at document_start: a Bean page started in this tab (so the popup can tell "never answered" from "went quiet after starting")
  const markSeen = (inf) => { try { if (inf && inf.token && inf.cid && !inf.disc) chrome.storage.local.set({ [L.TABSEEN + inf.token + '.' + inf.cid]: { url: (location.pathname + location.search).replace(/[?&]p9b\w=[^&]*/g, '').slice(0, 160), at: Date.now() } }); } catch (_) { /* ignore */ } };
  markSeen(info);
  // test hook (tests/mock-youtube.js DUPINST pages only: they set data-p9bn-test="dup"): start a SECOND copy of the run logic in this page at once, like a duplicate injection would
  if (info.token && !info.disc && !info.restore) document.addEventListener('p9bn-test-dup', () => { if (root.getAttribute('data-p9bn-test') === 'dup') runBatch(info).catch(() => {}); });
  const startRun = (inf) => (inf.disc ? runDiscover(inf) : inf.restore ? runRestore(inf) : runBatch(inf)).catch((e) => { try { console.log('[p9bn] runner error', e && e.message); } catch (_) { /* ignore */ } });
  if (info.token) startRun(info);
  else adoptBind().then((inf) => { if (inf) { info = inf; markSeen(inf); startRun(inf); } }).catch(() => {});
  // 1.1.3: REAL YouTube rewrites the watch URL after load (history.replaceState keeps only the params it knows), so Bean's run tokens (p9bn/p9bc/p9bh) can be gone when the page is reloaded, and
  // the channel switch's next= can lose them too. Before every navigation this tab makes, it stores a one-shot HAND-OVER (p9bn.bind: run, container, channel, video, comment, time). A
  // token-less /watch page of exactly that video + comment, loading within the grace period, adopts the run from it (once). Nothing else is ever adopted.
  async function adoptBind() {
    let u; try { u = new URL(location.href); } catch (_) { return null; }
    if (!/(^|\.)youtube\.com$/i.test(u.hostname) || u.pathname !== '/watch') return null;
    const v = u.searchParams.get('v') || '', lc = u.searchParams.get('lc') || ''; if (!v || !lc) return null;
    const bd = await sget(K.bind); if (!bd || !bd.run) return null;
    if (Date.now() - (bd.at || 0) > L.NAV_GRACE_MS + 60000) return null;
    const sameV = bd.vid === v || (L.canonVid(bd.vid) && L.canonVid(bd.vid) === L.canonVid(v));
    if (!sameV || !(bd.lc === lc || L.canonLc(bd.lc) === L.canonLc(lc))) return null;
    // read-only check first: the run must be running and still be waiting for exactly this item
    const rb = await sget(K.batch); if (!rb || rb.id !== bd.run || rb.state !== 'running') return null;
    if (!(rb.items || []).some((it) => it.vid === bd.vid && it.lc === bd.lc && (it.cid || '') === (bd.cid || '') && (it.chid || '') === (bd.chid || '') && (it.status === 'queued' || it.status === 'running'))) return null;
    // YouTube may replace the page again (a reload right after a channel switch): the hand-over stays valid for a few pages, its time window moves on with each (max 6)
    if ((bd.n || 0) >= 6) return null;
    await sset(K.bind, Object.assign({}, bd, { n: (bd.n || 0) + 1, at: Date.now() }));
    diag(`token-less ${u.pathname} page adopted the run from the hand-over (${bd.kind || 'nav'}, page ${(bd.n || 0) + 1}): YouTube had removed Bean's parameters from the URL`);
    return { vid: v, lc, token: bd.run, cid: bd.cid || '', pid: '', chid: bd.chid || '', disc: false, restore: false, via: 'bind' };
  }
  // the one way this tab navigates inside a run: the hand-over first, then an explicit URL WITH the tokens (never location.reload(): the current URL may have lost them)
  async function bindNav(b, item, cid, kind) { try { await sset(K.bind, { run: b.id, cid, chid: (item && item.chid) || '', vid: item && item.vid, lc: item && item.lc, kind, at: Date.now() }); } catch (_) { /* the URL tokens still work */ } }
  // 1.1.7: a tab of a run that uses the VPN does not navigate (next item, channel switch, fresh reload, verify) until ExpressVPN reports `connected` + a short settle: the owner page answers a p9bn.vpnreq with up:true
  // (a read-only state wait, up to 150 s). A page loaded while the VPN drops ends on Panel 9's error page. When it never comes back the navigation goes ahead anyway (logged), the popup then recovers the tab.
  async function vpnGate(b, item, cid, kind) {
    if (!(b && b.vpn && b.vpn.on) || (item && item.vpnSkip)) return true;
    // 1.1.7.1: the owner page publishes the VPN state once a second (p9bn.vpnok): connected for 3+ s and a sample younger than 3 s = no request, no wait (before: a storage round trip + the settle before EVERY page)
    try { const v = await sget('p9bn.vpnok'); if (v && v.up && v.bid === b.id && Date.now() - v.at <= 3000 && v.at - v.since >= 3000) return true; } catch (_) { /* request path */ }
    const t0 = Date.now(); let r = null;
    const hb = setInterval(() => { patch(b.id, null, null, {}).catch(() => {}); }, 5000);
    try { r = await vpnSwitch({ bid: b.id, idx: -1, cid, up: true }, () => {}, () => !batchEnded, null); } catch (_) { r = { ok: true }; } finally { clearInterval(hb); }
    if (r && r.code === 'stopped') return false;
    const w = Math.round((Date.now() - t0) / 1000);
    if (w >= 4 || !(r && r.ok)) patch(b.id, null, null, null, (bb) => { (bb.events = bb.events || []).push([Date.now(), (r && r.ok) ? `waited ${w} s for ExpressVPN to be connected before the ${kind} page` : `ExpressVPN was not connected after ${w} s: the ${kind} page is loaded anyway` ]); bb.events = bb.events.slice(-20); }).catch(() => {});
    return true;
  }
  async function goTo(url, b, item, cid, kind) {
    if (!(await vpnGate(b, item, cid, kind))) return;
    await bindNav(b, item, cid, kind);
    batchEnded = true; location.assign(url);
  }
  // a page that carries (or was handed) a run but cannot use it: say so (global diag + the run record's log), with the URL path and the reason
  function orphan(why, b) {
    try {
      const path = location.pathname + (info.vid ? '?v=' + info.vid.slice(0, 11) : '');
      diag(`${path}: ${why}`);
      if (b && b.id) patchNow(b.id, null, null, null, (bb) => { bb.orphans = (bb.orphans || []).concat([[Date.now(), info.cid || '', location.pathname, String(why).slice(0, 110)]]).slice(-20); }).catch(() => {});
    } catch (_) { /* ignore */ }
  }

  // ---- tiny on-page status toast (shadow DOM so YouTube CSS cannot touch it)
  let toastEl = null, toastBox = null;
  function toast(text, kind) {
    touch(String(text || '').replace(/^Bean[^·]*·\s*(?:\d+\/\d+\s*·\s*)?/, ''));
    try {
      if (!toastEl) {
        toastEl = document.createElement('div'); toastEl.id = 'p9bn-toast';
        toastEl.style.cssText = 'all:initial;position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:2147483000;pointer-events:none';
        const sh = toastEl.attachShadow({ mode: 'open' });
        const st = document.createElement('style');
        st.textContent = '.b{font:600 13px/1.35 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#ececee;background:#111113;border:1px solid #2c2c31;border-radius:999px;padding:9px 16px;box-shadow:0 10px 30px rgba(0,0,0,.55);display:flex;gap:8px;align-items:center;max-width:90vw}.d{width:9px;height:9px;border-radius:50%;background:#8b96ff;flex:none}.ok .d{background:#52d6a0}.warn .d{background:#f0b25a}.bad .d{background:#ff7a6b}.busy .d{animation:p 1s infinite}@keyframes p{50%{opacity:.3}}';
        toastBox = document.createElement('div'); toastBox.className = 'b busy';
        const dot = document.createElement('span'); dot.className = 'd';
        const tx = document.createElement('span'); tx.className = 't';
        toastBox.append(dot, tx); sh.append(st, toastBox);
      }
      if (!toastEl.isConnected) root.appendChild(toastEl);
      toastBox.className = 'b ' + (kind || 'busy');
      toastBox.querySelector('.t').textContent = text;
    } catch (_) { /* never break the page */ }
  }

  // ---- channels: YouTube's own account switcher (the list behind avatar menu → "Switch account"), read with the page's own session ----------------------------------
  // Nothing is extracted or stored from the session: the request is a same-origin GET exactly like the page's, the answer is reduced to names / handles / avatars / page ids.
  // 1.1.4: EVERY wait is bounded: one fetch gets 20 s (AbortController), 3 attempts, so a hung /getAccountSwitcherEndpoint can never stall a page for more than ~70 s. onTry(n, why) reports each failed attempt.
  async function readChannels(onTry) {
    for (let i = 0; i < 3; i++) {
      let why = '';
      const ac = typeof AbortController === 'function' ? new AbortController() : null; const tm = ac ? setTimeout(() => { try { ac.abort(); } catch (_) { /* ignore */ } }, 20000) : 0;
      try {
        const r = await fetch('/getAccountSwitcherEndpoint', { credentials: 'same-origin', cache: 'no-store', signal: ac ? ac.signal : undefined });
        if (r.ok) { const p = L.parseSwitcher(await r.text()); if (p.ok) { clearTimeout(tm); return p; } why = 'list had no channels (' + (p.why || '?') + ')'; } else why = 'HTTP ' + r.status;
      } catch (e) { why = e && e.name === 'AbortError' ? 'no answer within 20 s' : 'fetch failed'; }
      clearTimeout(tm);
      try { if (onTry) onTry(i + 1, why); } catch (_) { /* ignore */ }
      if (i < 2) await sleep(1500);
    }
    return { ok: false, channels: [] };
  }
  // small log of things that went wrong, for the person who has to find out why (cleared with the run)
  function diag(m) { try { sget(K.diag).then((d) => sset(K.diag, ((d || []).concat([{ t: Date.now(), cid: info.cid, m: String(m).slice(0, 160) }])).slice(-30))); } catch (_) { /* ignore */ } }

  // "Refresh channels": this tab only reads the channel list of its container and stores it
  async function runDiscover(inf) {
    let d = null;
    for (let t0 = Date.now(); Date.now() - t0 < 15000; await sleep(400)) { d = await sget(K.disc); if (d && d.id === inf.token) break; d = null; }
    if (!d || d.state !== 'running') return;
    toast('Bean · reading the channels of this account…', 'busy');
    await waitFor(() => document.readyState === 'complete', 20000, null, 200); await sleep(1200);
    const r = await readChannels();
    const key = L.chKey(inf.pid, inf.cid), old = await sget(key), at = Date.now();
    let rec;
    if (r.ok) rec = { at, ok: true, channels: L.cacheChannels(r.channels), active: (r.channels.find((c) => c.active) || {}).id || '', err: '' };
    else { const why = 'No channel list (signed out, or YouTube changed its account switcher)'; rec = old && old.ok ? Object.assign({}, old, { at, err: why }) : { at, ok: false, channels: [], active: '', err: why }; }
    await sset(key, rec); if (rec && rec.ok) { try { await stor(() => chrome.storage.local.remove(K.stale + (inf.cid || '')), 'storage write'); } catch (_) { /* ignore */ } }
    toast(r.ok ? `Bean · ${r.channels.length} channel${r.channels.length === 1 ? '' : 's'} found` : 'Bean · could not read the channels', r.ok ? 'ok' : 'warn');
  }

  // the tab that went back to the home page after the last channel of a container: is the channel that was active before the run active again?
  async function runRestore(inf) {
    let b = null;
    for (let t0 = Date.now(); Date.now() - t0 < 30000; await sleep(400)) { b = await readB(); if (b && b.id === inf.token) break; b = null; }
    if (!b) return;
    known = b;
    const g = (b.groups || []).find((x) => (x.cid || '') === (inf.cid || ''));
    if (!g || g.restore !== 'pending') return;
    toast('Bean · checking that the original channel is back…', 'busy');
    await waitFor(() => document.readyState === 'complete', 20000, null, 200);
    const r = await readChannels();
    const act = r.ok ? r.channels.find((c) => c.active) : null; if (act) noteActive(inf.cid || '', act.id, act.name, 'menu');
    const ok = !!act && L.sameChannel(act, { id: g.orig, name: g.origName });
    toast(ok ? 'Bean · back on ' + g.origName : 'Bean · could not switch back to ' + g.origName, ok ? 'ok' : 'warn');
    await patch(b.id, null, null, null, (bb) => { const gg = (bb.groups || []).find((x) => (x.cid || '') === (inf.cid || '')); if (gg) { gg.restore = ok ? 'ok' : 'failed'; gg.restoreMsg = ok ? '' : (act ? `still on '${act.name}'` : 'could not read the channel list'); } finishGroup(bb, inf.cid || ''); });
    stripToken();
  }
  // this container has nothing left to do: mark it done, decide whether the whole run is, and schedule the (human-like) gap before the popup opens the next container's tab
  // 1.1.6.3: the saved pace (p9bn.pace, written by the popup only). paceStored is refreshed by a storage event and read again before every gap; the run record mirrors it (b.pace) so the log shows what was used.
  let paceStored = null, paceLogged = '';
  try { chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c[K.pace]) paceStored = c[K.pace].newValue; }); } catch (_) { /* ignore */ }
  async function readPace(b, ev) {
    try { paceStored = await sget(K.pace); } catch (_) { /* keep the last */ }
    const p = L.pickPace(paceStored, b && b.pace);
    if (p !== paceLogged) { paceLogged = p; if (ev) ev('pace', `${L.paceLabel(p)} (the saved Bean pace, one setting for every run)`); }
    if (b && b.pace !== p) { b.pace = p; patch(b.id, null, null, { pace: p }).catch(() => {}); }
    return p;
  }
  function finishGroup(bb, cid) {
    const g = (bb.groups || []).find((x) => (x.cid || '') === cid); if (g) { g.status = 'done'; g.doneAt = Date.now(); }
    if (bb.state !== 'running') return;
    const left = bb.items.some((it) => it.status === 'queued' || it.status === 'running');
    if (!left) bb.state = 'done'; else bb.nextAt = Date.now() + L.pauseMs(L.pickPace(paceStored, bb.pace));
  }

  async function runBatch(inf) {
    const runner = Math.random().toString(36).slice(2) + Date.now().toString(36);
    // 1.1.1: ONE copy of the run logic per page. A duplicate injection (or anything else that starts runBatch a second time in this document) stops here.
    if (root.getAttribute('data-p9bn-inst')) return;
    root.setAttribute('data-p9bn-inst', runner);
    // The popup writes the run record and opens this tab at the same moment. Panel 9 mirrors chrome.storage between sessions (= containers) a moment later,
    // so this tab may start before the record reaches its own session: wait for it (up to 15 s) instead of giving up.
    let b = null;
    for (let t0 = Date.now(); Date.now() - t0 < 30000; await sleep(400)) { b = await readB(); if (b && b.id === inf.token) break; b = null; }
    if (!b) { orphan(`the run record never reached this container's storage${inf.via ? ' (page adopted from the hand-over)' : ''}`, null); return; }          // stale link or somebody else's run: do nothing at all
    const cid = inf.cid || '', chid = inf.chid || '';
    const inGroup = (it) => (it.cid || '') === cid;
    if (b.state !== 'running') { toast('Bean: this run was ' + (b.state === 'done' ? 'finished' : 'stopped'), 'warn'); orphan('the run is already ' + b.state, null); stripToken(); return; }
    if (Date.now() - (b.created || 0) > 90 * 60000) { await patch(b.id, null, null, { state: 'stopped' }); stripToken(); return; }
    const idx = b.items.findIndex((it) => it.vid === inf.vid && it.lc === inf.lc && inGroup(it) && (it.chid || '') === chid && (it.status === 'queued' || it.status === 'running'));
    if (idx < 0) { toast('Bean: this link was already handled', 'warn'); orphan('no queued/running item for this video, comment and channel in the run (already handled, or another channel is expected)', b); stripToken(); return; }
    const mine = b.items[idx];
    // 1.1.1: if Bean already SENT a like for this comment + channel (the "clicked" marker exists), this page never clicks: it only VERIFIES the state and reports it
    let mkey = markerKey(mine); let marker = null; try { marker = await sget(mkey); } catch (_) { /* ignore */ }
    // 1.1.7.1: the run record can know a like was SENT (item.sent / item.verify, written by the page that clicked) while this page does not find the marker (a different key after a channel trade / switch, a mirror that has not delivered it yet). A click was sent
    // for this item, so this page ONLY verifies: it reads the marker the click page named (item.mk) or, failing that, stands in for it with the record's own word. liked then means 'liked' (never 'already'), with no 'first page after a switch' re-read.
    const loggedClick = (mine.lg || []).some((l) => l && l[1] === 'click');          // 1.1.7.1: the click line of an earlier page of this item (it travels with the heartbeat): a like was sent even if `sent` and the marker never arrived
    if (!marker && (mine.sent || mine.verify || loggedClick)) {
      try { if (mine.mk && mine.mk !== mkey) { marker = await sget(mine.mk); if (marker) mkey = mine.mk; } } catch (_) { /* ignore */ }
      if (!marker) marker = { at: Math.max(mine.sent || 0, mine.verify || 0, b.created || 0), bid: b.id, vid: mine.vid, lc: mine.lc, phase: 'verify', recovered: true, vpn: mine.vpn ? { location: mine.vpn.location || '', ipChanged: mine.vpn.ipChanged == null ? null : !!mine.vpn.ipChanged } : null };
    }
    const verifyMode = !!marker;
    // 1.1.4: a running item owned by another page whose heartbeat is still fresh: that page may be the one YouTube just reloaded/replaced in THIS tab (it is gone, its heartbeat only has not gone stale yet).
    // Wait for the heartbeat to stop (up to 25 s) and then take over; if it keeps beating it is a live duplicate and this page does nothing (and says so).
    if (!verifyMode && mine.status === 'running' && mine.runner && mine.runner !== runner && Date.now() - (mine.hb || 0) < 15000) {
      let owned = true;
      for (let t0 = Date.now(); Date.now() - t0 < 25000; await sleep(1000)) {
        const cur = await readB(); const ci = cur && cur.id === b.id && cur.items && cur.items[idx];
        if (!ci || ci.status !== 'running') { owned = !!ci && ci.status !== 'queued'; break; }
        if (ci.runner === runner || !ci.runner || Date.now() - (ci.hb || 0) >= 15000) { owned = false; break; }
      }
      if (owned) { orphan('another live page of this tab owns the item (its heartbeat kept beating for 25 s): this page does nothing', b); return; }
      const cur2 = await readB(); if (cur2 && cur2.id === b.id && cur2.items && cur2.items[idx]) { b = cur2; Object.assign(mine, cur2.items[idx]); }
      diag('took over an item whose previous page had gone (YouTube replaced the page in this tab)');
    }
    const lg = (mine.lg || []).slice(-50);          // the step log of this item (shown in the popup's run log); survives reloads because it lives in the run record
    const ev = (step, detail) => { touch(step); lg.push([Date.now(), step, String(detail == null ? '' : detail).slice(0, 180)]); if (lg.length > 60) lg.splice(0, lg.length - 60); };

    // 1.1.6.3: the page after a like (verify) shows the click line even if the run record lost it (real run: #20 was liked and verified with no click line)
    if (verifyMode && marker.recovered) lg.push([Date.now(), 'verify', 'the like marker was not found, but the run record says a like was sent for this item: verifying only, never clicking again']);
    if (verifyMode && marker.clickEv && !lg.some((l) => l && l[1] === 'click')) lg.push([marker.clickEv[0], 'click', String(marker.clickEv[2] || '') + ' (recovered from the safety marker)']);
    let stop = false;
    onFence = () => { stop = true; };
    known = b;
    const alive = () => !stop;
    // 1.1.4 PAUSE: called only at an item boundary (the item is final and recorded: never between the click and the verify) and right before a navigation. While the popup's Pause request (batch.pauseReq)
    // stands, this tab stays open on its idle page: no navigation, no VPN switch, no click; it keeps the run record fresh. Resume (pauseReq cleared) or Stop/end of run releases it.
    const pauseOn = async (c) => { let pk = null; try { pk = await sget(K.pause); } catch (_) { /* ignore */ } return L.pauseWanted(pk, c); };     // 1.1.6: the Pause key (popup-only writer) wins over the run record's mirror
    const holdIfPaused = async (why) => {
      const c0 = await readB();
      if (!c0 || c0.id !== b.id || c0.state !== 'running' || stop || !(await pauseOn(c0))) return;
      const since = Date.now();
      const mark = (bb) => { if (!bb.pause) bb.pause = { since, where: why }; if (!bb.pauseReq) bb.pauseReq = since; };
      await patch(b.id, null, null, null, (bb) => { mark(bb); (bb.events = bb.events || []).push([Date.now(), `paused — this container's tab waits (${why}); no page loads, no VPN change, no click`]); bb.events = bb.events.slice(-20); });
      for (let k = 0; !stop; k++) {
        toast(`Bean ${tag()} · paused — press Resume in the popup`, 'warn');
        await sleep(1000);
        const c2 = await readB();
        if (!c2 || c2.id !== b.id || c2.state !== 'running') { stop = true; break; }
        if (!(await pauseOn(c2))) break;
        if (k % 3 === 2) patch(b.id, null, null, {}, mark).catch(() => {});      // keeps batch.updated fresh while paused and re-asserts the mirror (a stale write by another page can wipe it)
      }
      if (!stop) toast(`Bean ${tag()} · resumed`, 'ok');
    };
    let mmSince = 0;                // a record of another run / none must persist for 8 s before it counts as "this run is gone"; an explicit stop counts at once
    const onB = (nb) => {
      if (stop || batchEnded) return;
      if (nb && nb.id === b.id) { mmSince = 0; if (nb.state !== 'running') { stop = true; fenced = true; } else if (!known || (nb.updated || 0) >= (known.updated || 0)) known = nb; return; }
      if (!mmSince) mmSince = Date.now(); else if (Date.now() - mmSince > 8000) { stop = true; diag('record of the run vanished'); }
    };
    try { chrome.storage.onChanged.addListener((c, area) => {
      if (area !== 'local') return;
      if (c[K.batch]) onB(c[K.batch].newValue);
      // 1.1.6.4: "is the tab of this run alive?" The popup asks after Bean was updated / reloaded (an orphaned tab's script is dead and cannot answer): ONE writer of p9bn.alive = the tab that runs this batch
      if (c[K.ping] && typeof c[K.ping].newValue === 'number' && !stop) { const av = { bid: b.id, cid: myCid(), for: c[K.ping].newValue, at: Date.now(), rt: !!(chrome.runtime && chrome.runtime.id), host: location.host }; sset(K.alive, av).catch(() => {}); if (myCid()) sset(K.alive + '.' + myCid(), av).catch(() => {}); }          // 1.1.7.8: up to 4 containers answer at once: each also answers on its OWN key (p9bn.alive.<container>), so one tab's answer never hides another's silence
    }); } catch (_) { /* ignore */ }
    const poll = setInterval(() => { readB().then(onB).catch(() => {}); }, 2500);
    const item = mine, cname = String(mine.cname || '').slice(0, 20);
    const groupIdx = b.items.map((it, i) => (inGroup(it) ? i : -1)).filter((i) => i >= 0);
    const n = groupIdx.indexOf(idx) + 1, total = groupIdx.length;
    const tag = () => (cname ? cname + (item.chname ? ' / ' + String(item.chname).slice(0, 20) : '') + ' · ' : '') + `${n}/${total}`;
    // heartbeat: lets the popup tell "working" from "tab was closed"
    const hb = setInterval(() => { patch(b.id, idx, { hb: Date.now(), prog: PROG.at, step: PROG.step, lg: lg.slice() }).catch(() => {}); }, 4000);
    // 1.1.7.1 DEADMAN (inside the tab): the heartbeat is its own timer and keeps beating while the item flow waits for an answer that never comes. A page whose item flow has made NO progress (no finished wait, log line or
    // status) for GUARD_MS hands the item back itself, in plain steps: nothing was clicked -> a fresh tab of the same container (same VPN location); a like was SENT -> a fresh tab ONLY verifies it (never clicks again).
    let sentLocal = 0, guardFired = false;
    const GUARD_MS = 80000;
    const handBack = async (why) => {
      stop = true; const nowH = Date.now();
      let sent = !!sentLocal; if (!sent) { try { sent = !!(await bound(sget(mkey), 8000, 'marker read')); } catch (_) { /* unknown */ } }
      if (!sent) sent = !!((known && known.items && known.items[idx] && (known.items[idx].sent || known.items[idx].verify)) || lg.some((l) => l && l[1] === 'click'));
      ev('guard', `no progress for ${Math.round((nowH - PROG.at) / 1000)} s (last step: ${PROG.step || '?'}): ${why}; ${sent ? 'a like was sent: a fresh tab only VERIFIES it, never clicks again' : 'nothing was clicked: continuing in a fresh tab of the same container'}`);
      clearInterval(hb); clearInterval(poll); clearInterval(guardIv);
      const sn = String(PROG.step || item.step || 'unknown').slice(0, 40); const stMap = Object.assign({}, item.stepTry || {}); stMap[sn] = (stMap[sn] || 0) + 1;
      const give = (item.ro || 0) >= I.MAX_REOPEN || stMap[sn] > 2;          // 1.1.7.6: per-step retry cap (twice) OR overall reopen cap
      const ip = give ? (sent ? { status: 'liked', code: 'liked-unverified', msg: 'The like was sent, but the fresh page that should confirm it did not report back.', hb: 0, runner: '', at: nowH, stepTry: stMap, lg: lg.slice() } : { status: 'failed', code: 'step-timeout', msg: E_STEP, hb: 0, runner: '', at: nowH, stepTry: stMap, lg: lg.slice() })
        : Object.assign({ status: 'queued', ro: (item.ro || 0) + 1, hb: 0, runner: '', stepTry: stMap, lg: lg.slice() }, sent ? { sent: sentLocal || (known && known.items && known.items[idx] && known.items[idx].sent) || nowH, mk: mkey, verify: nowH } : {});
      try { await bound(patchNow(b.id, idx, ip, give ? null : { graceUntil: nowH + L.NAV_GRACE_MS }, (bb) => { const gg = (bb.groups || []).find((x) => (x.cid || '') === cid); if (gg) { if (give) { /* the group carries on with its next item */ } else { gg.status = 'queued'; gg.recycle = (gg.recycle || 0) + 1; gg.reopened = (gg.reopened || 0) + 1; } } if (!give) bb.nextAt = nowH + 1500; bb.events = (bb.events || []).concat([[nowH, 'a tab step did not finish (' + why + '): handed back by the tab itself']]).slice(-20); }), 25000, 'hand back'); } catch (_) { /* the runner's watchdog is the second line */ }
      stripToken();
    };
    const E_STEP = 'A step in this container’s tab timed out and the safe reattempts (fresh tab, same location, never re-clicking a verified like) did not finish it either. Nothing was clicked for it.';
    const guardIv = setInterval(() => {
      if (stop || guardFired || batchEnded || Date.now() - PROG.at < GUARD_MS) return;
      const ci = known && known.items && known.items[idx]; if (!ci || ci.status !== 'running') return;          // only an item this page is still working on (a finished / handed-back item is nobody's stall)
      guardFired = true; handBack('an awaited step never settled').catch(() => {});
    }, 5000);

    toast(`Bean ${tag()} · opening…`, 'busy');
    await readPace(b, ev);
    ev('open', `page loaded (${location.pathname}); item ${n} of ${total}; run found ${inf.via === 'bind' ? 'through the hand-over (YouTube had removed the URL parameters)' : 'in the URL parameters'}${item.tries >= 1 ? '; after a channel switch' : ''}${verifyMode ? '; a like was already sent earlier -> verifying only, no click' : ''}`);
    await patch(b.id, idx, { status: 'running', runner, hb: Date.now(), at: Date.now(), prog: Date.now(), step: 'page loaded', swat: 0, lg: lg.slice() }, { idx }, (bb) => { const g = (bb.groups || []).find((x) => (x.cid || '') === cid); if (g && g.status !== 'done') g.status = 'running'; });

    // ---- which channel is this tab on? (only for containers whose channels are known: the item then names the channel it must be liked from)
    let res = null, activeNow = null;
    const recheck = async () => {         // right before the click: a FRESH identity from all signals (page session, account menu, header picture) must confirm the selected channel
      if (!item.chid) return { ok: true, msg: 'container has no channel list: uses the active channel' };
      const info = await readIdentity(alive);
      const r = await readChannels();
      if (!r.ok) return { ok: false, code: 'unknown-state', msg: 'could not read the active channel' };
      const idn = identityNow(item, info, r); ev('identity', 'right before the click: ' + idn.text);
      if (!idn.ok) return { ok: false, code: 'wrong-channel', msg: idn.text };
      noteActive(cid, item.chid, item.chname, 'identity');          // 1.1.7.1: the multi-signal identity confirmed this channel as the active one of this container
      return { ok: true, msg: 'identity confirmed' };
    };
    // 1.1.2: when this tab already VERIFIED the active channel of this container on an earlier item (group.active), the slow "read the channel list" step is skipped: the item is either on
    // the right channel already, or goes straight to YouTube's switch address. The fresh read right before the click (recheck) is NOT skipped, so no like can come from a wrong channel.
    const gAct = ((b.groups || []).find((x) => (x.cid || '') === cid) || {}).active || '';
    if (!verifyMode) { await holdIfPaused('before this item is processed: nothing has been sent for it'); if (stop) return; }
    const idInfo0 = item.chid && !verifyMode ? await readIdentity(alive) : null;
    // ORDER PLANNING: when the page is already on ANOTHER ticked channel of this container (same comment, nothing done for it yet), that channel goes first: the two items trade their channel, saving a switch
    // (the "like sent" marker belongs to the channel that is really liked, i.e. the traded one: mkey is recomputed after the trade)
    if (idInfo0 && !(item.tries >= 1)) {
      const curId = I.pageChannelId(idInfo0);
      const sj = curId && curId !== item.chid ? b.items.findIndex((o, k) => k > idx && (o.cid || '') === (item.cid || '') && o.vid === item.vid && o.lc === item.lc && o.status === 'queued' && !o.tries && o.chid === curId) : -1;
      let swapMarker = null; if (sj >= 0) { try { swapMarker = await sget(markerKey(Object.assign({}, item, { chid: b.items[sj].chid, chhandle: b.items[sj].chhandle, ck: b.items[sj].ck }))); } catch (_) { /* ignore */ } }      // a like already sent for the other channel: no trade, the normal path (verify only) applies
      if (sj >= 0 && !swapMarker) {
        const F = ['chid', 'chname', 'chhandle', 'ck'], pick = (o) => F.reduce((a, f) => { a[f] = o[f]; return a; }, {}), mine0 = pick(item), other0 = pick(b.items[sj]);
        const nb = await patch(b.id, null, null, null, (bb) => { const A = bb.items[idx], B = bb.items[sj]; if (A && B && B.status === 'queued' && !B.tries && A.chid === mine0.chid && B.chid === other0.chid) { Object.assign(A, other0); Object.assign(B, mine0); } });
        ev('switch', 'trade written: item ' + (idx + 1) + ' -> ' + (nb && nb.items && nb.items[idx] && nb.items[idx].chid) + ', item ' + (sj + 1) + ' -> ' + (nb && nb.items && nb.items[sj] && nb.items[sj].chid));
        if (nb && nb.items && nb.items[idx] && nb.items[idx].chid === other0.chid) { healIdentity = { b: b.id, idx, sj, vid: item.vid, mine: other0, other: mine0 }; Object.assign(item, other0); mkey = markerKey(item); if (b.items[sj]) Object.assign(b.items[sj], mine0); ev('switch', `the page is already on '${other0.chname || other0.chid}' (also ticked): that channel is done first, and '${mine0.chname || mine0.chid}' follows (one switch saved)`); }
      }
    }
    // 1.1.6.3: hand the container back: the item goes back to the queue (nothing clicked, nothing sent), the popup closes this tab and opens a NEW tab in the same container (verified close; the item keeps its VPN location)
    const reopenNow = async (why, wantName) => {
      const nowR = Date.now();
      ev('switch', `reopen ${(item.ro || 0) + 1} of ${I.MAX_REOPEN}: ${why}: closing this tab and continuing in a NEW tab of the same container (nothing was clicked)`);
      toast(`Bean ${tag()} · continuing in a fresh tab…`, 'busy');
      clearInterval(hb); clearInterval(poll);
      await patch(b.id, idx, { status: 'queued', ro: (item.ro || 0) + 1, hb: 0, runner: '', lg: lg.slice() }, { graceUntil: nowR + L.NAV_GRACE_MS }, (bb) => { const gg = (bb.groups || []).find((x) => (x.cid || '') === cid); if (gg) { gg.status = 'queued'; gg.recycle = (gg.recycle || 0) + 1; gg.reopened = (gg.reopened || 0) + 1; } bb.nextAt = nowR + 1500; bb.events = (bb.events || []).concat([[nowR, `new tab for the same container: this one kept the old channel identity (${wantName || item.chname || item.chid})`]]).slice(-20); });
      stripToken();
    };
    const idPre = idInfo0 ? I.combine(I.signalPage(idInfo0, item.chid), null, null) : null;
    // 1.1.6.3 (the real 1.1.6.2 run f3jv8szpmvytshin: all 9 switches needed the fresh tab, after a switcher read and a probe): a page that FOLLOWS a switch (tries >= 1) whose own session (ytcfg) is still another channel goes straight to a
    // fresh tab: no switcher read (14 s on real YouTube), no fetch probe, no second load. The 3-signal gate decides again in the new tab.
    if (item.chid && !verifyMode && (item.tries || 0) >= 1 && (item.ro || 0) < 1 && idPre && idPre.verdict === 'mismatch') {
      ev('identity', idPre.text);
      await reopenNow('this page follows a channel switch but its own session is still another channel: straight to a fresh tab (no switcher read, no probe, no second load)');
      return;
    }
    const skipRead = !!(item.chid && !verifyMode && gAct && gAct === item.chid && !(item.tries >= 1) && idPre && idPre.verdict === 'confirmed');      // 1.1.4: the list read is only skipped when NO switch is needed; a switch is ALWAYS made with the address of the freshly read list entry
    if (skipRead) { noteActive(cid, item.chid, item.chname, 'identity'); ev('identity', idPre.text.replace(/ → CONFIRMED.*$/, ' → page session confirmed')); ev('switch', 'this container was on the selected channel for the previous item and the page itself is rendered for it: the list is not read again (it is read fresh right before the click)'); }
    if (item.chid && !verifyMode && !skipRead) {
      toast(`Bean ${tag()} · checking the channel…`, 'busy');
      const t0c = Date.now();
      await waitFor(() => document.readyState !== 'loading', 20000, alive, 200);       // 1.1.6: the account switcher is a fetch and ytcfg is inline in the head: no need to wait for the whole page (images, comments) to load
      ev('channel', `reading the account switcher (page ${document.readyState}, ${Math.round((Date.now() - t0c) / 100) / 10}s after load${item.tries >= 1 ? '; this page follows a channel switch' : ''})`);
      const cur = await Promise.race([readChannels((n, why) => ev('channel', `read attempt ${n} failed: ${why}`)), new Promise((r) => setTimeout(() => r({ ok: false, channels: [], timeout: true }), 70000))]);
      activeNow = cur.ok ? cur.channels.find((c) => c.active) : null;
      if (activeNow) noteActive(cid, activeNow.id, activeNow.name, 'menu');          // 1.1.7.1: what the account menu says is active NOW (replaces a stored channel that turned out wrong at open time)
      const want = cur.ok ? cur.channels.find((c) => c.id === item.chid) : null;
      ev('channel', cur.ok ? `active '${activeNow ? activeNow.name : '?'}', selected '${want ? want.name : '(not in list)'}', list has ${cur.channels.length}` : (cur.timeout ? 'the account switcher did not answer in 70 s' : 'could not read the channel list'));
      if (!cur.ok) res = { code: 'switch-failed', msg: 'could not read the channel list' };
      else if (!want) { res = { code: 'switch-failed', msg: `this account no longer has the channel '${item.chname || item.chid}' in its account menu (renamed, deleted, or it needs signing in again): skipped, nothing was clicked. Refresh the channels in Bean.` }; await markStale(item.cid, item.chid, 'not in the account menu'); }
      else {
        // remember what was active before the run touched anything (once per container), so it can be put back
        await patch(b.id, null, null, null, (bb) => { const g = (bb.groups || []).find((x) => (x.cid || '') === cid); if (g && !g.orig && activeNow) { g.orig = activeNow.id; g.origName = activeNow.name; } });
        // 1.1.6: "switched" needs BOTH: the switcher lists the wanted channel as active AND the page's own ytcfg identity (DELEGATED_SESSION_ID / DATASYNC_ID) is that channel. When the switcher says yes
        // but the page disagrees, the switch is made again (full navigation through the sign-in address), at most twice; after that the item is switch-failed and never clicked.
        const sameFetch = L.sameChannel(activeNow, want);
        const idn = sameFetch ? identityNow(item, await readIdentity(alive), cur) : null; if (idn) ev('identity', idn.text);
        // 1.1.6.1: the menu says "switched" but the page disagrees (the real 1.1.6 run). Ask the server for a FRESH copy of this very page: if THAT says the target, the document in the tab is a stale copy
        // (cache / service worker / history) and a unique-address re-load fixes it, no sign-in needed; if it also says the old channel, the sign-in itself did not take and the switch is made again.
        let fresh, straightNow = false;
        if (idn && idn.verdict !== 'confirmed') {
          ev('identity', 'this document: ' + docFacts());
          // 1.1.6.3 (the real 1.1.6.2 run: a fresh tab always showed the target): right after a switch (this page follows one) and before any reopen, this tab is NOT asked to prove anything: no fetch probe, no settle
          // wait, no same-tab reload. The three-signal gate has already said "not confirmed" here, so the item goes straight to a NEW tab, whose gate decides. A tab that is itself the reopened one probes as before.
          const straight = sameFetch && (item.tries || 0) >= 1 && (item.ro || 0) < 1;
          let fp = straight ? { says: 'target', ms: 0, straight: true } : await freshProbe(item.chid);
          // 1.1.6.2: YouTube's /signin is an interstitial whose cookies can still be arriving when the next page loads. Before anything navigates again, ask for fresh copies (no navigation, nothing clicked) until the server
          // renders the target: up to SETTLE_POLLS more times, 5 s apart, only while this item is being handled.
          for (let k = 0; !fp.straight && k < SETTLE_POLLS && fp.says !== 'target' && !stop && alive(); k++) { ev('identity', `the server does not render '${want.name}' yet (${fp.says}): waiting ${SETTLE_MS / 1000} s and asking again (${k + 1} of ${SETTLE_POLLS}); the sign-in may still be settling`); await sleep(SETTLE_MS); fp = await freshProbe(item.chid); }
          fresh = fp.says; straightNow = !!fp.straight;
          if (fp.straight) ev('identity', 'after the channel switch this tab is not confirmed: going straight to a fresh tab (no probe, no same-tab reload)'); else ev('identity', `a fresh copy of this same page (no cache, unique address${fp.status ? ', HTTP ' + fp.status : ''}${fp.err ? ', ' + fp.err : ''}, ${Math.round(fp.ms / 100) / 10}s) says: ${fp.says === 'target' ? 'the TARGET channel ' + I.tail6(fp.id) + ' => the tab holds a stale copy' : fp.says === 'other' ? 'ANOTHER channel ' + I.tail6(fp.id) + ' => the sign-in did not change the page identity' : 'could not be read'}`);
        }
        const step = I.nextStep({ tries: item.tries || 0, rf: item.rf || 0, ro: item.ro || 0, fetchSame: sameFetch, verdict: idn ? idn.verdict : null, fresh });
        if (step === 'fail') await markStale(item.cid, item.chid, 'the channel could not be switched to');
        if (step === 'fail') res = { code: 'switch-failed', msg: sameFetch ? `YouTube's account menu lists '${want.name}' as active, but the identity could not be confirmed (${idn.verdict}): ${idn.text}` : (activeNow ? `YouTube still shows '${activeNow.name}'` : 'the active channel could not be read') };
        else if (step === 'reopen') {
          // 1.1.6.2 (the real 1.1.6.1 run): the server renders the target for a fresh copy, but a navigation INSIDE this tab keeps showing the old channel (reloads and the page's own menu did not help); a tab opened LATER showed the target.
          // So this tab hands the container back: the item goes back to the queue (nothing was clicked, nothing was sent), the popup closes this tab and opens a NEW tab in the same container.
          await reopenNow(straightNow ? 'this tab is not confirmed after the switch (the fresh tab decides)' : fresh === 'target' ? `the server renders '${want.name}' but this tab keeps the old channel` : 'the page identity could not be confirmed in this tab', want.name);
          return;
        } else if (step === 'refresh') {
          const wk = await clearWorkers();
          ev('switch', `refresh ${(item.rf || 0) + 1} of ${I.MAX_REFRESH}: the server renders '${want.name}' but this tab holds an old copy: loading the same page again from a unique address (removed ${wk.w} service worker(s), ${wk.c} cache(s)); no sign-in, nothing clicked`);
          toast(`Bean ${tag()} · reloading fresh…`, 'busy');
          clearInterval(hb); clearInterval(poll);
          await holdIfPaused('before reloading the page'); if (stop) return;
          await patch(b.id, idx, { rf: (item.rf || 0) + 1, hb: 0, runner: '', lg: lg.slice() }, { graceUntil: Date.now() + L.NAV_GRACE_MS });
          if (stop) return;
          await goTo(L.watchUrl(item.vid, item.lc, b.id, cid, item.chid, Date.now().toString(36)), b, item, cid, 'switch');
          return;
        } else if (step === 'switch') {
          // the avatar menu → "Switch account" → channel does exactly this: it goes to YouTube's signin address for that channel and comes back to the page (next=)
          // 1.1.6.1: next= is a UNIQUE address (p9bt), so the page that comes back can never be answered from a copy of the page the tab showed before the switch
          const target = L.switchUrl(want, L.watchUrl(item.vid, item.lc, b.id, cid, item.chid, Date.now().toString(36)));
          const method = I.switchMethod((item.tries || 0) + (item.swlost || 0));          // 1.1.7.1: an attempt whose switch address never came back is not counted in `tries`, but the next one uses the other method
          toast(`Bean ${tag()} · switching to ${want.name}…`, 'busy');
          clearInterval(hb); clearInterval(poll);
          ev('switch', `attempt ${(item.tries || 0) + (item.swlost || 0) + 1} of ${I.MAX_SWITCH_TRIES}: '${activeNow ? activeNow.name : '?'}'${sameFetch ? ' (the page itself is not that channel yet)' : ''} -> '${want.name}' via ${method === 'ui' ? "the page's own account menu (a click on the channel row)" : "YouTube's own switch address"}`);
          await holdIfPaused('before switching channel');
          if (stop) return;
          if ((item.tries || 0) >= 1) await sleep(I.backoffMs(item.tries));          // bounded back-off before the next attempt
          await patch(b.id, idx, { tries: (item.tries || 0) + 1, swat: Date.now(), hb: 0, lg: lg.slice() }, { graceUntil: Date.now() + (method === 'ui' ? L.SWITCH_WATCH_UI_MS : L.SWITCH_WATCH_MS) }, (bb) => { const g = (bb.groups || []).find((x) => (x.cid || '') === cid); if (g) g.switches = (g.switches || 0) + 1; });      // 1.1.7.1: switch-page watchdog: the next page must load within ~28 s (45 s via the page's own menu) or the container is reopened in a fresh tab (the runner)
          if (!target || stop) return;
          if (method === 'ui') {
            await bindNav(b, item, cid, 'switch'); batchEnded = true;
            const r = await uiSwitch(want, alive);
            if (r === 'clicked') { await sleep(6000); if (stop) return; ev('switch', "the page's own menu did not navigate within 6 s: using the switch address instead"); }          // 1.1.7.1: was 15 s (a click that navigates unloads this page at once; 15 s of waiting for nothing)
            else ev('switch', `the page's own account menu could not be used (${r}): using the switch address instead`);
            await patch(b.id, idx, { lg: lg.slice() });
          }
          await goTo(target, b, item, cid, 'switch');
          return;
        } else { item.chname = want.name; ev('switch', `verified: the account menu, the page session and the header picture agree on '${want.name}'`); }
      }
    }
    if (!res) {
      try { hideOthers(item.lc); } catch (_) { /* cosmetic only */ }
      try { res = await processComment(item, b.pace, (t) => toast(`Bean ${tag()} · ${t}`, 'busy'), alive, b.vpn && b.vpn.on && !item.vpnSkip && !verifyMode ? { bid: b.id, idx, cid } : null, { ev, recheck, b, runner, hold: holdIfPaused, idx, verify: verifyMode, marker, mkey, onSent: () => { sentLocal = Date.now(); return patch(b.id, idx, { sent: sentLocal, mk: mkey, cnt0: cnt0Now, cwarn: cwarnNow, lg: lg.slice() }).catch(() => {}); } }); }
      catch (e) { res = { code: 'click-failed', msg: String(e && e.message || e).slice(0, 120) }; }
    }
    clearInterval(hb);
    // 1.1.7.1: a step before the click that got no answer / did not finish (the VPN confirmation, a storage read, the identity re-check) is NEVER a result: nothing was clicked, so the container is handed back and continues in a fresh tab
    // (the item keeps its VPN location). After MAX_REOPEN of those it fails with a plain message.
    if ((res.code === 'vpn-unanswered' || res.code === 'step-timeout') && !stop && (item.ro || 0) < I.MAX_REOPEN) { await reopenNow(res.msg || res.code); return; }
    if (res.code === 'stale-liked' && !stop) {
      clearInterval(poll); ev('state', 'liked on the first page after a channel switch: that can be the previous channel\'s like, so it is not believed; reloading once from a fresh page to read it again');
      await patch(b.id, idx, Object.assign({ fresh: Date.now(), runner: '', hb: 0, lg: lg.slice() }, res.vpn ? { vpn: { location: res.vpn.location || '', ipChanged: res.vpn.ipChanged == null ? null : !!res.vpn.ipChanged } } : {}), { graceUntil: Date.now() + L.NAV_GRACE_MS });
      if (!stop) { await goTo(L.watchUrl(item.vid, item.lc, b.id, cid, item.chid, Date.now().toString(36)), b, item, cid, 'verify'); return; }
    }
    if (res.code === 'verify-reload' && !stop) {         // the like was sent and held for a few seconds: reload the page and read the state again from a FRESH page before it is called "liked"
      clearInterval(poll); ev('verify', 'reloading the page to confirm the like from a fresh page');
      await patch(b.id, idx, { runner: '', hb: 0, verify: Date.now(), lg: lg.slice() }, { graceUntil: Date.now() + L.NAV_GRACE_MS });
      if (!stop) { await goTo(L.watchUrl(item.vid, item.lc, b.id, cid, item.chid, Date.now().toString(36)), b, item, cid, 'verify'); return; }
    }
    if (res.code === 'verify-retry' && !stop) {         // 1.1.6.3: the like was SENT and the fresh page could not tell (comment missing, state unknown, session unclear): read again from another fresh page, bounded; NEVER "not found", NEVER a second click
      const vt = (item.vtries || 0) + 1;
      if (vt < VERIFY_TRIES) {
        clearInterval(poll); ev('verify', `${res.msg}: reading the state again from a fresh page (${vt} of ${VERIFY_TRIES - 1}); nothing is clicked`);
        await patch(b.id, idx, { vtries: vt, runner: '', hb: 0, verify: Date.now(), lg: lg.slice() }, { graceUntil: Date.now() + L.NAV_GRACE_MS });
        await sleep(1500 * vt); if (stop) return;
        await goTo(L.watchUrl(item.vid, item.lc, b.id, cid, item.chid, Date.now().toString(36)), b, item, cid, 'verify'); return;
      }
      const mineM = marker && marker.bid === b.id && (marker.at || 0) >= (b.created || 0);
      res = mineM ? { code: 'liked-unverified', msg: `The like was sent (and stayed pressed 3 s), but ${VERIFY_TRIES} fresh pages could not confirm it: ${res.msg}. Counted as sent, never clicked again.`, vpn: marker.vpn || null } : { code: 'click-sent-before' };
    }
    if (stop) { clearInterval(poll); toast('Bean · stopped', 'warn'); if (fenced) retire(); stripToken(); return; }
    ev('result', `${res.code}${res.msg ? ' — ' + res.msg : ''}`);

    // YouTube Focus missing/off is the same in every container: stop the whole run. "Not signed in" only concerns THIS container: skip its other links, the next container still runs.
    // A channel that could not be switched to only costs its own links.
    const blocking = res.code === 'ytf-off' || res.code === 'no-ytf' || res.code === 'not-signed-in' || res.code === 'vpn-unavailable';
    const everywhere = res.code === 'ytf-off' || res.code === 'no-ytf' || res.code === 'vpn-unavailable';
    const done = await patch(b.id, idx, { status: res.code === 'liked-unverified' ? 'liked' : res.code === 'liked' || res.code === 'already' ? res.code : 'failed', code: res.code, msg: res.msg || '', at: Date.now(), hb: 0, verify: 0, lg: lg.slice(), chname: item.chname || (activeNow && !item.chid ? activeNow.name : ''), vpn: res.vpn || null }, null, (bb) => { const g = (bb.groups || []).find((x) => (x.cid || '') === cid); if (g && item.chid) g.active = (res.code === 'liked' || res.code === 'already') ? item.chid : ''; });      // 1.1.7.1: a like / "already" is only reached after the identity check: that channel is the container's active one
    if (item.chid && (res.code === 'liked' || res.code === 'already')) await noteActive(cid, item.chid, item.chname, 'identity');      // 1.1.2: remember which channel was just verified in this container
    const kind = L.kind(res.code);
    toast(`Bean ${tag()} · ${res.code === 'switch-failed' ? L.label(res.code) + ' ' + (item.chname || '') : L.label(res.code)}`, kind);
    if (!done) { clearInterval(poll); return; }
    if (blocking) {
      await patch(b.id, null, null, everywhere ? { state: 'stopped' } : {}, (bb) => { bb.items.forEach((it) => { if (it.status === 'queued' && (everywhere || inGroup(it))) { it.status = 'skipped'; it.code = res.code; it.msg = 'Skipped: ' + L.label(res.code); } }); });
    }
    let next = -1;
    if (!blocking) next = done.items.findIndex((it) => inGroup(it) && it.status === 'queued');
    if (next < 0) {
      // this container's links are all done. If channels were switched, put the original channel back (and check it) before the next container starts.
      const g = (done.groups || []).find((x) => (x.cid || '') === cid);
      const lastAct = await (async () => { if (!b.restoreBack || !g || !g.orig || !(g.switches > 0) || stop) return null; const r = await readChannels(); return r.ok ? { list: r.channels, act: r.channels.find((c) => c.active) } : { list: [], act: null }; })();
      if (lastAct && lastAct.act) noteActive(cid, lastAct.act.id, lastAct.act.name, 'menu');
      if (lastAct && !(lastAct.act && L.sameChannel(lastAct.act, { id: g.orig, name: g.origName }))) {
        const back = lastAct.list.find((c) => c.id === g.orig);
        await patch(b.id, null, null, null, (bb) => { const gg = (bb.groups || []).find((x) => (x.cid || '') === cid); if (gg) { gg.restore = back ? 'pending' : 'failed'; if (!back) gg.restoreMsg = 'that channel is not in the list any more'; if (!back) finishGroup(bb, cid); } });
        clearInterval(poll);
        if (back) { await holdIfPaused('before switching back to the original channel'); if (stop) { stripToken(); return; } toast(`Bean · switching back to ${g.origName}…`, 'busy'); await patch(b.id, null, null, { graceUntil: Date.now() + L.NAV_GRACE_MS }).catch(() => {}); await sleep(1200); batchEnded = true; location.assign(L.switchUrl(back, L.restoreUrl(b.id, cid))); return; }
        stripToken(); return;
      }
      await patch(b.id, null, null, null, (bb) => { const gg = (bb.groups || []).find((x) => (x.cid || '') === cid); if (gg && gg.switches > 0 && gg.orig) gg.restore = 'ok'; finishGroup(bb, cid); });
      clearInterval(poll); stripToken();
      return;
    }
    await holdIfPaused('before the next item');
    // 1.1.7 TAB RECYCLE (lib/orders.js shouldRecycle, same numbers): a tab that handled RECYCLE_ITEMS items, or lived RECYCLE_MS, ends here (nothing in flight, nothing sent for the next item) and hands its container back:
    // the group goes back to 'queued', the popup / runner closes this tab and opens a fresh one for the same container (same wave VPN location kept when rotation is on). Frees the page's memory on long runs.
    { const gR = (done.groups || []).find((x) => (x.cid || '') === cid), nowR = Date.now();
      const mineR = done.items.filter((it) => inGroup(it) && it.status !== 'queued' && it.status !== 'running' && (it.at || 0) >= ((gR && gR.openedAt) || 0)).length;
      if (!stop && gR && (mineR >= RECYCLE_ITEMS || (gR.openedAt && nowR - gR.openedAt >= RECYCLE_MS && mineR >= 3))) {
        ev('recycle', `this tab handled ${mineR} item${mineR === 1 ? '' : 's'} in ${Math.round((nowR - gR.openedAt) / 60000)} min: it hands the container back so a fresh tab continues (nothing is in flight)`);
        await patch(b.id, null, null, { graceUntil: nowR + L.NAV_GRACE_MS }, (bb) => { const gg = (bb.groups || []).find((x) => (x.cid || '') === cid); if (gg) { gg.status = 'queued'; gg.recycle = (gg.recycle || 0) + 1; gg.recycledAt = nowR; } bb.nextAt = nowR + 2000; bb.events = (bb.events || []).concat([[nowR, `tab recycled after ${mineR} items (${(gR.name || cid || 'container')})`]]).slice(-20); });
        clearInterval(poll); stripToken(); return;
      } }
    // human-like pause, then the same tab goes to the next comment (or the next channel) of this container.
    // 1.1.2: the NEXT item's VPN location is set DURING this pause: this page is loaded and idle (nothing in flight) and it only navigates after the connection is confirmed — so the next
    // page loads on the new exit and the VPN is never touched while a page loads, redirects, verifies or clicks.
    // 1.1.7.7 WAVE-SHARED VPN: when the wave already has a location (or this item was stamped before the tab opened), do NOT rotate again in the pace gap — every container in the wave shares one switch.
    let nextIdx = next, vres = null, vevs = [];
    for (let first = true; ; first = false) {
      const nx0 = done.items[nextIdx];
      const needVpn = !!(b.vpn && b.vpn.on && nx0 && !nx0.vpnSkip && !stop);
      const haveLoc = !!(nx0 && nx0.vpn && nx0.vpn.location !== undefined);
      const waveLoc = b.wave && b.wave.loc && b.wave.loc.location !== undefined ? b.wave.loc : null;
      vevs = [];
      let vp = null;
      if (needVpn && haveLoc) { vres = { ok: true, location: nx0.vpn.location || '', ipChanged: nx0.vpn.ipChanged }; vevs.push([Date.now(), 'vpn', `kept shared/wave location '${nx0.vpn.location || '?'}' (no per-channel rotate inside the wave)`]); }
      else if (needVpn && waveLoc) {
        vres = { ok: true, location: waveLoc.location || '', ipChanged: waveLoc.ipChanged == null ? null : !!waveLoc.ipChanged };
        vevs.push([Date.now(), 'vpn', `inherited wave ${b.wave.n} location '${waveLoc.location || '?'}' (one VPN switch for the parallel set)`]);
        await patch(b.id, nextIdx, { vpn: { location: vres.location, ipChanged: vres.ipChanged } }).catch(() => {});
      } else {
        vp = needVpn ? vpnSwitch({ bid: b.id, idx: nextIdx, cid }, () => {}, alive, (st, d) => vevs.push([Date.now(), st, d])) : null;
        vres = null;
      }
      if (first) await readPace(b, ev);          // 1.1.6.3: the ONE saved pace, read fresh right before the gap: a change applies from this item on
      const pause = first ? L.pauseMs(L.pickPace(paceStored, b.pace)) : 0;
      if (first) { ev('gap', `${Math.round(pause / 100) / 10} s before the next item (${L.paceLabel(L.pickPace(paceStored, b.pace))})`); patch(b.id, idx, { lg: lg.slice() }).catch(() => {}); }          // shown in the run log
      const t0 = Date.now();
      while (Date.now() - t0 < pause && !stop) {
        toast(`Bean ${tag()} · ${L.label(res.code)} — next in ${Math.max(1, Math.ceil((pause - (Date.now() - t0)) / 1000))}s${vp ? ' (VPN switching meanwhile)' : ''}`, kind);
        patch(b.id, null, null, {}).catch(() => {});       // refreshes batch.updated
        await sleep(1000);
      }
      if (vp) vres = await vp;
      if (vp && !stop) toast(`Bean ${tag()} · VPN ${vres && vres.ok ? 'ready' : 'failed'}`, vres && vres.ok ? 'ok' : 'bad');
      if (stop || !vres || vres.ok) break;
      // the switch failed: only THAT next item fails (it is not even loaded); the following item gets its own switch
      const failIdx = nextIdx, evs = vevs, code = vres.code || 'vpn-failed', everywhere2 = code === 'vpn-unavailable';
      const after = await patch(b.id, failIdx, { status: 'failed', code, msg: vres.msg || '', at: Date.now(), hb: 0, lg: ((done.items[failIdx] && done.items[failIdx].lg) || []).concat(evs, [[Date.now(), 'result', code + ' — the VPN could not be set before this item: not loaded, not clicked']]).slice(-60) }, everywhere2 ? { state: 'stopped' } : null,
        (bb) => { if (everywhere2) bb.items.forEach((it) => { if (it.status === 'queued') { it.status = 'skipped'; it.code = code; it.msg = 'Skipped: ' + L.label(code); } }); });
      if (!after || everywhere2) { clearInterval(poll); stripToken(); return; }
      done.items = after.items; nextIdx = after.items.findIndex((it) => inGroup(it) && it.status === 'queued');
      if (nextIdx < 0) { await patch(b.id, null, null, null, (bb) => { finishGroup(bb, cid); }); clearInterval(poll); stripToken(); return; }
    }
    clearInterval(poll);
    if (!stop) { try { const cur = await readB(); if (cur && cur.id === b.id && cur.state !== 'running') stop = true; } catch (_) { /* ignore */ } }   // last look at the record before leaving this page (Stop may have arrived without an event)
    if (stop) { toast('Bean · stopped', 'warn'); if (fenced) retire(); stripToken(); return; }
    await holdIfPaused('before loading the next item');
    if (stop) { toast('Bean · stopped', 'warn'); if (fenced) retire(); stripToken(); return; }
    const nx = done.items[nextIdx];
    if (vres && vres.ok) await patch(b.id, nextIdx, { vpn: { location: vres.location || '', ipChanged: vres.ipChanged == null ? null : !!vres.ipChanged }, lg: ((nx && nx.lg) || []).concat(vevs).slice(-60) }, { graceUntil: Date.now() + L.NAV_GRACE_MS }).catch(() => {});
    else await patch(b.id, null, null, { graceUntil: Date.now() + L.NAV_GRACE_MS }).catch(() => {});        // 1.1.2: the next page may take a long time to load: say so
    await goTo(L.watchUrl(nx.vid, nx.lc, b.id, cid, nx.chid), b, nx, cid, 'next');
  }

  // read-modify-write on the batch record. itemPatch applies to items[idx]; bPatch to the batch; fn(batch) for anything else.
  // All writes of this tab go through ONE queue: the heartbeat, the pause countdown and the result writes are read-modify-write on the same record, and when they
  // interleave the older one overwrites the newer (a finished item went back to "running").
  let patchChain = Promise.resolve();
  function patch(id, idx, itemPatch, bPatch, fn) {
    const run = patchChain.then(() => bound(patchNow(id, idx, itemPatch, bPatch, fn), 45000, 'run record write'));          // 1.1.7.1: one write that never settles can no longer block every later write (heartbeat, results)
    patchChain = run.catch(() => {});
    return run;
  }
  // Panel 9's cross-session storage mirror can briefly bring back an OLDER record (or none) for this key. The tab keeps the last good copy of ITS run and, when
  // the stored record is missing or older, continues from that copy instead of abandoning the run.
  let known = null;
  // Same mirror, same-run case: an older copy of the record can also come back with a finished item shown as queued/running again (it would make this tab load that
  // link a second time). Every finished item this tab has seen is remembered and put back into the record before anything is decided or written.
  const finSeen = {};
  const isFin = (it) => !!it && it.status !== 'queued' && it.status !== 'running';
  function noteFin(b) { if (b && Array.isArray(b.items)) b.items.forEach((it, i) => { if (isFin(it) && !finSeen[b.id + ':' + i]) finSeen[b.id + ':' + i] = JSON.parse(JSON.stringify(it)); }); }
  function healFin(b) { if (b && Array.isArray(b.items)) b.items.forEach((it, i) => { const f = finSeen[b.id + ':' + i]; if (f && !isFin(it)) b.items[i] = JSON.parse(JSON.stringify(f)); }); }
  // 1.1.7 SPLIT WRITERS: this tab NEVER writes the run record (p9bn.batch). What it wants to change is folded into its own cumulative REPORT (p9bn.rep.<run>.<container>.<slot>, whole key, only this tab writes it) and
  // a tiny HEARTBEAT (p9bn.hb.…); the page that owns the run merges them (lib/reports.js). The tab's own view of the run = the record + its own report on top (readB), so it never loses sight of what it just did.
  const myCid = () => (info && info.cid) || '';
  async function ensureSlot(id) {
    if (rep && rep.bid === id) return;
    const keys = []; for (let k = 0; k < R.SLOTS; k++) keys.push(R.keyHb(id, myCid(), k));
    let have = {}; try { have = await stor(() => chrome.storage.local.get(keys), 'storage read'); } catch (_) { /* first free slot */ }
    let k = 0; for (; k < R.SLOTS - 1; k++) if (!have[keys[k]]) break;         // a free slot (an older tab of this container keeps its own until the runner has merged and cleared it)
    repSlot = k; rep = R.emptyRep(Date.now()); rep.bid = id;
  }
  // 1.1.7: the page's view = the run record + the reports of the EARLIER pages of this same tab/container (newer than the tab's open time, repCut) + its own report. A page that follows a channel switch / reload must
  // see at once what the page before it reported (tries, fresh, sent, verify...): the runner merges reports only once a second (or once a minute in a throttled hidden page), a new page loads in under that.
  async function readB() {
    const raw = await sget(K.batch); if (!raw || (rep && raw.id !== rep.bid)) return raw;
    // (no report of its own yet = a page that has just loaded: it still sees the reports of the pages before it - the very first read of a page after a channel switch decides which item it takes)
    try {
      const cid = myCid(), cut = ((raw.repCut || {})[cid]) || 0, keys = []; for (let k = 0; k < R.SLOTS; k++) if (!rep || k !== repSlot) keys.push(R.keyRep(raw.id, cid, k));
      const got = await stor(() => chrome.storage.local.get(keys), 'storage read'), olds = Object.keys(got).map((k) => got[k]).filter((r) => r && r.gen && (!rep || r.gen < rep.gen) && r.gen >= cut && r.bid === raw.id).sort((x, y) => x.gen - y.gen);
      for (const r of olds) R.overlay(raw, r);
    } catch (_) { /* own report only */ }
    return rep ? R.overlay(raw, rep) : raw;
  }
  async function patchNow(id, idx, itemPatch, bPatch, fn) {
    let b = await readB();
    if ((!b || b.id !== id) && known && known.id === id && (!b || (b.created || 0) < (known.created || 0))) b = JSON.parse(JSON.stringify(known));
    if (!b || b.id !== id) return null;
    // 1.1.1 FENCE: once the run is over (done / stopped) this page never writes to it again and stops (a late write could resurrect the run or change a result)
    if (b.state !== 'running') { known = b; fenced = true; if (onFence) { try { onFence(); } catch (_) { /* ignore */ } } return b; }
    const before = JSON.parse(JSON.stringify(b));
    healFin(b);
    if (healIdentity && healIdentity.b === b.id) { const A = b.items[healIdentity.idx], P = b.items[healIdentity.sj]; if (A && (A.status === 'queued' || A.status === 'running') && A.chid !== healIdentity.mine.chid && A.vid === healIdentity.vid) Object.assign(A, healIdentity.mine); if (P && P.status === 'queued' && !P.tries && P.chid !== healIdentity.other.chid) Object.assign(P, healIdentity.other); }
    if (idx != null && itemPatch && b.items[idx]) Object.assign(b.items[idx], itemPatch);
    if (bPatch) { if (b.state !== 'running' && bPatch.state) return b; Object.assign(b, bPatch); }   // never resurrect a stopped run
    if (fn) fn(b);
    b.updated = Date.now();
    if (!(bPatch && bPatch.graceUntil)) b.graceUntil = 0;         // 1.1.2: a normal write = the page is alive; only a write that announces a navigation sets a grace period
    noteFin(b);
    await ensureSlot(id);
    const d = R.delta(before, b, Date.now());
    if (!R.isEmpty(d)) { R.mergeInto(rep, d); rep.seq++; await sset(R.keyRep(id, myCid(), repSlot), rep); }
    hbSeq++; await sset(R.keyHb(id, myCid(), repSlot), { gen: rep.gen, slot: repSlot, seq: hbSeq, rseq: rep.seq, graceMs: d.graceMs, idx: idx == null ? -1 : idx, at: Date.now() });
    known = b;
    return b;
  }
  let fenced = false, onFence = null;
  // 1.1.6 order planning traded the channels of two queued items. Another page of the extension can still write an OLDER copy of the run record (the storage hand-over race) and put the old channels back; every write of this tab re-asserts the trade until the run moves on
  let healIdentity = null;
  // the run is over: this tab does nothing more. It leaves the YouTube page (the popup also closes the tab) so that nothing on it can act, even if the tab stays open.
  function retire() { batchEnded = true; let had = false; try { had = new URL(location.href).searchParams.has(L.TOKEN); } catch (_) { /* ignore */ } if (had) setTimeout(() => { try { location.replace('about:blank'); } catch (_) { /* ignore */ } }, 700); }
  let batchEnded = false;           // set once this tab has finished with its run: late storage events must not make it log or write anything
  function stripToken() {
    batchEnded = true;
    try { const u = new URL(location.href); if (u.searchParams.has(L.TOKEN)) { for (const k of [L.TOKEN, L.CTOKEN, L.HTOKEN, L.DTOKEN, L.PTOKEN]) u.searchParams.delete(k); history.replaceState(history.state, '', u.pathname + u.search + u.hash); } } catch (_) { /* ignore */ }
  }

  // ================================================================== the actual "find it, like it" logic
  const COMMENT = 'ytd-comment-view-model, ytd-comment-renderer';
  async function waitFor(fn, ms, alive, step) {
    const t0 = Date.now();
    for (;;) {
      let v = null;
      try { v = fn(); } catch (_) { v = null; }
      if (v) return v;
      if (Date.now() - t0 >= ms || (alive && !alive())) return null;
      await sleep(step || 200);
    }
  }
  const visible = (el) => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';

  // 'in' | 'out' | 'unknown'
  function signedState() {
    if (root.hasAttribute('data-ytf-acct')) return 'in';
    const m = document.querySelector('ytd-masthead');
    if (!m) return 'unknown';
    if (m.querySelector('#avatar-btn, button[aria-label="Account menu" i]')) return 'in';
    if (m.querySelector('a[href*="accounts.google.com/ServiceLogin" i], a[href*="accounts.google.com/v3/signin" i], a[aria-label^="Sign in" i], ytd-button-renderer.style-suggestive a')) return 'out';
    return 'unknown';
  }
  const lcOf = (a) => { try { return new URL(a.getAttribute('href') || '', location.origin).searchParams.get('lc') || ''; } catch (_) { return ''; } };
  function findComment(lc) {
    const scope = document.querySelector('ytd-comments') || document;
    for (const a of scope.querySelectorAll('a[href*="lc="]')) {
      if (lcOf(a) !== lc) continue;
      const c = a.closest(COMMENT);
      if (c) return c;
    }
    return null;
  }
  // only used when the id anchor cannot be matched: YouTube's own "Highlighted comment" badge on the linked comment
  function findHighlighted() {
    const b = document.querySelector('ytd-comments #linked-comment-badge:not([hidden]) , ytd-comments [id="linked-comment-badge"]');
    if (!b || !visible(b) || !String(b.textContent || '').trim()) return null;
    return b.closest(COMMENT);
  }
  // ---- 1.1.6.1 channel-switch helpers (read-only probes, plus the page's own account-menu click; none of them ever touches a like button)
  // facts about THIS document that tell a stale copy from a fresh one: how it was navigated to, whether a service worker / the HTTP cache answered it
  function docFacts() {
    try {
      const n = (performance.getEntriesByType('navigation') || [])[0] || {};
      const ctl = navigator.serviceWorker && navigator.serviceWorker.controller ? 'yes' : 'no';
      return `navigation ${n.type || '?'}, ${n.redirectCount == null ? '?' : n.redirectCount} redirects, answered by a service worker ${n.workerStart > 0 ? 'yes' : 'no'}, page controlled by a worker ${ctl}, delivery ${n.deliveryType || 'network'}, ${n.transferSize == null ? '?' : n.transferSize === 0 ? '0 B transferred (cache)' : Math.round(n.transferSize / 1024) + ' kB transferred'}`;
    } catch (_) { return 'not readable'; }
  }
  // a FRESH copy of this very page (cache:'no-store', a unique address): what channel does the server render it for right now?
  async function freshProbe(chid) {
    const t0 = Date.now(), ctl = typeof AbortController === 'function' ? new AbortController() : null, to = ctl ? setTimeout(() => ctl.abort(), 45000) : 0;
    try {
      const u = new URL(location.href); u.searchParams.set('p9bt', Date.now().toString(36) + 'f');
      const r = await fetch(u.toString(), { cache: 'no-store', credentials: 'same-origin', signal: ctl ? ctl.signal : undefined });
      const text = await r.text(); const info = I.parseYtcfg([text]);
      return { says: I.freshSays(info, chid), id: I.pageChannelId(info), status: r.status, ms: Date.now() - t0 };
    } catch (e) { return { says: 'unknown', id: null, status: 0, ms: Date.now() - t0, err: String(e && e.message || e).slice(0, 60) }; }
    finally { if (to) clearTimeout(to); }
  }
  // YouTube's service worker and its cache storage can answer a page load with an old copy: remove them (YouTube re-registers its own later)
  async function clearWorkers() {
    let w = 0, c = 0;
    try { const regs = navigator.serviceWorker && navigator.serviceWorker.getRegistrations ? await Promise.race([navigator.serviceWorker.getRegistrations(), sleep(4000).then(() => [])]) : []; for (const r of regs) { try { if (await r.unregister()) w++; } catch (_) { /* ignore */ } } } catch (_) { /* ignore */ }
    try { if (self.caches && caches.keys) { for (const k of await Promise.race([caches.keys(), sleep(4000).then(() => [])])) { try { if (await caches.delete(k)) c++; } catch (_) { /* ignore */ } } } } catch (_) { /* ignore */ }
    return { w, c };
  }
  // the page's OWN way to switch: avatar -> the account switcher row -> the channel's row. It makes YouTube do its own navigation. Returns 'clicked' | a short reason. Only menu rows are clicked, never anything near a comment.
  // 1.1.6.2: LANGUAGE-INDEPENDENT. No label of the menu is read or matched (the labels are in the user's language: Russian, Arabic, Japanese, ...). The switcher row is found by STRUCTURE:
  //   the account menu's first section holds [Google Account, Switch account, Sign out]; the account and sign-out rows are links (<a href>), the switcher is the in-menu action without an address.
  //   Candidates = rows of that first section WITHOUT an address (the last row is never taken when the section has 3 or more rows: that is sign-out). The click is checked by its RESULT: the list of channels
  //   (ytd-account-item-renderer rows) must open, else the menu is closed again and nothing else is tried. The channel row is chosen by the channel's picture / its NAME (user data, not interface text).
  function switchRows(menu) {
    const secs = Array.from(menu.querySelectorAll('ytd-multi-page-menu-section-renderer')).filter((x) => x.querySelector('ytd-compact-link-renderer'));
    const rows = Array.from((secs[0] || menu).querySelectorAll('ytd-compact-link-renderer'));
    const hasAddr = (r) => !!r.querySelector('a[href]');
    const pool = rows.length >= 3 ? rows.slice(0, -1) : rows;
    return pool.filter((r) => !hasAddr(r));
  }
  async function uiSwitch(want, alive) {
    const av = document.querySelector('ytd-masthead #avatar-btn, ytd-masthead button#avatar-btn');
    if (!av) return 'no avatar button on this page';
    try { av.click(); } catch (_) { return 'the avatar button could not be clicked'; }
    const menu = await waitFor(() => document.querySelector('ytd-multi-page-menu-renderer'), 6000, alive, 150);
    if (!menu) return 'the account menu did not open';
    await waitFor(() => menu.querySelectorAll('ytd-compact-link-renderer').length >= 2, 5000, alive, 150);      // the menu is filled in a moment after it opens
    const cands = switchRows(menu);
    const close = () => { try { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); } catch (_) { /* ignore */ } };
    if (cands.length !== 1) { close(); return cands.length ? `${cands.length} rows of the menu could be the account switcher (by structure): not guessing` : 'no account switcher row found in the menu (by structure)'; }
    try { (cands[0].querySelector('tp-yt-paper-item, a') || cands[0]).click(); } catch (_) { return 'the account switcher row could not be clicked'; }
    const rows = await waitFor(() => { const x = Array.from(document.querySelectorAll('ytd-account-item-renderer')); return x.length ? x : null; }, 9000, alive, 200);
    if (!rows) { close(); return 'the channel list did not open'; }
    const norm = (t) => String(t || '').replace(/\s+/g, ' ').trim().toLowerCase(), nm = norm(want.name), title = (r) => norm((r.querySelector('#channel-title') || {}).textContent || '');
    const pic = (r) => { try { const im = r.querySelector('img'); return im ? I.normAvatar(String(im.currentSrc || im.src || im.getAttribute('src') || '')) : ''; } catch (_) { return ''; } };
    const wp = want.avatar ? I.normAvatar(String(want.avatar)) : '';
    const byPic = wp ? rows.filter((r) => pic(r) && pic(r) === wp) : [];
    const hit = byPic.length === 1 ? byPic[0] : (rows.find((r) => title(r) === nm) || rows.filter((r) => norm(r.textContent).includes(nm)).sort((x, y) => norm(x.textContent).length - norm(y.textContent).length)[0]);
    if (!hit) { close(); return `no row for the channel '${want.name}' in the list`; }
    try { (hit.querySelector('tp-yt-paper-icon-item, #contents, a') || hit).click(); } catch (_) { return 'the channel row could not be clicked'; }
    return 'clicked';
  }
  // 1.1.6 diagnostics (read-only): who the page says it is rendered for, and the comment's vote count as shown. Never touches page scripts: the identity is parsed from the inline ytcfg text.
  function pageIdentity() {
    try { return I.parseYtcfg(Array.from(document.scripts).map((sc) => { const t = sc.textContent; return t && t.length < 4000000 ? t : ''; })); } catch (_) { return {}; }      // read-only
  }
  // slow ytcfg: the page's own session can appear a little after the page is "complete"; wait for it (up to 6 s) before calling it unreadable
  async function readIdentity(alive) {
    let i = pageIdentity();
    for (let t0 = Date.now(); i.dsid === undefined && i.sync === undefined && Date.now() - t0 < 6000 && (!alive || alive()); ) { await sleep(300); i = pageIdentity(); }
    return i;
  }
  function mastheadSrc() { try { const im = document.querySelector('ytd-masthead #avatar-btn img, ytd-masthead button#avatar-btn img, ytd-masthead img#img'); return im ? String(im.currentSrc || im.src || im.getAttribute('src') || '') : ''; } catch (_) { return ''; } }
  // all identity signals for ONE item at ONE moment: page session (ytcfg), account menu (a fresh switcher read `cur`, or null when not read), header picture. Plain-English evidence in .text.
  function identityNow(item, info, cur) {
    const active = cur && cur.ok ? cur.channels.find((c) => c.active) : null, want = cur && cur.ok ? cur.channels.find((c) => c.id === item.chid) : null;
    const page = I.signalPage(info, item.chid);
    const menu = cur ? (cur.ok ? I.signalMenu(active, want) : { s: 'unknown', text: 'the account menu could not be read' }) : null;
    return I.combine(page, menu, I.signalMasthead(mastheadSrc(), want, active));
  }
  function voteText(c, btn) {
    try {
      const n = c.querySelector('#vote-count-middle, [id*="vote-count"]'); const nt = n ? (n.textContent || '').trim() : '';
      const lab = String((btn && btn.getAttribute('aria-label')) || ''); const m = /(\d[\d.,\s\u00a0]*[KkMmКМтыс.]*)\s*(?:other|\S+\s*people|человек|люд)/.exec(lab);
      const host = btn && btn.closest('#like-button, ytd-comment-engagement-bar'); const ht = host ? (host.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 20) : '';
      return `count shown “${nt || '(none)'}”, like-button text “${ht || '(none)'}”, label count ${m ? '“' + m[1].trim() + '”' : '(not in the label)'}`;
    } catch (_) { return 'not readable'; }
  }
  function likeButton(c) {
    const host = c.querySelector('#like-button');
    let btn = host ? (host.matches('button') ? host : host.querySelector('button')) : null;
    if (!btn) for (const x of c.querySelectorAll('ytd-comment-engagement-bar button, #toolbar button')) { const l = (x.getAttribute('aria-label') || '').toLowerCase(); if (/\blike\b/.test(l) && !/dislike|unlike/.test(l)) { btn = x; break; } else if (/^unlike/.test(l)) { btn = x; break; } }
    return btn;
  }
  // true | false | null (cannot tell -> we must not click)
  function pressed(btn) {
    const ap = btn.getAttribute('aria-pressed');
    const l = (btn.getAttribute('aria-label') || '').trim().toLowerCase();
    if (ap === 'true' || /^(unlike|remove like)/.test(l)) return true;      // either signal says "liked" -> liked (never click on a contradiction)
    if (ap === 'false') return false;
    return null;
  }
  const signInDialog = () => {
    for (const d of document.querySelectorAll('ytd-popup-container tp-yt-paper-dialog, ytd-popup-container yt-dialog-view-model, ytd-popup-container ytd-modal-with-title-and-button-renderer, yt-confirm-dialog-renderer')) {
      if (d.querySelector('a[href*="accounts.google.com" i], a[href*="ServiceLogin" i]') || /\bsign in\b/i.test(String(d.textContent || '').slice(0, 400))) return d;
    }
    return null;
  };

  // 1.1.0 VPN rotation. The tab cannot reach Panel 9 itself, so it asks the page that owns the run (Bean's popup, or its background runner) through chrome.storage:
  // p9bn.vpnreq {rid,bid,…} -> that page switches to the next saved location, waits until it is connected and the exit address changed -> p9bn.vpn {rid, stage:'done', ok, …}.
  // The like happens only after an ok answer: a failed / stuck switch costs this like (reported), never a like from the wrong address.
  // 1.1.7.1: the wait between two reads of the owner's answer ends the moment the answer (p9bn.vpn) arrives in this page's storage (a storage event is not a timer: it is not delayed or batched in a tab Panel 9 treats as background), or after `ms`
  const vwake = (ms) => new Promise((res) => { let done = false, fn = null, tm = 0; const fin = () => { if (done) return; done = true; clearTimeout(tm); try { chrome.storage.onChanged.removeListener(fn); } catch (_) { /* ignore */ } touch(); res(); }; fn = (c) => { if (c && c[K.vpn]) fin(); }; try { chrome.storage.onChanged.addListener(fn); } catch (_) { /* timer only */ } tm = setTimeout(fin, ms); });
  async function vpnSwitch(v, say, alive, ev) {
    const rid = Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
    const send = (n, fallback) => sset(K.vreq, { rid, bid: v.bid, idx: v.idx, cid: v.cid, check: !!v.check, up: !!v.up, at: Date.now(), n, fallback: !!fallback });
    await send(1, false);
    const t0 = Date.now(); let working = false, tries = 1, beatAt = 0, sampleAt = 0, nextTry = t0 + 4000;          // 1.1.7.1: asked again after 1.5 s, 3 s, then every 4 s (a storage event that never reached the owner page cost a full 4 s every time; a repeat is one more small write)
    for (;;) {
      const a = await sget(K.vpn);
      if (a && a.rid === rid) {
        if (a.stage === 'done') { if (ev) ev('vpn', a.ok && v.check ? `confirmed right before the click: still connected to '${a.location || '?'}'` : a.ok ? `connected to '${a.location || '?'}'; exit address changed: ${a.ipChanged === false ? 'NO' : a.ipChanged ? 'yes' : 'unknown'}; took ${Math.round((Date.now() - t0) / 1000)}s` : `failed (${a.code || 'vpn-failed'}) ${a.msg || ''}`); return a.ok ? { ok: true, location: a.location || '', ipChanged: a.ipChanged } : { ok: false, code: a.code || 'vpn-failed', msg: a.msg || '' }; }
        if (!working) { working = true; say(v.check ? 'checking the VPN connection…' : v.up ? 'waiting for ExpressVPN to be connected…' : 'switching the VPN location…'); if (ev && tries > 1) ev('vpn', `request answered after ${tries} sends (${Math.round((Date.now() - t0) / 1000)}s)`); }
      }
      if (!alive()) return { ok: false, code: 'stopped' };
      if (v.maxMs && Date.now() - t0 > v.maxMs) return { ok: false, code: 'vpn-unanswered', msg: `no answer from Bean’s window / background runner in ${Math.round(v.maxMs / 1000)} s` };          // 1.1.7.1: bounded request (the pre-click check): working-but-never-done counts as unanswered too
      if (ev && working && !v.check && !v.up && Date.now() - t0 > 12000 && Date.now() - (beatAt || t0) > 12000) { beatAt = Date.now(); ev('vpn', `still switching the VPN location (${Math.round((Date.now() - t0) / 1000)} s)`); }          // 1.1.7.1: a visible sign of life in the item log (the runner treats a silent step as a stalled tab)
      // 1.1.5: nobody answered yet: ask again every 4 s (the storage event may have been missed); after 20 s the request says "fallback" so Bean's hidden runner may answer too; give up after 45 s
      if (!working && Date.now() >= nextTry && Date.now() - t0 < 45000) { tries++; nextTry = Date.now() + 4000; await send(tries, Date.now() - t0 > 20000); if (ev && (tries === 3 || tries === 7)) ev('vpn', `no answer yet from Bean's window / background runner: asking again (send ${tries}${Date.now() - t0 > 20000 ? ', hidden runner may answer' : ''})`); }
      if (!working && (v.check || v.up) && Date.now() - t0 > 12000) return { ok: false, code: 'vpn-unanswered', msg: `no answer from Bean’s window / background runner to ${tries} VPN requests in 12 s` };          // 1.1.7.1: the read-only questions (gate / pre-click check) give up after 12 s, the rotation keeps its 45 s
      if (!working && Date.now() - t0 > 45000) return { ok: false, code: 'vpn-failed', msg: `Bean’s window (and its background runner) did not answer ${tries} VPN requests in 45 s — keep Bean’s window or the background runner running while VPN rotation is on` };
      // 1.1.7.1: the owner ANSWERED ("working") but its final answer never came back through Panel 9's storage mirror: that is a lost message, not a failed VPN. First the owner's live one-way sample: connected, on this run's location, and
      // connected AFTER this request (a rotation just finished) = done. Otherwise, after 120 s the step is reported as "unanswered" (plain words; the container is reopened in a fresh tab, location kept), never as "vpn-failed".
      if (working && !v.check && Date.now() - t0 > 20000 && Date.now() - (sampleAt || 0) > 5000) {
        sampleAt = Date.now();
        try { const o = await bound(sget('p9bn.vpnok'), 5000, 'reading the VPN sample'); if (o && o.up && o.bid === v.bid && o.locOk && (v.up || (o.since || 0) >= t0 - 2000) && Date.now() - (o.at || 0) <= 5000) { if (ev) ev('vpn', `the owner's final answer did not arrive, but its live sample shows ExpressVPN connected to '${o.location || '?'}' since after this request: taken as done`); return { ok: true, location: o.location || '', ipChanged: null }; } } catch (_) { /* keep waiting */ }
      }
      if (working && !v.up && !v.check && Date.now() - t0 > 120000) return { ok: false, code: 'vpn-unanswered', msg: 'Bean’s window started the VPN step but its final answer never arrived (120 s)' };
      if (Date.now() - t0 > 260000) return { ok: false, code: (working && !v.up) ? 'vpn-unanswered' : 'vpn-failed', msg: working ? 'the VPN step did not report back in 4 minutes' : 'the location switch took longer than 4 minutes' };
      await vwake(400);
    }
  }
  // 1.1.2: while Bean drives this tab only the linked comment's thread is shown (a <style> rule, nothing is removed, cloned or modified; the like button and aria-pressed are never touched, so
  // YouTube Focus works as before and the click stays programmatic). The rule refers to the thread by the comment id inside its own link.
  function hideOthers(lc) {
    const top = String(lc || '').split('.')[0]; if (!/^[A-Za-z0-9_-]{10,}$/.test(top) || document.getElementById('p9bn-focus-css')) return;
    const st = document.createElement('style'); st.id = 'p9bn-focus-css';
    st.textContent = `ytd-comments ytd-comment-thread-renderer:not(:has(a[href*="lc=${top}"])){display:none !important}`;
    (document.head || document.documentElement).appendChild(st);
  }
  async function processComment(item, pace, say, alive, vpnReq, X) {
    const ev = X.ev;
    if (root.getAttribute('data-p9bn-test') === 'hangver') { ev('test', 'hook: this verify page never settles'); await new Promise(() => {}); }          // test hook (tests/mock-youtube.js HANGVER_ pages only)
    say('checking YouTube Focus…');
    if (!(await waitFor(() => document.body, 8000, alive))) return { code: 'wrong-page' };
    if (!isWatch()) return { code: 'wrong-page' };
    // --- gate: yt-focus must be there and its comments-only switch must be on
    // 1.1.6: YouTube Focus can be slow right after a channel switch (a fresh page, a fresh session): wait longer before concluding it is missing (the comment itself is found by its id, whatever YouTube Focus shows)
    if (!(await waitFor(ytfPresent, 10000, alive, 150))) return { code: 'no-ytf' };
    // yt-focus may still be applying its first state; a container's session created a moment ago may still be receiving YouTube Focus' saved settings (Panel 9 copies them in): give the switch a few seconds before concluding it is off
    await waitFor(ytfComments, 7000, alive, 100);
    if (!ytfComments()) return { code: 'ytf-off' };
    if (!(await waitFor(() => ytfFocus() && isWatch(), 7000, alive))) return { code: 'wrong-page', msg: 'comment-only layout is not active on this page' };
    if (!alive()) return { code: 'stopped' };
    // --- signed in?
    say('checking sign-in…');
    const ss = await waitFor(() => { const s = signedState(); return s === 'unknown' ? null : s; }, 10000, alive, 250);
    ev('gate', `YouTube Focus comment-only on; signed ${ss === 'in' ? 'in' : 'state ' + ss}`);
    if (ss === 'out') return { code: 'not-signed-in' };
    // --- find the linked comment (YouTube loads comments lazily; replies sit behind an expander)
    say('looking for the comment…');
    const t0 = Date.now(); let c = null, nudged = 0, replyOpen = 0, lastNudge = 0, more = 0;
    // 1.1.2: adaptive: 35 s normally, up to 60 s while YouTube is visibly still loading the comments (spinner / page not complete); the loop wakes the instant the DOM changes
    const loadingNow = () => document.readyState !== 'complete' || !!document.querySelector('ytd-comments tp-yt-paper-spinner[active], ytd-comments #spinner[active], ytd-comments ytd-continuation-item-renderer');
    const domWake = (ms) => new Promise((res) => { let done = false; const fin = () => { if (done) return; done = true; try { mo.disconnect(); } catch (_) { /* ignore */ } clearTimeout(tm); res(); }; let mo = null; try { mo = new MutationObserver(fin); mo.observe(document.querySelector('ytd-comments') || document.body || document.documentElement, { childList: true, subtree: true }); } catch (_) { /* ignore */ } const tm = setTimeout(fin, ms); });
    while (Date.now() - t0 < (loadingNow() ? 60000 : 35000) && alive()) {
      c = findComment(item.lc);
      if (c) break;
      if (Date.now() - t0 > 2500 && Date.now() - lastNudge > 2200) {        // comments render when the section nears the viewport
        lastNudge = Date.now(); nudged++;
        const cs = document.querySelector('ytd-comments'); try { if (cs && nudged % 2) cs.scrollIntoView({ block: 'start' }); else window.scrollBy(0, 240); window.dispatchEvent(new Event('scroll')); } catch (_) { /* ignore */ }
      }
      const msg = document.querySelector('ytd-comments ytd-message-renderer');
      if (msg && /turned off|disabled/i.test(msg.textContent || '')) return X.verify && X.marker ? { code: 'verify-retry', msg: 'the fresh page showed a "comments turned off" message' } : { code: 'comments-off' };
      // 1.1.6: Bean never looks at the player (YouTube Focus 1.4.0 blocks the player scripts in comments-only mode, so a player error screen means nothing); only the page's own playability message counts
      if (document.querySelector('yt-playability-error-supported-renderers #reason') && Date.now() - t0 > 6000 && !document.querySelector(COMMENT)) return X.verify && X.marker ? { code: 'verify-retry', msg: 'the fresh page showed a playability message' } : { code: 'unavailable' };
      if (item.lc.indexOf('.') > 0) {                                        // a reply: open its parent's replies (1.1.6: YouTube Focus 1.4.0 hides the "N replies" buttons in comments-only mode; after 4 s the expander is clicked even if it is hidden, which is not a like)
        const parent = findComment(item.lc.split('.')[0]);
        const th = parent && parent.closest('ytd-comment-thread-renderer');
        if (th) {
          const rep = th.querySelector('ytd-comment-replies-renderer');
          const open = rep && rep.querySelector('#more-replies button, #more-replies');
          if (open && (visible(open) || Date.now() - t0 > 4000) && !replyOpen) { replyOpen++; (open.matches('button') ? open : open.querySelector('button') || open).click(); await sleep(900); }
          else if (rep && more < 6) { const cont = rep.querySelector('ytd-continuation-item-renderer button, #button-more button'); if (cont && (visible(cont) || Date.now() - t0 > 4000) && Date.now() - lastNudge > 1200) { more++; lastNudge = Date.now(); cont.click(); await sleep(900); } }
        }
      }
      await domWake(300); await sleep(50);
    }
    if (!alive()) return { code: 'stopped' };
    if (!c) c = findHighlighted();
    if (!c) {
      const s = signedState();
      if (X.verify && X.marker) return { code: 'verify-retry', msg: 'the comment was not on the fresh page' + (s === 'out' ? ' (it looks signed out)' : s === 'unknown' ? ' (signed state unknown)' : '') };      // 1.1.6.3: a like was SENT: a page that did not show the comment says nothing, never "not found"
      // 1.1.7.2: a DELETED comment, told apart from a slow page by structure only (no text): signed in, a top-level comment, the comment list really loaded (threads are there) and none of them
      // carries YouTube's linked-comment badge (the thread a ?lc= address always puts on top). A reply, a signed-out page or an empty list stays a plain "not found" (retried)
      if (s === 'in' && item.lc.indexOf('.') < 0 && document.querySelectorAll('ytd-comments ytd-comment-thread-renderer').length >= 2 && !document.querySelector('ytd-comments #linked-comment-badge') && !findComment(item.lc)) return { code: 'comment-gone', msg: 'the comments loaded but this comment is not among them' };
      return { code: 'not-found', msg: s === 'out' ? 'signed out' : '' };
    }
    // --- the Like button
    say('found it…');
    try { c.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch (_) { /* ignore */ }
    const btn = await waitFor(() => { const x = likeButton(c); return x && visible(x) ? x : null; }, 8000, alive, 250);
    if (!alive()) return { code: 'stopped' };
    if (!btn) return X.verify && X.marker ? { code: 'verify-retry', msg: 'the like button was not on the fresh page' } : { code: 'not-found', msg: 'no like button' };
    ev('comment', `found (${copiesOf(item.lc).length} copy/copies on the page); like button label “${String(btn.getAttribute('aria-label') || '').slice(0, 40)}”`);
    if (X.verify && item.chid) {      // after the click: the fresh page must STILL be this channel's session, otherwise the state it shows says nothing about this channel
      const vi = I.combine(I.signalPage(await readIdentity(alive), item.chid), null, null); ev('identity', 'verify page: ' + vi.text);
      if (vi.verdict !== 'confirmed') return X.marker ? { code: 'verify-retry', msg: 'the fresh page could not be confirmed as this channel\'s session (' + vi.text + ')' } : { code: 'identity-unclear', msg: 'after the click the page was not confirmed as this channel\'s session, so what it shows could not be counted: ' + vi.text };
    }
    ev('votes', voteText(c, btn));
    if (!X.verify && X.hold) { await X.hold('before the VPN location and the like of this item: nothing has been sent'); if (!alive()) return { code: 'stopped' }; }

    // --- 1.1.2: the VPN is NEVER switched while a page is loading. The location of this item was set BEFORE its page was loaded (popup: before the tab opened; tab: in the pace gap
    // after the previous item). Only if that did not happen (older run record) is it switched here — after the page finished loading, one after the other, never in parallel.
    let vpnInfo = item.vpn && item.vpn.location !== undefined ? { location: item.vpn.location, ipChanged: item.vpn.ipChanged } : null;
    // 1.1.6: the location set for THIS item in the pace gap can be missing from the item record (a lost write, or a page that returned before saving it). The VPN helper's last answer names the item
    // it was for: when that is this item and it succeeded, it is adopted instead of switching AGAIN (a second switch costs ~20 s and would move the exit address mid-item).
    if (vpnReq && !X.verify && !vpnInfo) {
      try { const la = await sget(K.vpn); if (la && la.stage === 'done' && la.ok && !la.check && la.bid === vpnReq.bid && la.idx === vpnReq.idx && Date.now() - (la.at || 0) < 600000) { vpnInfo = { location: la.location || '', ipChanged: la.ipChanged == null ? null : !!la.ipChanged }; ev('vpn', `the location set for this item before its page loaded is adopted ('${vpnInfo.location || '?'}'); not switched again`); await patch(X.b.id, X.idx, { vpn: vpnInfo }).catch(() => {}); } } catch (_) { /* fall through to the switch */ }
    }
    // 1.1.7.7: prefer the wave's shared location over a mid-page rotate (would move the exit under the other parallel containers)
    if (vpnReq && !X.verify && !vpnInfo && X.b && X.b.wave && X.b.wave.loc && X.b.wave.loc.location !== undefined) {
      vpnInfo = { location: X.b.wave.loc.location || '', ipChanged: X.b.wave.loc.ipChanged == null ? null : !!X.b.wave.loc.ipChanged };
      ev('vpn', `adopted wave ${X.b.wave.n} shared location '${vpnInfo.location || '?'}' (no mid-page rotate)`);
      await patch(X.b.id, X.idx, { vpn: vpnInfo }).catch(() => {});
    }
    if (vpnReq && !X.verify && !vpnInfo) {
      await waitFor(() => document.readyState === 'complete', 20000, alive, 200);
      ev('vpn', 'no location was set before this page loaded: switching now that the page has finished loading');
      const vr = await vpnSwitch(vpnReq, say, alive, ev);
      if (!alive()) return { code: 'stopped' };
      if (!vr.ok) return { code: vr.code, msg: vr.msg };
      vpnInfo = { location: vr.location, ipChanged: vr.ipChanged };
      await patch(X.b.id, X.idx, { vpn: { location: vr.location || '', ipChanged: vr.ipChanged == null ? null : !!vr.ipChanged } }).catch(() => {});      // 1.1.6: kept for the fresh reload that may follow (it must not switch again)
      await sleep(600);                                                       // the page's own connections settle on the new route
    }
    say('reading the like state…');
    const st = await stableState(item.lc, { minMs: 2500, quietMs: 900, afterLoadMs: 5000, maxMs: 20000, alive });
    ev('state', `${st.state}; aria-pressed per copy: [${st.vec.join(', ')}]; stable for ${st.stableMs}ms`);
    if (!alive()) return { code: 'stopped' };
    // 1.1.5: the FIRST page after a channel switch can still show the PREVIOUS channel's like (seen on real YouTube: the 2nd channel's comment looked already liked). It is never believed: the page is reloaded
    // once from a fresh (cache-busted) address and the state is read again, with the channel re-read, before "already liked" is concluded. A page that was already freshly reloaded is believed.
    if (st.state === 'liked' && !X.verify && (item.tries || 0) >= 1 && !item.fresh) return { code: 'stale-liked', vpn: vpnInfo };
    if (st.state === 'liked' && !X.verify && item.fresh && (item.tries || 0) >= 1 && X.b && (X.b.items || []).some((o, i) => i !== X.idx && (o.cid || '') === (item.cid || '') && o.vid === item.vid && o.lc === item.lc && o.status === 'liked')) {
      ev('state', 'still liked after the fresh reload, and the previous channel of this container just liked this same comment: that is the previous channel\'s like, not this channel\'s; not counted');
      return { code: 'identity-unclear', msg: 'YouTube kept showing the previous channel\'s like after the switch', vpn: vpnInfo };
    }
    if (st.state === 'liked') return X.verify && X.marker ? verifiedResult(X, true) : { code: 'already', vpn: vpnInfo, msg: item.fresh ? 'still liked after a fresh reload of the page that follows the channel switch' : undefined };
    if (st.state !== 'unliked') return X.verify && X.marker ? verifiedResult(X, null) : { code: 'unknown-state', vpn: vpnInfo };
    if (X.verify) return verifiedResult(X, false);                                // a like was already sent earlier: never click again, just report what the page shows
    if (vpnReq) {                                                             // the VPN must still be connected to that location right before the click (a state read: nothing is switched)
      let vc = null;
      // 1.1.7.1: FIRST the owner page's own live sample (p9bn.vpnok, written once a second, one-way: no request, no answer to wait for): connected, on the location this run set, sample younger than 3 s = confirmed
      try { const o = await bound(sget('p9bn.vpnok'), 5000, 'reading the VPN sample'); if (o && o.up && o.bid === vpnReq.bid && o.locOk && Date.now() - o.at <= 5000) { vc = { ok: true, location: o.location || '', ipChanged: undefined }; ev('vpn', `confirmed right before the click from the live sample: still connected to '${o.location || '?'}'`); } } catch (_) { /* the request below */ }
      // no fresh sample: ask (3 NEW requests, 4 s each = ~12 s); no confirmation = no click (the tab hands the container back, the location is kept)
      for (let k = 1; !vc && k <= 3 && alive(); k++) { const r1 = await vpnSwitch(Object.assign({}, vpnReq, { check: true, maxMs: 4000 }), say, alive, ev); if (r1.ok || r1.code !== 'vpn-unanswered') { vc = r1; break; } ev('vpn', `the check right before the click got no answer (try ${k} of 3): nothing is clicked without it`); }
      if (!vc) { if (!alive()) return { code: 'stopped' }; return { code: 'vpn-unanswered', msg: 'the VPN check right before the click got no answer after 3 tries', vpn: vpnInfo }; }
      if (!alive()) return { code: 'stopped' };
      if (!vc.ok) return { code: vc.code, msg: vc.msg, vpn: vpnInfo };
      if (!vpnInfo && vc.location) vpnInfo = { location: vc.location, ipChanged: vc.ipChanged };
    }
    await sleep(Math.round(rnd(300, 900)));                                   // human-like beat before the click
    if (!alive()) return { code: 'stopped' };
    const r = await clickOnce(item, say, alive, X, vpnInfo);
    if (r.vpn === undefined && vpnInfo) r.vpn = vpnInfo;
    return r;
  }

  // ================================================================== 1.1.1 click safety
  const fnv = (str, seed) => { let h = seed >>> 0; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h; };
  const hash64 = (str) => fnv(str, 0x811c9dc5).toString(36) + fnv(str, 0x9747b28c).toString(36);
  const ckOf = (it) => it.ck || L.chanKey(it.chid ? { id: it.chid, handle: it.chhandle } : null, it.cid || '');
  const markerKey = (it) => K.clk + hash64(it.vid + '|' + it.lc + '|' + ckOf(it));
  // every rendered copy of the comment (the thread copy and a "highlighted" copy are different elements, each with its own button)
  function copiesOf(lc) {
    const out = [], scope = document.querySelector('ytd-comments') || document;
    for (const a of scope.querySelectorAll('a[href*="lc="]')) { if (lcOf(a) !== lc) continue; const c = a.closest(COMMENT); if (c && out.indexOf(c) < 0) out.push(c); }
    if (!out.length) { const h = findHighlighted(); if (h) out.push(h); }
    return out;
  }
  const stateVec = (lc) => copiesOf(lc).map((c) => { const b = likeButton(c); return b ? pressed(b) : null; });
  const btnIds = new WeakMap(); let btnN = 0;
  // 'liked' (any copy ever shows it) | 'unliked' (every copy reads "not pressed", unchanged for minMs, nothing mutating, page fully loaded for afterLoadMs) | 'unknown'
  async function stableState(lc, o) {
    const t0 = Date.now(); let lastMut = Date.now(), sig = '', sigSince = Date.now(), completeAt = 0, mo = null, obs = [];
    const watch = () => { try { const cs = copiesOf(lc); if (cs.length === obs.length && cs.every((x, i) => x === obs[i])) return; if (mo) mo.disconnect(); mo = new MutationObserver(() => { lastMut = Date.now(); }); obs = cs; for (const c of cs) mo.observe(c, { subtree: true, attributes: true, attributeFilter: ['aria-pressed', 'aria-label'] }); } catch (_) { /* ignore */ } };
    let vec = [];
    try {
      for (;;) {
        if (!o.alive()) return { state: 'stopped', vec, stableMs: 0 };
        watch();
        vec = stateVec(lc);
        if (vec.some((x) => x === true)) return { state: 'liked', vec, stableMs: Date.now() - sigSince };
        const ids = copiesOf(lc).map((c) => { const b = likeButton(c); if (!b) return 0; if (!btnIds.has(b)) btnIds.set(b, ++btnN); return btnIds.get(b); });
        const cur = JSON.stringify([vec, ids]);
        if (cur !== sig) { sig = cur; sigSince = Date.now(); }
        if (document.readyState === 'complete' && !completeAt) completeAt = Date.now();
        const good = vec.length > 0 && vec.every((x) => x === false);
        if (good && completeAt && Date.now() - sigSince >= o.minMs && Date.now() - lastMut >= o.quietMs && performance.now() >= o.afterLoadMs) return { state: 'unliked', vec, stableMs: Date.now() - sigSince };
        if (Date.now() - t0 > o.maxMs) return { state: 'unknown', vec, stableMs: Date.now() - sigSince };
        await sleep(300);
      }
    } finally { if (mo) mo.disconnect(); }
  }
  // single-flight lock: only the holder may click. 1.1.7.8 (4 containers at once): the lock is PER CONTAINER (p9bn.lock.<container>). Its job is to stop two pages of the SAME container (a duplicate tab,
  // a reload) clicking the same like; pages of different containers are different accounts. A single global key made the 3 parallel tabs wait on each other's mirrored lock (2-8 s late) until busy-lock.
  const lockKey = () => (myCid() ? K.lock + '.' + myCid() : K.lock);
  async function lockTake(me, alive) {
    const end = Date.now() + 30000;
    while (Date.now() < end && alive()) {
      let l = null; try { l = await sget(lockKey()); } catch (_) { /* ignore */ }
      if (!l || !l.owner || (l.until || 0) < Date.now() || l.owner === me) {
        try { await sset(lockKey(), { owner: me, until: Date.now() + 40000, at: Date.now() }); } catch (_) { /* ignore */ }
        await sleep(260);                                                      // the storage mirror between sessions needs a moment: read back before believing it
        let l2 = null; try { l2 = await sget(lockKey()); } catch (_) { /* ignore */ }
        if (l2 && l2.owner === me) return true;
      }
      await sleep(300 + Math.random() * 250);
    }
    return false;
  }
  async function lockDrop(me) { try { const l = await sget(lockKey()); if (l && l.owner === me) await sset(lockKey(), { owner: '', until: 0, at: Date.now() }); } catch (_) { /* ignore */ } }
  // the result of a page that only VERIFIES (a like was already sent): liked = true | false | null (unreadable)
  function verifiedResult(X, liked) {
    const mine = X.marker && X.marker.bid === X.b.id && (X.marker.at || 0) >= (X.b.created || 0);
    if (liked === true) { X.ev('verify', 'fresh page shows the comment as liked'); return mine ? { code: 'liked', msg: 'confirmed from a fresh page after the click', vpn: X.marker.vpn || null } : { code: 'already' }; }
    if (liked === false) { X.ev('verify', 'fresh page shows the comment NOT liked'); return mine ? { code: 'not-registered' } : { code: 'click-sent-before' }; }          // 1.1.7.1: Bean clicked, the page showed the like, but a FRESH page shows it un-liked: the like did not register on YouTube's side (never re-clicked from this channel; the spare-channel fill replaces it)
    X.ev('verify', 'could not read the state on the fresh page'); return { code: 'verify-retry', msg: 'the like state could not be read on the fresh page' };
  }
  // the ONE place a like is clicked. Order: lock -> marker/ledger check -> channel re-check -> fresh state -> marker WRITTEN + read back -> click -> confirm -> hold -> (reload & verify).
  let cnt0Now = null, cwarnNow = '';
  async function clickOnce(item, say, alive, X, vpnInfo) {
    const ev = X.ev, me = X.runner + ':' + X.idx;
    say('safety checks…');
    try {
      if (!(await bound(lockTake(me, alive), 35000, 'the click lock'))) return { code: alive() ? 'busy-lock' : 'stopped' };
    } catch (e) { return { code: 'step-timeout', msg: String((e && e.message) || e).slice(0, 120) }; }
    try {
      { const cur = await bound(readB(), 15000, 'reading the run record'); if (!cur || cur.id !== X.b.id || cur.state !== 'running') { ev('guard', 'the run record is not this running run any more: not clicking'); return { code: 'stopped' }; } }     // re-verify the run record right before the click (a stale first read must never drive a click)
      if (await bound(sget(X.mkey), 15000, 'reading the like marker')) { ev('guard', 'the “like sent” marker for this comment+channel exists: not clicking'); return { code: 'click-sent-before' }; }
      let led = false; try { led = !!(LG && await LG.storedHas((k) => stor(() => chrome.storage.local.get(k), 'storage read'), item.vid, item.lc, ckOf(item))); } catch (_) { /* ignore */ }
      if (led) { ev('guard', 'the permanent ledger already lists this channel on this comment: not clicking'); return { code: 'ledger-used' }; }
      { const tt = root.getAttribute('data-p9bn-test'); if (tt === 'loseone') { TL.n = 1; ev('test', 'hook: the reply of the next storage call is lost once'); } else if (tt === 'loseall') { TL.n = 3; ev('test', 'hook: the replies of the next storage call are lost 3 times'); } }
      if (root.getAttribute('data-p9bn-test') === 'hangpre') { ev('test', 'hook: this step never settles'); await new Promise(() => {}); }          // test hook (tests/mock-youtube.js HANGPRE_ pages only)
      const rck = () => (root.getAttribute('data-p9bn-test') === 'hangrec' ? new Promise(() => {}) : X.recheck());          // test hook (HANGREC_ pages only)
      let ch = await bound(rck(), 40000, 'the identity re-check'); if (!ch.ok && ch.code === 'unknown-state') { await sleep(1200); ch = await bound(rck(), 40000, 'the identity re-check'); }
      ev('channel', `re-checked right before the click: ${ch.msg}`);
      if (!ch.ok) return { code: ch.code || 'wrong-channel', msg: ch.msg };
      const cs = copiesOf(item.lc), vec = cs.map((c) => { const b = likeButton(c); return b ? pressed(b) : null; });
      if (!vec.length || !vec.every((x) => x === false)) { ev('guard', `state changed before the click: [${vec.join(', ')}]`); return vec.some((x) => x === true) ? { code: 'already' } : { code: 'unknown-state' }; }
      const btn = likeButton(cs[0]); if (!btn || !visible(btn)) return { code: 'not-found', msg: 'no like button' };
      const val = { at: Date.now(), bid: X.b.id, vid: item.vid, lc: item.lc, runner: X.runner, phase: 'sent', vpn: vpnInfo || null, clickEv: [Date.now(), 'click', `one click; aria-pressed before: [${vec.join(', ')}]`] };      // 1.1.6.3: the click line also lives in the marker, which only this page writes: a lost run-record write can no longer drop it
      // 1.1.7.1 cross-check: the like count the page shows right before this click. When an EARLIER item of this same comment ended "liked" but showed the SAME (or a higher) count before ITS click, that earlier like probably did not register
      // server-side (aria-pressed is only the page's own state): said in the log, and written on both items (cnt0 / cwarn), never a click decision.
      try {
        const cn = /label count “(\d[\d.,\s\u00a0]*)/.exec(voteText(cs[0], btn)), n0 = cn ? parseInt(String(cn[1]).replace(/\D/g, ''), 10) : NaN;
        if (!isNaN(n0)) { cnt0Now = n0; const bk = known || X.b; const prev = ((bk && bk.items) || []).filter((it, ix) => ix !== X.idx && it.vid === item.vid && it.lc === item.lc && (it.status === 'liked' || it.code === 'liked' || it.code === 'liked-unverified') && typeof it.cnt0 === 'number' && it.cnt0 >= n0);
          if (prev.length) { cwarnNow = prev.map((it) => it.chname || it.chid || '?').join(', '); ev('count', `warning: the comment shows ${n0} likes right before this click, no more than before the earlier like of ${cwarnNow} (it showed ${prev[0].cnt0}): that earlier like may not have registered on YouTube's side`); } else ev('count', `likes shown before this click: ${n0}`); }
      } catch (_) { /* informational only */ }
      if (!alive()) return { code: 'stopped' };          // 1.1.7.1: a page that was handed back (deadman) or stopped never clicks, even when a stuck step wakes up late
      await sset(X.mkey, val); const back = await sget(X.mkey);
      if (!back || back.at !== val.at) { ev('guard', 'could not store the safety marker: not clicking'); return { code: 'marker-failed' }; }
      say('liking…'); ev('click', `one click; aria-pressed before: [${vec.join(', ')}]`);
      btn.click();                                                             // exactly ONE click, ever (the marker is already stored: nothing can click this again)
      try { if (X.onSent) await Promise.race([X.onSent(), sleep(2500)]); } catch (_) { /* best effort: the marker already says the like was sent */ }       // 1.1.6.3: awaited (bounded): the click line is in the run record before anything else can navigate       // 1.1.2: the run record learns that a like was sent (a lost page then ends as liked-unverified, not interrupted)
      const t1 = Date.now();
      const on = await waitFor(() => { const b2 = likeButton(copiesOf(item.lc)[0] || cs[0]); return b2 && pressed(b2) === true; }, 6000, null, 120);
      if (!on) { ev('after', 'aria-pressed never turned true within 6 s'); if (signInDialog() || signedState() === 'out') return { code: 'not-signed-in' }; return { code: 'click-failed' }; }
      ev('after', `aria-pressed true after ${Date.now() - t1}ms`);
      for (let hold = Date.now() + 3200; Date.now() < hold;) {                  // a rejected like flips back: it has to STAY pressed
        await sleep(250);
        const b2 = likeButton(copiesOf(item.lc)[0] || cs[0]);
        if (b2 && pressed(b2) === false) { ev('after', `aria-pressed turned false again ${Date.now() - t1}ms after the click`); try { await stor(() => chrome.storage.local.remove(X.mkey), 'storage write'); } catch (_) { /* ignore */ } return { code: 'like-not-kept' }; }
      }
      ev('after', 'still pressed 3 s later');
      await sset(X.mkey, Object.assign({}, val, { phase: 'verify' }));
      return { code: 'verify-reload' };
    } catch (e) { if (e && e.stepTimeout) return { code: 'step-timeout', msg: String(e.message).slice(0, 120) }; throw e; } finally { await lockDrop(me); }
  }
})();
