// Bean 1.1.0 — the three additions around the 1.0.0 liker: ExpressVPN location rotation, the permanent per-comment channel ledger, and the named API.
// Loaded after popup.js (shares its globals: settings, batch, ctrs, sel, targets(), askYtf(), …). The SAME page also runs hidden as Bean's "runner" (popup.html?runner=1, started by a Panel 9
// that has the Bean VPN bridge patch while the API is on), so API jobs work with no window open. Every storage key has ONE writer (Panel 9 merges storage per key across sessions):
//   p9bn.api            the install identity + token + masked key hint …… the popup UI
//   p9bn.apistat.popup | .runner   status of the API loop of that page …… that page
//   p9bn.runner         heartbeat of the hidden runner …… the runner
//   p9bn.vpnreq         "switch the location now" from the YouTube tab …… that tab (one tab at a time)
//   p9bn.vpn            the answer …… the page that owns the run (batch.owner)
//   p9bn.vpnptr         which saved location is next …… the owner of the run
//   p9bn.led.*          the ledger …… the page that runs jobs now (runner if alive, else the popup); the popup only ADDS (import/restore) otherwise
//   p9bn.cmd            ledger clear/prune asked by a popup while the runner is alive …… the popup; answered by the runner in p9bn.cmdres
(() => {
  'use strict';
  const A = self.P9BEAN_API, LG = self.P9BEAN_LEDGER, V = self.P9BEAN_VPN;
  const ROLE = /[?&]runner=1\b/.test(location.search) ? 'runner' : 'popup';
  const VERSION = (chrome.runtime.getManifest() || {}).version || '';
  const KK = { api: 'p9bn.api', stat: 'p9bn.apistat.' + ROLE, runner: 'p9bn.runner', vreq: 'p9bn.vpnreq', vpn: 'p9bn.vpn', ptr: 'p9bn.vpnptr', cmd: 'p9bn.cmd', cmdres: 'p9bn.cmdres', batch0: 'p9bn.batch', rm: 'p9bn.ledrm' };
  const S = { api: null, client: null, led: null, ledReady: false, recorded: new Set(), runnerAt: 0, job: null, jobs: [], online: false, lastPoll: 0, err: '', errCode: '', loop: false, vp: null, vpAt: 0, regions: null, key: null, mirrorErr: '', cfgSig: '', cfgAt: 0, vbusy: '', lastStat: '', pendingCmd: '', cancelIds: new Set() };
  const now = () => Date.now();
  // 1.1.1 "Possible likes": will this container be skipped? signed out (known from the container list), or it bypasses the VPN while rotation is on and "skip bypass" is ticked
  // (known only once ExpressVPN has been probed: until then null = unknown). -> { reason } | null
  const skipInfo = (c) => {
    if (c && c.checked && !c.signedIn) return { reason: 'signed out' };
    if (vsaved().length && settings.vpn && settings.vpn.skipBypass) {
      const r = S.vp && S.vp.ok && S.vp.routes ? S.vp.routes[(c && c.id) || 'default'] : undefined;
      if (r === 'bypass' || r === 'proxy') return { reason: r === 'bypass' ? 'bypasses the VPN' : 'uses its own proxy (bypasses the VPN)' };
      if (r === undefined) return { reason: '', unknown: true };
    }
    return null;
  };
  const hasVpnBridge = () => !!(window.panel9ext && typeof window.panel9ext.vpn === 'function');
  // 1.1.7.1: every read-only ExpressVPN state call is bounded (a Panel 9 IPC call that never answers kept the pre-click check 'working' for minutes while the tab waited)
  const vpnCall = (arg, ms) => Promise.race([window.panel9ext.vpn(arg), new Promise((_, rej) => setTimeout(() => rej(new Error('the ExpressVPN helper did not answer in ' + Math.round((ms || 12000) / 1000) + ' s')), ms || 12000))]);
  const runnerAlive = () => now() - S.runnerAt < 12000;
  const executor = () => ROLE === 'runner' || !runnerAlive();            // the page that runs API jobs and writes the ledger now
  const clean = (e) => String((e && e.message) || e || '').replace(/^Error invoking remote method '[^']+': (Error: )?/, '').slice(0, 160);
  const apiOn = () => !!(S.api && S.api.enabled && S.api.token && !S.api.revoked);
  const ck = (c, ch) => L.chanKey(ch || null, c);

  // ================================================================ ledger
  async function ledgerLoad() {
    S.led = new LG.Ledger(LG.chromeStore(chrome.storage.local)); await S.led.load(); S.ledReady = true; try { if (typeof renderPossible === 'function') renderPossible(); } catch (_) { /* popup not ready */ }
    if (!S.led.out.length && S.led.stats().comments === 0) { /* fresh install */ }
  }
  const ledUsed = (vid, lc, c) => !!(S.ledReady && S.led.has(L.canonVid(vid), L.canonLc(lc), c));
  let flushT = 0;
  const flushSoon = () => { clearTimeout(flushT); flushT = setTimeout(async () => { try { await S.led.flush(); renderLedger(); mirror().catch(() => {}); } catch (_) { flushSoon(); } }, 150); };       // 1.1.2: written to storage 150 ms after a verified like (was 1.2 s), retried if it fails
  // final items of a run -> ledger. Only the page that is the writer records; adding is idempotent (a channel already in the ledger is a 'dup').
  function recordFinal(b) {
    if (!b || !Array.isArray(b.items) || !S.ledReady || !executor()) return;
    let n = 0;
    b.items.forEach((it, i) => {
      if (it.status !== 'liked' && it.status !== 'already') return;
      if (it.ledgerVoid) return;                      // 1.1.6: its marks were cleared on purpose (Ledger → Clear all marks for this comment): the old run record must not put them back
      const key = b.id + ':' + i; if (S.recorded.has(key)) return; S.recorded.add(key);
      const r = S.led.add(L.canonVid(it.vid), L.canonLc(it.lc), it.ck || ck(it.cid), it.status === 'liked' ? 'l' : 'a', it.at || now());
      if (r === 'added') n++;
    });
    if (S.recorded.size > 5000) S.recorded = new Set([...S.recorded].slice(-2000));
    if (n) flushSoon();
    // 1.1.6: a channel that liked (or was confirmed "already liked" under a confirmed identity) is reachable: its "could not be reached" flag goes away
    try { const okc = {}; b.items.forEach((it) => { if ((it.status === 'liked' || it.status === 'already') && it.cid && it.chid && !it.ledgerVoid) (okc[it.cid] = okc[it.cid] || new Set()).add(it.chid); }); for (const cid of Object.keys(okc)) clearStale(cid, okc[cid]); } catch (_) { /* best effort */ }
  }
  async function clearStale(cid, ok) {
    const r = typeof chStale !== 'undefined' ? chStale[cid] : null; if (!r || !Array.isArray(r.ids) || !r.ids.some((i) => ok.has(i))) return;
    const ids = r.ids.filter((i) => !ok.has(i)); const key = 'p9bn.chstale.' + cid;
    if (ids.length) await sset(key, Object.assign({}, r, { ids })); else await chrome.storage.local.remove(key);
  }
  // 1.1.6: removals reach the server copy (so /capacity stops counting cleared marks). Queued in storage until the server has them; an older server without the endpoint (404) keeps its copy, said plainly in the note.
  async function queueRm(rows) { if (!rows || !rows.length) return; try { const cur = (await sget(KK.rm)) || []; await sset(KK.rm, cur.concat(rows).slice(-20000)); S.rmPending = Math.min(20000, cur.length + rows.length); } catch (_) { /* best effort */ } }
  async function flushRm() {
    if (!S.client) return; const rm = await sget(KK.rm); if (!Array.isArray(rm) || !rm.length) { S.rmPending = 0; return; }
    S.rmPending = rm.length;
    try { for (let i = 0; i < rm.length; i += 500) await S.client.ledgerRemove(rm.slice(i, i + 500)); await sset(KK.rm, []); S.rmPending = 0; S.rmUnsupported = false; }
    catch (e) { if (e && e.status === 404) { S.rmUnsupported = true; await sset(KK.rm, []); S.rmPending = 0; return; } throw e; }
  }
  async function mirror() {
    if (!apiOn() || !executor() || !S.ledReady || S.mirroring) return;
    S.mirroring = true;
    try {
      await flushRm();
      if (S.led.stats().overflow) { await pushAll(); S.led.setOverflow(false); await S.led.flush(); }
      for (let i = 0; i < 40; i++) {
        const part = S.led.takeOut(500); if (!part.length) break;
        await S.client.ledgerPost(part); await S.led.ackOut(part.length);
      }
      S.mirrorErr = ''; S.mirrorBackoff = 0;
    } catch (e) { S.mirrorErr = clean(e); S.mirrorBackoff = Math.min(300000, (S.mirrorBackoff || 5000) * 2); setTimeout(() => { mirror().catch(() => {}); }, S.mirrorBackoff); }       // 1.1.2: retry with exponential backoff (10 s ... 5 min); the server ignores entries it already has, so a retry can never double-count
    finally { S.mirroring = false; renderLedger(); }
  }
  async function pushAll() {           // the whole ledger -> the server (idempotent: it ignores what it already has)
    await flushRm();                   // 1.1.6: removals queued earlier go first, so they can never wipe entries sent now (and a failed removal stops this push)
    const all = S.led.entries(); let sent = 0;
    for (let i = 0; i < all.length; i += 1000) { await S.client.ledgerPost(all.slice(i, i + 1000)); sent += Math.min(1000, all.length - i); }
    return sent;
  }
  async function restoreFromServer() {
    if (!S.client || !S.api || !S.api.token) throw new Error('Create or link an API first.');
    await flushRm().catch(() => {});          // 1.1.6: marks cleared here must not come back from the server copy
    let after = 0, got = 0, added = 0;
    for (let i = 0; i < 400; i++) {
      const r = await S.client.ledgerGet(after, 1000); const es = r.entries || [];
      const res = S.led.addMany(es, { noOut: true }); added += res.added; got += es.length; after = r.next || after;
      if (r.done || !es.length) break;
    }
    await S.led.flush(); renderLedger(); return { got, added };
  }

  // ================================================================ VPN
  // timeouts: defaults suit a real ExpressVPN (a reconnect takes seconds); `settings.vpn.t` is a test-only override (clamped)
  const vtimes = () => { const t = (settings.vpn && settings.vpn.t) || {}, o = {}; for (const [k, lo, hi] of [['connectMs', 500, 120000], ['ipMs', 500, 60000], ['pollMs', 50, 5000], ['settleMs', 0, 10000], ['attempts', 1, 3]]) if (Number.isFinite(t[k])) o[k] = Math.min(hi, Math.max(lo, t[k])); return o; };
  const rot = () => { const key = JSON.stringify(vtimes()); if (!S.rot || S.rotKey !== key) { S.rotKey = key; S.rot = new V.Rotator({ call: (a) => window.panel9ext.vpn(a), timeouts: vtimes() }); } return S.rot; };
  const vsaved = () => ((settings.vpn && settings.vpn.locs) || []).filter((x) => x && typeof x.id === 'string' && x.id);
  // Saved locations must be EXACT ids from Panel 9's list (it accepts nothing else). Anything stored in another form (an old label, other case/spacing, 'smart…') is moved to its exact id or
  // dropped, once, with a note shown in the VPN section. Returns true when the saved list changed. Never throws; if the list can't be read nothing is changed (the rotate guard then refuses).
  async function ensureExactLocs(force) {
    const raw = (settings.vpn && settings.vpn.locs) || []; if (!raw.length || !hasVpnBridge()) return false;
    let regs; try { regs = await rot().knownRegions(!!force); } catch (_) { return false; }
    if (!regs.length) return false;
    const m = V.migrateLocs(raw, regs); if (!m.changed) return false;
    settings.vpn = Object.assign({}, settings.vpn, { locs: m.locs, note: m.note || (settings.vpn && settings.vpn.note) || '' });
    await sset(K.settings, settings).catch(() => {}); if (m.dropped.length || m.migrated.length) await sset(KK.ptr, 0).catch(() => {});
    S.vp = null; return true;
  }
  async function vpnProbe(force) {
    if (!force && S.vp && now() - S.vpAt < 15000) return S.vp;
    S.vp = hasVpnBridge() ? await rot().preflight() : { ok: false, support: 'none', msg: 'This Panel 9 has no ExpressVPN bridge for Bean.' };
    S.vpAt = now(); return S.vp;
  }
  // before a run: is rotation wanted (locations saved)? then ExpressVPN must work, otherwise the run does not start. Containers that do not follow the VPN are named.
  async function prepare(tg) {
    const hadRaw = ((settings.vpn && settings.vpn.locs) || []).length; if (!hadRaw) return { ok: true, active: false, warn: [], bypass: new Set() };
    const pf = await vpnProbe(true);
    if (!pf.ok) { const n = vsaved().length || hadRaw; return { ok: false, active: true, msg: 'VPN rotation is on (' + n + ' location' + (n === 1 ? '' : 's') + ' saved) but ' + (pf.msg || 'ExpressVPN is not available') + ' Fix that, or clear the saved locations.' }; }
    const mig = await ensureExactLocs(false), locs = vsaved();
    // every saved location was invalid and got dropped: never fall back silently to the user's own connection
    if (!locs.length) return { ok: false, active: true, msg: 'VPN rotation was on, but none of the saved locations is in ExpressVPN\'s list any more.' + (settings.vpn && settings.vpn.note ? ' ' + settings.vpn.note : '') + ' Pick locations again in Bean → VPN locations (or leave them all unticked to use your own connection).' };
    const bypass = new Set(), warn = [];
    if (mig && settings.vpn && settings.vpn.note) warn.push(settings.vpn.note);
    for (const t of tg) { const r = (pf.routes || {})[t.id || 'default']; if (r === 'bypass' || r === 'proxy') { bypass.add(t.id); warn.push(`Container '${t.name || t.id}' ${r === 'bypass' ? 'is set to Outside VPN' : 'uses its own proxy'}, so the VPN location does not change its address.`); } }
    return { ok: true, active: true, n: locs.length, warn, bypass };
  }
  function decorate(b, pre, tg) {
    b.owner = ROLE;
    if (!pre || !pre.active) return b;
    b.vpn = { on: true, n: pre.n, warn: pre.warn };
    const skip = !!(settings.vpn && settings.vpn.skipBypass);
    for (const it of b.items) if (pre.bypass.has(it.cid) && it.status === 'queued') { if (skip) { it.status = 'skipped'; it.code = 'vpn-bypass'; it.msg = 'Skipped: this container bypasses the VPN'; it.at = now(); } else it.vpnSkip = true; }
    for (const g of b.groups) if (!b.items.some((it) => it.cid === g.cid && it.status === 'queued')) { g.status = 'done'; g.doneAt = g.doneAt || now(); }
    return b;
  }
  // 1.1.2: ONE rotation routine for both callers: (a) the popup / runner BEFORE it opens a container's first tab (nothing is loading then), (b) a YouTube tab asking for the NEXT item's
  // location while it sits idle in the pace gap (storage request below). The VPN is never switched while a Bean page is loading, redirecting, verifying or clicking.
  const runOverNow = async (bid) => { if (await sget('p9bn.stop.' + bid)) return true; const bb = await sget(K.batch); return !!(bb && bb.id === bid && bb.state !== 'running'); };
  async function runIsOver(bid) { for (let i = 0; i < 3; i++) { if (!(await runOverNow(bid))) return false; if (i < 2 && !(await sget('p9bn.stop.' + bid))) await new Promise((r) => setTimeout(r, 700)); } return true; }
  async function rotateNow(bid) {
    await ensureExactLocs(false); const locs = vsaved(); let out;
    if (!locs.length) out = { ok: false, code: 'vpn-failed', msg: 'no VPN location is saved any more' };
    else {
      const ptr = Number(await sget(KK.ptr)) || 0;
      // 1.1.1: the rotation stops as soon as the run is over (done / stopped / cleared): no VPN activity after the run
      // 1.1.7: only a DEFINITIVE end of THIS run stops the rotation: the run's stop key, or its own record (same run id) showing "not running" on 3 reads in a row. A missing record or another run's record (a stale
      // mirror copy) says nothing: it used to read as "the run is over" and skipped the first item 2 s after the start.
      S.vabort = false; let overHits = 0; const vw = setInterval(async () => { try { if (await runOverNow(bid)) { overHits++; if (overHits >= 3 || (await sget('p9bn.stop.' + bid))) S.vabort = true; } else overHits = 0; } catch (_) { /* ignore */ } }, 1200);
      S.vrot = true; S.vokSince = 0;
      try { out = await rot().rotate(locs, ptr % locs.length, { stop: () => S.vabort }); } catch (e) { out = { ok: false, code: 'vpn-failed', msg: clean(e), idx: ptr % locs.length }; }
      S.vrot = false; S.vokSince = 0; clearInterval(vw);
      if (out.idx != null) await sset(KK.ptr, (out.idx + 1) % locs.length);
    }
    S.vlast = { bid, at: now(), ok: !!out.ok, location: out.location || '', ipChanged: out.ipChanged == null ? null : !!out.ipChanged };
    S.vp = null; S.vlog = (S.vlog || []).concat([{ at: now(), bid, kind: 'switch', ok: !!out.ok }]).slice(-40);
    return out;
  }
  // 1.1.7 "never open or navigate a container tab while the VPN is down". ExpressVPN can drop by itself (real logs: outages of 5-25 s every 30-60 s); a tab opened, or a page loaded, in that window ends on Panel 9's
  // error page and the script never runs. Before ANY tab is opened or navigated (and before a channel switch) of a run that uses the VPN, the owner page waits here until ExpressVPN reports `connected`, and
  // then a short settle (VPN_SETTLE_MS, from the moment it was SEEN connected after a non-connected state, or from the end of Bean's own rotation). Read-only: no connection is touched.
  const VPN_SETTLE_MS = 3000;
  async function vpnUp(bid, o) {
    o = o || {}; const maxMs = o.maxMs || 150000, t0 = now(); let state = 'unknown', loc = '';
    // 1.1.7.1: this page's own once-a-second sample says connected for 3+ s and is younger than 2.5 s: no state read, no wait (a real ExpressVPN state read takes 1-3 s)
    if (!S.vrot && S.vsampAt && t0 - S.vsampAt < 2500 && S.vokSince && t0 - S.vokSince >= VPN_SETTLE_MS && !(bid && (await runOverNow(bid).catch(() => false)) && (await runIsOver(bid)))) return { ok: true, state: 'connected', location: S.vsampLoc || '', waited: 0 };
    for (;;) {
      if (bid && (await runOverNow(bid).catch(() => false)) && (await runIsOver(bid))) return { ok: false, code: 'stopped', msg: 'the run is over' };
      let st = null; try { st = await vpnCall({ op: 'state', fresh: true, noip: true }); } catch (_) { st = null; }
      const v = st && st.vpn; state = v ? String(v.state || 'unknown') : 'unknown'; loc = (v && v.location) || '';
      const prev = S.vst || { state: '', at: 0 };
      if (state !== prev.state) S.vst = { state, at: now(), first: !prev.state };
      if (state === 'connected') {
        const vs = S.vst, stable = vs.first ? 0 : vs.at, wait = stable + VPN_SETTLE_MS - now();          // 1.1.7.1: the settle follows a connection this page SAW coming back after a drop; Bean's own rotation already waited for 'connected' + its own settle + the address check, so it adds no 3 s (it did, before every tab)
        if (wait <= 0) return { ok: true, state, location: loc, waited: now() - t0 };
        await new Promise((r) => setTimeout(r, Math.min(wait, 1000))); continue;
      }
      if (now() - t0 > maxMs) return { ok: false, code: 'vpn-failed', msg: `ExpressVPN was not connected for ${Math.round((now() - t0) / 1000)} s (state: ${state}); nothing was opened or loaded in the meantime`, state };
      await new Promise((r) => setTimeout(r, 1000));
    }
  }
  // "is the VPN still on the location the last switch connected?" — a state read only, no connection is touched. A tab asks this right before it clicks.
  // read-only peek for diagnostics (never connects): { state, location }
  async function vpnPeek() { try { const st = await vpnCall({ op: 'state', fresh: true, noip: true }), v = st && st.vpn; return { state: v ? String(v.state || 'unknown') : 'unknown', location: (v && v.location) || '' }; } catch (e) { return { state: 'unreadable', location: '', err: clean(e) }; } }
  // 1.1.7.1 the VPN gate without a round trip: while a run that uses the VPN is owned by THIS page, it reads the (read-only) ExpressVPN state once a second and publishes p9bn.vpnok {up, since, at}. A tab about to navigate
  // reads that key itself (content.js vpnGate): connected for 3+ s and a sample younger than 3 s = it goes at once. No sample / not connected / just reconnected = the old request path (waits for connected + settle).
  const VOK = 'p9bn.vpnok';
  async function vpnSample() {
    if (S.vsamp) return; S.vsamp = true;
    try {
      const b = await sget(K.batch);
      if (S.noVok || !b || b.state !== 'running' || !b.vpn || !b.vpn.on || (b.owner || 'popup') !== ROLE || !hasVpnBridge()) return;          // S.noVok: test hook only (no sample = the tab must use the request path)
      let state = 'rotating', loc = ''; if (!S.vrot) { const pk = await vpnPeek(); state = pk.state; loc = pk.location; }
      const t = now(), up = state === 'connected' && !S.vrot; S.vsampAt = up ? t : 0; S.vsampLoc = loc;
      if (!up) S.vokSince = 0; else if (!S.vokSince) S.vokSince = t;
      const l = S.vlast, locOk = up && (!(l && l.bid === b.id && l.ok && l.location) || V.sameLoc(loc, { id: l.location, name: l.location }));          // the same test as checkNow: still on the location this run connected
      const sig = b.id + '|' + up + '|' + (S.vokSince || 0) + '|' + locOk; if (S.vokSig === sig && t - (S.vokAt || 0) < 2000) return;          // one small write every 2 s (every change at once): Panel 9 mirrors each write to every container
      S.vokSig = sig; S.vokAt = t; await sset(VOK, { at: t, bid: b.id, up, since: S.vokSince || 0, state, location: loc, locOk });
    } catch (_) { /* the tab then uses the request path */ } finally { S.vsamp = false; }
  }
  async function checkNow(bid) {
    const l = S.vlast; let st = null; try { st = await vpnCall({ op: 'state', fresh: true, noip: true }); } catch (e) { return { ok: false, code: 'vpn-failed', msg: 'ExpressVPN state could not be read: ' + clean(e) }; }
    const v = st && st.vpn; S.vlog = (S.vlog || []).concat([{ at: now(), bid, kind: 'check', ok: !!(v && v.state === 'connected') }]).slice(-40);
    if (!v || v.state !== 'connected') return { ok: false, code: 'vpn-failed', msg: 'ExpressVPN is not connected any more (' + ((v && v.state) || 'unknown') + ')' };
    if (l && l.bid === bid && l.ok && l.location && !V.sameLoc(v.location, { id: l.location, name: l.location })) return { ok: false, code: 'vpn-failed', msg: 'ExpressVPN moved away from the location Bean connected (' + l.location + ')' };
    return { ok: true, location: v.location || (l && l.location) || '', ipChanged: l && l.bid === bid ? l.ipChanged : null };
  }
  async function onVpnReq(rq) {
    // one evaluation per request at a time (the storage event, the 1.5 s poll and the tab's re-sends all arrive here)
    if (!rq || !rq.rid) return; const tag = rq.rid + (rq.fallback ? 'f' : ''); if (S.vseen === tag) return; S.vseen = tag;
    let claimed = false; try { claimed = await onVpnReq1(rq, tag); } finally { if (!claimed && S.vseen === tag) S.vseen = ''; }
  }
  async function onVpnReq1(rq) {
    if (S.dropVreqUntil && now() < S.dropVreqUntil) return false;
    if (S.dropCheckUntil && now() < S.dropCheckUntil && rq.check) return false;                // test hook only: the pre-click VPN CHECK is never answered                 // test hook only: simulates a request this page never saw
    if (S.vbusy === rq.rid || now() - (rq.at || 0) > 30000) return false;
    const b = await sget(K.batch);
    if (!b || b.id !== rq.bid || !b.vpn || !b.vpn.on) return false;
    // 1.1.5: the page that owns the run answers; when it stayed silent for 20 s the tab asks again with `fallback` set and the hidden runner (if its heartbeat is fresh) answers instead.
    // Only one page ever works on a request: whoever finds an answer for this rid already there does nothing.
    const mine = (b.owner || 'popup') === ROLE;
    if (!mine && !(ROLE === 'runner' && rq.fallback)) return false;
    { const cur = await sget(KK.vpn); if (cur && cur.rid === rq.rid) return false; }
    S.vbusy = rq.rid;
    await sset(KK.vpn, { rid: rq.rid, stage: 'working', kind: rq.up ? 'up' : rq.check ? 'check' : 'rotate', at: now() });
    let out; try { out = rq.up ? await vpnUp(rq.bid, { maxMs: 150000 }) : rq.check ? await checkNow(rq.bid) : await rotateNow(rq.bid); } catch (e) { out = { ok: false, code: 'vpn-failed', msg: 'the VPN step failed: ' + clean(e) }; }          // 1.1.7.1: a throw can no longer leave the tab on "working" for ever: the answer is always written
    if (S.dropDoneUntil && now() < S.dropDoneUntil) return true;          // test hook only: the owner did the VPN step but its final answer is lost on the way to the tab
    const ans = { rid: rq.rid, bid: rq.bid, idx: rq.idx, stage: 'done', ok: !!out.ok, code: out.code || '', msg: out.msg || '', location: out.location || '', ipChanged: out.ipChanged == null ? null : !!out.ipChanged, check: !!rq.check, up: !!rq.up, at: now() };
    await sset(KK.vpn, ans);
    // 1.1.7.1: Panel 9's storage mirror can lose one write on its way to the tab's container: the same final answer is written again after 3, 8 and 15 s (only while it is still this request's answer)
    for (const ms of [3000, 8000, 15000]) setTimeout(() => { sget(KK.vpn).then((c) => { if (c && c.rid === rq.rid && c.stage === 'done') return sset(KK.vpn, Object.assign({}, ans, { at: now() })); }).catch(() => {}); }, ms);
    return true;
  }

  // ================================================================ the API: config push, poll loop, jobs
  const mkClient = () => { S.client = S.api && S.api.token ? new A.BeanApi({ base: A.effBase(S.api.base), getToken: () => (S.api && S.api.token) || '' }) : null; };
  // 1.1.6: the channels Bean can really like from: ticked, still in the account's channel list, and not flagged by the last run (not found in the account menu / could not be switched to). The API's /capacity is computed from this list.
  const badCh = (cid, chid) => { const r = typeof chStale !== 'undefined' ? chStale[cid] : null; return !!(r && Array.isArray(r.ids) && r.ids.indexOf(chid) >= 0 && now() - (r.at || 0) < 86400000); };
  const savedKeys = () => { const out = []; for (const c of (ctrs ? ctrs.containers : [])) { if (!sel.has(c.id)) continue; const list = known(c.id), s = chSel[c.id]; if (list && s && s.size) { for (const ch of list) { if (s.has(ch.id) && !badCh(c.id, ch.id)) out.push(ck(c.id, ch)); } } else out.push(ck(c.id, null)); } return [...new Set(out)]; };
  // 1.1.6: one push at a time (an older snapshot can no longer arrive after a newer one); a change that happens while a push is running is pushed right after; a failed push is retried (2 s, 4 s ... 60 s) instead of waiting for the next 60 s tick
  function pushConfig(force) {
    if (!apiOn() || !S.client || !executor()) return Promise.resolve();
    if (S.cfgBusy) { S.cfgAgain = true; S.cfgForce = S.cfgForce || !!force; return S.cfgBusy; }
    S.cfgBusy = (async () => {
      try { let f = !!force; for (let i = 0; i < 4; i++) { S.cfgAgain = false; await pushConfig1(f || S.cfgForce); S.cfgForce = false; f = false; if (!S.cfgAgain) break; } }
      finally { S.cfgBusy = null; }
    })();
    return S.cfgBusy;
  }
  async function pushConfig1(force) {
    // the hidden runner does not always get the storage event of a change made in the popup (Panel 9's storage mirror): it re-reads the selection and the channel lists itself before it computes what to push
    if (ROLE === 'runner') { try { const st = await sget(K.settings); if (st && typeof st === 'object') settings = st; await loadChannelCache(); restoreSel(); } catch (_) { /* keep what we have */ } }
    const keys = savedKeys(), v = vsaved();
    const asked = await askYtf(0).catch(() => 0); const gate = verdict(asked);
    const cfg = { channels: keys, gate: gate === 'unknown' ? (S.api.lastGate || 'unknown') : gate, vpn: { on: v.length > 0, n: v.length }, name: S.api.name, version: VERSION, panel9: (/Panel ?9\/([\d.]+)/.exec(navigator.userAgent) || [])[1] || '' };
    const sig = JSON.stringify([cfg.channels, cfg.gate, cfg.vpn, cfg.name]);
    if (!force && sig === S.cfgSig && now() - S.cfgAt < 120000) return;
    try { await S.client.putConfig(cfg); S.cfgSig = sig; S.cfgAt = now(); S.cfgKeys = keys.length; S.cfgFail = 0; }
    catch (e) { S.err = clean(e); S.errCode = e.code || ''; S.cfgFail = (S.cfgFail || 0) + 1; clearTimeout(S.cfgRetryT); S.cfgRetryT = setTimeout(() => { pushConfig(true).catch(() => {}); }, Math.min(60000, 2000 * Math.pow(2, Math.min(S.cfgFail, 5)))); }
  }
  let cfgT = 0; const cfgSoon = () => { clearTimeout(cfgT); cfgT = setTimeout(() => pushConfig(false).catch(() => {}), 1500); };
  async function writeStat(force) {
    const st = { at: now(), role: ROLE, online: S.online, lastPoll: S.lastPoll, err: S.err, errCode: S.errCode, job: S.job ? { id: S.job.id, done: S.job.done, total: S.job.total, state: S.job.state } : null, jobs: S.jobs.slice(0, 5), mirrorErr: S.mirrorErr, cfg: { keys: S.cfgKeys, at: S.cfgAt, fail: S.cfgFail || 0, rm: S.rmPending || 0 } };
    const sig = JSON.stringify([st.online, st.err, st.job, st.jobs, st.mirrorErr]);
    if (!force && sig === S.lastStat && now() - (S.lastStatAt || 0) < 15000) return;
    S.lastStat = sig; S.lastStatAt = now(); await sset(KK.stat, st).catch(() => {});
  }
  const toResult = (b, it) => {
    const st = it.status === 'liked' || it.status === 'already' ? it.status : it.status === 'failed' ? 'failed' : 'skipped';
    const r = { n: it.jn, seq: it.seq, status: st, code: st === 'liked' || st === 'already' ? '' : (it.code || (it.status === 'stopped' ? 'stopped' : 'not_started')), message: st === 'liked' || st === 'already' ? '' : (it.msg || L.label(it.code || '') || ''), container: it.cname || '', channel: it.chname || '', handle: it.chhandle || '', at: it.at || now() };
    if (b.vpn && b.vpn.on) r.vpn = { location: (it.vpn && it.vpn.location) || '', ip_changed: it.vpn ? it.vpn.ipChanged : (it.vpnSkip ? false : null), bypassed: !!it.vpnSkip || it.code === 'vpn-bypass' };
    return r;
  };
  const isFinalIt = (it) => it.status !== 'queued' && it.status !== 'running';
  async function runJob(job) {
    const rep = (body) => S.client.report(job.job_id, body);
    const total = (job.links || []).reduce((n, l) => n + (l.quantity || 0), 0);
    S.job = { id: job.job_id, state: 'starting', done: 0, total }; writeStat(true);
    const finishErr = async (code, message, results, warnings) => { await rep({ state: 'finished', error: { code, message }, results: results || [], warnings: warnings || [] }).catch(() => {}); S.job = null; S.jobs.unshift({ id: job.job_id, status: 'failed', code, at: now() }); S.jobs.length = Math.min(S.jobs.length, 5); writeStat(true); };
    try {
      await loadContainers(); await loadChannelCache(); restoreSel();
      if (!ctrs) return finishErr('no_bridge', 'This Panel 9 does not give Bean the container list (Bean requires Panel 9 2.3.10 or newer).');
      const tg = targets();
      if (!sel.size) return finishErr('no_channels_saved', 'No containers or channels are saved in Bean. Tick them in Bean, then try again.');
      const asked = await askYtf(1500), v = verdict(asked);
      if (v === 'off') return finishErr('focus_off', 'YouTube Focus “Comments only” is off. Switch it on in Panel 9, then submit the job again.');
      if (v === 'missing') return finishErr('focus_missing', 'YouTube Focus is not installed or not enabled in Panel 9.');
      for (let i = 0; i < 90; i++) { const cb = await sget(K.batch), dc = await sget('p9bn.disc'); if (!running(cb) && !(dc && dc.state === 'running' && now() - (dc.created || 0) < 180000)) break; if (i === 89) return finishErr('busy', 'Bean was busy with another run for more than 90 seconds.'); await sleep(1000); }
      const pre = await prepare(tg); if (!pre.ok) return finishErr('vpn_unavailable', pre.msg);
      if (!S.ledReady) await ledgerLoad();
      const links = (job.links || []).map((l) => ({ n: l.n, vid: l.vid, lc: l.lc, quantity: l.quantity, url: L.watchUrl(l.vid, l.lc) }));
      const plan = L.planApi(links, tg, (vid, lc, c) => S.led.has(vid, lc, c));
      const short = [];       // what the plan could not cover any more (the ledger or the saved channels changed since the job was accepted): reported, never silently dropped
      for (const sf of plan.shortfalls) { const l = links.find((x) => x.n === sf.jn); for (let k = 0; k < sf.missing; k++) short.push({ n: sf.jn, seq: (l.quantity - sf.missing) + k, status: 'skipped', code: 'no_capacity', message: 'No unused channel left for this comment', container: '', channel: '', handle: '', at: now() }); }
      const warnings = pre.warn.slice();
      if (!plan.items.length) return finishErr('no_capacity', 'No saved channel is free for these comments any more.', short, warnings);
      const id = Math.random().toString(36).slice(2, 10) + now().toString(36), pace = L.pickPace(await sget(K.pace), settings.pace);          // 1.1.6.3: API jobs use the ONE saved pace (a per-job pace is ignored)
      let b = { id, state: 'running', pace, created: now(), updated: now(), nextAt: 0, idx: 0, groups: plan.groups, items: plan.items, job: job.job_id };
      decorate(b, pre, tg); b.job = job.job_id; { const om = L.openModeLabel(L.bgTabsOn(await sget(L.BGTABS_KEY).catch(() => null))); b.openMode = om; (b.events = b.events || []).push([now(), 'open mode — ' + om]); }       // 1.1.6.5: one line per run
       b.restoreBack = !!settings.restoreBack; batch = b; own.id = id; own.last = b; own.stopped = false; own.cleared = false;
      await sset(K.batch, b); renderResults(); advance().catch(() => {});
      S.job.state = 'running'; writeStat(true);
      const sent = new Set(); let lastRep = 0, cancelled = false, first = true, miss = 0;
      for (;;) {
        await sleep(1200);
        const cur = await sget(K.batch);
        if (cur && cur.id !== id && own.id === id && !own.cleared && ++miss <= 6) continue;      // a stale write of the previous run can replace the record for a moment; advance() puts this run's record back
        if (!cur || cur.id !== id) { await rep({ state: 'finished', error: { code: 'interrupted', message: 'The run record disappeared (cleared in Bean).' }, results: [...short], warnings }).catch(() => {}); break; }
        if (cur.state === 'running' && now() - (cur.updated || 0) > 5 * 60000) { /* advance() stops it */ }
        miss = 0;
        const fresh = []; cur.items.forEach((it, i) => { if (isFinalIt(it) && !sent.has(i)) fresh.push([i, toResult(cur, it)]); });
        S.job.done = cur.items.filter((it) => it.status === 'liked' || it.status === 'already').length;
        const over = cur.state !== 'running';
        if (over || (fresh.length && now() - lastRep > 2500) || first || now() - lastRep > 20000) {
          const results = fresh.map((x) => x[1]); if (over) { cur.items.forEach((it, i) => { if (!sent.has(i) && !isFinalIt(it)) { it.status = 'skipped'; it.code = it.code || 'not_started'; results.push(toResult(cur, it)); } }); results.push(...short); }
          let resp = null;
          try { resp = await rep(over ? { state: 'finished', results, warnings, error: errorOf(cur, cancelled || S.cancelIds.has(job.job_id)) } : { state: 'running', results, warnings: first ? warnings : undefined }); fresh.forEach((x) => sent.add(x[0])); first = false; lastRep = now(); }
          catch (e) { if (e.code === 'job_not_found') break; S.err = clean(e); }
          if (resp && resp.cancel && !cancelled && !over) { cancelled = true; await stop(); }
          if (resp && resp.ignored && resp.status !== 'running') { if (!over && cur.state === 'running') await stop(); break; }
        }
        if (over) { S.jobs.unshift({ id: job.job_id, status: 'finished', at: now() }); S.jobs.length = Math.min(S.jobs.length, 5); break; }
        writeStat(false);
      }
    } catch (e) { await finishErr('internal', 'Bean could not run the job: ' + clean(e)); }
    finally { S.job = null; writeStat(true); }
  }
  // why a stopped run ended: a blocker every container shares gets a precise error; a manual Stop / server cancel gets none (the server then says "cancelled")
  function errorOf(cur, cancelled) {
    if (cur.state === 'done') return undefined;
    if (cancelled) return undefined;
    const bl = cur.items.find((it) => it.code === 'ytf-off' || it.code === 'no-ytf' || it.code === 'vpn-unavailable');
    if (bl) return bl.code === 'vpn-unavailable' ? { code: 'vpn_unavailable', message: bl.msg || L.label(bl.code) } : { code: bl.code === 'ytf-off' ? 'focus_off' : 'focus_missing', message: L.label(bl.code) + '.' };
    return { code: 'stopped', message: 'The run was stopped in Bean.' };
  }
  async function cancelJob(id) { S.cancelIds.add(id); if (S.cancelIds.size > 50) S.cancelIds.delete(S.cancelIds.values().next().value); if (S.job && S.job.id === id) { const cur = await sget(K.batch); if (cur && cur.job === id && cur.state === 'running') await stop(); } }

  async function apiLoop() {
    if (S.loop) return; S.loop = true; let wait = 2000;
    try {
      for (;;) {
        if (!apiOn() || !S.client || !executor()) { if (S.online) { S.online = false; writeStat(true); } await sleep(S.client && apiOn() ? 1500 : 8000); continue; }       // 1.1.6.3: nothing to poll while the API is off: wake every 8 s, not 1.5 s
        const t0 = now();
        try {
          const r = await S.client.poll(S.job ? 10 : 20, VERSION, (/Panel ?9\/([\d.]+)/.exec(navigator.userAgent) || [])[1] || '');
          S.online = true; S.lastPoll = now(); S.err = ''; S.errCode = ''; wait = 2000;
          for (const id of r.cancel || []) { if (self.B17) B17.cancelJob(id).catch(() => {}); else cancelJob(id).catch(() => {}); }
          const j = (r.jobs || [])[0]; if (j) { if (self.B17) B17.accept(j).catch(() => {}); else if (!S.job) runJob(j).catch(() => {}); }          // 1.1.7: an API job joins the same queue as the popup's orders
          if (S.cfgAt === 0 || now() - S.cfgAt > 120000) pushConfig(false).catch(() => {});
          if (S.led && S.led.stats().pending) mirror().catch(() => {});
          writeStat(false);
          if (now() - t0 < 900) await sleep(2000);
        } catch (e) {
          S.online = false; S.err = clean(e); S.errCode = e.code || '';
          if (e.status === 401 || e.status === 403) { writeStat(true); await sleep(10000); continue; }
          writeStat(true); await sleep(wait); wait = Math.min(30000, wait * 2);
        }
      }
    } finally { S.loop = false; }
  }

  // ================================================================ runner heartbeat
  function startRunner() {
    document.documentElement.classList.add('runner');
    const beat = () => sset(KK.runner, { at: now(), v: VERSION, id: S.rid || (S.rid = Math.random().toString(36).slice(2, 8)) }).catch(() => {});
    beat(); setInterval(beat, 4000);
    setInterval(() => { loadContainers().then(() => { restoreSel(); }).catch(() => {}); }, 60000);
    // a page's own ping answer: the runner keeps the gate fresh for the config push
    setInterval(() => { if (apiOn()) cfgSoon(); }, ROLE === 'runner' ? 8000 : 60000);          // 1.1.6: the runner checks for a changed selection every 8 s even if no storage event arrived (nothing is sent when nothing changed)
  }

  // ================================================================ UI helpers
  const h = (tag, props, kids) => { const e = document.createElement(tag); for (const k of Object.keys(props || {})) { if (k === 'text') e.textContent = props[k]; else if (k === 'class') e.className = props[k]; else if (k.indexOf('on') === 0) e.addEventListener(k.slice(2), props[k]); else if (props[k] != null) e.setAttribute(k, props[k]); } for (const c of [].concat(kids || [])) if (c != null) e.append(c.nodeType ? c : document.createTextNode(String(c))); return e; };
  const ago = (t) => { if (!t) return 'never'; const s = Math.max(0, Math.round((now() - t) / 1000)); return s < 90 ? s + ' s ago' : s < 5400 ? Math.round(s / 60) + ' min ago' : Math.round(s / 3600) + ' h ago'; };
  const confirm2 = (btn, label, fn) => { let armed = 0, t = 0; const base = btn.textContent; btn.addEventListener('click', () => { if (!armed) { armed = 1; btn.textContent = label; btn.classList.add('armed'); t = setTimeout(() => { armed = 0; btn.textContent = base; btn.classList.remove('armed'); }, 4000); return; } clearTimeout(t); armed = 0; btn.textContent = base; btn.classList.remove('armed'); fn(); }); };
  const note = (el, text, kind) => { if (!el) return; el.textContent = text || ''; el.className = 'snote' + (kind ? ' ' + kind : ''); };

  // ---------------------------------------------------------------- VPN section
  const vui = { q: '', pick: null, status: '', statusKind: '', busy: false };
  function renderVpn() {
    const box = document.getElementById('vpnbody'); if (!box) return; box.textContent = '';
    const sum = document.getElementById('vpnsum'); const saved = vsaved(); if (sum) sum.textContent = saved.length ? saved.length + ' saved' : 'off';
    if (!hasVpnBridge()) { box.append(h('p', { class: 'snote', text: 'VPN rotation needs a newer Panel 9 (the release with Bean’s ExpressVPN bridge). Until then Bean works as before, from your own connection.' })); return; }
    if (!S.vp) { box.append(h('p', { class: 'snote', text: 'Checking ExpressVPN…' })); vpnProbe(true).then(renderVpn).catch(() => {}); return; }
    if (S.vp.support === 'old') { box.append(h('p', { class: 'snote', text: S.vp.msg })); return; }
    if (!S.vp.ok) box.append(h('p', { class: 'snote bad', text: S.vp.msg || 'ExpressVPN control is not available.' }), h('p', { class: 'snote', text: 'Needs ExpressVPN 12.69+ for Windows, signed in and running, and Panel 9 started as administrator.' }));
    else box.append(h('p', { class: 'snote ok', text: 'ExpressVPN is ready' + (S.vp.st && S.vp.st.vpn.state === 'connected' ? ' · connected to ' + S.vp.st.vpn.location : S.vp.st && S.vp.st.vpn.state ? ' · ' + S.vp.st.vpn.state : '') + '.' }));
    if (settings.vpn && settings.vpn.note) box.append(h('p', { class: 'snote warn', id: 'vnote', text: settings.vpn.note }));
    box.append(h('p', { class: 'snote', text: 'Before every like Bean switches to the next saved location, waits until it is connected and the exit address has changed, and skips the like if it cannot. Leave all unticked to keep your own connection.' }));
    const pick = vui.pick || (vui.pick = new Map(saved.map((x) => [x.id, x])));
    const top = h('div', { class: 'srow' });
    const inp = h('input', { type: 'search', placeholder: 'Filter locations…', 'aria-label': 'Filter locations', value: vui.q }); inp.addEventListener('input', () => { vui.q = inp.value; renderVpnList(); });
    top.append(inp, h('button', { class: 'lnk', type: 'button', text: S.regions ? 'Reload' : 'Load locations', onclick: async () => { try { note(vui.el, 'Loading locations…'); S.regions = await rot().regions(true); renderVpn(); } catch (e) { note(vui.el, clean(e), 'bad'); } } }));
    box.append(top);
    const list = h('div', { class: 'vlist', id: 'vlist' }); box.append(list);
    vui.el = h('p', { class: 'snote' }); box.append(vui.el);
    const act = h('div', { class: 'srow end' });
    const sv = h('button', { class: 'btn small primary', type: 'button', id: 'vsave', text: 'Save locations', onclick: saveVpn });
    const clr = h('button', { class: 'btn small', type: 'button', text: 'Clear', onclick: () => { vui.pick = new Map(); renderVpn(); } });
    const tst = h('button', { class: 'btn small', type: 'button', id: 'vtest', text: 'Test next switch', title: 'Switches ExpressVPN to the next saved location now and checks that the exit address changed' });
    confirm2(tst, 'Switch VPN now?', testSwitch);
    act.append(tst, clr, sv); box.append(act);
    if (saved.length) { const sb = !!(settings.vpn && settings.vpn.skipBypass); const lab = h('label', { class: 'chk' }); const cb = h('input', { type: 'checkbox', id: 'vskip' }); cb.checked = sb; cb.addEventListener('change', () => { settings.vpn = Object.assign({}, settings.vpn || { locs: saved }, { skipBypass: cb.checked }); sset(K.settings, settings).catch(() => {}); }); lab.append(cb, ' Skip containers that bypass the VPN (otherwise they like from their own address and are flagged)'); box.append(lab); }
    renderVpnList(); renderBypassWarn(box);
    if (!S.regions) rot().regions(false).then(async (r) => { S.regions = r; if (await ensureExactLocs(false)) { vui.pick = null; renderVpn(); return; } renderVpnList(); }).catch((e) => { note(vui.el, 'Locations could not be read: ' + clean(e), 'bad'); });
  }
  function renderBypassWarn(box) {
    if (!vsaved().length || !S.vp || !S.vp.ok || !ctrs) return;
    const names = ctrs.containers.filter((c) => sel.has(c.id) && ['bypass', 'proxy'].includes((S.vp.routes || {})[c.id])).map((c) => c.name + ' (' + (S.vp.routes[c.id] === 'bypass' ? 'Outside VPN' : 'proxy') + ')');
    if (names.length) box.append(h('p', { class: 'snote warn', text: 'These ticked containers do not follow ExpressVPN, so rotating changes nothing for them: ' + names.join(', ') + '.' }));
  }
  function renderVpnList() {
    const list = document.getElementById('vlist'); if (!list) return; list.textContent = '';
    const q = vui.q.trim().toLowerCase(); const regs = S.regions || [];
    if (!S.regions) { list.append(h('div', { class: 'snote', text: 'Loading locations…' })); return; }
    let shown = 0;
    for (const r of regs) {
      if (q && r.name.toLowerCase().indexOf(q) < 0) continue; if (++shown > 150) break;
      const cb = h('input', { type: 'checkbox' }); cb.checked = vui.pick.has(r.id);
      cb.addEventListener('change', () => { if (cb.checked) vui.pick.set(r.id, { id: r.id, name: r.name, cc: r.cc }); else vui.pick.delete(r.id); updVsave(); });
      list.append(h('label', { class: 'vrow' }, [cb, h('span', { class: 'cn', text: r.name, title: r.name })]));
    }
    if (!shown) list.append(h('div', { class: 'snote', text: regs.length ? 'No location matches.' : 'No locations were returned.' }));
    if (shown > 150) list.append(h('div', { class: 'snote', text: 'Showing the first 150 — filter to narrow down.' }));
    updVsave();
  }
  function updVsave() { const b = document.getElementById('vsave'); if (!b) return; const a = [...vui.pick.keys()].sort().join('|'), s = vsaved().map((x) => x.id).sort().join('|'); b.disabled = a === s; b.textContent = vui.pick.size ? `Save ${vui.pick.size} location${vui.pick.size === 1 ? '' : 's'}` : 'Save (none)'; }
  async function saveVpn() {
    const locs = [...vui.pick.values()].slice(0, 100); settings.vpn = Object.assign({}, settings.vpn || {}, { locs, note: '' }); await sset(K.settings, settings); await sset(KK.ptr, 0).catch(() => {});
    note(vui.el, locs.length ? `Saved ${locs.length} location${locs.length === 1 ? '' : 's'}. The next run rotates through them in this order.` : 'Cleared: Bean uses your own connection.', 'ok'); renderVpn(); if (apiOn()) cfgSoon();
  }
  async function testSwitch() {
    await ensureExactLocs(false); const locs = vsaved(); if (!locs.length) { note(vui.el, 'Save at least one location first.', 'warn'); return; }
    note(vui.el, 'Switching… this can take up to a minute.', '');
    const ptr = Number(await sget(KK.ptr)) || 0; const r = await rot().rotate(locs, ptr % locs.length);
    if (r.idx != null) await sset(KK.ptr, (r.idx + 1) % locs.length);
    note(vui.el, r.ok ? 'Connected to ' + r.location + (r.ipChanged === false ? '' : ' · the exit address changed.') : 'Failed: ' + r.msg, r.ok ? 'ok' : 'bad'); S.vp = null;
  }

  // ---------------------------------------------------------------- ledger section
  const lui = { q: '', msg: '' };
  const fmtD = (t) => { try { return new Date(t).toISOString().slice(0, 10); } catch (_) { return ''; } };
  function chLabel(c) { if (!c) return ''; const m = /^([pch]):(.*)$/.exec(c); if (!m) return c; for (const cid of Object.keys(chCache || {})) { const l = (chCache[cid] || {}).channels || []; for (const x of l) if (ck(cid, x) === c) return x.name + (x.handle ? ' ' + x.handle : ''); } if (m[1] === 'c' && ctrs) { const x = ctrs.containers.find((y) => y.id === m[2]); if (x) return "container '" + x.name + "'"; } return c.length > 28 ? c.slice(0, 26) + '…' : c; }
  function renderLedger() {
    const box = document.getElementById('ledbody'); if (!box) return;
    const sum = document.getElementById('ledsum'); if (!S.ledReady) { if (sum) sum.textContent = '…'; return; }
    const st = S.led.stats(); if (sum) sum.textContent = st.comments + ' comment' + (st.comments === 1 ? '' : 's');
    box.textContent = '';
    box.append(h('p', { class: 'snote', text: 'For every comment Bean remembers which channels liked it (or found it already liked) and never uses one of them on it again. ' + st.comments + ' comments · ' + st.pairs + ' channel uses · ' + st.channels + ' channels' + (st.pending ? ' · ' + st.pending + ' waiting for the server copy' : '') + (st.full ? ' · FULL (oldest entries can be pruned)' : '') + '.' }));
    if (S.mirrorErr) box.append(h('p', { class: 'snote warn', text: 'Server copy: ' + S.mirrorErr }));
    const inp = h('input', { type: 'search', placeholder: 'Search video id, comment id or channel…', 'aria-label': 'Search the ledger', value: lui.q }); inp.addEventListener('input', () => { lui.q = inp.value; renderLedRows(); }); box.append(inp);
    box.append(h('div', { class: 'ledrows', id: 'ledrows' }));
    lui.el = h('p', { class: 'snote' }); box.append(lui.el);
    const act = h('div', { class: 'srow wrap' });
    act.append(h('button', { class: 'btn small', type: 'button', text: 'Copy JSON', onclick: async () => { try { await navigator.clipboard.writeText(S.led.exportJson()); note(lui.el, 'Copied ' + st.comments + ' comments to the clipboard.', 'ok'); } catch (e) { note(lui.el, 'Could not copy: ' + clean(e), 'bad'); } } }));
    act.append(h('button', { class: 'btn small', type: 'button', text: 'Import…', onclick: () => { const ta = document.getElementById('ledimp'); ta.hidden = !ta.hidden; document.getElementById('ledimpgo').hidden = ta.hidden; } }));
    const rs = h('button', { class: 'btn small', type: 'button', id: 'ledrestore', text: 'Restore from server', onclick: async () => { try { note(lui.el, 'Restoring…'); const r = await restoreFromServer(); note(lui.el, `Server copy read: ${r.got} entries, ${r.added} new here.`, 'ok'); } catch (e) { note(lui.el, 'Restore failed: ' + clean(e), 'bad'); } } }); rs.disabled = !(S.api && S.api.token);
    act.append(rs);
    const pr = h('button', { class: 'btn small', type: 'button', id: 'ledprune', text: 'Prune > 180 days' }); confirm2(pr, 'Really prune?', () => ledCmd('prune', 180));
    const cl = h('button', { class: 'btn small danger', type: 'button', id: 'ledclear', text: 'Clear ledger' }); confirm2(cl, 'Really clear?', () => ledCmd('clear'));
    act.append(pr, cl); box.append(act);
    box.append(h('textarea', { id: 'ledimp', rows: 3, hidden: '', placeholder: 'Paste a Bean ledger JSON export here', spellcheck: 'false' }));
    box.append(h('button', { class: 'btn small', type: 'button', id: 'ledimpgo', hidden: '', text: 'Add to ledger', onclick: importLedger }));
    renderLedRows();
  }
  function renderLedRows() {
    const el = document.getElementById('ledrows'); if (!el || !S.ledReady) return; el.textContent = '';
    const q = lui.q.trim().toLowerCase(); let rows;
    if (!q) rows = S.led.recent('', 40); else { rows = []; S.led.each((v, c, k, kind, t) => { if (rows.length < 80 && (v + ' ' + c + ' ' + k + ' ' + chLabel(k)).toLowerCase().indexOf(q) >= 0) rows.push([v, c, k, kind, t]); }); }
    if (!rows.length) { el.append(h('div', { class: 'snote', text: q ? 'No match.' : 'Nothing recorded yet.' })); return; }
    // 1.1.5: when the rows belong to ONE comment that has "already liked" marks, offer to clear just those marks (liked entries stay)
    { const cs = new Set(rows.map((r) => r[0] + '|' + r[1]));
      if (cs.size === 1) { const [v0, c0] = rows[0], kd = S.led.kinds(v0, c0);
        { const nAll = kd.l.length + kd.a.length;       // 1.1.6: undo EVERY mark of this comment (a like that landed as the previous channel is recorded as liked for a channel that never liked it)
          const bar0 = h('div', { class: 'lbar', id: 'ledalready' }, [h('p', { class: 'snote', text: `This comment (${v0} …${c0.replace(/\..*$/, '').slice(-6)}): ${kd.l.length} liked, ${kd.a.length} “already liked”. If marks are wrong (the like went to another channel than recorded), clear them: those channels can then like it again.` })]);
          const b0 = h('button', { class: 'btn small', type: 'button', id: 'ledclearcomment', text: `Clear all ${nAll} mark${nAll === 1 ? '' : 's'} for this comment`, title: 'Removes every ledger entry of this one comment, plus its “like sent” safety markers. Other comments are not touched.' }); confirm2(b0, 'Really clear them?', () => ledCmd('remove-comment', { vid: v0, lc: c0 })); bar0.append(b0);
          if (kd.a.length) { const b = h('button', { class: 'btn small', type: 'button', id: 'ledclearalready', text: `Clear only the ${kd.a.length} “already liked” mark${kd.a.length === 1 ? '' : 's'}`, title: 'Removes only the “already liked” entries of this one comment from Bean’s ledger (the liked entries stay)' }); confirm2(b, 'Really clear them?', () => ledCmd('remove-already', { vid: v0, lc: c0 })); bar0.append(b); }
          el.append(bar0); } }
      else if (rows.length && q) el.append(h('div', { class: 'snote', text: 'Several comments match: tap a row’s text to narrow the list to its comment, then the “Clear all marks for this comment” button appears.' })); }
    for (const [v, c, k, kind, t] of rows) {
      const reply = c.indexOf('.') > 0;
      el.append(h('div', { class: 'lrow' }, [h('span', { class: 'ld ' + (kind === 'l' ? 'ok' : 'warn') }), h('span', { class: 'lt', role: 'button', tabindex: '0', title: v + ' · ' + c + ' (tap to show only this comment)', onclick: () => { lui.q = c; renderLedger(); }, text: `${chLabel(k)} · ${v}${reply ? ' · reply' : ''} …${c.replace(/\..*$/, '').slice(-6)}` }), h('span', { class: 'ls', title: 'how many channels used this comment', text: (kind === 'l' ? 'liked ' : 'already ') + fmtD(t) + ' · ' + S.led.count(v, c) + ' ch' })].concat([(() => { const rm = h('button', { class: 'lrm', type: 'button', text: '✕', title: 'Remove this entry from the ledger (Bean may then use this channel on this comment again)', 'aria-label': 'Remove this ledger entry' }); confirm2(rm, 'Remove?', () => ledCmd('remove', { vid: v, lc: c, ck: k })); return rm; })()])));
    }
  }
  async function importLedger() {
    const ta = document.getElementById('ledimp'); let j;
    try { j = JSON.parse(ta.value); } catch (_) { note(lui.el, 'That is not valid JSON.', 'bad'); return; }
    const es = j && j.bean === 'ledger' && Array.isArray(j.entries) ? j.entries : null;
    if (!es) { note(lui.el, 'That is not a Bean ledger export.', 'bad'); return; }
    const r = S.led.addMany(es.slice(0, 200000), { noOut: !executor() ? true : false }); await S.led.flush(); ta.value = ''; ta.hidden = true; document.getElementById('ledimpgo').hidden = true;
    note(lui.el, `Added ${r.added} entries (${r.dup} already known${r.bad ? ', ' + r.bad + ' invalid' : ''}${r.full ? ', ' + r.full + ' over the limit' : ''}).`, 'ok'); renderLedger(); if (apiOn()) pushAll().catch(() => {});
  }
  // clear / prune are not "adds": when the hidden runner is the ledger writer the popup asks it to do it (one writer); otherwise this page does it
  async function ledCmd(op, arg) {
    if (executor() && ROLE === 'popup' || ROLE === 'runner') { await ledDo(op, arg); note(lui.el, op === 'clear' ? 'Ledger cleared.' : op === 'remove' ? 'Entry removed (a copy already sent to the API server stays there).' : op === 'remove-comment' ? 'Cleared all ' + (S.lastRemoved || 0) + ' mark(s) of this comment (and its “like sent” safety markers). Bean can like it again. Do not press “Restore from server” for this comment: the server copy still has them.' : op === 'remove-already' ? 'Cleared ' + (S.lastRemoved || 0) + ' “already liked” mark(s). The liked entries were kept. (A copy already sent to the API server stays there: do not press “Restore from server” for this comment.)' : 'Pruned.', 'ok'); return; }
    const id = Math.random().toString(36).slice(2, 8); await sset(KK.cmd, { id, op, arg, at: now() }); note(lui.el, 'Asking the background runner…');
    for (let i = 0; i < 20; i++) { await sleep(500); const r = await sget(KK.cmdres); if (r && r.id === id) { await S.led.load(); renderLedger(); note(lui.el, r.msg, r.ok ? 'ok' : 'bad'); return; } }
    note(lui.el, 'The background runner did not answer.', 'bad');
  }
  async function ledDo(op, arg) {
    if (op === 'clear') { const seen = new Set(), rows = []; try { S.led.each((v, c) => { const k = v + '|' + c; if (!seen.has(k) && rows.length < 5000) { seen.add(k); rows.push([v, c, '*']); } }); } catch (_) { /* best effort */ } await S.led.clear(); await queueRm(rows); S.recorded = new Set(); try { const all = await chrome.storage.local.get(null); const ks = Object.keys(all).filter((k) => k.indexOf('p9bn.clk.') === 0); if (ks.length) await chrome.storage.local.remove(ks); } catch (_) { /* best effort */ } }
    else if (op === 'remove') { const r = S.led.remove(arg && arg.vid, arg && arg.lc, arg && arg.ck); if (r) { await S.led.flushAll(); await queueRm([[L.canonVid(arg.vid), L.canonLc(arg.lc), arg.ck]]); } }
    else if (op === 'remove-comment') {
      const vid = arg && arg.vid, lc = arg && arg.lc; const r = S.led.removeComment(vid, lc); if (r) await S.led.flushAll(); await queueRm([[L.canonVid(vid), L.canonLc(lc), '*']]); S.lastRemoved = r;          // queued even when this device has none: the server copy may hold marks this device does not (restored earlier / another device)
      try {       // the "like sent" safety markers of this comment (they would make Bean only VERIFY it) and the finished items of the run record (recordFinal would re-add their marks)
        const all = await chrome.storage.local.get(null), ks = Object.keys(all).filter((k) => k.indexOf('p9bn.clk.') === 0 && all[k] && L.canonVid(all[k].vid) === L.canonVid(vid) && L.canonLc(all[k].lc) === L.canonLc(lc));
        if (ks.length) await chrome.storage.local.remove(ks);
        const rb = all[KK.batch0]; if (rb && Array.isArray(rb.items)) { let ch = false; for (const it of rb.items) if ((it.status === 'liked' || it.status === 'already') && L.canonVid(it.vid) === L.canonVid(vid) && L.canonLc(it.lc) === L.canonLc(lc) && !it.ledgerVoid) { it.ledgerVoid = true; ch = true; } if (ch) await chrome.storage.local.set({ [KK.batch0]: rb }); }
      } catch (_) { /* best effort */ }
    }
    else if (op === 'remove-already') { const ks = S.led.kinds(arg && arg.vid, arg && arg.lc).a.slice(); const r = S.led.removeKind(arg && arg.vid, arg && arg.lc, 'a'); if (r) { await S.led.flushAll(); await queueRm(ks.map((k) => [L.canonVid(arg.vid), L.canonLc(arg.lc), k])); } S.lastRemoved = r; }
    else if (op === 'prune') { const n = S.led.prune(Math.max(1, Number(arg) || 180)); await S.led.flushAll(); if (n < 0) return; }
    renderLedger(); if (apiOn() && op !== 'prune') { mirror().catch(() => {}); }
  }

  // ---------------------------------------------------------------- API section
  const aui = { name: '', msg: '', kind: '', busy: false, link: false };
  function maskedKey() { return S.api && S.api.hint ? S.api.hint : ''; }
  function renderApi() {
    const box = document.getElementById('apibody'); if (!box) return; box.textContent = '';
    const sum = document.getElementById('apisum'); const api = S.api;
    if (sum) sum.textContent = api && api.token && !api.revoked ? (api.enabled ? api.name : api.name + ' · paused') : api && api.revoked ? 'revoked' : 'off';
    const msg = h('p', { class: 'snote' + (aui.kind ? ' ' + aui.kind : ''), id: 'apimsg', text: aui.msg || '' });
    if (S.key) {
      box.append(h('div', { class: 'keybox' }, [h('b', { text: 'Your API key — copy it now. It is shown only once.' }), h('code', { id: 'apikey', text: S.key }),
        h('div', { class: 'srow end' }, [h('button', { class: 'btn small', type: 'button', id: 'apicopy', text: 'Copy key', onclick: async () => { try { await navigator.clipboard.writeText(S.key); aui.msg = 'Copied.'; aui.kind = 'ok'; } catch (e) { aui.msg = 'Could not copy — select the key and copy it by hand.'; aui.kind = 'warn'; } renderApi(); } }), h('button', { class: 'btn small primary', type: 'button', id: 'apihide', text: 'I saved it — hide', onclick: () => { S.key = null; aui.msg = ''; renderApi(); } })])]));
    }
    if (!api || !api.token || api.revoked) {
      if (api && api.revoked) box.append(h('p', { class: 'snote warn', text: 'The API key of “' + api.name + '” was revoked. You can create a new one (the ledger is kept).' }));
      box.append(h('p', { class: 'snote', text: 'The API lets an app of yours submit comment links to THIS Bean install and read the results. A key drives only the install that created it. Jobs run with the containers and channels saved here, your ledger and your VPN locations — and only while YouTube Focus “Comments only” is on.' }));
      const nm = h('input', { type: 'text', id: 'apiname', maxlength: '40', placeholder: 'Name tag, e.g. studio-pc', 'aria-label': 'API name tag', value: aui.name || (api && api.name) || '' }); nm.addEventListener('input', () => { aui.name = nm.value; });
      box.append(nm, h('div', { class: 'srow end' }, [h('button', { class: 'btn small', type: 'button', id: 'apilinkbtn', text: aui.link ? 'Cancel' : 'I already have a key', onclick: () => { aui.link = !aui.link; renderApi(); } }), h('button', { class: 'btn small primary', type: 'button', id: 'apicreate', text: 'Create API', onclick: createApi })]));
      if (aui.link) { const ki = h('input', { type: 'password', id: 'apilinkkey', placeholder: 'bean_… (the key you saved)', autocomplete: 'off', spellcheck: 'false' }); box.append(h('p', { class: 'snote', text: 'After a reinstall: paste the key you saved to get this install’s API and its ledger back.' }), ki, h('div', { class: 'srow end' }, [h('button', { class: 'btn small primary', type: 'button', id: 'apilink', text: 'Link', onclick: () => linkApi(ki.value) })])); }
      box.append(msg); box.append(advanced()); return;
    }
    // created
    const st = readStat();
    const online = st.online && now() - st.at < 60000;
    box.append(h('div', { class: 'apihead' }, [h('b', { text: api.name }), h('span', { class: 'pill ' + (!api.enabled ? '' : online ? 'on' : 'off'), id: 'apistate', text: !api.enabled ? 'paused' : online ? 'online' : st.errCode === 'invalid_api_key' || st.errCode === 'revoked' ? 'key rejected' : 'offline' })]));
    box.append(h('div', { class: 'kv' }, [h('span', { text: 'API key' }), h('code', { id: 'apihint', text: maskedKey() })]));
    box.append(h('div', { class: 'kv' }, [h('span', { text: 'Base URL' }), h('code', { text: A.effBase(api.base) + '/api/bean/v1' })]));
    box.append(h('div', { class: 'kv' }, [h('span', { text: 'Runs jobs' }), h('span', { text: runnerAlive() || ROLE === 'runner' ? 'in the background (no window needed)' : 'while this Bean window is open' })]));
    box.append(h('div', { class: 'kv' }, [h('span', { text: 'Capacity' }), h('span', { id: 'apicap', text: savedKeys().length + ' saved channel' + (savedKeys().length === 1 ? '' : 's') })]));
    if (st.job) box.append(h('p', { class: 'snote', text: `Running job ${st.job.id.slice(0, 8)}… ${st.job.done}/${st.job.total}` }));
    if (st.err) box.append(h('p', { class: 'snote bad', text: st.err }));
    if ((st.jobs || []).length) box.append(h('p', { class: 'snote', text: 'Recent jobs: ' + st.jobs.map((j) => j.id.slice(0, 6) + ' ' + (j.status === 'finished' ? 'done' : j.status) + (j.code ? ' (' + j.code + ')' : '')).join(' · ') }));
    box.append(h('div', { class: 'srow wrap' }, [
      h('button', { class: 'btn small', type: 'button', id: 'apitoggle', text: api.enabled ? 'Pause API' : 'Resume API', onclick: () => setApi({ enabled: !api.enabled }) }),
      (() => { const b = h('button', { class: 'btn small', type: 'button', id: 'apiregen', text: 'Regenerate key' }); confirm2(b, 'Replace the key?', regenApi); return b; })(),
      (() => { const b = h('button', { class: 'btn small danger', type: 'button', id: 'apirevoke', text: 'Revoke' }); confirm2(b, 'Revoke the API?', revokeApi); return b; })()]));
    box.append(msg); box.append(advanced());
  }
  function advanced() {
    const d = h('details', { class: 'adv' }); d.append(h('summary', { text: 'Advanced' }));
    const cur = A.effBase((S.api && S.api.base) || aui.base);
    const inp = h('input', { type: 'text', id: 'apibase', value: cur, 'aria-label': 'Server URL', spellcheck: 'false', disabled: S.api && S.api.token && !S.api.revoked ? '' : null }); inp.addEventListener('input', () => { aui.base = inp.value; });
    d.append(h('p', { class: 'snote', text: 'Server URL (https only; http only for this computer). Change it before you create the API.' }), inp); return d;
  }
  function readStat() { const a = S.stats && S.stats.runner && now() - S.stats.runner.at < 30000 ? S.stats.runner : null, b = S.stats && S.stats.popup && now() - S.stats.popup.at < 30000 ? S.stats.popup : null; return a || b || (S.stats && (S.stats.runner || S.stats.popup)) || { online: false, at: 0, err: '', jobs: [] }; }
  async function loadStats() { const v = await chrome.storage.local.get(['p9bn.apistat.popup', 'p9bn.apistat.runner']); S.stats = { popup: v['p9bn.apistat.popup'], runner: v['p9bn.apistat.runner'] }; }
  function say(m, kind) { aui.msg = m; aui.kind = kind || ''; renderApi(); }
  async function setApi(patch) { const next = Object.assign({}, S.api, patch); await sset(KK.api, next); S.api = next; mkClient(); renderApi(); if (patch.enabled) { pushConfig(true).catch(() => {}); } }
  async function createApi() {
    if (aui.busy) return; const name = (aui.name || '').trim();
    if (!/^[A-Za-z0-9][A-Za-z0-9 ._@#:/+-]{0,39}$/.test(name)) return say('Give it a name tag: 1–40 characters (letters, digits, space and . _ - @ # : / +).', 'bad');
    const base = A.validBase(aui.base || A.DEFAULT_BASE); if (!base) return say('The server URL must be https (or http on this computer).', 'bad');
    aui.busy = true; say('Creating…');
    try {
      const old = S.api && S.api.installId ? { installId: S.api.installId } : null; const idn = Object.assign(A.newIdentity(), old || {});
      const cl = new A.BeanApi({ base, getToken: () => '' }); const r = await cl.register(idn, name, VERSION);
      const rec = { enabled: true, installId: idn.installId, token: idn.token, name, hint: r.api_key_hint, base, created: now(), revoked: false };
      await sset(KK.api, rec); S.api = rec; mkClient(); S.key = r.api_key; aui.msg = 'API created. Copy the key now — it will not be shown again.'; aui.kind = 'ok';
      if (!S.ledReady) await ledgerLoad(); S.cfgAt = 0; renderApi();
      pushAll().catch(() => {}); pushConfig(true).catch(() => {});
    } catch (e) { say(e.code === 'install_exists' ? 'This install already has an API. Use Regenerate.' : clean(e), 'bad'); }
    finally { aui.busy = false; }
  }
  async function linkApi(key) {
    key = String(key || '').trim(); if (!/^bean_[A-Za-z0-9_-]{20,70}$/.test(key)) return say('That does not look like a Bean API key.', 'bad');
    const base = A.validBase(aui.base || A.DEFAULT_BASE); if (!base) return say('The server URL must be https (or http on this computer).', 'bad');
    say('Linking…');
    try {
      const idn = A.newIdentity(); const cl = new A.BeanApi({ base, getToken: () => '' }); const r = await cl.link(key, idn.token);
      const rec = { enabled: true, installId: r.install_id, token: idn.token, name: r.name, hint: r.api_key_hint, base, created: now(), revoked: false, linked: true };
      await sset(KK.api, rec); S.api = rec; mkClient(); aui.link = false; if (!S.ledReady) await ledgerLoad();
      let msg = 'Linked “' + r.name + '”.'; try { const x = await restoreFromServer(); msg += ` Ledger restored: ${x.added} entries.`; await pushAll(); } catch (e) { msg += ' (Ledger restore failed: ' + clean(e) + ')'; }
      S.cfgAt = 0; say(msg, 'ok'); pushConfig(true).catch(() => {});
    } catch (e) { say(clean(e), 'bad'); }
  }
  async function regenApi() {
    try { const r = await S.client.regenerate(); await setApi({ hint: r.api_key_hint }); S.key = r.api_key; aui.msg = 'New key created; the old one no longer works. Copy it now.'; aui.kind = 'ok'; renderApi(); } catch (e) { say(clean(e), 'bad'); }
  }
  async function revokeApi() {
    try { await S.client.revoke(false); const rec = Object.assign({}, S.api, { enabled: false, revoked: true, token: '', hint: '' }); await sset(KK.api, rec); S.api = rec; S.client = null; S.key = null; aui.msg = 'Revoked. The key stopped working and queued jobs were cancelled.'; aui.kind = 'ok'; renderApi(); } catch (e) { say(clean(e), 'bad'); }
  }

  // ================================================================ wiring
  function onStorage(c, area) {
    if (area !== 'local') return;
    if (c[KK.api]) { S.api = c[KK.api].newValue || null; mkClient(); S.cfgAt = 0; if (apiOn()) cfgSoon(); renderApi(); }
    if (c[KK.runner]) { S.runnerAt = (c[KK.runner].newValue || {}).at || 0; }
    if (c['p9bn.apistat.popup'] || c['p9bn.apistat.runner']) loadStats().then(renderApi);
    if (c[K.batch]) { const b = c[K.batch].newValue; if (b) recordFinal(b); }
    if (c[KK.vreq] && c[KK.vreq].newValue) onVpnReq(c[KK.vreq].newValue).catch(() => {});
    if (c[K.ytf] && apiOn()) cfgSoon();
    if (Object.keys(c).some((k) => k.indexOf('p9bn.chstale.') === 0)) loadChannelCache().then(() => { cfgSoon(); try { renderContainers(); renderPlan(); } catch (_) { /* popup only */ } }).catch(() => {});
    if (ROLE === 'runner') {
      if (c[K.settings]) { settings = c[K.settings].newValue && typeof c[K.settings].newValue === 'object' ? c[K.settings].newValue : {}; restoreSel(); cfgSoon(); (async () => { const old = ctrs; try { await loadContainers(); await loadChannelCache(); } catch (_) { /* keep what we have */ } if (!ctrs) ctrs = old; restoreSel(); cfgSoon(); })(); }          // the selection is applied at once; the container list is re-read afterwards (never lost if the read fails)
      if (Object.keys(c).some((k) => k.indexOf('p9bn.ch.') === 0)) loadChannelCache().then(() => { normalizeSel(); cfgSoon(); });
      if (c[KK.cmd] && c[KK.cmd].newValue && c[KK.cmd].newValue.id !== S.pendingCmd) { const q = c[KK.cmd].newValue; S.pendingCmd = q.id; ledDo(q.op, q.arg).then(() => sset(KK.cmdres, { id: q.id, ok: true, msg: q.op === 'clear' ? 'Ledger cleared.' : q.op === 'remove' ? 'Entry removed.' : q.op === 'remove-comment' ? 'Cleared all ' + (S.lastRemoved || 0) + ' mark(s) of this comment (and its “like sent” safety markers). Do not press “Restore from server” for this comment.' : q.op === 'remove-already' ? 'Cleared ' + (S.lastRemoved || 0) + ' “already liked” mark(s). The liked entries were kept.' : 'Pruned.' })).catch((e) => sset(KK.cmdres, { id: q.id, ok: false, msg: clean(e) })); }
    }
    if (c['p9bn.led.meta'] && S.ledReady && !(S.led.dirty && S.led.dirty.size) && !(ROLE === 'popup' ? executor() : true)) { clearTimeout(S.relT); S.relT = setTimeout(() => S.led.load().then(renderLedger), 600); }
  }
  async function init() {
    const v = await chrome.storage.local.get([KK.api, KK.runner, 'p9bn.apistat.popup', 'p9bn.apistat.runner']);
    S.api = v[KK.api] || null; S.runnerAt = (v[KK.runner] || {}).at || 0; mkClient(); await loadStats();
    await ledgerLoad(); chrome.storage.onChanged.addListener(onStorage);
    if (ROLE === 'runner') startRunner();
    // a run that finished while no page was watching (popup closed) is recorded now
    const b = await sget(K.batch); if (b) recordFinal(b);
    renderVpn(); renderLedger(); renderApi();
    setInterval(() => { sget(KK.vreq).then((rq) => { if (rq) return onVpnReq(rq); }).catch(() => {}); }, 4000);
    setInterval(() => { vpnSample().catch(() => {}); }, 1000);          // 1.1.7.1          // 1.1.5: a request whose storage event never arrived is still found
    setInterval(() => { if (!document.hidden || ROLE === 'runner') renderApi(); if (S.ledReady && executor() && S.led.stats().pending && apiOn()) mirror().catch(() => {}); }, 5000);
    if (apiOn()) { await loadContainers().catch(() => {}); restoreSel(); }
    apiLoop().catch(() => {});
    setInterval(() => { if (!S.loop) apiLoop().catch(() => {}); }, 3000);
    if (ROLE === 'popup') document.getElementById('sections').hidden = false;
    if (apiOn()) pushConfig(false).catch(() => {});
  }
  // 1.1.7: the server's running + queued jobs of this install, for the Queue panel (read-only; null when the API is off). Throws the ApiError (404 not_found = a server without the list).
  const apiJobs = async () => (apiOn() && S.client ? S.client.jobs() : null);
  self.B11 = { apiJobs, apiOn, vpnUp, vpnPeek, runIsOver, runOverNow, toResult, isFinalIt, writeStat, ROLE, rotateNow, checkNow, init, prepare, skipInfo, decorate, used: ledUsed, recordFinal, renderVpn, renderLedger, renderApi, cfgSoon, savedKeys, bad: badCh, ledDo, S, executor, runnerAlive };
})();
