// Bean 1.1.7: the Orders section of the popup. Three collapsible panels (Running / Queue / History) over the one persistent queue (p9bn.orders, written only by the page that runs it).
// This page only READS the queue and sends requests (cancel / move / retry / clear history) through B17.request. The collapse state is remembered in p9bn.ui (written only here).
// Text is always set with textContent (link ids, channel names and server messages are data, never markup).
(() => {
  'use strict';
  if (typeof ROLE === 'undefined' || ROLE !== 'popup' || !document.getElementById('orders')) return;
  const root = document.getElementById('orders');
  const STATE = { queued: 'Waiting', running: 'Running', waiting: 'Paused', done: 'Done', partial: 'Partly done', failed: 'Failed', stopped: 'Stopped', cancelled: 'Cancelled' };
  const PANELS = [['run', 'Running', true], ['queue', 'Queue', true], ['hist', 'History', false]];
  let ui = { run: true, queue: true, hist: false }, last = '';
  const AJ = self.P9BEAN_APIJOBS;
  let srv = { rows: [], err: '' };                         // 1.1.7: the API server's running + queued jobs of this install (read-only; refreshed every AJ.REFRESH_MS while the popup is open)
  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  const planned = (o) => (o.links || []).reduce((n, l) => n + (l.quantity != null ? l.quantity : ((o.res && o.res[l.vid + '|' + l.lc]) || []).length), 0);
  const doneN = (o) => (o.carry ? o.carry.liked + o.carry.already : 0);
  const ago = (t) => { if (!t) return ''; const d = new Date(t); return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); };
  const srcName = (o) => (o.src === 'api' ? 'API' : 'popup');
  const linkWord = (o) => `${o.links.length} link${o.links.length === 1 ? '' : 's'}`;
  async function send(req, btn) {
    if (btn) btn.disabled = true;
    const r = await B17.request(req, 8000).catch(() => ({ ok: false, message: 'No answer from the queue.' }));
    if (r && r.message && !r.ok) setMsg(r.message, 'warn');
    await pull(); if (btn) btn.disabled = false;
  }
  function btn(label, title, fn) { const b = el('button', 'lnk', label); b.type = 'button'; b.title = title; b.addEventListener('click', () => fn(b)); return b; }
  function row(o, kind, i, n) {
    const r = el('div', 'orow ' + kind), top = el('div', 'otop'), meta = el('div', 'ometa hint');
    const head = `#${o.seq} · ${srcName(o)}`;
    if (kind === 'run') {
      top.append(el('span', 'otitle', `${head} · ${STATE[o.state] || o.state}`), el('span', 'ocount', `${doneN(o)} of ${planned(o) || '…'} likes`));
      meta.textContent = `${linkWord(o)}${o.state === 'waiting' && o.waitWhy ? ' · ' + o.waitWhy : ''}${o.startedAt ? ' · started ' + ago(o.startedAt) : ''}${o.carry && o.carry.failed ? ' · ' + o.carry.failed + ' failed' : ''}${o.cancelReq ? ' · stopping…' : ''}`;
      const bar = el('div', 'obar'), fill = el('i'); const p = planned(o); fill.style.width = (p ? Math.min(100, Math.round(100 * doneN(o) / p)) : 0) + '%'; bar.append(fill);
      r.append(top, bar, meta);
      const act = el('div', 'oact'); act.append(btn('Cancel order', 'Stop this order now (likes already given stay)', (b) => send({ op: 'cancel', oid: o.id }, b))); r.append(act);
    } else if (kind === 'queue') {
      top.append(el('span', 'otitle', `${head}`), el('span', 'ocount', `${planned(o)} like${planned(o) === 1 ? '' : 's'}`));
      meta.textContent = `${linkWord(o)} · waiting${i === 0 && !n.running ? ' (next)' : ''}${o.waitWhy ? ' · ' + o.waitWhy : ''}`;
      r.append(top, meta);
      const act = el('div', 'oact');
      if (i > 0) act.append(btn('Up', 'Run earlier', (b) => send({ op: 'move', oid: o.id, dir: -1 }, b)));
      if (i < n.last) act.append(btn('Down', 'Run later', (b) => send({ op: 'move', oid: o.id, dir: 1 }, b)));
      act.append(btn('Cancel', 'Take it out of the queue (nothing was liked)', (b) => send({ op: 'cancel', oid: o.id }, b))); r.append(act);
    } else {
      const c = o.counts || {};
      top.append(el('span', 'otitle', `${head} · ${STATE[o.state] || o.state}`), el('span', 'ocount', `${(c.liked || 0) + (c.already || 0)} of ${c.total != null ? c.total : planned(o)}`));
      const bits = [linkWord(o), ago(o.finishedAt)]; if (c.failed) bits.push(c.failed + ' failed'); if (c.skipped) bits.push(c.skipped + ' not tried');
      meta.textContent = bits.filter(Boolean).join(' · ');
      r.append(top, meta);
      if (o.err && o.err.message) r.append(el('div', 'oerr', o.err.message));
      for (const sf of o.shortfall || []) r.append(el('div', 'oerr', `Link ${sf.n}: ${sf.got} of ${sf.want} — no unused channel was left for the rest.`));
      if (['partial', 'failed', 'stopped'].includes(o.state) && (c.failed || c.skipped || (o.shortfall || []).length)) { const act = el('div', 'oact'); act.append(btn('Retry the rest', 'A new order for the likes that did not happen (a channel that already liked is never used again)', (b) => send({ op: 'retry', oid: o.id }, b))); r.append(act); }
    }
    return r;
  }
  // one API-server job: place in line + status, the likes asked, when it was created (WAT), the caller's note, and its links as plain text
  function srvRow(j) {
    const r = el('div', 'orow srv'), top = el('div', 'otop'), meta = el('div', 'ometa hint');
    top.append(el('span', 'otitle', `${j.placeLabel} \u00b7 ${j.statusLabel}`), el('span', 'ocount', `${j.likes} like${j.likes === 1 ? '' : 's'}`));
    meta.textContent = ['API server', j.created ? 'created ' + j.created : '', j.note, j.picked ? 'Bean has it' : ''].filter(Boolean).join(' \u00b7 ');
    r.append(top, meta);
    j.links.slice(0, 3).forEach((l) => { const d = el('div', 'hint olink', `${l.label} \u00b7 ${l.likes} like${l.likes === 1 ? '' : 's'}`); if (l.tip) d.title = l.tip; r.append(d); });
    if (j.links.length > 3) r.append(el('div', 'hint olink', `+ ${j.links.length - 3} more link${j.links.length - 3 === 1 ? '' : 's'}`));
    return r;
  }
  function draw(d) {
    const q = (d && d.queue) || [], h = (d && d.hist) || [];
    const sig = JSON.stringify([ui, q.map((o) => [o.id, o.state, o.waitWhy, o.carry && o.carry.liked, o.carry && o.carry.already, o.carry && o.carry.failed, o.cancelReq, o.res && Object.keys(o.res).length]), h.map((o) => [o.id, o.state, o.finishedAt]), AJ ? AJ.signature(srv.rows) : '', srv.err]);
    if (sig === last) return; last = sig;
    const run = q.filter((o) => o.state === 'running' || o.state === 'waiting'), wait = q.filter((o) => !(o.state === 'running' || o.state === 'waiting'));
    root.hidden = !q.length && !h.length && !srv.rows.length;
    root.textContent = '';
    const head = el('div', 'ohead', 'Orders'); root.append(head);
    const lists = { run, queue: wait, hist: h };
    for (const [k, title] of PANELS) {
      const det = el('details', 'opanel'); det.dataset.k = k; det.open = !!ui[k];
      const sum = el('summary', '', title); sum.append(el('span', 'hint', ` ${(lists[k].length + (k === 'queue' ? srv.rows.length : 0)) || ''}`)); det.append(sum);
      const body = el('div', 'obody');
      if (!lists[k].length && !(k === 'queue' && srv.rows.length)) body.append(el('div', 'hint oempty', k === 'run' ? 'Nothing is running.' : k === 'queue' ? 'Nothing is waiting.' : 'No finished orders yet.'));
      else lists[k].forEach((o, i) => body.append(row(o, k, i, { running: run.length > 0, last: wait.length - 1 })));
      if (k === 'queue' && (srv.rows.length || srv.err)) {                       // 1.1.7: what the API server holds for this install (the running job and the waiting ones, in the order it runs them)
        const box = el('div', 'srvbox'); box.append(el('div', 'hint srvhead', `API server \u00b7 ${srv.rows.length ? srv.rows.length + ' job' + (srv.rows.length === 1 ? '' : 's') : 'no jobs'}`));
        srv.rows.forEach((j) => box.append(srvRow(j)));
        if (srv.err) box.append(el('div', 'hint oempty srverr', srv.err));
        body.append(box);
      }
      if (k === 'hist' && h.length) { const act = el('div', 'oact'); act.append(btn('Clear history', 'Remove the finished orders from this list (the ledger keeps who liked what)', (b) => send({ op: 'clear-history' }, b))); body.append(act); }
      det.append(body);
      det.addEventListener('toggle', () => { if (!!ui[k] === det.open) return; ui[k] = det.open; chrome.storage.local.set({ [P9BEAN_ORD.UI]: ui }).catch(() => {}); last = ''; });
      root.append(det);
    }
  }
  async function pull() {
    try { const d = await sget(P9BEAN_ORD.KEY); ordData = d || null; draw(d); if (typeof renderPossible === 'function') { clearTimeout(self.__op); self.__op = setTimeout(() => { try { refreshButtons(); } catch (_) { /* ignore */ } }, 400); } } catch (_) { /* storage not ready */ }
  }
  // the server list: only when the API is on; a failed refresh keeps the last list and says so in plain words (a server without the list answers 404)
  async function pullSrv() {
    if (!AJ || typeof B11 === 'undefined' || !B11.apiOn || !B11.apiOn()) { if (srv.rows.length || srv.err) { srv = { rows: [], err: '' }; last = ''; pull(); } return; }
    try {
      const r = await B11.apiJobs(); const od = ordData || {}; const mine = new Set((od.queue || []).concat(od.hist || []).map((o) => o.jobId).filter(Boolean));
      srv = { rows: AJ.view(r, { mine }), err: '' };
    } catch (e) {
      srv = { rows: srv.rows, err: e && (e.status === 404 || e.code === 'not_found') ? 'This server cannot list its jobs yet.' : e && e.status === 403 ? 'The API was revoked.' : 'Could not reach the server: showing the last list.' };
    }
    last = ''; pull();
  }
  self.renderOrders = () => { last = ''; pull(); pullSrv(); };
  self.pullApiJobs = pullSrv;
  (async () => {
    try { const u = await sget(P9BEAN_ORD.UI); if (u && typeof u === 'object') ui = Object.assign(ui, { run: !!u.run, queue: !!u.queue, hist: !!u.hist }); } catch (_) { /* defaults */ }
    await pull();
    chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && c[P9BEAN_ORD.KEY]) pull(); });
    pullSrv(); setTimeout(pullSrv, 2500); setInterval(() => { if (!document.hidden) pullSrv(); }, AJ ? AJ.REFRESH_MS : 10000);          // 1.1.7: the server's jobs, every 10 s while the popup is open
    setInterval(pull, 3000);                                 // the storage mirror can be late: a slow poll keeps the list true
  })();
})();
