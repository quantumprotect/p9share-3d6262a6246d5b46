# Bean API (Bean 1.1.0)

Submit comment-like jobs to **one specific Bean install** over HTTPS, and read the results.

> **One key = one install.** An API key is created inside a Bean install ("Create API" + a name tag) and drives **only that install** —
> its saved containers/channels, its VPN locations, its ledger. A key can never read, cancel or queue anything on another install.
> If you run Bean on three PCs you create three APIs (three names, three keys) and talk to each one separately.

Base URL: `https://api10.norhartpro.com/api/bean/v1`

Everything is JSON (`Content-Type: application/json`), UTF-8. Times are ISO-8601 UTC (`2026-10-30T19:04:11Z`).

## 1. How it works (30 seconds)

```
your app ──HTTPS──▶ api10.norhartpro.com/api/bean/v1/… ◀──long-poll── Bean (Panel 9 on the PC)
   POST /jobs  ─▶ queued ───────────────────────────────▶ Bean claims it, likes from its saved channels, reports each like
   GET  /jobs/<id> ◀──────────── per-like results ◀───────
```

* Bean connects **outbound** to the server (no inbound port, no tunnel to the PC). The server only queues.
* Bean runs a job with the containers/channels, pace and VPN locations **saved in Bean**, and the **ledger**: a channel is never used twice on the same comment.
* Jobs only run while **YouTube Focus “Comments only” is on** in Panel 9. **1.1.7:** when it is off (or ExpressVPN is unavailable) the job is no longer failed at once: it joins Bean's queue and **waits** (status stays `queued`/`running`, Bean retries after 1, 2, 5, 10, 15 and 15 minutes); only after the sixth failed try does it end `failed` with `focus_off` / `vpn_unavailable`. Cancelling the job (`POST /jobs/{id}/cancel`) takes it out of the queue.
* The PC must be on, Panel 9 running (with the Bean-VPN-bridge release of Panel 9 Bean runs jobs in a hidden background page; on an older Panel 9 Bean's window must stay open).
  `GET /install` tells you whether the install is `online`.

## 2. Authentication

```
Authorization: Bearer <your-bean-key>
```
(`X-API-Key: bean_…` is accepted too.) The key is shown **once** in Bean when you press *Create API*; afterwards Bean shows it masked (`bean_AbCd…wXyZ`).
*Regenerate* replaces it (the old key stops working immediately); *Revoke* kills it. Only a SHA-256 hash is stored on the server. Keep the key in a secret store, never in a repository or a log.

## 3. Concepts

**Comment link** — any YouTube link that carries a comment id: `https://www.youtube.com/watch?v=VIDEOID&lc=COMMENTID`,
`https://youtu.be/VIDEOID?lc=COMMENTID`, `…/shorts/VIDEOID?lc=…`. A **reply** has an id `PARENT.REPLY` (the `lc` value of a reply link); a reply is its own comment.
A link without `lc=` is rejected (`invalid_link`). Parameters other than `v`/`lc` are ignored; the same video+comment given twice in one request → `duplicate_link`.

**Channel** — a YouTube channel (a profile) that Bean can like from; the install's *saved channels* are the containers/channels ticked in Bean.
One like = one channel.

**Capacity of a link** = `channels_saved − channels_used_on_this_comment − reserved_by_queued_jobs`.
* `channels_used` counts saved channels the ledger already recorded as used on that exact comment (liked it, or found it already liked). A channel is never used twice on a comment, ever.
* `reserved_by_queued_jobs` are likes promised to jobs that are still queued/running for the same comment, so two jobs never promise the same channel twice.
* `max_likes` is what you can still ask for.

**Quantity** — likes wanted for a link (integer 1–200).
* **omitted → all available** (`max_likes` at submit time; if that is 0 the request fails with `no_capacity`).
* above capacity → **rejected** with `422 quantity_exceeds_capacity` (default), or **clamped** to the maximum when you send `"over_quantity": "clamp"` (the link then shows `"clamped": true`).

## 4. Endpoints

### `GET /health` (no auth)
```json
{"ok": true, "service": "bean-api", "version": 1, "time": "2026-10-30T19:04:11Z"}
```

### `GET /install` — which install this key drives
```json
{
  "install_id": "bi_hGuemZ7-0Y2ebLjo0N6y4wvL", "name": "studio-pc",
  "online": true, "last_seen_at": "2026-10-30T19:04:09Z", "seconds_since_seen": 2,
  "bean_version": "1.1.0", "created_at": "2026-10-30T18:00:00Z",
  "api_key_hint": "bean_AbCd…wXyZ", "key_created_at": "2026-10-30T18:00:00Z",
  "queue": {"queued": 0, "running": 1},
  "saved_channels": 4, "youtube_focus": "on",
  "vpn": {"enabled": true, "locations": 3}, "ledger_entries": 211,
  "config_updated_at": "2026-10-30T19:03:55Z"
}
```
`online` = Bean polled within the last ~45 s. `youtube_focus`: `on` | `off` | `unknown` (unknown = no YouTube tab answered; jobs still try). If `online` is false jobs queue and wait (up to 24 h, then `expired`).

### `GET /capacity?link=<url-encoded link>&link=…`  or  `POST /capacity {"links": [...]}`
```json
{"install_id": "bi_…", "name": "studio-pc", "online": true, "as_of": "2026-10-30T19:03:55Z",
 "capacity": [{
   "vid": "dQw4w9WgXcQ", "lc": "UgxABC…", "link": "https://www.youtube.com/watch?v=dQw4w9WgXcQ&lc=UgxABC…", "is_reply": false,
   "channels_saved": 4, "channels_used": 1, "reserved_by_queued_jobs": 0, "max_likes": 3}]}
```
Up to 20 links. `as_of` is when Bean last synced its channel list (the answer is as fresh as that).

#### Live "possible likes" — what YT Panel should show (1.1.6)
Use these numbers instead of a fixed 1–200:

| Where | Field | Meaning |
|---|---|---|
| `GET /install` | `saved_channels` | **Global**: how many channels Bean can like from right now (no link needed). |
| `GET/POST /capacity` (per link) | `channels_saved` | The same number, as the server saw it when it answered. |
| | `channels_used` | Of those, how many already liked **this** comment (the permanent ledger). Cleared marks stop counting. |
| | `reserved_by_queued_jobs` | Likes already promised to queued/running API jobs for this comment (so two buyers cannot take the same slot). |
| | **`max_likes`** | **What you may order for this comment now** = `channels_saved − channels_used − reserved_by_queued_jobs` (never below 0). Use it as the upper limit of the quantity box. |
| top level | `as_of` | When Bean last synced its channel list (ISO, UTC). Bean pushes within ~2 s of a change; if it is older than a few minutes, treat the number as a guess. |
| top level | `online` | Bean polled within ~45 s. When false, jobs wait in the queue (up to 24 h) — show "offline". |

What changes the numbers (all within seconds while Bean is online):
* **Channel selection** in Bean (ticking or unticking a container or channel) → `channels_saved` follows.
* **Channels Bean cannot use are not counted**: a ticked channel that is no longer in its account's channel list (renamed, deleted, signed out), or that the last run could not switch to (`switch-failed`), is left out until the owner refreshes the channels in Bean or a like from it succeeds again (flags also expire after 24 h). So `max_likes` never promises a like that Bean already knows it cannot make.
* **The ledger**: every like or confirmed "already liked" raises `channels_used`; **clearing marks in Bean** (*Ledger → Clear all marks for this comment*, *Clear only the "already liked" marks*, or *Clear ledger*) removes them from the server copy too (`POST /agent/ledger/remove`, needs a server with that endpoint — `server-patch-ledger-remove.diff`). On an older server the server copy keeps them and `max_likes` stays lower than Bean shows.
* **Server jobs in the popup (1.1.7, read-only)**: Bean's Queue panel lists this install's running and queued server jobs (link or video, likes asked, status, created time in WAT, place in line, the caller's `note`) through `GET /api/bean/agent/jobs` (install-token auth, scoped to the install, no keys, tokens or hashes in the answer; `server-patch-agent-jobs.diff`, NOT deployed). A server without it answers 404 and the panel simply shows nothing for it. It is refreshed every 10 s while the popup is open.
* Cached answers: do not cache `/capacity` for longer than ~10 s; it is cheap and always computed live from the stored config and ledger.

Bean's own "Possible likes" panel uses the same rule, so what Oluchi sees in Bean equals `max_likes`.

### `POST /jobs` — submit a job
Request:
```json
{
  "links": [
    {"link": "https://www.youtube.com/watch?v=dQw4w9WgXcQ&lc=UgxABC…", "quantity": 3},
    "https://youtu.be/9bZkp7q19f0?lc=UgxDEF….REPLY1"
  ],
  "over_quantity": "reject",
  "note": "campaign 12",
  "idempotency_key": "order-8841"
}
```
* `links` — 1–20 items: a string, or `{"link": "...", "quantity": n}`. (`{"link": "..."}` at top level is accepted for one link.)
* `over_quantity` — `"reject"` (default) or `"clamp"`.
* `note` — free text ≤120 chars, echoed back. `idempotency_key` (or header `Idempotency-Key`) — resubmitting the same key returns the original job (HTTP 200, `"idempotent_replay": true`) instead of a duplicate.

Response `202 Accepted` (+ `Location: /api/bean/v1/jobs/<id>`):
```json
{
  "job_id": "job_Qnkfw9fzFV_AQvyL", "status": "queued",
  "created_at": "…Z", "started_at": null, "finished_at": null, "expires_at": "…Z",
  "note": "campaign 12",
  "links": [
    {"n": 1, "link": "https://www.youtube.com/watch?v=dQw4w9WgXcQ&lc=UgxABC…", "vid": "dQw4w9WgXcQ", "comment_id": "UgxABC…", "requested": 3, "accepted": 3, "clamped": false, "max_at_submit": 4},
    {"n": 2, "link": "…", "vid": "9bZkp7q19f0", "comment_id": "UgxDEF….REPLY1", "requested": null, "accepted": 4, "clamped": false, "max_at_submit": 4}
  ],
  "progress": {"total_likes": 7, "done": 0, "liked": 0, "already_liked": 0, "failed": 0, "skipped": 0},
  "results": [], "error": null, "warnings": [], "cancel_requested": false, "install_online": true
}
```
All-or-nothing: if any link is invalid / over capacity (reject mode) nothing is queued and you get a 4xx with details (see §6).

### `GET /jobs/{job_id}` — status + per-like results
```json
{
  "job_id": "job_Qnkfw9fzFV_AQvyL", "status": "running",
  "created_at": "…Z", "started_at": "…Z", "finished_at": null, "expires_at": "…Z", "note": null,
  "progress": {"total_likes": 7, "done": 3, "liked": 2, "already_liked": 0, "failed": 1, "skipped": 0},
  "links": [ … as above … ],
  "results": [
    {"n": 1, "seq": 0, "status": "liked",  "code": "", "message": "", "container": "Channel A", "channel": "Alice", "handle": "@alice", "at": 1761850000.3,
     "vpn": {"location": "UK - London", "ip_changed": true, "bypassed": false}},
    {"n": 1, "seq": 1, "status": "skipped", "code": "ledger-used", "message": "Channel already used on this comment", "container": "Channel A", "channel": "Alice Cooking", "handle": "", "at": 1761850004.1},
    {"n": 1, "seq": 2, "status": "failed", "code": "vpn-stuck", "message": "VPN stayed on “connecting” — not liked", "container": "Channel B", "channel": "Bob", "handle": "@bob", "at": 1761850020.9}
  ],
  "error": null, "warnings": [], "cancel_requested": false
}
```
`results[]` is one row per like attempt (`n` = link number, `seq` = attempt number within the link). `status` ∈ `liked`, `already` (that channel had already liked it — not clicked), `failed`, `skipped`.
`code` is Bean's reason for non-liked rows, e.g. `ledger-used`, `not-signed-in`, `not-found`, `comments-off`, `unavailable`, `click-failed`, `switch-failed`, `open-failed`, `interrupted`, `stopped`, `not_started`, `no_capacity`, `vpn-failed`, `vpn-stuck`, `vpn-noip`, `vpn-unavailable`, `vpn-bypass`.
`vpn` appears when the install rotates ExpressVPN locations; `bypassed: true` means that container is set to *Outside VPN*, so the like was made from its own address (a warning is also added to `warnings[]`). `ip_changed` is `true` when Bean read the exit address before and after the switch and they differ, or `null` when there was no readable exit address to compare with before the switch (the new exit address was still confirmed non-empty and a like is never made after a failed or unconfirmed switch); it is never `false` on a liked item.
Results are appended as likes happen — poll to watch progress. Likes are never retried automatically (a retry could un-like).

### `GET /jobs?status=running&limit=20` — recent jobs (newest first, ≤100)
```json
{"jobs": [{"job_id": "job_…", "status": "completed", "created_at": "…Z", "finished_at": "…Z", "progress": {…}, "error": null, "warnings": [], "note": null, "expires_at": "…Z", "started_at": "…Z", "cancel_requested": false}]}
```

### `POST /jobs/{job_id}/cancel` — optional cancel
Queued → `cancelled` immediately. Running → `"cancel_requested": true`; Bean stops after the like in progress, likes already made stay made, the rest are not done, final status `cancelled`.
A finished job answers `200` with a `message` saying there was nothing to cancel.

## 5. Job lifecycle

| status | meaning |
|---|---|
| `queued` | waiting for Bean to poll (install offline, or busy with an earlier job — jobs of one install run **one at a time, in order**) |
| `running` | Bean claimed it and is liking |
| `completed` | every requested like was made (`liked` + `already` = total) |
| `partial` | finished but some likes did not happen (see `results[]` / `error`) |
| `failed` | nothing could be done — see `error` (e.g. `focus_off`) — or Bean vanished mid-job without results |
| `cancelled` | you cancelled it |
| `expired` | nobody claimed it for 24 h (install offline) |

**Pausing (Bean 1.1.4).** The person at the PC can press *Pause* in Bean. A paused install keeps its job in `running` (the like in progress finishes first; then nothing new happens: no page load, VPN change or click) and `progress` does not move until they press *Resume* (the job then carries on from the next item). The job is reported as `running` with no extra field today (the server has no pause field yet); if progress stays still for a long time on a `running` job, the install may be paused. A run that stays paused for 6 hours is stopped by Bean and the job ends like any stopped job (`stopped`, likes already made are listed).

`error` on a job: `{ "code": "...", "message": "..." }` — `focus_off` (YouTube Focus “Comments only” is off: switch it on in Panel 9 and resubmit), `focus_missing`, `vpn_unavailable` (ExpressVPN needs Panel 9 run as administrator and the ExpressVPN app running and signed in),
`no_channels_saved`, `no_capacity` (the ledger/channels changed since you submitted), `no_bridge` (Panel 9 too old), `busy`, `interrupted`, `agent_lost` (Panel 9 closed or offline mid-job; likes already made are listed), `stopped`, `internal`.
Finished jobs and their results are kept **7 days**, then deleted (`404 job_not_found`).

## 6. Errors

HTTP status + `{"error": {"code": "...", "message": "...", "details": {…}}}`.

| HTTP | code | when |
|---|---|---|
| 400 | `invalid_json`, `invalid_request`, `invalid_link`, `duplicate_link`, `too_many_links`, `invalid_quantity` | malformed request (`details.index` = which link) |
| 401 | `invalid_api_key` | missing / wrong / revoked / replaced key |
| 404 | `job_not_found`, `not_found` | unknown job (or a job of another install), unknown route |
| 409 | `no_channels_saved` | the Bean install has no channels selected yet |
| 413 | `payload_too_large` | body > 1 MB |
| 422 | `quantity_exceeds_capacity` | a quantity is above `max_likes` (use `over_quantity: "clamp"`); `details.problems[]` lists `{n, link, requested, max_likes}` |
| 422 | `no_capacity` | a link has no unused channel left; nothing queued |
| 429 | `rate_limited`, `queue_full` | slow down (see `Retry-After`); ≥25 queued jobs |
| 403 | `install_revoked` | (Bean-side) the API was revoked |

## 7. Rate limits and polling

* **120 requests/min per key**, **10 job submissions/min per install**, **25 queued jobs per install**, 20 links and 200 likes per link per request. Headers `X-RateLimit-Limit`, `X-RateLimit-Remaining`; on `429` honour `Retry-After` (seconds).
* Poll `GET /jobs/{id}` every **5 s** while `running`, every **15–30 s** while `queued`; stop at `completed|partial|failed|cancelled|expired`. Likes are paced by Bean (2–10 s each by the pace saved in Bean, longer between channels/containers), so a 50-like job takes minutes — do not poll faster than once per 3 s.
* Ask `/capacity` before submitting if you need to size a job; submit with `over_quantity: "clamp"` to take whatever is left.
* Use `idempotency_key` when your caller may retry a POST.

## 8. Snippets

### curl
```bash
export BEAN_KEY='bean_…'            # from Bean → API → Create API (shown once)
B=https://api10.norhartpro.com/api/bean/v1
curl -s $B/install  -H "Authorization: Bearer $BEAN_KEY"
curl -s "$B/capacity?link=$(python3 -c 'import urllib.parse,sys;print(urllib.parse.quote(sys.argv[1]))' 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&lc=UgxABC')" -H "Authorization: Bearer $BEAN_KEY"
curl -s -X POST $B/jobs -H "Authorization: Bearer $BEAN_KEY" -H 'Content-Type: application/json' \
  -d '{"links":[{"link":"https://www.youtube.com/watch?v=dQw4w9WgXcQ&lc=UgxABC","quantity":3}],"over_quantity":"clamp"}'
curl -s $B/jobs/job_XXXX -H "Authorization: Bearer $BEAN_KEY"
curl -s -X POST $B/jobs/job_XXXX/cancel -H "Authorization: Bearer $BEAN_KEY"
```

### JavaScript (Node 18+ / browser)
```js
const B = 'https://api10.norhartpro.com/api/bean/v1', KEY = process.env.BEAN_KEY;
async function bean(path, body) {
  const r = await fetch(B + path, { method: body ? 'POST' : 'GET', headers: { Authorization: 'Bearer ' + KEY, 'Content-Type': 'application/json' }, body: body && JSON.stringify(body) });
  const j = await r.json();
  if (!r.ok) { const e = new Error(j.error.code + ': ' + j.error.message); e.code = j.error.code; e.details = j.error.details; throw e; }
  return j;
}
const job = await bean('/jobs', { links: [{ link: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&lc=UgxABC', quantity: 3 }], over_quantity: 'clamp', idempotency_key: 'order-8841' });
let j = job;
while (['queued', 'running'].includes(j.status)) { await new Promise((r) => setTimeout(r, j.status === 'running' ? 5000 : 15000)); j = await bean('/jobs/' + job.job_id); }
console.log(j.status, j.progress, j.results.map((x) => [x.status, x.channel, x.code]));
```

### Python 3 (requests)
```python
import os, time, requests
B = "https://api10.norhartpro.com/api/bean/v1"
H = {"Authorization": "Bearer " + os.environ["BEAN_KEY"]}

def bean(method, path, **kw):
    r = requests.request(method, B + path, headers=H, timeout=30, **kw)
    j = r.json()
    if not r.ok:
        raise RuntimeError(f'{j["error"]["code"]}: {j["error"]["message"]}')
    return j

job = bean("POST", "/jobs", json={"links": [{"link": "https://www.youtube.com/watch?v=dQw4w9WgXcQ&lc=UgxABC", "quantity": 3}],
                                   "over_quantity": "clamp", "idempotency_key": "order-8841"})
while job["status"] in ("queued", "running"):
    time.sleep(5 if job["status"] == "running" else 15)
    job = bean("GET", "/jobs/" + job["job_id"])
print(job["status"], job["progress"])
for x in job["results"]:
    print(x["n"], x["status"], x["channel"], x["code"])
```

## 9. Notes for integrators

* Check `GET /install` first: `online`, `youtube_focus` and `saved_channels` tell you whether a job can run now.
* A like only counts once Bean saw it registered on YouTube (`liked`); `already` means the channel had already liked that comment.
* VPN: when the install has ExpressVPN locations saved, Bean switches to the next location before every like and only likes after it verified the exit address changed. A failed switch means **no like** for that item (`vpn-failed` / `vpn-stuck` / `vpn-noip`).
* Reinstalling Bean: the ledger is mirrored to the server; linking the saved key (*Bean → API → I already have a key*) restores the same install and its ledger.
* Tabs: Bean never has more than one of its own tabs open while it works through a job (containers are processed one after another and each tab is closed before the next one opens).
* No webhooks: poll. The API never exposes YouTube sessions, cookies, container names beyond what is in `results[]`, or any credential.
