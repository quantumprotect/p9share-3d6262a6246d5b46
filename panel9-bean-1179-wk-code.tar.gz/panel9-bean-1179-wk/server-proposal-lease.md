# Proposal (NOT applied, needs Oluchi's approval): stop renewing a running job's lease on polls

Today `_claim()` (bean_api.py ~l.708) renews `lease_until` of the running job on EVERY poll. A Bean that polls but no longer reports (the 09:38 incident: local run kept liking, nothing reported) therefore keeps the job `running` for ever and, because `_claim` hands out one job per install, blocks the whole queue.

Proposed change (server, small):
1. `_claim()` no longer touches `lease_until` of the running job on a poll. The lease is renewed only by `a_report` (it already does, ~l.750) and by an explicit heartbeat: a report with `state: "running"` and no results.
2. Bean sends that heartbeat every 60 s while it has a live local run for the job (ext17 `apiGuard` already runs on its own timer; one extra `client.report(job, {state:'running', results: []})`). Without it a long VPN rotation + page load stretch (>2 min between results) would expire a healthy job.
3. Raise `lease_s` for a running job to ~10 min (silent = Bean is gone). Housekeeping then does what it already does (re-queue with `attempts+1`, results kept), so a dead Bean frees the queue in ~10 min instead of never.
4. 1.1.7.1 clients already reconcile (finish re-sent, orphan reported `interrupted`), so the change is safe for them; older clients keep working as long as they report per result.

Risk: a Bean that is alive but stuck for >10 min would lose the job (it is re-queued, the already-reported results stay; the 1.1.7.1 ledger prevents a second like from the same channel).
